<?php
/*
ISK-NG Lite 用の端末一覧（閲覧専用）。いま開いている大会に接続している端末だけを表示する。
IskDevices テーブルに記録されている情報を表示するだけで、端末への指示や設定変更は行わない。
サーバー内の全端末の一覧と、端末コードの変更・端末の削除は AllDevices.php で行う。
- 最終通信時刻（端末からの API 呼び出しのたびに Api/ISK-NG/index.php が更新する。UTC で記録される）
- アプリ種別とバージョン（ハンドシェイク時に Api/ISK-NG/v1/handshake.php が記録する）
- 選択中の的（端末で的を選んだ時に Api/ISK-NG/v1/manual.php が記録する）
- 予選の的では、入力中の距離（前半/後半）とエンド。Lite の端末は距離をサーバーに伝えないため、
  その的の選手の点数（Qualifications）がどの距離の何エンド目まで入っているかから判断する
- バッテリー残量（アプリが送ってきた場合のみ。マイナス値は充電中）

変更履歴:
2026/11/10 サーバー全体の一覧（AllDevices.php）とは、表の行の右端のタブ（liteDevTabs）で切り替える
2026/09/25 コード変更・削除を AllDevices.php（サーバー内の全端末）へ移し、共通部分を Lib.php へ切り出し
2026/09/25 端末コードの変更と端末の削除を追加
2026/09/24 予選の的に入力中の距離（前半/後半）とエンドを表示
2026/09/24 「途絶」を「切断」に変更、列見出しクリックで並び替え、最終通信を大会のタイムゾーンで表示
2026/09/24 初版
*/
require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php
require_once('Common/Lib/CommonLib.php');
require_once($CFG->DOCUMENT_PATH . 'Api/ISK-NG/config.php');
require_once(__DIR__ . '/Lib.php');

CheckTourSession(true);
if(($_SESSION['UseApi']??'') != ISK_NG_LITE_CODE) {
	CD_redirect($CFG->ROOT_DIR);
}
checkFullACL(AclISKServer, 'iskUser', AclReadOnly);
$CanSeeAll = hasFullACL(AclISKServer, 'iskManagement', AclReadOnly);

$ToId = intval($_SESSION['TourId']);

$NumDist = '';
$q = safe_r_sql("select ToNumDist from Tournament where ToId=$ToId");
if($r = safe_fetch($q)) {
	$NumDist = strval($r->ToNumDist);
}
$LocalTz = liteDevLocalTz($ToId);
$TzLabel = 'UTC' . (new DateTime('now', $LocalTz))->format('P');

$SessionNames = [];
$q = safe_r_sql("select SesOrder, SesName from Session where SesTournament=$ToId and SesType='Q'");
while($r = safe_fetch($q)) {
	$SessionNames[$r->SesOrder] = $r->SesName;
}

$Devices = [];
$Versions = [];
$q = safe_r_sql("select IskDvDevice, IskDvCode, IskDvAppVersion, IskDvVersion, IskDvSchedKey, IskDvTarget, IskDvBattery, IskDvLastSeen
	from IskDevices
	where IskDvTournament=$ToId and IskDvGroup>=0
	order by IskDvLastSeen desc, IskDvCode");
while($r = safe_fetch($q)) {
	$Devices[] = $r;
	if($r->IskDvVersion) {
		$Versions[] = $r->IskDvVersion;
	}
}
usort($Versions, 'version_compare');
$LatestVersion = end($Versions) ?: '';

// 予選のセッション・距離ごとのエンド数と1エンドの矢数
$DistInfo = [];
$q = safe_r_sql("select DiSession, DiDistance, DiEnds, DiArrows from DistanceInformation where DiTournament=$ToId and DiType='Q'");
while($r = safe_fetch($q)) {
	$DistInfo[$r->DiSession][$r->DiDistance] = $r;
}

// 予選の的ごとに、点数が入っている距離とその最終エンド: $Progress[セッション][的][距離] = エンド
$Progress = [];
if(intval($NumDist) > 0) {
	$Fields = [];
	for($d = 1; $d <= intval($NumDist); $d++) {
		$Fields[] = "QuD{$d}Arrowstring";
	}
	$q = safe_r_sql("select QuSession, QuTarget, " . implode(', ', $Fields) . "
		from Qualifications
		inner join Entries on EnId=QuId and EnTournament=$ToId
		where QuTarget>0");
	while($r = safe_fetch($q)) {
		for($d = 1; $d <= intval($NumDist); $d++) {
			$Arrows = rtrim($r->{"QuD{$d}Arrowstring"});
			if($Arrows === '') {
				continue;
			}
			$PerEnd = max(1, intval($DistInfo[$r->QuSession][$d]->DiArrows ?? 0) ?: 3);
			$End = intval(ceil(strlen($Arrows) / $PerEnd));
			$Progress[$r->QuSession][$r->QuTarget][$d] = max($End, $Progress[$r->QuSession][$r->QuTarget][$d] ?? 0);
		}
	}
}

// 予選の的の進み具合（例: 前半 4/6エンド）
function liteDevProgress($Session, $Target, $NumDist, $Progress, $DistInfo) {
	$Done = $Progress[$Session][$Target] ?? [];
	if(!$Done) {
		return '未入力';
	}
	$Dist = max(array_keys($Done));
	$End = $Done[$Dist];
	$Ends = intval($DistInfo[$Session][$Dist]->DiEnds ?? 0);
	if(intval($NumDist) == 2) {
		$Label = ($Dist == 1 ? '前半' : '後半');
	} else {
		$Label = '第' . $Dist . '距離';
	}
	if(!$Ends) {
		return $Label . ' ' . $End . 'エンド目';
	}
	return $Label . ' ' . ($End >= $Ends ? '終了' : $End . '/' . $Ends . 'エンド');
}
$ProgressFn = function($Session, $Target) use ($NumDist, $Progress, $DistInfo) {
	return liteDevProgress($Session, $Target, $NumDist, $Progress, $DistInfo);
};

$Now = time();
$Counts = ['active' => 0, 'recent' => 0, 'lost' => 0];

$IncludeFA = true;
$PAGE_TITLE = 'ISK端末一覧（Lite）';
$JS_SCRIPT = liteDevHeadAssets('LiteDev');

require_once('Common/Templates/head.php');

$Rows = '';
$RowNum = 0;
foreach($Devices as $r) {
	$St = liteDevStatus($r->IskDvLastSeen, $Now);
	$Counts[$St['state']]++;
	list($Version, $VersionNote) = liteDevVersion($r->IskDvVersion, $LatestVersion);
	list($BatteryText, $BatteryKey) = liteDevBattery($r->IskDvBattery);
	list($AssignHtml, $AssignKey) = liteDevAssignment($r, $NumDist, $SessionNames, $ProgressFn);
	$AppName = strval(AppNames[$r->IskDvAppVersion] ?? $r->IskDvAppVersion);

	$Rows .= '<tr data-row="' . ($RowNum++) . '">'
		. '<td class="Center" data-sort="' . $St['key'] . '">' . liteDevStateHtml($St['state'], $St['text']) . '</td>'
		. '<td class="Center Bold" data-sort="' . htmlspecialchars($r->IskDvCode) . '" title="' . htmlspecialchars($r->IskDvDevice) . '">' . htmlspecialchars($r->IskDvCode) . '</td>'
		. '<td class="NoWrap" data-sort="' . htmlspecialchars($AssignKey) . '">' . $AssignHtml . '</td>'
		. '<td class="NoWrap" data-sort="' . htmlspecialchars($AppName) . '">' . htmlspecialchars($AppName) . '</td>'
		. '<td class="Center" data-sort="' . htmlspecialchars(liteDevVersionKey($r->IskDvVersion)) . '">' . $Version . '</td>'
		. '<td class="NoWrap">' . $VersionNote . '</td>'
		. '<td class="Right NoWrap" data-sort="' . $BatteryKey . '">' . $BatteryText . '</td>'
		. '<td class="NoWrap" data-sort="' . intval($St['lastSeen']) . '">' . liteDevLastSeenText($St['lastSeen'], $LocalTz) . '</td>'
		. '<td class="Right NoWrap" data-sort="' . ($St['elapsed'] ?? PHP_INT_MAX) . '">' . $St['elapsedText'] . '</td>'
		. '</tr>';
}

echo '<table class="Tabella freeWidth LiteDevTable">';
echo '<thead>';
echo '<tr><th colspan="9" class="Main">ISK端末一覧（Lite）</th></tr>';
echo '<tr><td colspan="9" class="Left">'
	// サーバー全体の一覧は ISK の管理権限があるときだけ開ける
	. ($CanSeeAll ? liteDevTabs('Devices.php') : '')
	. '登録端末 ' . count($Devices) . '台'
	. '（' . liteDevStateHtml('active', '通信中') . ' ' . $Counts['active']
	. '　' . liteDevStateHtml('recent', '応答待ち') . ' ' . $Counts['recent']
	. '　' . liteDevStateHtml('lost', '切断') . ' ' . $Counts['lost'] . '）'
	. '　最新バージョン: ' . ($LatestVersion !== '' ? htmlspecialchars($LatestVersion) : '—')
	. '　' . liteDevRefreshControls()
	. '</td></tr>';
echo '<tr>'
	. '<th class="Title" data-sort-col="0" data-sort-type="num">状態</th>'
	. '<th class="Title" data-sort-col="1">端末コード</th>'
	. '<th class="Title" data-sort-col="2">選択中の的</th>'
	. '<th class="Title" data-sort-col="3">アプリ</th>'
	. '<th class="Title" data-sort-col="4">バージョン</th>'
	. '<th class="Title"></th>'
	. '<th class="Title" data-sort-col="6" data-sort-type="num">電池</th>'
	. '<th class="Title" data-sort-col="7" data-sort-type="num">最終通信（' . $TzLabel . '）</th>'
	. '<th class="Title" data-sort-col="8" data-sort-type="num">経過</th>'
	. '</tr>';
echo '</thead>';
echo '<tbody id="LiteDevBody">';
if($Rows) {
	echo $Rows;
} else {
	echo '<tr><td colspan="9" class="Center LiteDevMuted">この大会に接続した端末はまだありません</td></tr>';
}
echo '</tbody>';
echo '<tfoot><tr><td colspan="9" class="Left LiteDevMuted">'
	. '状態は最終通信からの経過時間で判定しています（' . intval(LITE_DEV_ACTIVE_SEC / 60) . '分以内: 通信中、' . intval(LITE_DEV_RECENT_SEC / 60) . '分以内: 応答待ち、それ以上: 切断）。'
	. 'Lite のアプリは点数送信などのときだけ通信するため、しばらく入力がない端末は電源が入っていても「切断」と表示されることがあります。'
	. '</td></tr></tfoot>';
echo '</table>';

require_once('Common/Templates/tail.php');
