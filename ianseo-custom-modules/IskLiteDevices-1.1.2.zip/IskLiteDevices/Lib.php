<?php
/*
ISK端末一覧（Devices.php: 大会ごと、AllDevices.php: サーバー全体）で共通に使う関数。

変更履歴:
2026/09/25 削除を、チェックボックスで選んだ複数の端末に対して行う形に変更
2026/09/25 初版（Devices.php から切り出し）
*/

// 最終通信からの経過秒数による状態の区切り
const LITE_DEV_ACTIVE_SEC = 120;
const LITE_DEV_RECENT_SEC = 600;
// 自動更新の間隔（秒）
const LITE_DEV_REFRESH_SEC = 30;
// 大会情報にタイムゾーンが入っていない時に使うタイムゾーン
const LITE_DEV_DEFAULT_TZ = '+09:00';

// 大会のタイムゾーン
function liteDevLocalTz($ToId) {
	$TzName = '';
	$q = safe_r_sql("select ToTimeZone from Tournament where ToId=" . intval($ToId));
	if($r = safe_fetch($q)) {
		$TzName = trim($r->ToTimeZone);
	}
	try {
		return new DateTimeZone($TzName !== '' ? $TzName : LITE_DEV_DEFAULT_TZ);
	} catch(Exception $e) {
		return new DateTimeZone(LITE_DEV_DEFAULT_TZ);
	}
}

// 最終通信時刻から状態を判定する
// 戻り値は ['state'=>CSS クラス, 'text'=>表示, 'key'=>並び替え用, 'elapsed'=>経過秒数または null, 'elapsedText'=>表示, 'lastSeen'=>UNIX 時刻]
function liteDevStatus($IskDvLastSeen, $Now) {
	$LastSeen = strtotime($IskDvLastSeen);
	$Elapsed = ($LastSeen > 0) ? max(0, $Now - $LastSeen) : null;
	if($Elapsed !== null and $Elapsed <= LITE_DEV_ACTIVE_SEC) {
		$Ret = ['state' => 'active', 'text' => '通信中', 'key' => 0];
	} elseif($Elapsed !== null and $Elapsed <= LITE_DEV_RECENT_SEC) {
		$Ret = ['state' => 'recent', 'text' => '応答待ち', 'key' => 1];
	} else {
		$Ret = ['state' => 'lost', 'text' => '切断', 'key' => 2];
	}

	if($Elapsed === null) {
		$ElapsedText = '—';
	} elseif($Elapsed < 60) {
		$ElapsedText = $Elapsed . '秒前';
	} elseif($Elapsed < 3600) {
		$ElapsedText = intval($Elapsed / 60) . '分前';
	} elseif($Elapsed < 86400) {
		$ElapsedText = intval($Elapsed / 3600) . '時間' . intval(($Elapsed % 3600) / 60) . '分前';
	} else {
		$ElapsedText = intval($Elapsed / 86400) . '日前';
	}
	$Ret['elapsed'] = $Elapsed;
	$Ret['elapsedText'] = $ElapsedText;
	$Ret['lastSeen'] = $LastSeen;
	return $Ret;
}

// 最終通信時刻の表示。IskDvLastSeen は UTC なので大会のタイムゾーンに変換する
function liteDevLastSeenText($LastSeen, $LocalTz) {
	if($LastSeen <= 0) {
		return '—';
	}
	return (new DateTime('@' . $LastSeen))->setTimezone($LocalTz)->format('Y-m-d H:i:s');
}

// バッテリー残量の表示と並び替え用キー
function liteDevBattery($IskDvBattery) {
	$Battery = intval($IskDvBattery);
	if($Battery == 0) {
		return ['<span class="LiteDevMuted">—</span>', -1];
	}
	return [abs($Battery) . '%' . ($Battery < 0 ? ' <i class="fa fa-bolt" title="充電中"></i>' : ''), abs($Battery)];
}

// バージョンの表示と注記。$LatestVersion は比べる相手の最新バージョン
function liteDevVersion($IskDvVersion, $LatestVersion, $CheckRequired = true) {
	$Version = htmlspecialchars($IskDvVersion ?? '');
	if($Version === '') {
		return ['<span class="LiteDevMuted">不明</span>', ''];
	}
	if($CheckRequired and version_compare($IskDvVersion, reqAppVersion, '<')) {
		return ['<span class="LiteDevOld">' . $Version . '</span>', '要更新（' . reqAppVersion . '以上）'];
	}
	if($LatestVersion and version_compare($IskDvVersion, $LatestVersion, '<')) {
		return ['<span class="LiteDevOld">' . $Version . '</span>', '他端末より古い'];
	}
	return [$Version, ''];
}

// バージョン文字列を並び替え用に桁揃えする（1.9.7 → 00001.00009.00007）
function liteDevVersionKey($Version) {
	return implode('.', array_map(function($p) { return sprintf('%05d', intval($p)); }, explode('.', $Version ?? '')));
}

// 選択中の的を読める形にする。戻り値は [表示用HTML, 並び替え用キー]
// $ProgressFn($Session, $Target) は予選の的の進み具合（HTML）を返す関数。null なら表示しない
function liteDevAssignment($r, $NumDist, $SessionNames, $ProgressFn = null) {
	$Key = $r->IskDvSchedKey;
	$Target = intval($r->IskDvTarget);
	if($Key === '' or !$Target) {
		return ['<span class="LiteDevMuted">未選択</span>', '9'];
	}
	$TargetKey = sprintf('%04d', $Target);
	if($Key[0] == 'Q' and $NumDist !== '' and substr($Key, 1, strlen($NumDist)) === $NumDist) {
		$Session = intval(substr($Key, 1 + strlen($NumDist)));
		$Label = '予選 ' . (($SessionNames[$Session] ?? '') !== '' ? htmlspecialchars($SessionNames[$Session]) : 'セッション' . $Session);
		$Label .= ' / ' . $Target . '番的';
		if($ProgressFn) {
			$Label .= ' <span class="LiteDevProgress">' . $ProgressFn($Session, $Target) . '</span>';
		}
		return [$Label, '1' . sprintf('%03d', $Session) . $TargetKey];
	}
	switch(substr($Key, 0, 2)) {
		case 'IR': $Label = 'ラウンドロビン（個人）'; $Sched = substr($Key, 2); break;
		case 'TR': $Label = 'ラウンドロビン（団体）'; $Sched = substr($Key, 2); break;
		default:
			$Label = ($Key[0] == 'T' ? '決勝（団体）' : ($Key[0] == 'I' ? '決勝（個人）' : htmlspecialchars($Key)));
			$Sched = substr($Key, 1);
	}
	if(strlen($Sched) >= 15) {
		// YYYY-MM-DDHH:MM:SS
		$Label .= ' ' . substr($Sched, 5, 5) . ' ' . substr($Sched, 10, 5);
	}
	return [$Label . ' / ' . $Target . '番的', '2' . $Sched . $TargetKey];
}

// 状態の表示
function liteDevStateHtml($State, $Text) {
	return '<span class="LiteDevState ' . $State . '">' . $Text . '</span>';
}

// ページの CSS と JavaScript（自動更新、列見出しクリックでの並び替え、コード変更・削除の確認）
// $StorageKey は並び順などを覚えておく sessionStorage の名前の頭につける文字列
/**
 * 「大会に接続」（Devices.php）と「サーバー全体」（AllDevices.php）を切り替えるタブ。表の行の右端に出す
 * $Current は今の画面のファイル名
 */
function liteDevTabs($Current) {
	$Ret = '<span class="LiteDevTabs">';
	foreach(['Devices.php' => '大会に接続', 'AllDevices.php' => 'サーバー全体'] as $Page => $Label) {
		$Ret .= '<a href="' . $Page . '"' . ($Page == $Current ? ' class="on"' : '') . '>' . $Label . '</a>';
	}
	return $Ret . '</span>';
}

function liteDevHeadAssets($StorageKey) {
	return array(
		'<style>
			.LiteDevTable td { padding: 0.25em 0.75em; }
			.LiteDevState { display: inline-block; min-width: 5em; padding: 0.1em 0.5em; border-radius: 0.3em; text-align: center; font-weight: bold; }
			.LiteDevState.active { background: #2e7d32; color: #fff; }
			.LiteDevState.recent { background: #f9a825; color: #000; }
			.LiteDevState.lost { background: #9e9e9e; color: #fff; }
			.LiteDevOld { color: #c62828; font-weight: bold; }
			.LiteDevMuted { color: #888; }
			.LiteDevProgress { display: inline-block; margin-left: 0.5em; padding: 0 0.4em; border: 1px solid #888; border-radius: 0.3em; }
			.LiteDevCurrent { font-weight: bold; }
			.LiteDevTable th[data-sort-col] { cursor: pointer; user-select: none; white-space: nowrap; }
			.LiteDevTable th[data-sort-col]::after { content: " \21C5"; opacity: 0.4; }
			.LiteDevTable th[data-sort-dir="asc"]::after { content: " \25B2"; opacity: 1; }
			.LiteDevTable th[data-sort-dir="desc"]::after { content: " \25BC"; opacity: 1; }
			.LiteDevTable form { display: inline; }
			.LiteDevMsg { padding: 0.3em 0.75em; font-weight: bold; }
			.LiteDevMsg.ok { background: #e8f5e9; color: #2e7d32; }
			.LiteDevMsg.ng { background: #ffebee; color: #c62828; }
			.LiteDevUuid { font-family: monospace; font-size: 0.9em; }
			.LiteDevTabs { float: right; margin-left: 1em; white-space: nowrap; }
			.LiteDevTabs a { display: inline-block; padding: 0.2em 1em; margin-left: 0.3em; border: 1px solid #999; border-radius: 0.4em 0.4em 0 0; text-decoration: none; background: #eee; color: #333; }
			.LiteDevTabs a.on { background: #fff; font-weight: bold; }
		</style>',
		'<script>
			document.addEventListener("DOMContentLoaded", function() {
				var cb = document.getElementById("LiteDevAutoRefresh");
				try { if(sessionStorage.getItem("' . $StorageKey . 'AutoRefresh") === "0") cb.checked = false; } catch(e) {}
				cb.addEventListener("change", function() {
					try { sessionStorage.setItem("' . $StorageKey . 'AutoRefresh", cb.checked ? "1" : "0"); } catch(e) {}
				});
				// 端末を選んでいる間は、選択が消えないよう自動更新を見送る
				setInterval(function() {
					if(cb.checked && !document.querySelector("input.LiteDevSel:checked")) location.reload();
				}, ' . (LITE_DEV_REFRESH_SEC * 1000) . ');

				// 全選択のチェックボックスと選択数の表示
				var all = document.getElementById("LiteDevSelAll");
				function updateSelCount() {
					var n = document.querySelectorAll("input.LiteDevSel:checked").length;
					var el = document.getElementById("LiteDevSelCount");
					if(el) el.textContent = n;
					if(all) {
						var total = document.querySelectorAll("input.LiteDevSel").length;
						all.checked = (total > 0 && n === total);
						all.indeterminate = (n > 0 && n < total);
					}
				}
				if(all) {
					all.addEventListener("change", function() {
						document.querySelectorAll("input.LiteDevSel").forEach(function(c) { c.checked = all.checked; });
						updateSelCount();
					});
				}
				document.querySelectorAll("input.LiteDevSel").forEach(function(c) { c.addEventListener("change", updateSelCount); });
				updateSelCount();

				// 列見出しクリックで昇順・降順を切り替える。並び順は自動更新後も保持する
				var body = document.getElementById("LiteDevBody");
				var heads = document.querySelectorAll("th[data-sort-col]");
				function sortBy(col, dir) {
					var th = document.querySelector("th[data-sort-col=\"" + col + "\"]");
					if(!th || !body) return;
					var isNum = (th.getAttribute("data-sort-type") === "num");
					var rows = Array.prototype.slice.call(body.querySelectorAll("tr[data-row]"));
					rows.sort(function(a, b) {
						var va = a.children[col].getAttribute("data-sort");
						var vb = b.children[col].getAttribute("data-sort");
						var c = isNum ? (parseFloat(va) - parseFloat(vb)) : (va < vb ? -1 : (va > vb ? 1 : 0));
						if(c === 0) c = parseInt(a.getAttribute("data-row")) - parseInt(b.getAttribute("data-row"));
						return dir === "desc" ? -c : c;
					});
					rows.forEach(function(r) { body.appendChild(r); });
					heads.forEach(function(h) { h.removeAttribute("data-sort-dir"); });
					th.setAttribute("data-sort-dir", dir);
					try { sessionStorage.setItem("' . $StorageKey . 'Sort", col + ":" + dir); } catch(e) {}
				}
				heads.forEach(function(th) {
					th.addEventListener("click", function() {
						sortBy(th.getAttribute("data-sort-col"), th.getAttribute("data-sort-dir") === "asc" ? "desc" : "asc");
					});
				});
				try {
					var saved = (sessionStorage.getItem("' . $StorageKey . 'Sort") || "").split(":");
					if(saved.length === 2) sortBy(saved[0], saved[1]);
				} catch(e) {}
			});

			function LiteDevChangeCode(form, oldCode) {
				var code = prompt("新しい端末コード（英数字4文字）を入力してください。\\n他の端末と同じコードは使えません。", oldCode);
				if(code === null) return false;
				form.elements["LiteDevCode"].value = code;
				return true;
			}
			function LiteDevDeleteSelected() {
				var codes = [];
				document.querySelectorAll("input.LiteDevSel:checked").forEach(function(c) { codes.push(c.getAttribute("data-code")); });
				if(!codes.length) {
					alert("削除する端末にチェックを入れてください。");
					return false;
				}
				return confirm(codes.length + "台の端末を削除します（" + codes.join(", ") + "）。\\nこれらの端末をもう一度使う時は、端末で QR コードを読み込み直してください。新しい端末コードで登録されます。");
			}
		</script>',
	);
}

// 自動更新のチェックボックスと「今すぐ更新」ボタン
function liteDevRefreshControls() {
	return '<label><input type="checkbox" id="LiteDevAutoRefresh" checked> ' . LITE_DEV_REFRESH_SEC . '秒ごとに自動更新</label>'
		. '　<input type="button" value="今すぐ更新" onclick="location.reload()">';
}

// 端末コードの変更・端末の削除。戻り値は [成功したか, メッセージ]
function liteDevAction($Post) {
	switch($Post['LiteDevAction'] ?? '') {
		case 'delete':
			return liteDevDelete($Post['LiteDevDevices'] ?? []);
		case 'code':
			return liteDevChangeCode(strval($Post['LiteDevDevice'] ?? ''), strval($Post['LiteDevCode'] ?? ''));
	}
	return [false, '不明な操作です。'];
}

// チェックボックスで選んだ端末（UUID の配列）を削除する
function liteDevDelete($Devices) {
	$List = [];
	foreach((is_array($Devices) ? $Devices : []) as $Device) {
		$List[] = StrSafe_DB(strval($Device));
	}
	if(!$List) {
		return [false, '削除する端末が選ばれていません。'];
	}
	$Codes = [];
	$q = safe_r_sql("select IskDvCode from IskDevices where IskDvDevice in (" . implode(',', $List) . ") order by IskDvCode");
	while($r = safe_fetch($q)) {
		$Codes[] = $r->IskDvCode;
	}
	if(!$Codes) {
		return [false, '該当する端末がありません（すでに削除されている可能性があります）。'];
	}
	safe_w_sql("delete from IskDevices where IskDvDevice in (" . implode(',', $List) . ")");
	return [true, count($Codes) . '台の端末を削除しました（' . implode(', ', $Codes) . '）。'];
}

// 端末コードを変更する
function liteDevChangeCode($Device, $NewCode) {
	$q = safe_r_sql("select IskDvCode from IskDevices where IskDvDevice=" . StrSafe_DB($Device));
	if(!($r = safe_fetch($q))) {
		return [false, '該当する端末がありません（すでに削除されている可能性があります）。'];
	}
	$OldCode = $r->IskDvCode;
	// 自動採番（Api/ISK-NG/v1/handshake.php）と同じ、36進数4桁の小文字にそろえる
	$NewCode = strtolower(trim($NewCode));
	if(!preg_match('/^[0-9a-z]{4}$/', $NewCode)) {
		return [false, '端末コードは英数字4文字で入力してください（例: 0012）。'];
	}
	if($NewCode == 'zzzz') {
		// 最大値にすると次の自動採番が5桁になり登録できなくなる
		return [false, 'zzzz は使えません。'];
	}
	if($NewCode == strtolower($OldCode)) {
		return [false, '端末コードは変わっていません。'];
	}
	// コードはサーバー全体で通しの番号なので、どの大会の端末とも重複させない
	$q = safe_r_sql("select IskDvDevice from IskDevices
		where lower(IskDvCode)=" . StrSafe_DB($NewCode) . " and IskDvDevice!=" . StrSafe_DB($Device));
	if(safe_num_rows($q)) {
		return [false, '端末コード ' . $NewCode . ' は他の端末が使っています。'];
	}
	safe_w_sql("update IskDevices set IskDvCode=" . StrSafe_DB($NewCode) . " where IskDvDevice=" . StrSafe_DB($Device));
	return [true, '端末コードを ' . $OldCode . ' から ' . $NewCode . ' に変更しました。'];
}

// コード変更のボタン
function liteDevCodeButton($r) {
	return '<form method="post" onsubmit="return LiteDevChangeCode(this, ' . htmlspecialchars(json_encode($r->IskDvCode)) . ')">'
			. '<input type="hidden" name="LiteDevAction" value="code">'
			. '<input type="hidden" name="LiteDevDevice" value="' . htmlspecialchars($r->IskDvDevice) . '">'
			. '<input type="hidden" name="LiteDevCode" value="">'
			. '<input type="submit" value="コード変更">'
		. '</form>';
}

// 削除する端末を選ぶチェックボックス。表の外にある削除用フォーム（id="LiteDevDeleteForm"）に属させる
function liteDevSelectBox($r) {
	return '<input type="checkbox" class="LiteDevSel" form="LiteDevDeleteForm" name="LiteDevDevices[]"'
		. ' value="' . htmlspecialchars($r->IskDvDevice) . '" data-code="' . htmlspecialchars($r->IskDvCode) . '">';
}

// 選んだ端末をまとめて削除するボタン（フォームごと）
function liteDevDeleteForm() {
	return '<form method="post" id="LiteDevDeleteForm" onsubmit="return LiteDevDeleteSelected()">'
			. '<input type="hidden" name="LiteDevAction" value="delete">'
			. '<input type="submit" value="選択した端末を削除">'
			. '（<span id="LiteDevSelCount">0</span>台を選択中）'
		. '</form>';
}
