/*
背景色の設定の画面: 色を選んだら、この画面の背景をすぐその色にする。
見本・色の選択・#RRGGBB の入力の 3 つをそろえる。

変更履歴:
2026/09/30 初版
*/
window.addEventListener('DOMContentLoaded', function() {
	var picker = document.getElementById('bgcPicker');
	var text = document.getElementById('bgcColor');
	var dark = document.getElementById('bgcDark');
	var swatches = document.querySelectorAll('.bgcSwatch');

	// preview: この画面の背景を変える。開いたときは変えない（デバッグモードの色など、今の画面の色をそのまま見せる）
	function show(color, preview) {
		if(!/^#[0-9A-Fa-f]{6}$/.test(color)) {
			return;
		}
		color = color.toUpperCase();
		if(preview) {
			document.documentElement.style.setProperty('--header-light', color);
		}
		picker.value = color.toLowerCase();
		swatches.forEach(function(b) {
			b.classList.toggle('bgcOn', b.dataset.color == color);
		});
		// 明るさ（0〜255）が低いと、黒や紺の文字が読みにくい
		var r = parseInt(color.substr(1, 2), 16), g = parseInt(color.substr(3, 2), 16), b = parseInt(color.substr(5, 2), 16);
		dark.hidden = (0.299 * r + 0.587 * g + 0.114 * b) >= 150;
	}

	swatches.forEach(function(b) {
		b.addEventListener('click', function() {
			text.value = b.dataset.color;
			show(b.dataset.color, true);
		});
	});
	picker.addEventListener('input', function() {
		text.value = picker.value.toUpperCase();
		show(picker.value, true);
	});
	text.addEventListener('input', function() {
		show(text.value.trim(), true);
	});
	show(text.value, false);
});
