<?php
/*
画面の背景色を、背景色の設定（index.php）で選んだ色にする。
管理者には、モジュールメニューに「背景色」を追加する。

本体の Common/Styles/colors.css を書き換えると ianseo の更新で元に戻るので、
更新で消されない Modules/Custom に置き、メニューを表示するとき（Common/Templates/head.php の PrintMenu()）に
colors.css の後から :root の色を上書きする。
メニューを表示しない画面（ポップアップ、head-min.php の画面、TV 表示など）は元の色のまま。

変更履歴:
2026/09/30 色を背景色の設定（index.php）で選べるようにした
2026/09/30 初版
*/
require_once(__DIR__ . '/Lib.php');

echo bgcStyle();

// 背景色はこの ianseo の全員の画面が変わるので、カスタムモジュール管理と同じく管理者だけに出す
if(empty($_SESSION['AUTH_ENABLE']) or !empty($_SESSION['AUTH_ROOT']) or (isset($acl) and subFeatureAcl($acl, AclRoot, '') == AclReadWrite)) {
	$ret['MODS'][] = MENU_DIVIDER;
	$ret['MODS'][] = '背景色' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . basename(__DIR__) . '/index.php';
}
