<?php
/*
背景色の設定: ianseo の画面の背景色を選んで保存する。
- 色は、見本から選ぶか、色の選択・#RRGGBB で入れる。選ぶとすぐこの画面に反映し、「保存」で全員の画面に反映する
- デバッグモードのときもこの色にするかを選ぶ（しないときは、デバッグモードの色 colors_debug.css のまま）
保存した色は menu.php が画面に出す。
背景色はこの ianseo の全員の画面が変わるので、管理者（本体の「更新」を使える人）だけが使える。

変更履歴:
2026/09/30 初版
*/
require_once(dirname(__DIR__) . '/config.php');
require_once(__DIR__ . '/Lib.php');

/** 背景色の見本（色 => 名前） */
const BGC_PRESETS = [
	'#F0FFF0' => '薄い緑',
	'#FFFDF0' => '薄いクリーム',
	'#F4F4F4' => '薄いグレー',
	'#FFF0F5' => '薄いピンク',
	BGC_IANSEO => 'ianseo の標準（薄い水色）',
];

/** 設定を変えられるか（カスタムモジュール管理・本体の「更新」と同じ条件） */
function bgcCanEdit() {
	if(!hasFullACL(AclRoot, '', AclReadWrite)) {
		return false;
	}
	return (empty($_SESSION['AUTH_ENABLE']) or !empty($_SESSION['AUTH_ROOT']));
}

/** フォーム送信の確認用のトークン */
function bgcToken() {
	if(empty($_SESSION['bgcToken'])) {
		$_SESSION['bgcToken'] = bin2hex(random_bytes(16));
	}
	return $_SESSION['bgcToken'];
}

if(!bgcCanEdit()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	if(empty($_SESSION['bgcToken']) or !hash_equals($_SESSION['bgcToken'], (string)($_POST['token'] ?? ''))) {
		$Flash = [false, '画面を開き直してから、もう一度試してください。'];
	} elseif(!bgcColor($_POST['color'] ?? '')) {
		$Flash = [false, '色は #RRGGBB の形（例: #F0FFF0）で入れてください。'];
	} elseif(!bgcSave($_POST['color'], !empty($_POST['debug']))) {
		$Flash = [false, '保存できませんでした。' . bgcDataDir() . ' にファイルを書けるか確かめてください。'];
	} else {
		$Flash = [true, '保存しました。'];
	}
	$_SESSION['bgcFlash'] = $Flash;
	CD_redirect($CFG->ROOT_DIR . 'Modules/Custom/' . basename(__DIR__) . '/index.php');
}

$Set = bgcLoad();

$PAGE_TITLE = '背景色';
$Url = $CFG->ROOT_DIR . 'Modules/Custom/' . basename(__DIR__) . '/';
$JS_SCRIPT = [
	'<link rel="stylesheet" href="' . htmlspecialchars($Url . 'index.css') . '">',
	'<script src="' . htmlspecialchars($Url . 'index.js') . '"></script>',
];
require_once('Common/Templates/head.php');

if($Flash = $_SESSION['bgcFlash'] ?? null) {
	unset($_SESSION['bgcFlash']);
	echo '<p class="' . ($Flash[0] ? 'bgcOk' : 'bgcErr') . '">' . htmlspecialchars($Flash[1]) . '</p>';
}

echo '<form method="post" id="bgcForm">';
echo '<input type="hidden" name="token" value="' . htmlspecialchars(bgcToken()) . '">';
echo '<table class="Tabella bgcTable">';
echo '<tr><th colspan="2" class="Main">背景色</th></tr>';

echo '<tr><th class="SubTitle">見本</th><td>';
foreach(BGC_PRESETS as $Color => $Name) {
	echo '<button type="button" class="bgcSwatch" data-color="' . $Color . '">'
		. '<span class="bgcChip" style="background-color:' . $Color . '"></span>' . htmlspecialchars($Name) . '<br><span class="bgcNote">' . $Color . '</span>'
		. '</button>';
}
echo '</td></tr>';

echo '<tr><th class="SubTitle">色</th><td>';
echo '<input type="color" id="bgcPicker" value="' . strtolower($Set['color']) . '"> ';
echo '<input type="text" name="color" id="bgcColor" value="' . $Set['color'] . '" size="9" maxlength="7" pattern="#[0-9A-Fa-f]{6}" required>';
echo '<div class="bgcNote">色を選ぶと、この画面の背景がすぐその色になります（ほかの画面は「保存」を押すと変わります）。</div>';
echo '<div class="bgcErr" id="bgcDark" hidden>暗い色です。文字が読みにくくなることがあります。</div>';
echo '</td></tr>';

echo '<tr><th class="SubTitle">デバッグモード</th><td>';
echo '<label><input type="checkbox" name="debug" value="1"' . ($Set['debug'] ? ' checked' : '') . '> デバッグモードのときもこの色にする</label>';
echo '<div class="bgcNote">チェックしないときは、デバッグ中と分かるように、デバッグモードの色（オレンジ系）のままにします。</div>';
echo '</td></tr>';

echo '<tr><td colspan="2" class="Center"><input type="submit" value="保存"></td></tr>';
echo '</table>';
echo '</form>';

echo '<div class="bgcNote bgcAbout">メニューのない画面（ポップアップ、TV 表示など）は、ianseo の標準の色のままです。<br>'
	. 'この設定は ' . htmlspecialchars('Modules/Custom/' . basename(__DIR__) . '/data/settings.json') . ' に保存します。ianseo を更新しても残ります。</div>';

include('Common/Templates/tail.php');
