<?php
/*
背景色: 設定の読み書き。
設定は data/settings.json に保存する（module.json の keep で、モジュールを更新しても残す）。

このファイルは menu.php（ianseo の画面を開くたび）からも読み込むので、
ianseo 本体の関数を使わない軽い処理だけにする。本体の関数を使う処理は index.php に置く。

変更履歴:
2026/09/30 初版
*/

/** 設定を保存していないときの背景色 */
const BGC_DEFAULT = '#F0FFF0';
/** ianseo の標準の背景色（Common/Styles/colors.css の --header-light） */
const BGC_IANSEO = '#F0F8FF';

/** 設定を置くフォルダ */
function bgcDataDir() {
	return __DIR__ . '/data/';
}

/** #RRGGBB の形なら大文字にして返す。違えば '' */
function bgcColor($Color) {
	$Color = trim((string)$Color);
	return preg_match('/^#[0-9A-Fa-f]{6}$/', $Color) ? strtoupper($Color) : '';
}

/**
 * 設定を読む
 * - color: 背景色（#RRGGBB）
 * - debug: デバッグモードのときもこの色にするか（false ならデバッグモードの色 colors_debug.css のまま）
 */
function bgcLoad() {
	$Set = ['color' => BGC_DEFAULT, 'debug' => false];
	$File = bgcDataDir() . 'settings.json';
	if(is_file($File) and is_array($Json = json_decode((string)@file_get_contents($File), true))) {
		if($Color = bgcColor($Json['color'] ?? '')) {
			$Set['color'] = $Color;
		}
		$Set['debug'] = !empty($Json['debug']);
	}
	return $Set;
}

/** 設定を保存する（保存できたら true） */
function bgcSave($Color, $Debug) {
	if(!($Color = bgcColor($Color))) {
		return false;
	}
	$Dir = bgcDataDir();
	if(!is_dir($Dir)) {
		@mkdir($Dir, 0775, true);
	}
	$Json = json_encode(['color' => $Color, 'debug' => (bool)$Debug], JSON_PRETTY_PRINT);
	return @file_put_contents($Dir . 'settings.json', $Json, LOCK_EX) !== false;
}

/**
 * 背景色を上書きする <style>
 * colors.css（と、デバッグモードの colors_debug.css）の後に出して、:root の --header-light を上書きする。
 * デバッグモードで、デバッグモードの色を残す設定なら '' を返す。
 */
function bgcStyle($Set = null) {
	$Set = $Set ?? bgcLoad();
	if(!empty($_SESSION['debug']) and !$Set['debug']) {
		return '';
	}
	return '<style>:root { --header-light:' . $Set['color'] . '; }</style>';
}
