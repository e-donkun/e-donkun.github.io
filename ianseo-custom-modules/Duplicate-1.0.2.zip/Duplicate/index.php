<?php
/*
既存の試合から新規作成。
選んだ試合の設定（部門・クラス・種目・距離・セッション・的・スケジュール・印刷や ISK の設定など）をコピーして、新しい試合を作る。
選手・所属・スタッフ、点数や順位はコピーしない。コピーする内容は Lib.php を参照。
- 試合を新規作成できる権限（AclRoot の書き込み）が必要
- 複製元には、エクスポートできる試合ならどれでも選べる（開いている試合があれば、それが初めから選ばれている）
- 作成したら、その新しい試合を開く

変更履歴:
2026/09/25 初版
*/
require_once(dirname(dirname(__FILE__)) . '/config.php');
require_once('Common/Lib/CommonLib.php');
require_once(__DIR__ . '/Lib.php');

if(!dupCanCreate()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}

$Sources = dupSourceList();
$Errors = [];
$Data = [
	'SrcId' => intval($_SESSION['TourId'] ?? 0),
	'ToCode' => '',
	'ToName' => '',
	'ToNameShort' => '',
	'WhenFrom' => '',
	'WhenTo' => '',
];
if(!isset($Sources[$Data['SrcId']])) {
	$Data['SrcId'] = 0;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	$Data = [
		'SrcId' => intval($_POST['SrcId'] ?? 0),
		'ToCode' => trim($_POST['ToCode'] ?? ''),
		'ToName' => trim($_POST['ToName'] ?? ''),
		'ToNameShort' => trim($_POST['ToNameShort'] ?? ''),
		'WhenFrom' => trim($_POST['WhenFrom'] ?? ''),
		'WhenTo' => trim($_POST['WhenTo'] ?? ''),
	];
	$Errors = dupValidate($Data, $Sources);
	if(!$Errors and !hasFullACL(AclCompetition, 'cExport', AclReadOnly, $Data['SrcId'])) {
		$Errors[] = '複製元の試合を読み出す権限がありません。';
	}
	if(!$Errors) {
		if($NewId = dupCloneTournament($Data)) {
			CD_redirect($CFG->ROOT_DIR . 'Common/TourOn.php?ToId=' . $NewId . '&BackTo=' . urlencode($CFG->ROOT_DIR . 'Main.php'));
		}
		$Errors[] = '試合を作成できませんでした。';
	}
} elseif($Data['SrcId']) {
	$Data['ToName'] = $Sources[$Data['SrcId']]->ToName;
	$Data['ToNameShort'] = $Sources[$Data['SrcId']]->ToNameShort;
}

$PAGE_TITLE = '既存の試合から新規作成';
$JS_SCRIPT = [
	'<style>
		.DupForm th.SubTitle { width: 12em; }
		.DupForm input[type=text] { width: 30em; max-width: 100%; }
		.DupForm input[name=ToCode] { width: 8em; }
		.DupErr { color: #c00; font-weight: bold; }
		.DupNote { color: #555; }
		.DupNote ul { margin: 0.3em 0 0.3em 1.5em; padding: 0; }
	</style>',
	'<script>
		// 複製元を選ぶと、大会名と略称を複製元のものにする（入力済みなら、複製元の名前のままのときだけ置き換える）
		function dupSourceChanged(sel) {
			var opt = sel.options[sel.selectedIndex];
			var form = sel.form;
			var prev = sel.dataset.prev ? sel.querySelector(\'option[value="\' + sel.dataset.prev + \'"]\') : null;
			["ToName", "ToNameShort"].forEach(function(f) {
				var key = f == "ToName" ? "name" : "short";
				if(form[f].value === "" || (prev && form[f].value === prev.dataset[key])) {
					form[f].value = opt.dataset[key] || "";
				}
			});
			document.getElementById("DupSrcDates").textContent = opt.dataset.dates || "";
			sel.dataset.prev = sel.value;
		}
		// 開始日を入れたとき、終了日が空か開始日より前なら、元の試合と同じ日数になるようにする
		function dupFromChanged(inp) {
			var sel = inp.form.SrcId, to = inp.form.WhenTo;
			var opt = sel.options[sel.selectedIndex];
			if(!inp.value || (to.value && to.value >= inp.value)) return;
			var d = new Date(inp.value + "T00:00:00Z");
			d.setUTCDate(d.getUTCDate() + parseInt(opt.dataset.days || "0", 10));
			to.value = d.toISOString().substring(0, 10);
		}
	</script>',
];

require_once('Common/Templates/head.php');

echo '<form method="post" action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '">';
echo '<table class="Tabella freeWidth DupForm">';
echo '<tr><th colspan="2" class="Main">既存の試合から新規作成</th></tr>';
if($Errors) {
	echo '<tr><td colspan="2" class="Left DupErr">' . implode('<br>', array_map('htmlspecialchars', $Errors)) . '</td></tr>';
}

echo '<tr><th class="SubTitle">複製元の試合</th><td>';
echo '<select name="SrcId" onchange="dupSourceChanged(this)" data-prev="' . $Data['SrcId'] . '">';
echo '<option value="0">--- 選んでください ---</option>';
foreach($Sources as $r) {
	$Days = intval((new DateTime($r->ToWhenFrom))->diff(new DateTime($r->ToWhenTo))->format('%r%a'));
	echo '<option value="' . $r->ToId . '"'
		. ' data-name="' . htmlspecialchars($r->ToName) . '"'
		. ' data-short="' . htmlspecialchars($r->ToNameShort) . '"'
		. ' data-dates="' . htmlspecialchars('期間: ' . $r->ToWhenFrom . ' ～ ' . $r->ToWhenTo) . '"'
		. ' data-days="' . max(0, $Days) . '"'
		. ($r->ToId == $Data['SrcId'] ? ' selected' : '') . '>'
		. htmlspecialchars($r->ToWhenFrom . '　' . $r->ToCode . '　' . $r->ToName)
		. '</option>';
}
echo '</select>';
echo ' <span id="DupSrcDates" class="DupNote">'
	. ($Data['SrcId'] ? htmlspecialchars('期間: ' . $Sources[$Data['SrcId']]->ToWhenFrom . ' ～ ' . $Sources[$Data['SrcId']]->ToWhenTo) : '')
	. '</span>';
echo '</td></tr>';

echo '<tr><th class="SubTitle">新しい大会コード</th><td>'
	. '<input type="text" name="ToCode" maxlength="8" value="' . htmlspecialchars($Data['ToCode']) . '">'
	. ' <span class="DupNote">半角の英数字と . _ - で8文字以内。まだ使われていないコードにしてください。</span>'
	. '</td></tr>';
echo '<tr><th class="SubTitle">大会名</th><td><input type="text" name="ToName" value="' . htmlspecialchars($Data['ToName']) . '"></td></tr>';
echo '<tr><th class="SubTitle">大会名（略称）</th><td><input type="text" name="ToNameShort" maxlength="60" value="' . htmlspecialchars($Data['ToNameShort']) . '"></td></tr>';
echo '<tr><th class="SubTitle">期間</th><td>'
	. '<input type="date" name="WhenFrom" value="' . htmlspecialchars($Data['WhenFrom']) . '" onchange="dupFromChanged(this)">'
	. ' ～ '
	. '<input type="date" name="WhenTo" value="' . htmlspecialchars($Data['WhenTo']) . '">'
	. '</td></tr>';

echo '<tr><td colspan="2" class="Center"><input type="submit" value="作成して開く"></td></tr>';

echo '<tr><td colspan="2" class="Left DupNote">'
	. 'コピーするもの:'
	. '<ul>'
	. '<li>大会の基本情報（種類・ルール・会場・通貨・印刷の設定など。大会コード・大会名・期間は上で入力したもの）、ロゴなどの画像</li>'
	. '<li>部門・クラス・サブクラス、距離、的の種類、種目（個人・団体）と種目に含めるクラス、表彰の設定</li>'
	. '<li>セッションと的の割り当て、距離ごとのエンド数・時刻、スケジュール、決勝の時刻と的、練習の時間</li>'
	. '<li>ゼッケン・IDカードのレイアウト、TV出力の設定、記録の設定、メールのひな形、アクセス制限の設定</li>'
	. '<li>ISK-NG などモジュールの設定（サーバーのURLやPINなど）</li>'
	. '</ul>'
	. 'コピーしないもの: 選手・所属・スタッフ、点数・順位・組み合わせ、ISK 端末の接続と受信したデータ、ianseo.net への結果送信の設定、ログ。'
	. '<br>日付の入った設定（セッション・距離ごとの時刻・スケジュール・決勝の時刻・練習）は、元の試合との開始日の差の分だけ日付をずらします。'
	. '<br>決勝の組み合わせ表は空の状態で作り直します。ISK の端末は、新しい試合の QR コードを読み込み直してください。'
	. '</td></tr>';

echo '</table>';
echo '</form>';

require_once('Common/Templates/tail.php');
