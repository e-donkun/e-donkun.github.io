<?php
/*
モジュールメニューに「カスタムモジュール」（カスタムモジュール管理）を追加する。
本体の「更新」と同じく、管理者だけに表示する。
更新があるモジュールがあれば、WordPress の管理メニューのように、「モジュール」と「カスタムモジュール」に数のバッジを出す。
数は前に受信したカタログと比べるだけで、ここでは配布サイトに取りに行かない（State.php）。

変更履歴:
2026/11/10 画面を開くたびに裏で更新を確認する script をやめる（受信は「新規追加」と「更新を確認」のときだけ）
2026/09/26 更新の数のバッジと、更新の確認を追加
2026/09/26 初版
*/
if(empty($_SESSION['AUTH_ENABLE']) or !empty($_SESSION['AUTH_ROOT']) or (isset($acl) and subFeatureAcl($acl, AclRoot, '') == AclReadWrite)) {
	require_once(__DIR__ . '/State.php');
	$cmCount = count(cmUpdates());
	$cmBadge = $cmCount ? cmUpdateBadge($cmCount) : '';
	// 本体が先に入れた「モジュール」の見出しにも付ける
	if($cmBadge !== '' and isset($ret['MODS'][0]) and is_string($ret['MODS'][0]) and strpos($ret['MODS'][0], '|') === false) {
		$ret['MODS'][0] .= $cmBadge;
	}
	$ret['MODS'][] = MENU_DIVIDER;
	$ret['MODS'][] = 'カスタムモジュール' . $cmBadge . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . basename(__DIR__) . '/index.php';
}
