<?php
/*
カスタムモジュール管理: モジュールの一覧、有効・無効、zip からのインストール・更新、削除、
配布サイトのカタログ（catalog.json）の受信、パッケージ（配布用 zip と catalog.json）の作成。
モジュールの作り方と配布の形は README.md を参照。

変更履歴:
2026/11/10 カタログを受信するとき、配布サイトのキャッシュを通さないようにする（?_= と Cache-Control: no-cache）
2026/11/09 Package.php・site/ を zip から外すのを、CM_PACKAGE_ONLY をやめて module.json の keep にする
2026/11/09 パッケージ作成は doshisha.click のときだけ（cmCanPackage）。配布用 zip に Package.php を入れない
2026/09/26 更新の確認（cmCheckUpdates）を追加。カタログの URL・保存場所は State.php へ移す
2026/09/26 パッケージ情報（動作確認した ianseo の版など）、カタログから選んでインストール、パッケージ作成を追加
2026/09/26 初版
*/
require_once(dirname(__DIR__) . '/config.php');
require_once(__DIR__ . '/State.php');
require_once(__DIR__ . '/Package.lib.php');

/** zip の中身の上限（展開したときの合計サイズとファイル数） */
const CM_MAX_BYTES = 200 * 1024 * 1024;
const CM_MAX_FILES = 20000;
/** 配布サイトのカタログ（catalog.json）の大きさの上限 */
const CM_MAX_CATALOG = 2 * 1024 * 1024;

/**
 * モジュールを管理できるか
 * 本体の「更新」（Update/index.php）と同じ条件にする
 */
function cmCanManage() {
	if(!hasFullACL(AclRoot, '', AclReadWrite)) {
		return false;
	}
	return (empty($_SESSION['AUTH_ENABLE']) or !empty($_SESSION['AUTH_ROOT']));
}

/**
 * パッケージ作成（Package.php）を使えるか
 * 配布用の zip を作るのは doshisha.click のサイトだけ。
 * Package.php と site/ は module.json の keep に書いてあるので、配布する zip には入らず、更新しても消えない
 */
function cmCanPackage() {
	$Host = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
	return is_file(__DIR__ . '/Package.php') and ($Host === 'doshisha.click' or substr($Host, -15) === '.doshisha.click');
}

/** フォーム送信の確認用のトークン */
function cmToken() {
	if(empty($_SESSION['cmToken'])) {
		$_SESSION['cmToken'] = bin2hex(random_bytes(16));
	}
	return $_SESSION['cmToken'];
}

function cmCheckToken($Token) {
	return !empty($_SESSION['cmToken']) and is_string($Token) and hash_equals($_SESSION['cmToken'], $Token);
}

/** モジュールの module.json を読む（なければ null） */
function cmLoadModuleMeta($Id) {
	$File = cmCustomDir() . $Id . '/module.json';
	return cmReadMeta(is_file($File) ? @file_get_contents($File) : null);
}

/**
 * インストール済みのモジュールの一覧（フォルダ名の順）
 * Modules/Custom の下のフォルダを全部並べる（module.json がないものも、フォルダ名で出す）
 * - meta: パッケージ情報（cmNormalizeMeta）
 * - compat: この ianseo で使えるか（cmCompat）
 */
function cmModules() {
	$State = cmLoadState();
	$Dir = cmCustomDir();
	$Ret = [];
	foreach(scandir($Dir) ?: [] as $Id) {
		if($Id[0] == '.' or !is_dir($Dir . $Id)) {
			continue;
		}
		$Path = $Dir . $Id . '/';
		$Raw = cmLoadModuleMeta($Id) ?? [];
		$Meta = cmNormalizeMeta($Raw);
		$Meta['id'] = $Id;
		if($Meta['name'] === '') {
			$Meta['name'] = $Id;
		}
		$Ret[$Id] = [
			'id' => $Id,
			'name' => $Meta['name'],
			'version' => $Meta['version'],
			'meta' => $Meta,
			'compat' => cmCompat($Meta),
			'error' => (string)($Raw['_error'] ?? ''),
			'hasMeta' => is_file($Path . 'module.json'),
			'hasMenu' => (is_file($Path . 'menu.php') || is_file($Path . 'menu.php.disabled')),
			'disabled' => cmIsDisabled($Id, $State),
			'self' => ($Id == CM_SELF),
		];
	}
	uksort($Ret, 'strcasecmp');
	return $Ret;
}

/** インストール済みのモジュールを id で探す（大文字・小文字を区別しない） */
function cmFindModule($Mods, $Id) {
	foreach($Mods as $m) {
		if(strcasecmp($m['id'], $Id) == 0) {
			return $m;
		}
	}
	return null;
}

/** 有効・無効を切り替える */
function cmSetEnabled($Id, $Enable) {
	$Mods = cmModules();
	if(!isset($Mods[$Id])) {
		return [false, 'モジュール「' . $Id . '」が見つかりません。'];
	}
	$m = $Mods[$Id];
	if($m['self']) {
		return [false, 'モジュール管理は無効にできません。'];
	}
	if($Enable and $m['compat']['problems']) {
		return [false, '「' . $m['name'] . '」は有効にできません。' . implode('', $m['compat']['problems'])];
	}
	$State = cmLoadState();
	$State['disabled'] = array_values(array_filter($State['disabled'], fn($d) => strcasecmp($d, $Id) != 0));
	if(!$Enable) {
		$State['disabled'][] = $Id;
	}
	if(!cmSaveState($State)) {
		return [false, '状態を保存できませんでした。Modules/Custom/.modules/ に書き込めるか確認してください。'];
	}
	if(!cmSetMenu($Id, $Enable)) {
		return [false, 'menu.php の名前を変えられませんでした。' . $Id . ' フォルダに書き込めるか確認してください。'];
	}
	$Msg = '「' . $m['name'] . '」を' . ($Enable ? '有効' : '無効') . 'にしました。';
	if($Enable and $m['compat']['tested'] == 'no') {
		$Msg .= '（注意: ' . $m['compat']['note'] . '）';
	}
	return [true, $Msg];
}

/** 削除する（無効にしてあるものだけ） */
function cmDelete($Id) {
	$Mods = cmModules();
	if(!isset($Mods[$Id])) {
		return [false, 'モジュール「' . $Id . '」が見つかりません。'];
	}
	if($Mods[$Id]['self']) {
		return [false, 'モジュール管理は削除できません。'];
	}
	if(!$Mods[$Id]['disabled']) {
		return [false, '削除する前に、無効にしてください。'];
	}
	if(!cmRmdir(cmCustomDir() . $Id)) {
		return [false, '「' . $Mods[$Id]['name'] . '」のファイルを全部は削除できませんでした。残ったファイルを手で削除してください。'];
	}
	$State = cmLoadState();
	$State['disabled'] = array_values(array_filter($State['disabled'], fn($d) => strcasecmp($d, $Id) != 0));
	cmSaveState($State);
	return [true, '「' . $Mods[$Id]['name'] . '」を削除しました。'];
}

/** フォルダを中身ごと削除する */
function cmRmdir($Dir) {
	if(!file_exists($Dir) and !is_link($Dir)) {
		return true;
	}
	if(is_link($Dir) or !is_dir($Dir)) {
		return @unlink($Dir);
	}
	$Ok = true;
	foreach(scandir($Dir) ?: [] as $f) {
		if($f != '.' and $f != '..') {
			$Ok = cmRmdir($Dir . '/' . $f) && $Ok;
		}
	}
	return @rmdir($Dir) && $Ok;
}

/** フォルダを中身ごとコピーする */
function cmCopy($From, $To) {
	if(is_file($From)) {
		@mkdir(dirname($To), 0777, true);
		return @copy($From, $To);
	}
	if(!is_dir($From)) {
		return true;
	}
	@mkdir($To, 0777, true);
	$Ok = true;
	foreach(scandir($From) ?: [] as $f) {
		if($f != '.' and $f != '..') {
			$Ok = cmCopy($From . '/' . $f, $To . '/' . $f) && $Ok;
		}
	}
	return $Ok;
}

/** 作業用のフォルダを作る（Modules/Custom/.modules/tmp/＜ランダム＞/） */
function cmTmpDir() {
	$Dir = cmDataDir(true) . 'tmp/' . date('YmdHis') . '-' . bin2hex(random_bytes(4)) . '/';
	return @mkdir($Dir, 0777, true) ? $Dir : false;
}

/** 作業用のフォルダを片づける（空になった tmp も消す） */
function cmCleanTmp($Dir) {
	cmRmdir(rtrim($Dir, '/'));
	@rmdir(cmDataDir() . 'tmp');
}

/**
 * zip からインストール・更新する（zip の形は cmZipInspect() を参照）
 *
 * - 新しいモジュールは無効の状態で入れる（WordPress のプラグインと同じ）
 * - 更新のときは、有効・無効はそのままにして、module.json の keep に書いたファイル・フォルダは前のものを残す
 * - module.json の requiresIanseo・requiresPhp を満たさないものは入れない
 * - $ExpectId を渡したときは、その id のモジュールでなければ入れない（カタログから入れるとき）
 */
function cmInstallZip($ZipFile, $ExpectId = '') {
	if(!class_exists('ZipArchive')) {
		return [false, 'PHP の zip 拡張が有効になっていないため、zip を展開できません（php.ini で extension=zip を有効にしてください）。'];
	}
	$Zip = new ZipArchive();
	if($Zip->open($ZipFile) !== true) {
		return [false, 'zip ファイルを開けませんでした。'];
	}
	try {
		$Info = cmZipInspect($Zip, CM_MAX_FILES, CM_MAX_BYTES);
		if(isset($Info['error'])) {
			return [false, $Info['error']];
		}
		$Id = $Info['id'];
		$Meta = $Info['meta'];
		if($ExpectId !== '' and strcasecmp($ExpectId, $Id) != 0) {
			return [false, 'ダウンロードした zip の中身が「' . $ExpectId . '」ではありません（' . $Id . '）。'];
		}
		$Compat = cmCompat($Meta);
		if($Compat['problems']) {
			return [false, '「' . ($Meta['name'] ?? $Id) . '」はこの ianseo には入れられません。' . implode('', $Compat['problems'])];
		}
		// 大文字・小文字だけが違う同じ名前のフォルダがあれば、それを更新する（Windows では同じフォルダになるため）
		if($Existing = cmFindModule(cmModules(), $Id)) {
			$Id = $Existing['id'];
		}

		// 作業用のフォルダに展開する
		if(!($Tmp = cmTmpDir())) {
			return [false, '作業用のフォルダを作れませんでした。Modules/Custom/ に書き込めるか確認してください。'];
		}
		$New = $Tmp . 'new';
		@mkdir($New, 0777, true);
		$Prefix = $Info['prefix'];
		foreach($Info['entries'] as $Name => $i) {
			if($Prefix !== '' and strpos($Name, $Prefix) !== 0) {
				continue;
			}
			$Rel = substr($Name, strlen($Prefix));
			if($Rel === '' or $Rel === false) {
				continue;
			}
			$Dest = $New . '/' . rtrim($Rel, '/');
			if(substr($Name, -1) == '/') {
				@mkdir($Dest, 0777, true);
				continue;
			}
			@mkdir(dirname($Dest), 0777, true);
			$In = $Zip->getStream($Zip->getNameIndex($i));
			$Out = $In ? @fopen($Dest, 'wb') : false;
			$Ok = ($In and $Out and stream_copy_to_stream($In, $Out) !== false);
			if($In) fclose($In);
			if($Out) fclose($Out);
			if(!$Ok) {
				cmCleanTmp($Tmp);
				return [false, '展開できませんでした: ' . $Name];
			}
		}
	} finally {
		$Zip->close();
	}

	return cmPlaceModule($Id, $New, $Meta, $Tmp, $Compat);
}

/**
 * 展開したモジュール（$New）を Modules/Custom/＜$Id＞ に置く
 * すでにあれば入れ替える（入れ替えに失敗したら、元に戻す）
 */
function cmPlaceModule($Id, $New, $Meta, $Tmp, $Compat) {
	$Target = cmCustomDir() . $Id;
	$Exists = is_dir($Target);
	$State = cmLoadState();
	$Name = (string)($Meta['name'] ?? $Id);
	$Version = (string)($Meta['version'] ?? '');

	if($Exists) {
		$OldMeta = cmLoadModuleMeta($Id) ?? [];
		$Disabled = cmIsDisabled($Id, $State);
		// 前のモジュールで作ったデータなど、残すものをコピーする
		foreach(array_unique(array_merge(cmKeepPaths($OldMeta), cmKeepPaths($Meta))) as $Keep) {
			if(file_exists($Target . '/' . $Keep)) {
				cmRmdir($New . '/' . $Keep);
				cmCopy($Target . '/' . $Keep, $New . '/' . $Keep);
			}
		}
	} else {
		// 新しいモジュールは無効の状態で入れる
		$Disabled = true;
		$State['disabled'][] = $Id;
		if(!cmSaveState($State)) {
			cmCleanTmp($Tmp);
			return [false, '状態を保存できませんでした。Modules/Custom/.modules/ に書き込めるか確認してください。'];
		}
	}
	if($Id == CM_SELF) {
		$Disabled = false;
	}
	if($Disabled and is_file($New . '/menu.php')) {
		@unlink($New . '/menu.php.disabled');
		rename($New . '/menu.php', $New . '/menu.php.disabled');
	}

	// 入れ替える
	if($Exists and !@rename($Target, $Tmp . 'old')) {
		cmCleanTmp($Tmp);
		return [false, '今の「' . $Name . '」を入れ替えられませんでした。ファイルを開いているプログラムがあれば閉じてから、もう一度試してください。'];
	}
	if(!@rename($New, $Target)) {
		if($Exists) {
			@rename($Tmp . 'old', $Target);
		}
		cmCleanTmp($Tmp);
		return [false, '「' . $Name . '」を Modules/Custom/' . $Id . ' に置けませんでした。書き込めるか確認してください。'];
	}
	cmCleanTmp($Tmp);

	$Label = '「' . $Name . '」' . ($Version !== '' ? '（' . $Version . '）' : '');
	$Warn = ($Compat['tested'] == 'no' ? '（注意: ' . $Compat['note'] . '）' : '');
	if($Exists) {
		return [true, $Label . 'に更新しました。' . ($Disabled ? '（無効のままです）' : '') . $Warn];
	}
	return [true, $Label . 'をインストールしました。使うときは「有効にする」を押してください。' . $Warn];
}

/** アップロードされた zip からインストールする */
function cmInstallUpload($File) {
	if(empty($File) or !isset($File['error'])) {
		return [false, 'zip ファイルを選んでください。'];
	}
	switch($File['error']) {
		case UPLOAD_ERR_OK:
			break;
		case UPLOAD_ERR_INI_SIZE:
		case UPLOAD_ERR_FORM_SIZE:
			return [false, 'zip ファイルが大きすぎて受け取れませんでした（アップロードできるのは ' . cmUploadLimit() . ' まで）。「URL からインストール」を使うか、php.ini の upload_max_filesize と post_max_size を大きくしてください。'];
		case UPLOAD_ERR_NO_FILE:
			return [false, 'zip ファイルを選んでください。'];
		default:
			return [false, 'zip ファイルを受け取れませんでした（エラー ' . intval($File['error']) . '）。'];
	}
	if(!is_uploaded_file($File['tmp_name'])) {
		return [false, 'zip ファイルを受け取れませんでした。'];
	}
	return cmInstallZip($File['tmp_name']);
}

/**
 * URL の zip をダウンロードしてインストールする
 * $Sha256 を渡したときは、ダウンロードしたファイルがそれと同じか確かめる
 */
function cmInstallUrl($Url, $Sha256 = '', $ExpectId = '') {
	if(!($Tmp = cmTmpDir())) {
		return [false, '作業用のフォルダを作れませんでした。Modules/Custom/ に書き込めるか確認してください。'];
	}
	$File = $Tmp . 'download.zip';
	$Err = '';
	if(!cmHttpGet($Url, $File, CM_MAX_BYTES, $Err)) {
		cmCleanTmp($Tmp);
		return [false, 'ダウンロードできませんでした: ' . $Err];
	}
	if($Sha256 !== '' and !hash_equals(strtolower($Sha256), hash_file('sha256', $File))) {
		cmCleanTmp($Tmp);
		return [false, 'ダウンロードした zip がカタログの内容と違います（sha256 が一致しません）。配布サイトの zip と catalog.json が合っているか確認してください。'];
	}
	$Ret = cmInstallZip($File, $ExpectId);
	cmCleanTmp($Tmp);
	return $Ret;
}

/** カタログから選んだモジュールをインストール・更新する */
function cmInstallFromCatalog($Id) {
	$Catalog = cmLoadCatalog();
	$c = $Catalog['modules'][$Id] ?? null;
	if(!$c) {
		return [false, 'カタログに「' . $Id . '」がありません。カタログを受信し直してください。'];
	}
	if($Problems = cmCompat($c)['problems']) {
		return [false, '「' . $c['name'] . '」はこの ianseo には入れられません。' . implode('', $Problems)];
	}
	return cmInstallUrl($c['download'], $c['sha256'], $c['id']);
}

/** アップロードできる大きさ（php.ini の upload_max_filesize と post_max_size の小さいほう） */
function cmUploadLimit() {
	$Bytes = function($v) {
		$v = trim((string)$v);
		$n = floatval($v);
		switch(strtolower(substr($v, -1))) {
			case 'g': $n *= 1024;
			case 'm': $n *= 1024;
			case 'k': $n *= 1024;
		}
		return $n;
	};
	$Limits = array_filter([$Bytes(ini_get('upload_max_filesize')), $Bytes(ini_get('post_max_size'))]);
	if(!$Limits) {
		return '制限なし';
	}
	return round(min($Limits) / 1024 / 1024, 1) . 'MB';
}

/**
 * http(s) で取ってくる
 * $ToFile があればそのファイルに保存し、なければ中身を返す
 * $NoCache なら、途中のキャッシュを使わないよう Cache-Control: no-cache を付ける
 */
function cmHttpGet($Url, $ToFile, $MaxBytes, &$Err, $Timeout = 300, $NoCache = false) {
	$Headers = $NoCache ? ['Cache-Control: no-cache', 'Pragma: no-cache'] : [];
	if(!preg_match('#^https?://[^/\s]+#i', $Url)) {
		$Err = 'http:// か https:// で始まる URL を入れてください。';
		return false;
	}
	$Out = $ToFile ? @fopen($ToFile, 'wb') : fopen('php://temp', 'w+b');
	if(!$Out) {
		$Err = '保存するファイルを作れませんでした。';
		return false;
	}
	$Total = 0;
	$TooBig = false;
	$Write = function($Data) use ($Out, &$Total, $MaxBytes, &$TooBig) {
		$Total += strlen($Data);
		if($Total > $MaxBytes) {
			$TooBig = true;
			return false;
		}
		fwrite($Out, $Data);
		return true;
	};

	$Ok = false;
	if(function_exists('curl_init')) {
		$Ch = curl_init($Url);
		curl_setopt_array($Ch, [
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_MAXREDIRS => 5,
			CURLOPT_CONNECTTIMEOUT => min(15, $Timeout),
			CURLOPT_TIMEOUT => $Timeout,
			CURLOPT_FAILONERROR => true,
			CURLOPT_USERAGENT => 'ianseo-ModuleManager',
			CURLOPT_HTTPHEADER => $Headers,
			CURLOPT_WRITEFUNCTION => function($Ch, $Data) use ($Write) {
				return $Write($Data) ? strlen($Data) : 0;
			},
		]);
		if(defined('CURLOPT_PROTOCOLS_STR')) {
			curl_setopt($Ch, CURLOPT_PROTOCOLS_STR, 'http,https');
			curl_setopt($Ch, CURLOPT_REDIR_PROTOCOLS_STR, 'http,https');
		} elseif(defined('CURLOPT_PROTOCOLS')) {
			curl_setopt($Ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
			curl_setopt($Ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
		}
		$Ok = curl_exec($Ch);
		if(!$Ok) {
			$Err = $TooBig ? '大きすぎます' : curl_error($Ch);
		}
		curl_close($Ch);
	} else {
		$Ctx = stream_context_create(['http' => [
			'timeout' => min(60, $Timeout),
			'follow_location' => 1,
			'max_redirects' => 5,
			'user_agent' => 'ianseo-ModuleManager',
			'header' => $Headers,
		]]);
		if($In = @fopen($Url, 'rb', false, $Ctx)) {
			$Ok = true;
			while(!feof($In)) {
				$Data = fread($In, 65536);
				if($Data === false or !$Write($Data)) {
					$Ok = false;
					break;
				}
			}
			fclose($In);
			if(!$Ok) {
				$Err = $TooBig ? '大きすぎます' : '読み込みの途中で止まりました';
			}
		} else {
			$Err = trim(error_get_last()['message'] ?? '接続できませんでした');
		}
	}

	if($ToFile) {
		fclose($Out);
		return (bool)$Ok;
	}
	rewind($Out);
	$Ret = stream_get_contents($Out);
	fclose($Out);
	return $Ok ? $Ret : false;
}

/* ---------- 配布サイトのカタログ ---------- */

/**
 * 配布サイトのカタログ（catalog.json）を受信して保存する
 * 形は README.md を参照
 */
function cmFetchCatalog($Url, $Timeout = 60) {
	if($Url === '') {
		return [false, '配布サイトのカタログの URL を入れてください。'];
	}
	$Err = '';
	// GitHub Pages などは catalog.json を数分キャッシュするので、毎回ちがう ?_= を付けて最新を受け取る
	$FetchUrl = $Url . (strpos($Url, '?') === false ? '?' : '&') . '_=' . time();
	$Body = cmHttpGet($FetchUrl, null, CM_MAX_CATALOG, $Err, $Timeout, true);
	if($Body === false) {
		return [false, '配布サイトのカタログを受信できませんでした: ' . $Err];
	}
	$Json = json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $Body), true);
	if(!is_array($Json) or !isset($Json['modules']) or !is_array($Json['modules'])) {
		return [false, '配布サイトのカタログの形が違います（{"modules": [...]} の JSON にしてください）。'];
	}
	$Mods = [];
	foreach($Json['modules'] as $m) {
		if($c = cmNormalizeCatalogEntry($m, $Url)) {
			// 同じ id が複数あれば、新しい版のほうを使う
			if(!isset($Mods[$c['id']]) or version_compare($c['version'], $Mods[$c['id']]['version'], '>')) {
				$Mods[$c['id']] = $c;
			}
		}
	}
	uasort($Mods, fn($a, $b) => strcasecmp($a['name'], $b['name']));
	$Catalog = [
		'url' => $Url,
		'title' => is_scalar($Json['title'] ?? null) ? (string)$Json['title'] : '',
		'fetched' => date('Y-m-d H:i:s'),
		'fetchedTs' => time(),
		'modules' => $Mods,
	];
	cmDataDir(true);
	if(file_put_contents(cmCatalogFile(), json_encode($Catalog, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) === false) {
		return [false, '受信したカタログを保存できませんでした。Modules/Custom/.modules/ に書き込めるか確認してください。'];
	}
	return [true, '配布サイトのカタログを受信しました（' . count($Mods) . ' 件）。'];
}

/**
 * 更新を確認する（配布サイトのカタログを受信するだけで、入れはしない）
 * 「新規追加」を開いたとき（Add.php）と、「更新を確認」を押したとき（index.php）に呼ぶ
 * 同時に何度も動かないように、ロックで止める。確認した時刻とエラーを記録する（インストール済みの画面に出す）
 * $Timeout: 配布サイトを待つ秒数
 * 返すもの: [成功か, メッセージ]。ほかで確認中で動かなかったときは null
 */
function cmCheckUpdates($Timeout = 60) {
	$Lock = @fopen(cmDataDir(true) . 'check.lock', 'c');
	if(!$Lock or !flock($Lock, LOCK_EX | LOCK_NB)) {
		return null;
	}
	try {
		$Check = ['lastCheck' => time(), 'error' => ''];
		cmSaveCheck($Check);
		$Ret = cmFetchCatalog(cmCatalogUrl(), $Timeout);
		if(!$Ret[0]) {
			$Check['error'] = $Ret[1];
			cmSaveCheck($Check);
		}
		return $Ret;
	} finally {
		flock($Lock, LOCK_UN);
		fclose($Lock);
	}
}

/** 前に受信したカタログ（今の URL のものだけ。なければ null） */
function cmLoadCatalog($Url = null) {
	$Url = $Url ?? cmCatalogUrl();
	$Catalog = is_file(cmCatalogFile()) ? json_decode((string)@file_get_contents(cmCatalogFile()), true) : null;
	if(!is_array($Catalog) or $Url === '' or ($Catalog['url'] ?? '') !== $Url or !is_array($Catalog['modules'] ?? null)) {
		return null;
	}
	return $Catalog;
}

/** カタログのほうが新しい版なら、そのカタログの 1 件を返す */
function cmNewer($Catalog, $Mod) {
	$c = $Catalog ? cmFindModule($Catalog['modules'], $Mod['id']) : null;
	if(!$c or $c['version'] === '' or $Mod['version'] === '') {
		return null;
	}
	return version_compare($c['version'], $Mod['version'], '>') ? $c : null;
}

/* ---------- パッケージ（配布用 zip と catalog.json）の作成 ---------- */

/** 作ったパッケージを置く場所（Modules/Custom/.modules/packages/） */
function cmPackagesDir($Create = false) {
	$Dir = cmDataDir($Create) . 'packages/';
	if($Create and !is_dir($Dir)) {
		@mkdir($Dir, 0777, true);
	}
	return $Dir;
}

/**
 * モジュールの module.json を保存する（画面で入れたパッケージ情報）
 * module.json にある、ここで扱わない項目はそのまま残す
 * $Notes があれば、changelog のこの版のところに書く
 */
function cmSaveModuleMeta($Id, $Input, $Notes = '') {
	$Mods = cmModules();
	if(!isset($Mods[$Id])) {
		return [false, 'モジュール「' . $Id . '」が見つかりません。'];
	}
	$Raw = cmLoadModuleMeta($Id) ?? [];
	if(!empty($Raw['_error'])) {
		return [false, $Raw['_error'] . '。直してから保存してください。'];
	}

	$Errors = [];
	$New = ['id' => $Id];
	foreach(array_keys(cmMetaLabels()) as $k) {
		if($k != 'id') {
			$New[$k] = trim((string)($Input[$k] ?? ''));
		}
	}
	if($New['name'] === '') {
		$Errors[] = 'パッケージ名を入れてください。';
	}
	if(!cmValidVersion($New['version'])) {
		$Errors[] = 'パッケージの版は 1.2.0 のような形で入れてください。';
	}
	foreach(['testedIanseo', 'requiresIanseo'] as $k) {
		if($New[$k] !== '' and !cmValidIanseo($New[$k])) {
			$Errors[] = cmMetaLabels()[$k] . 'は 2026-03-01 または 2026-03-01 rev 255 のような形で入れてください。';
		}
	}
	if($New['testedIanseo'] === '') {
		$Errors[] = '動作確認した ianseo の版を入れてください。';
	}
	if($New['requiresIanseo'] !== '' and $New['testedIanseo'] !== '' and cmIanseoCompare($New['requiresIanseo'], $New['testedIanseo']) === 1) {
		$Errors[] = '必要な ianseo の版が、動作確認した版より新しくなっています。';
	}
	if($New['requiresPhp'] !== '' and !preg_match('/^\d+(\.\d+){0,2}$/', $New['requiresPhp'])) {
		$Errors[] = '必要な PHP の版は 8.0 のような形で入れてください。';
	}
	foreach(['homepage', 'authorUrl'] as $k) {
		if($New[$k] !== '' and !cmHttpUrl($New[$k])) {
			$Errors[] = cmMetaLabels()[$k] . 'は http:// か https:// で始まる URL にしてください。';
		}
	}
	if($Errors) {
		return [false, implode(' ', $Errors)];
	}

	// 変更履歴（この版のところを書き換える。新しい版は先頭に足す）
	$Log = cmNormalizeMeta($Raw)['changelog'];
	$Notes = trim(str_replace("\r\n", "\n", $Notes));
	$Found = false;
	foreach($Log as &$c) {
		if($c['version'] === $New['version']) {
			$Found = true;
			if($Notes !== '') {
				$c['notes'] = $Notes;
			}
			$c['date'] = date('Y-m-d');
		}
	}
	unset($c);
	if(!$Found and $Notes !== '') {
		array_unshift($Log, ['version' => $New['version'], 'date' => date('Y-m-d'), 'notes' => $Notes]);
	}

	// 項目の順をそろえて、ほかの項目（keep など）は後ろに残す
	$Out = [];
	foreach($New as $k => $v) {
		if($v !== '' or $k == 'id') {
			$Out[$k] = $v;
		}
	}
	if($Log) {
		$Out['changelog'] = $Log;
	}
	foreach($Raw as $k => $v) {
		if(!array_key_exists($k, $New) and $k != 'changelog') {
			$Out[$k] = $v;
		}
	}
	$Json = json_encode($Out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	$Json = preg_replace_callback('/^( {4})+/m', fn($m) => str_repeat("\t", strlen($m[0]) / 4), $Json) . "\n";
	if(file_put_contents(cmCustomDir() . $Id . '/module.json', $Json, LOCK_EX) === false) {
		return [false, 'module.json を保存できませんでした。' . $Id . ' フォルダに書き込めるか確認してください。'];
	}
	return [true, '「' . $New['name'] . '」のパッケージ情報を保存しました。'];
}

/**
 * モジュールを配布用の zip（パッケージ）にして Modules/Custom/.modules/packages/＜id＞-＜版＞.zip に置く
 * - 一番上に＜フォルダ名＞/ を入れる
 * - 無効にしていても、menu.php の名前で入れる
 * - keep に書いたもの（その会場で作ったデータなど）は入れない
 */
function cmBuildPackage($Id) {
	$Mods = cmModules();
	if(!isset($Mods[$Id])) {
		return [false, 'モジュール「' . $Id . '」が見つかりません。'];
	}
	$m = $Mods[$Id];
	if(!class_exists('ZipArchive')) {
		return [false, 'PHP の zip 拡張が有効になっていないため、zip を作れません。'];
	}
	if(!$m['hasMeta'] or !cmValidVersion($m['meta']['version']) or $m['meta']['testedIanseo'] === '') {
		return [false, '先にパッケージ情報（パッケージの版と、動作確認した ianseo の版）を保存してください。'];
	}
	$Name = $Id . '-' . $m['meta']['version'] . '.zip';
	$File = cmPackagesDir(true) . $Name;
	$Zip = new ZipArchive();
	if($Zip->open($File . '.tmp', ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
		return [false, 'zip を作れませんでした。Modules/Custom/.modules/ に書き込めるか確認してください。'];
	}
	$Base = cmCustomDir() . $Id;
	$HasMenu = is_file($Base . '/menu.php');
	$It = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($Base, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
	$Files = [];
	foreach($It as $f) {
		$Rel = str_replace('\\', '/', substr($f->getPathname(), strlen($Base) + 1));
		if(preg_match('#(^|/)(\.git|__MACOSX)(/|$)|(^|/)(\.DS_Store|Thumbs\.db)$#', $Rel)) {
			continue;
		}
		foreach($m['meta']['keep'] as $Keep) {
			if($Rel === $Keep or strpos($Rel, $Keep . '/') === 0) {
				continue 2;
			}
		}
		if($Rel == 'menu.php.disabled') {
			if($HasMenu) {
				continue;
			}
			$Rel = 'menu.php';
		}
		$Files[$Rel] = $f;
	}
	ksort($Files, SORT_STRING);
	$Zip->addEmptyDir($Id);
	foreach($Files as $Rel => $f) {
		if($f->isDir()) {
			$Zip->addEmptyDir($Id . '/' . $Rel);
		} else {
			$Zip->addFile($f->getPathname(), $Id . '/' . $Rel);
		}
	}
	if(!$Zip->close() or !@rename($File . '.tmp', $File)) {
		@unlink($File . '.tmp');
		return [false, 'zip を作れませんでした。'];
	}
	return [true, 'パッケージ ' . $Name . ' を作りました。'];
}

/**
 * 作ったパッケージの一覧（新しい順）
 * それぞれ: file, size, sha256, updated, meta（zip の中の module.json）
 */
function cmPackages() {
	$Ret = [];
	foreach(glob(cmPackagesDir() . '*.zip') ?: [] as $File) {
		$Zip = new ZipArchive();
		if($Zip->open($File) !== true) {
			continue;
		}
		$Info = cmZipInspect($Zip, CM_MAX_FILES, CM_MAX_BYTES);
		$Zip->close();
		if(isset($Info['error'])) {
			continue;
		}
		$Meta = cmNormalizeMeta($Info['meta']);
		$Meta['id'] = $Info['id'];
		$Ret[] = [
			'file' => basename($File),
			'size' => filesize($File),
			'sha256' => hash_file('sha256', $File),
			'updated' => date('Y-m-d', filemtime($File)),
			'meta' => $Meta,
		];
	}
	usort($Ret, fn($a, $b) => strcasecmp($a['meta']['id'], $b['meta']['id']) ?: version_compare($b['meta']['version'], $a['meta']['version']));
	return $Ret;
}

/**
 * 配布サイトに置く catalog.json を作る
 * 作ったパッケージのうち、モジュールごとに一番新しい版を載せる（download は zip のファイル名。catalog.json と同じ場所に置く）
 */
function cmCatalogJson($Title = '') {
	$Mods = [];
	foreach(cmPackages() as $p) {
		$Id = $p['meta']['id'];
		if(isset($Mods[$Id]) and version_compare($p['meta']['version'], $Mods[$Id]['version'], '<=')) {
			continue;
		}
		$Entry = [];
		foreach(array_keys(cmMetaLabels()) as $k) {
			if($p['meta'][$k] !== '' or $k == 'id') {
				$Entry[$k] = $p['meta'][$k];
			}
		}
		if($p['meta']['changelog']) {
			$Entry['changelog'] = $p['meta']['changelog'];
		}
		$Entry['download'] = $p['file'];
		$Entry['sha256'] = $p['sha256'];
		$Entry['size'] = $p['size'];
		$Entry['updated'] = $p['updated'];
		$Mods[$Id] = $Entry;
	}
	ksort($Mods, SORT_STRING | SORT_FLAG_CASE);
	$Out = [];
	if($Title !== '') {
		$Out['title'] = $Title;
	}
	$Out['generated'] = date('Y-m-d H:i:s');
	$Out['generator'] = 'ianseo ' . cmIanseoCurrent() . ' / ' . CM_SELF;
	$Out['modules'] = array_values($Mods);
	$Json = json_encode($Out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	return preg_replace_callback('/^( {4})+/m', fn($m) => str_repeat("\t", strlen($m[0]) / 4), $Json) . "\n";
}

/** ファイルをダウンロードさせる */
function cmSendDownload($File, $Name, $Type) {
	while(ob_get_level()) {
		ob_end_clean();
	}
	header('Content-Type: ' . $Type);
	header('Content-Disposition: attachment; filename="' . $Name . '"');
	header('Content-Length: ' . filesize($File));
	readfile($File);
}

/* ---------- 画面の部品 ---------- */

/** 管理画面の URL */
function cmUrl($Page = 'index.php', $Query = []) {
	global $CFG;
	return $CFG->ROOT_DIR . 'Modules/Custom/' . CM_SELF . '/' . $Page . ($Query ? '?' . http_build_query($Query) : '');
}

/** 操作のボタン（1 つずつ小さなフォームにする） */
function cmButton($Act, $Label, $Fields = [], $Confirm = '') {
	$Ret = '<form method="post" class="cmInline"' . ($Confirm !== '' ? ' onsubmit="return confirm(' . htmlspecialchars(json_encode($Confirm, JSON_UNESCAPED_UNICODE)) . ')"' : '') . '>'
		. '<input type="hidden" name="token" value="' . htmlspecialchars(cmToken()) . '">'
		. '<input type="hidden" name="act" value="' . htmlspecialchars($Act) . '">';
	foreach($Fields as $k => $v) {
		$Ret .= '<input type="hidden" name="' . htmlspecialchars($k) . '" value="' . htmlspecialchars($v) . '">';
	}
	return $Ret . '<input type="submit" value="' . htmlspecialchars($Label) . '"></form>';
}

/** 動作確認のバッジ */
function cmCompatBadge($Compat) {
	if($Compat['problems']) {
		return '<span class="cmBadge cmBadgeErr">' . htmlspecialchars(implode('', $Compat['problems'])) . '</span>';
	}
	$Class = ['yes' => 'cmBadgeOn', 'no' => 'cmBadgeNew'][$Compat['tested']] ?? 'cmBadgeOff';
	return '<span class="cmBadge ' . $Class . '">' . htmlspecialchars($Compat['note']) . '</span>';
}

/** 画面の上の部分（見出し・タブ・メッセージ） */
function cmPageHead($Title, $Tab) {
	global $PAGE_TITLE, $JS_SCRIPT, $CFG;
	$PAGE_TITLE = $Title;
	$JS_SCRIPT = ['<link rel="stylesheet" href="' . htmlspecialchars(cmUrl('cm.css')) . '">'];
	require_once('Common/Templates/head.php');
	echo '<div class="cmTabs">';
	$Tabs = ['index.php' => 'インストール済み', 'Add.php' => '新規追加'];
	if(cmCanPackage()) {
		$Tabs['Package.php'] = 'パッケージ作成';
	}
	foreach($Tabs as $Page => $Label) {
		echo '<a href="' . htmlspecialchars(cmUrl($Page)) . '"' . ($Page == $Tab ? ' class="cmTabOn"' : '') . '>' . $Label
			. (($Page == 'index.php' && ($Count = count(cmUpdates()))) ? '<span class="cmCount">' . $Count . '</span>' : '')
			. '</a>';
	}
	echo '<span class="cmNote">' . htmlspecialchars(cmIanseoCurrent() ?: '不明') . '　PHP ' . htmlspecialchars(PHP_VERSION) . '</span>';
	echo '</div>';
	if($Flash = $_SESSION['cmFlash'] ?? null) {
		unset($_SESSION['cmFlash']);
		echo '<p class="' . ($Flash[0] ? 'cmOk' : 'cmErr') . '">' . htmlspecialchars($Flash[1]) . '</p>';
	}
}

/** 操作のあと、メッセージを残して画面を開き直す */
function cmDone($Ret, $Page, $Query = []) {
	$_SESSION['cmFlash'] = $Ret;
	CD_redirect(cmUrl($Page, $Query));
}

/** POST のトークンを確かめる（だめなら、メッセージを残して開き直す） */
function cmRequireToken($Page, $Query = []) {
	if(!cmCheckToken($_POST['token'] ?? '')) {
		// アップロードが post_max_size を超えると $_POST が空になる
		cmDone([false, empty($_POST) ? 'zip ファイルが大きすぎて受け取れませんでした（アップロードできるのは ' . cmUploadLimit() . ' まで）。' : '画面を開き直してから、もう一度試してください。'], $Page, $Query);
	}
}
