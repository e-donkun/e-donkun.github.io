<?php

	ini_set('display_errors', "On");

	require_once(dirname(dirname(__FILE__)) . '/config.php');
	require_once('Common/Lib/Fun_Modules.php');
	require_once('Common/tcpdf/tcpdf.php');

	CheckTourSession(true);
	
	$TourCode=stripslashes($_REQUEST['Tour']);
	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
	if(!($TourId > 0)) {
		die("error!");
	}
	

		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,
			CoCode,CoName,
			QuTargetNo, QuTarget, SUBSTRING(QuTargetNo,2) AS Target,
			QuScore, QuGold, QuXnine,
			ToId,ToGolds AS GoldLabel, ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
		  DivDescription,ClDescription,
		  ToName,ToWhere,ToWhenFrom,ToWhenTo,ToCode,
		  
    RANK() OVER (
        PARTITION BY CONCAT(EnDivision, EnClass)
        ORDER BY QuScore DESC, QuGold DESC, QuXnine DESC
    ) AS Ranking

		FROM Entries 
		INNER JOIN Qualifications ON EnId=QuId 
		LEFT JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament 
		LEFT JOIN Tournament ON EnTournament=ToId
		LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType

    INNER JOIN Divisions ON DivTournament=ToId AND DivId=EnDivision    
    INNER JOIN Classes ON ClTournament=ToId AND ClId=EnClass
  	WHERE EnAthlete=1 AND ToId = {$TourId} AND CONCAT(EnDivision,EnClass) LIKE TdClasses";
	//var_dump($Select);
	$Rs=safe_r_sql($Select);

	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}
  
  
	usort($ArrayData, function($a, $b) {
    return $a['Class'] <=> $b['Class']             // Class は昇順
        ?: $b['QuScore'] <=> $a['QuScore']         // QuScore は降順
        ?: $b['QuGold'] <=> $a['QuGold']           // QuGold は降順
        ?: $b['QuXnine'] <=> $a['QuXnine'];        // QuXnine は降順

	});
	
	




	if(empty($_REQUEST["Data"])){
		
		include('Common/Templates/head.php');
		
		echo "<h1>賞状発行</h1>";
		$preClass = null;
		echo "<form method='post'>";
		foreach($ArrayData as $no => $Data){
			if( $preClass != $Data['Class'] ) { 
				echo "<hr>"; 
				echo "{$Data['Class']} {$Data['DivDescription']}部門 {$Data['ClDescription']}<br>";
				$rank=1;
			}
			$preClass = $Data['Class'] ;
			if(intval($Data['Ranking'])>8) continue;
			echo "{$Data['Ranking']}位";
			echo "<input type='checkbox' name='Data[]' value='{$no}'>";
			echo "{$Data['EnFirstName']} {$Data['EnName']} ";
			echo "{$Data['QuScore']}";
			echo "{$Data['CoName']} ";
			echo "<br>";
		} 
		echo "<hr><input type='submit' value='PDF出力'>";
		echo "</form>";

		include('Common/Templates/tail.php');
	
	} else {
		
		
		$filteredArrayData = array_map(function($index) use ($ArrayData) {
			return $ArrayData[$index];
		}, $_REQUEST["Data"]);

	
		   
    $pdf = new TCPDF('P', 'mm', 'JIS_B5', true, 'UTF-8', false);
		$pdf->setAutoPageBreak(false, 0);
		$pdf->setPrintHeader(false);
		$pdf->setPrintFooter(false);


		
		$pdf->setFontSize(12);
		$pdf->setMargins(0, 0, 0);
		$pdf->setCellPadding(0);

	  
		$paper_h = 257;
		$paper_w = 182;
		$pageMargin = 40;


		
		// IPAフォント埋め込み
		$font = new TCPDF_FONTS();   
		$fontfile = 'fonts/YujiSyuku-Regular.ttf';
		$myFont = $font->addTTFfont($fontfile);
		
		foreach($filteredArrayData as $Data){
			
			$pdf->AddPage();
			$page = $pdf->importPage(1); 
			$pdf->useTemplate($page); 

			yokoText(90,80,"{$Data['DivDescription']}部門{$Data['ClDescription']}",14);
			yokoText(56,76,numberToKanji($Data['Ranking']),30);
			yokoText(115,107,"{$Data['QuScore']}点",10);
			yokoText(60,90,$Data['CoName'],15);
			$name = "{$Data['EnFirstName']} {$Data['EnName']}";
			yokoText(70,95,"{$name}",30);	
			 
		}
		
		$pdf->Output();
	
	}

	
function yokoText($x, $y, $str, $size) {
	global $pdf, $myFont;
	$pdf->SetFont($myFont, '', $size);
	$pdf->Text($x, $y, $str);
}	
	
	
function tateText($x, $y, $str, $size) {
	global $pdf, $myFont;
	//フォントサイズ設定
	$pdf->SetFont($myFont, '', $size);
	//字間
	$fh = pt2mm($size*1.1);
	//文字数
	
	$str = mb_convert_kana($str,"ASK", 'UTF-8');
	$l = mb_strlen($str, 'UTF-8');
	for ($i=0; $i<$l; $i++) {
		$s1 = mb_substr($str, $i, 1, 'UTF-8');
		$adj_x = 0; $adj_y = 0;
		// 文字ごとの位置や回転調整
		switch($s1){
			case '「':
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.5);
				$adj_rotate_posi_x = pt2mm($size*0.4);
				$adj_rotate_posi_y = 0;
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
			break;
			case '」':
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.5);
				$adj_rotate_posi_x = pt2mm($size*0.4);
				$adj_rotate_posi_y = pt2mm($size*0.3);
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
			break;
			case '（':
			case '）':
			case '《':
			case '》':
			case '～':
			case 'ー':
			case '〔':
			case '〕':
				//$adj_rotate_x = pt2mm($size);
				//$adj_rotate_y = pt2mm($size*0.3);
				//$adj_rotate_posi_x = pt2mm($size*0.7);
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.4);
				$adj_rotate_posi_x = pt2mm($size*0.75);
				if($size<=12){
					$adj_rotate_posi_y = pt2mm($size*0.15);
				}else{
					$adj_rotate_posi_y = pt2mm($size*0.2);
				}
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
			break;
			case '。':
			case '、':
				$adj_x = $fh * 0.7; $adj_y = -$fh * 0.7;
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
			break;
			case 'っ':
			case 'ッ':
				$adj_x = pt2mm($size*0.1);
				$adj_y = -1*pt2mm($size*0.1);
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
			break;
			default:
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
			break;
		}
	}
}

// 1 インチ = 25.4 ミリメートル
// 1 ポイント = 1/72 インチ
// 1mm　は、 25.4分の1インチ
function mm2pt($mm) {
	$pt = $mm / 25.4 * 72;
	return $pt;
}
function pt2mm($pt) {
	$mm = $pt / 72  * 25.4;
	return $mm;
}



function numberToKanji($number) {
    $kanjiNumbers = ['〇', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
    $kanjiUnits = ['', '十', '百', '千'];
    $kanjiBigUnits = ['', '万', '億', '兆'];

    if ($number == 0) return $kanjiNumbers[0];

    $result = '';
    $strNumber = strval($number);
    $length = strlen($strNumber);
    $groupCount = ceil($length / 4);

    for ($i = 0; $i < $groupCount; $i++) {
        $group = substr($strNumber, -4 * ($i + 1), 4);
        $group = str_pad($group, 4, '0', STR_PAD_LEFT);
        $groupKanji = '';

        for ($j = 0; $j < 4; $j++) {
            $digit = intval($group[$j]);
            if ($digit !== 0) {
                $groupKanji .= ($digit === 1 && $j !== 3) ? $kanjiUnits[3 - $j] : $kanjiNumbers[$digit] . $kanjiUnits[3 - $j];
            }
        }

        if ($groupKanji !== '') {
            $result = $groupKanji . $kanjiBigUnits[$i] . $result;
        }
    }

    return $result;
}