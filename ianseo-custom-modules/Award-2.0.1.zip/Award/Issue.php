<?php
/*
賞状の発行。
編集の画面（Edit.php）の上のタブ「賞状発行」から開く（?tpl=テンプレートの id）。テンプレートを変えられない人は、テンプレート選択の名前から開く。
上のタブは「戻る」「テンプレート編集」「賞状発行」（awTabs）。
開いている試合の順位から選手（団体戦はチーム）を選んで、賞状の PDF を出力する。
順位は、テンプレートの設定（source）で決まる。「予選（部門・クラスごと）」「個人戦」「団体戦」（個人戦・団体戦は決勝の最終順位）。
テンプレートに表彰数の決め方があれば、種目ごとの参加数から表彰数を出し、その順位までを初めから選んでおく。
順位にない人（特別賞など）は、手入力の欄に書いて一緒に出せる。
- 「発行」: 発行履歴（data/history）に記録する
- 「試し刷り」: 記録しない。用紙の画像を重ねて位置を確かめることもできる

変更履歴:
2026/09/30 PDF は、いつも同じウィンドウ（target=preview）に開く
2026/09/30 順位のもと（予選・個人戦・団体戦）は、発行の画面で選ばず、テンプレートの設定で決めるようにした
2026/09/30 テンプレートは ?tpl= で決める。上のタブを「戻る」「テンプレート編集」「賞状発行」にした
2026/09/29 個人戦・団体戦の決勝の最終順位から選べるようにした。表彰数の決め方で初めから選んでおくようにした
2026/09/27 賞状の番号をなくした
2026/09/26 テンプレートを選んで出力し、発行履歴に記録するようにした（index.php から移した）
2026/09/23 初版
*/
require_once(dirname(dirname(__FILE__)) . '/config.php');
require_once('Common/Lib/CommonLib.php');
require_once(__DIR__ . '/Lib.php');

CheckTourSession(true);
if(!awCanView()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}

// テンプレートは ?tpl= で決める。決まっていなければテンプレート選択へ戻す
$Templates = awListTemplates();
$TplId = $_REQUEST['tpl'] ?? '';
if(!isset($Templates[$TplId])) {
	CD_redirect('index.php');
}
$Tpl = $Templates[$TplId];
$Tour = awTournament($_SESSION['TourId']);
$MaxRank = max(1, intval($_REQUEST['max'] ?? 8));
// 順位のもと（予選・個人戦・団体戦）は、テンプレートの設定で決める
$Sources = AW_SOURCES;
$Src = $Tpl['source'];
$Ranking = $Src == 'qual' ? awQualificationRanking($Tour['id']) : awEventRanking($Tour['id'], $Src == 'team');

// PDF の出力
if($_SERVER['REQUEST_METHOD'] == 'POST') {
	$Test = (($_POST['mode'] ?? '') == 'test');
	$Error = '';
	if(!awCheckToken()) {
		$Error = '画面の有効期限が切れました。画面を読み込み直してから、もう一度出力してください。';
	} else {
		$IssueDate = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['IssueDate'] ?? '') ? $_POST['IssueDate'] : date('Y-m-d');
		$Common = awCommonValues($Tour, $IssueDate);
		$Selected = array_flip(array_map('strval', (array)($_POST['En'] ?? [])));
		$SourceName = ['qual' => 'qualification', 'ind' => 'individual', 'team' => 'team'][$Src];
		$Certs = [];
		foreach($Ranking as $r) {
			if(isset($Selected[$r['Key']])) {
				$Certs[] = ['source' => $SourceName, 'enId' => intval($r['EnId']), 'key' => $r['Key'], 'values' => $Common + awEntryValues($r, $Tpl)];
			}
		}
		foreach(awParseManual($_POST['Manual'] ?? '') as $m) {
			$Certs[] = ['source' => 'manual', 'enId' => 0, 'values' => $Common + awPersonValues($m, $Tpl)];
		}
		if(!$Certs) {
			$Error = '賞状を出す人を選んでください。';
		} elseif(!$Test and (!awEnsureDirs() or !awRecordIssue($TplId, $Certs, ['id' => $Tour['id'], 'code' => $Tour['code'], 'name' => $Tour['name']], $IssueDate, $_POST['Note'] ?? ''))) {
			$Error = '発行履歴を記録できませんでした（data フォルダに書き込めるか確かめてください）。';
		}
	}
	if($Error !== '') {
		$PAGE_TITLE = '賞状の発行';
		$JS_SCRIPT = ['<link href="./award.css" rel="stylesheet" type="text/css">'];
		require_once('Common/Templates/head.php');
		echo '<div class="AwErr">' . awH($Error) . '</div>';
		include('Common/Templates/tail.php');
		exit;
	}
	$pdf = awMakePdf($Tpl, array_column($Certs, 'values'), $Test && !empty($_POST['withPaper']), $Tpl['name']);
	$pdf->Output(($Test ? '試し刷り_' : '賞状_') . $Tpl['name'] . '.pdf', 'I');
	exit;
}

// 手入力の欄: 1 行に 1 枚。タブかカンマで区切って「氏名, 所属, 部門, クラス, 順位, 得点」
function awParseManual($text) {
	$ret = [];
	foreach(preg_split('/\R/u', (string)$text) as $line) {
		if(trim($line) === '') {
			continue;
		}
		$c = array_map('trim', strpos($line, "\t") !== false ? explode("\t", $line) : str_getcsv($line, ',', '"', ''));
		$ret[] = [
			'氏名' => $c[0] ?? '',
			'所属' => $c[1] ?? '',
			'部門' => $c[2] ?? '',
			'クラス' => $c[3] ?? '',
			'順位' => $c[4] ?? '',
			'得点' => $c[5] ?? '',
		];
	}
	return array_slice($ret, 0, 500);
}

$Issued = awIssuedCount($Tour['code'], $TplId);

$PAGE_TITLE = '賞状 - 発行';
$JS_SCRIPT = [
	'<link href="./award.css" rel="stylesheet" type="text/css">',
	'<script>
		function awCheckClass(cb) {
			document.querySelectorAll("input[data-class=\'" + cb.dataset.cls + "\']").forEach(function(c) { c.checked = cb.checked; });
		}
		function awCheckTop(n) {
			document.querySelectorAll("input[name=\'En[]\']").forEach(function(c) { c.checked = parseInt(c.dataset.rank, 10) <= n; });
		}
		// 表彰数の決め方で出した表彰数（種目ごと）までを選ぶ
		function awCheckLimit() {
			document.querySelectorAll("input[name=\'En[]\']").forEach(function(c) { c.checked = c.dataset.limit !== "" && parseInt(c.dataset.rank, 10) >= 1 && parseInt(c.dataset.rank, 10) <= parseInt(c.dataset.limit, 10); });
		}
		// 発行したら、少しあとで画面を読み込み直して「発行済み」を出す
		// PDF は、いつも同じ名前（preview）のウィンドウに開く。すでに開いていれば、そのウィンドウを前に出す
		function awSubmitted(e) {
			var w = window.open("", "preview");
			if(w) { w.focus(); }
			if(e.submitter && e.submitter.value == "issue") {
				setTimeout(function() { location.reload(); }, 2000);
			}
			return true;
		}
	</script>',
];
$IncludeFA = true;
require_once('Common/Templates/head.php');

echo awTabs('issue', $TplId);

echo '<form method="get" style="margin-bottom:1em">';
echo '<input type="hidden" name="tpl" value="' . awH($TplId) . '">';
echo 'テンプレート: <b>' . awH($Tpl['name']) . '</b>';
echo '　順位: <b>' . awH($Sources[$Src]) . '</b>';
echo '　表示する順位: <select name="max" onchange="this.form.submit()">';
foreach([1, 3, 6, 8, 10, 16, 32, 9999] as $n) {
	echo '<option value="' . $n . '"' . ($n == $MaxRank ? ' selected' : '') . '>' . ($n == 9999 ? '全員' : $n . '位まで') . '</option>';
}
echo '</select>';
echo '</form>';

echo '<form method="post" action="Issue.php?tpl=' . awH(rawurlencode($TplId)) . '&max=' . $MaxRank . '" target="preview" onsubmit="return awSubmitted(event)">';
echo awTokenField();

echo '<table class="Tabella freeWidth AwTable">';
echo '<tr><th class="Left">発行日</th><td><input type="date" name="IssueDate" value="' . date('Y-m-d') . '" required> <span class="AwNote">{発行年月日} などに入る日付</span></td></tr>';
echo '<tr><th class="Left">メモ</th><td><input type="text" name="Note" size="50" maxlength="500" placeholder="発行履歴に残すメモ（任意）"></td></tr>';
echo '</table>';

echo '<p>選ぶ: ';
foreach([1, 3, 8] as $n) {
	echo '<button type="button" onclick="awCheckTop(' . $n . ')">' . $n . '位まで</button> ';
}
$Rule = $Tpl['awardRule'];
if(awAwardLimit($Rule, 1) !== null) {
	echo '<button type="button" onclick="awCheckLimit()">表彰数で選ぶ</button> ';
}
echo '<button type="button" onclick="awCheckTop(0)">選ぶのをやめる</button></p>';

// 種目ごとの参加数と表彰数
$Counts = [];
foreach($Ranking as $r) {
	$Counts[$r['Class']] = ($Counts[$r['Class']] ?? 0) + 1;
}

$PreClass = null;
$Rows = 0;
foreach($Ranking as $r) {
	if(intval($r['Ranking']) > $MaxRank) {
		continue;
	}
	$Limit = awAwardLimit($Rule, $Counts[$r['Class']]);
	if($PreClass !== $r['Class']) {
		if($PreClass !== null) {
			echo '</table>';
		}
		$PreClass = $r['Class'];
		$Title = $Src == 'qual' ? $r['Class'] . '　' . $r['DivDescription'] . '部門　' . $r['ClDescription'] : $r['EventName'] . '（' . $r['Class'] . '）';
		echo '<div class="AwClass">' . awH($Title)
			. ' <span class="AwNote">（参加 ' . $Counts[$r['Class']] . ($Limit !== null ? ' → 表彰 ' . $Limit : '') . '）</span>'
			. '<label><input type="checkbox" data-cls="' . awH($r['Class']) . '" onclick="awCheckClass(this)">全員</label></div>';
		echo '<table class="AwAthletes">';
	}
	$n = $Issued[$r['Key']] ?? 0;
	$Rank = intval($r['Ranking']);
	// 表彰数の決め方があれば、表彰する順位で、まだ発行していないものを初めから選んでおく
	$Checked = ($Limit !== null and $Rank >= 1 and $Rank <= $Limit and intval($r['QuScore']) > 0 and !$n);
	$Name = isset($r['Members']) ? $r['Members'] : trim($r['EnFirstName'] . ' ' . $r['EnName']);
	echo '<tr' . ($n ? ' class="AwIssued"' : '') . '><td><label><input type="checkbox" name="En[]" value="' . awH($r['Key']) . '" data-class="' . awH($r['Class']) . '" data-rank="' . $Rank . '" data-limit="' . ($Limit ?? '') . '"' . ($Checked ? ' checked' : '') . '> '
		. ($Rank ? $Rank . '位' : '順位なし') . '</label></td>'
		. '<td>' . awH($Name) . '</td>'
		. '<td>' . awH($r['CoName']) . '</td>'
		. '<td class="AwNum">' . intval($r['QuScore']) . '</td>'
		. '<td>' . ($n ? '<span class="AwBadge">発行済み' . ($n > 1 ? ' ' . $n . '回' : '') . '</span>' : '') . '</td></tr>';
	$Rows++;
}
if($PreClass !== null) {
	echo '</table>';
}
if(!$Rows) {
	echo '<p>' . awH($Sources[$Src]) . 'がありません。</p>';
}

echo '<h3>手入力</h3>';
echo '<div class="AwNote">順位にない人（特別賞など）に出すときに書きます。1 行に 1 枚、タブかカンマで区切って「氏名, 所属, 部門, クラス, 順位, 得点」（表計算ソフトからそのまま貼り付けられます。使わない欄は空で構いません）。</div>';
echo '<textarea name="Manual" rows="4" cols="80" placeholder="京都 花子, 京都アーチェリークラブ, リカーブ, 一般女子, , "></textarea>';

echo '<p>';
echo '<button type="submit" name="mode" value="issue"><b>PDF を出力して発行を記録</b></button>';
echo '　<button type="submit" name="mode" value="test">試し刷り（記録しない）</button>';
echo ' <label><input type="checkbox" name="withPaper" value="1">試し刷りに用紙の画像を重ねる</label>';
echo '</p>';
echo '<p class="AwNote">用紙の画像は印刷しません（試し刷りで「重ねる」を選んだときだけ、位置の確認のために重ねます）。</p>';
echo '</form>';

include('Common/Templates/tail.php');
