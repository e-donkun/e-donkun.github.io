<?php

/*

You can customize your menus adding lines in this file. The structure is as follows:
  · $ret['XXXX'][] = 'Description of the item' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Link/To/Your/page.php';
  OR
  · $ret['XXXX'][] = MENU_DIVIDER;

* Global variables:
- $on: if true, a tournament is selected and open
- $ret['XXXX']: the first level menu items.
  You can insert whatever you want as the key to create a new main menu
  or add your items in the predefined menus.
  A list of first level predefined keys (XXXX) follow:
  · COMP: Competition
  · PART: Participants
  · QUAL: Qualification
  · ELIM: Eliminations
  · FINI: Individual Finals
  · FINT: Team Finals
  · CLUB: Club Team Finals
  · CAST: Cas-Cag Finals
  · PRNT: Printouts
  · HHT:  HHT features
  · MEDI: Media outputs
- MENU_DIVIDER: a constant that writes a separation line in the menu
- $CFG->ROOT_DIR: the prefix for EVERY link you want to insert in your pages.

* Sub menu:
Creating a submenu is straight forward: just add a nested array, giving it a (string)key, as in:
	$ret['XXXX']['YYYY']

* Link to resource
Each menu item is a string, that joins the text description of the item and the link itself with a pipe (|) symbol:
	$ret['XXXX'][] = 'Description of the item' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Link/To/Your/page.php';

*/
	$ret['MEDI'][] = MENU_DIVIDER;
	$ret['MEDI'][] = 'ライブ得点集計' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'LiveScoreboard/LiveScoreboard.php';

	$ret['PRNT'][] = MENU_DIVIDER;
	$ret['PRNT'][] = '賞状PDF出力' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Award/index.php';
	$ret['PRNT'][] = '賞状PDF出力(つつじ賞)' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Award/tsutsuji.php';
	$ret['PRNT'][] = '賞状PDF出力(市ア協)' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Award/OutputCityAssociation.php';
	$ret['PRNT'][] = '賞状PDF出力(近畿大会)' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Award/kinki2026.php';  

if($on AND $acl[AclQualification] == AclReadWrite) {
	/* 標準で廃止されたUSCAAエクスポート・インポートを活かすなら下の３行のコメント外す	*/
        /*      $ret['QUAL']['SCOR'][] = MENU_DIVIDER;
                $ret['QUAL']['SCOR'][] = get_text('MenuLM_GetScoreUSCAA') .'|'.GetWebDirectory(__FILE__).'/index.php';
                $ret['QUAL']['SCOR'][] = get_text('MenuLM_ExportScoreUSCAA') . '|' . GetWebDirectory(__FILE__) . '/export.php';
        */
                $ret['QUAL'][] = MENU_DIVIDER;
                $ret['QUAL'][] = get_text('MenuLM_Export ARF') . '|' . $CFG->ROOT_DIR . 'Modules/Custom/ExportQualAJAF.php';
	/* 拡張版AJAFエクスポートを活かすなら下の２行のコメント外す	*/
        /*      $ret['QUAL'][] = get_text('MenuLM_Import ARF') . '|' . $CFG->ROOT_DIR . 'Modules/Custom/ExportQualAJAF1.php';
                $ret['QUAL'][] = get_text('MenuLM_Export-FR-Results') . '|' . $CFG->ROOT_DIR . 'Modules/Custom/ExportQualAJAF2.php';
        */
	/* ６射計エクスポートを活かすなら下の１行のコメント外す	*/
        /*     $ret['QUAL'][] = 'CSVエクスポート エンド毎' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/ExportQualPerEnd.php';
        */
        }
?>