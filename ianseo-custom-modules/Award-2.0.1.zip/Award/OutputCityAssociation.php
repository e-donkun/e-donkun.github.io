<?php

	ini_set('display_errors', "On");

	require_once(dirname(dirname(__FILE__)) . '/config.php');
	require_once('Common/Lib/Fun_Modules.php');
	require_once('Common/tcpdf/tcpdf.php');

	CheckTourSession(true);
	
	$TourCode=stripslashes($_REQUEST['Tour']);
	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
	if(!($TourId > 0)) {
		die("error!");
	}
	

		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,
			CoCode,CoName,
			QuTargetNo, QuTarget, SUBSTRING(QuTargetNo,2) AS Target,
			QuScore, QuGold, QuXnine,
			ToId,ToGolds AS GoldLabel, ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
		  DivDescription,ClDescription,
		  ToName,ToWhere,ToWhenFrom,
		  CONCAT('令和', YEAR(ToWhenTo) - 2018, '年', DATE_FORMAT(ToWhenTo, '%c月%e日')) as ToWhenTo,ToCode,ToComDescr,
		  
    RANK() OVER (
        PARTITION BY CONCAT(EnDivision, EnClass)
        ORDER BY QuScore DESC, QuGold DESC, QuXnine DESC
    ) AS Ranking

		FROM Entries 
		INNER JOIN Qualifications ON EnId=QuId 
		LEFT JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament 
		LEFT JOIN Tournament ON EnTournament=ToId
		LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType

    INNER JOIN Divisions ON DivTournament=ToId AND DivId=EnDivision    
    INNER JOIN Classes ON ClTournament=ToId AND ClId=EnClass
  	WHERE EnAthlete=1 AND ToId = {$TourId} AND CONCAT(EnDivision,EnClass) LIKE TdClasses";
	//var_dump($Select);
	$Rs=safe_r_sql($Select);

	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}
  
  
	usort($ArrayData, function($a, $b) {
    return $a['Class'] <=> $b['Class']             // Class は昇順
        ?: $b['QuScore'] <=> $a['QuScore']         // QuScore は降順
        ?: $b['QuGold'] <=> $a['QuGold']           // QuGold は降順
        ?: $b['QuXnine'] <=> $a['QuXnine'];        // QuXnine は降順

	});
	
	




	if(empty($_REQUEST["Data"])){
		
		include('Common/Templates/head.php');
    
    
    $classCounts = [];

    foreach ($ArrayData as $Data) {
        $class = $Data['Class'];
        if (!isset($classCounts[$class])) {
            $classCounts[$class] = 0;
        }
        $classCounts[$class]++;
    }
		
    echo <<<EOT
<style>
  .select-row {
    display: block;
    padding: 5px;
    cursor: pointer;
    font-size:1.5em;
  }
  .select-row.checked {
    background-color: yellow;
  }

@media print {
  .no-print {
    display: none !important;
  }
  .select-row.checked {
    background-color: #eee;
  }
  .select-row:not(.checked) {
    color:gray;
    font-size:0.9em;
  }
}
</style>

<script>
  function toggleRow(checkbox) {
    const label = checkbox.closest('label');
    if (checkbox.checked) {
      label.classList.add('checked');
    } else {
      label.classList.remove('checked');
    }
  }
</script>
EOT;
echo "<h1 class='no-print'>賞状発行</h1>";
    
$awardlimit = null;
$preClass = null;
$linecnt = 0;
echo "<form method='post' target='_blank'>";
echo "<input type='submit' value='PDF出力' class='no-print'>";
foreach($ArrayData as $no => $Data){
    if( $preClass != $Data['Class'] ) { 
        $awardLimit = getAwardLimit($classCounts[$Data['Class']]);
        echo "<hr>"; 
        echo "<h2>{$Data['Class']} {$Data['DivDescription']}部門 {$Data['ClDescription']}";
        echo "(参加者数{$classCounts[$Data['Class']]}→表彰数{$awardLimit})</h2>";
        $rank=1;
        $linecnt = 0;
    }
    $linecnt++;
    $preClass = $Data['Class'] ;
    if(intval($Data['Ranking'])>($awardLimit+2) || ( $Data['QuScore'] == 0 && $linecnt > 1)){
      echo "○";
      continue;
    }

    $checked = ($Data['Ranking']<=$awardLimit && $Data['QuScore']>0) ? "checked" : "" ;
    echo "<label class='select-row {$checked}'>";
    echo (($Data['QuScore']>0) ? "{$Data['Ranking']}位 " : "出力テスト" );
    echo "<input type='checkbox' name='Data[]' value='{$no}' class='no-print' onchange='toggleRow(this)' {$checked}> ";
    echo "{$Data['EnFirstName']} {$Data['EnName']} ";
    echo "{$Data['QuScore']} ";
    echo "{$Data['CoName']} ";
    echo "</label>";
}
echo "<hr>";
echo "</form>";
/*   
		$preClass = null;
		echo "<form method='post'>";
		foreach($ArrayData as $no => $Data){
			if( $preClass != $Data['Class'] ) { 
				echo "<hr>"; 
				echo "{$Data['Class']} {$Data['DivDescription']}部門 {$Data['ClDescription']}<br>";
				$rank=1;
			}
			$preClass = $Data['Class'] ;
			if(intval($Data['Ranking'])>8) continue;
			echo "{$Data['Ranking']}位";
			echo "<input type='checkbox' name='Data[]' value='{$no}'>";
			echo "{$Data['EnFirstName']} {$Data['EnName']} ";
			echo "{$Data['QuScore']}";
			echo "{$Data['CoName']} ";
			echo "<br>";
		} 
		echo "<hr><input type='submit' value='PDF出力'>";
		echo "</form>";
*/

		include('Common/Templates/tail.php');
	
	} else {
		
		
		$filteredArrayData = array_map(function($index) use ($ArrayData) {
			return $ArrayData[$index];
		}, $_REQUEST["Data"]);

		
		$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
		$pdf->setAutoPageBreak(false, 0);
		$pdf->setPrintHeader(false);
		$pdf->setPrintFooter(false);

		
		$pdf->setFontSize(12);
		$pdf->setMargins(20, 20, 20);
		$pdf->setCellPadding(0);

		$paper_w = 210;	  
		$paper_h = 297;
		$pageoffset_y = 40;
		$pageoffset_x = 0;
		
		// IPAフォント埋め込み
		$font = new TCPDF_FONTS();   
		$fontfile = 'fonts/YujiSyuku-Regular.ttf';
		$myFont = $font->addTTFfont($fontfile);
		
		foreach($filteredArrayData as $Data){
			
			$pdf->AddPage();
			
			// 1. 表題（上部に大きく配置）
			$pdf->SetFont($myFont, '', 56);
			$pdf->Ln(20);
			$pdf->Cell(0, 30, '表  彰  状', 0, 1, 'C');
			
			// 2. カテゴリー
			$pdf->SetXY(50, 80);
			$pdf->SetFont($myFont, '', 24);
			$category_text = "{$Data['DivDescription']}{$Data['ClDescription']}";
			$category_text_zenkaku = mb_convert_kana($category_text, "RNS");
			$pdf->Cell(0, 10, $category_text_zenkaku, 0, 1);
			
			// 3. 氏名
			$pdf->SetXY(60, 95);
			$pdf->SetFont($myFont, '', 24);
			$club_name_text = "{$Data['CoName']}";
			$club_name_text_zenkaku = mb_convert_kana($club_name_text, "RNS");
			$pdf->Cell(0, 10, $club_name_text_zenkaku, 0, 1);
			$pdf->SetXY(80, 110);
			$pdf->SetFont($myFont, '', 30);
			$pdf->Cell(0, 10, "{$Data['EnFirstName']} {$Data['EnName']}　殿", 0, 1);
			
			// 4. 成績
			$pdf->SetXY(60, 130);
			$pdf->SetFont($myFont, '', 30);
			$result_text = "第{$Data['Ranking']}位　　{$Data['QuScore']}点";
			$result_text_zenkaku = mb_convert_kana($result_text, "RNS");
			$pdf->Cell(0, 10, $result_text_zenkaku, 0, 1);
			
			// 5. 本文
			$pdf->SetXY(35, 155);
			$pdf->SetFont($myFont, '', 24);
			$body_text = "あなたは{$Data['ToName']}において頭書の成績を収められましたのでその栄誉を称えこれを表彰します。";
			$body_text_zenkaku = mb_convert_kana($body_text, "RNS");
			$pdf->MultiCell(150, 10, $body_text_zenkaku, 0, 'J', false, 1, 32); 
			
			// 6. 日付・発行者（下部に配置）
			$pdf->SetXY(65, 220);
			$pdf->SetFont($myFont, '', 20);
			$date_text = "{$Data['ToWhenTo']}";
			$date_text_zenkaku = mb_convert_kana($date_text, "RNS");
			$pdf->Cell(0, 10, $date_text_zenkaku, 0, 1);
			$pdf->SetXY(65, 232);
			$pdf->Cell(0, 10, "京都市アーチェリー協会", 0, 1);
			$pdf->SetXY(65, 245);
			$pdf->Cell(0, 10, "会　長　　　深   尾     博", 0, 1);
			
			// 印鑑
			$pdf->Image("stamp_city_association.png", 145, 230, 25, 25, '','',null,false,300);
		}
		
		$pdf->Output();
	
	}
	
	
	
function tateText($x, $y, $str, $size, $width=1.1) {
	global $pdf, $myFont;
	//フォントサイズ設定
	$pdf->SetFont($myFont, '', $size);
	//字間
	$fh = pt2mm($size*$width);
	//文字数
	
	$str = mb_convert_kana($str,"ASK", 'UTF-8');
	$l = mb_strlen($str, 'UTF-8');
	for ($i=0; $i<$l; $i++) {
		$s1 = mb_substr($str, $i, 1, 'UTF-8');
		$adj_x = 0; $adj_y = 0;
		// 文字ごとの位置や回転調整
		switch($s1){
			case '「':
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.5);
				$adj_rotate_posi_x = pt2mm($size*0.4);
				$adj_rotate_posi_y = 0;
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
        break;
			case '」':
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.5);
				$adj_rotate_posi_x = pt2mm($size*0.4);
				$adj_rotate_posi_y = pt2mm($size*0.3);
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
        break;
			case '（':
			case '）':
			case '《':
			case '》':
			case '～':
			case 'ー':
			case '〔':
			case '〕':
			case '【':
			case '】':      
				//$adj_rotate_x = pt2mm($size);
				//$adj_rotate_y = pt2mm($size*0.3);
				//$adj_rotate_posi_x = pt2mm($size*0.7);
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.4);
				$adj_rotate_posi_x = pt2mm($size*0.75);
				if($size<=12){
					$adj_rotate_posi_y = pt2mm($size*0.15);
				}else{
					$adj_rotate_posi_y = pt2mm($size*0.2);
				}
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
        break;
			case '。':
			case '、':
				$adj_x = $fh * 0.7; $adj_y = -$fh * 0.7;
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
        break;
			case 'っ':
			case 'ッ':
				$adj_x = pt2mm($size*0.1);
				$adj_y = -1*pt2mm($size*0.1);
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
        break;
			default:
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
        break;
		}
	}
}

function convertToKanjiDate($raw_date) {
    // 日付を年、月、日に分割
    
    $date = new DateTime($raw_date);

    $year  = $date->format('Y');
    $month = $date->format('n');
    $day   = $date->format('j');

    // 変換用配列
    $numMap = ['0'=>'〇', '1'=>'一', '2'=>'二', '3'=>'三', '4'=>'四', '5'=>'五', '6'=>'六', '7'=>'七', '8'=>'八', '9'=>'九'];

    // 1. 年の変換（一文字ずつ置換）
    $kanjiYear = strtr($year, $numMap);

    // 2. 月・日の変換ロジック
    $convertMD = function($num) use ($numMap) {
        $n = (int)$num;
        if ($n === 10) return '十';
        if ($n < 10) return $numMap[$n];
        if ($n < 20) return '十' . $numMap[$n % 10];
        if ($n % 10 === 0) return $numMap[$n / 10] . '十';
        return $numMap[(int)($n / 10)] . '十' . $numMap[$n % 10];
    };

    $kanjiMonth = $convertMD($month);
    $kanjiDay = $convertMD($day);

    return "{$kanjiYear}年{$kanjiMonth}月{$kanjiDay}日";
}

// 1 インチ = 25.4 ミリメートル
// 1 ポイント = 1/72 インチ
// 1mm　は、 25.4分の1インチ
function mm2pt($mm) {
	$pt = $mm / 25.4 * 72;
	return $pt;
}
function pt2mm($pt) {
	$mm = $pt / 72  * 25.4;
	return $mm;
}



function numberToKanji($number) {
    $kanjiNumbers = ['〇', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
    $kanjiUnits = ['', '十', '百', '千'];
    $kanjiBigUnits = ['', '万', '億', '兆'];

    if ($number == 0) return $kanjiNumbers[0];

    $result = '';
    $strNumber = strval($number);
    $length = strlen($strNumber);
    $groupCount = ceil($length / 4);

    for ($i = 0; $i < $groupCount; $i++) {
        $group = substr($strNumber, -4 * ($i + 1), 4);
        $group = str_pad($group, 4, '0', STR_PAD_LEFT);
        $groupKanji = '';

        for ($j = 0; $j < 4; $j++) {
            $digit = intval($group[$j]);
            if ($digit !== 0) {
                $groupKanji .= ($digit === 1 && $j !== 3) ? $kanjiUnits[3 - $j] : $kanjiNumbers[$digit] . $kanjiUnits[3 - $j];
            }
        }

        if ($groupKanji !== '') {
            $result = $groupKanji . $kanjiBigUnits[$i] . $result;
        }
    }

    return $result;
}


function getAwardLimit($participantCount) {
    if ($participantCount <= 3) {
        return 1;
    } elseif ($participantCount <= 5) {
        return 2;
    } elseif ($participantCount <= 7) {
        return 3;
    } elseif ($participantCount <= 9) {
        return 4;
    } elseif ($participantCount <= 11) {
        return 5;
    } else {
        return 6;
    }
}
