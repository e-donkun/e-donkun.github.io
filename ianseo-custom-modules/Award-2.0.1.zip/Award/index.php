<?php
/*
賞状のテンプレートの一覧。
テンプレートの新規作成・編集・複製・削除、別の ianseo に持っていくための書き出し・読み込みをする。
テンプレートは試合ごとではなく、この ianseo 全体で共通（data/templates に保存）。
- 一覧を見る・発行するのは、予選の印刷ができる人（awCanView）
- 作る・変える・消すのは、大会のデータを変えられる人（awCanEdit）

変更履歴:
2026/09/30 名前を押すと編集の画面へ。表のボタンは複製・削除・書き出しの 3 つだけにした（発行は、編集の画面の上のタブ「賞状発行」から）
2026/09/30 テンプレート選択の画面にした。見本から追加する機能をやめた（見本は data/templates に置いてある）
2026/09/26 テンプレートの一覧にした（賞状の出力は Issue.php へ移した）
2026/09/23 初版（予選の順位から賞状の PDF を出力）
*/
require_once(dirname(dirname(__FILE__)) . '/config.php');
require_once('Common/Lib/CommonLib.php');
require_once(__DIR__ . '/Lib.php');

CheckTourSession(true);
if(!awCanView()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}
$CanEdit = awCanEdit();
$Writable = awEnsureDirs();
$Errors = [];
$Msg = $_GET['msg'] ?? '';

// 書き出し（画像も中に入れた JSON）
if(isset($_GET['export']) and ($t = awLoadTemplate($_GET['export']))) {
	$out = awExportTemplate($t);
	header('Content-Type: application/json; charset=utf-8');
	header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode('賞状テンプレート_' . $t['name'] . '.json'));
	echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	$Act = $_POST['act'] ?? '';
	if(!$CanEdit) {
		$Errors[] = 'テンプレートを変更する権限がありません。';
	} elseif(!awCheckToken()) {
		$Errors[] = '画面の有効期限が切れました。もう一度操作してください。';
	} elseif(!$Writable) {
		$Errors[] = 'data フォルダに書き込めません。';
	} elseif($Act == 'new') {
		if($t = awSaveTemplate(awNewTemplate())) {
			CD_redirect('Edit.php?id=' . $t['id']);
		}
		$Errors[] = 'テンプレートを作れませんでした。';
	} elseif($Act == 'copy' and ($t = awLoadTemplate($_POST['id'] ?? ''))) {
		$t['id'] = '';
		$t['name'] .= ' のコピー';
		$t['createdAt'] = '';
		if($t = awSaveTemplate($t)) {
			CD_redirect('Edit.php?id=' . $t['id']);
		}
		$Errors[] = 'テンプレートを複製できませんでした。';
	} elseif($Act == 'delete' and ($t = awLoadTemplate($_POST['id'] ?? ''))) {
		awDeleteTemplate($t['id']);
		CD_redirect('index.php?msg=' . rawurlencode('「' . $t['name'] . '」を削除しました。発行履歴は残っています。'));
	} elseif($Act == 'import') {
		$f = $_FILES['file'] ?? null;
		if(!is_array($f) or ($f['error'] ?? UPLOAD_ERR_NO_FILE) != UPLOAD_ERR_OK or !is_uploaded_file($f['tmp_name'])) {
			$r = 'ファイルを受け取れませんでした。';
		} else {
			$r = awImportTemplate(file_get_contents($f['tmp_name']));
		}
		if(is_array($r)) {
			CD_redirect('Edit.php?id=' . $r['id']);
		}
		$Errors[] = $r;
	}
}

$Templates = awListTemplates();

$PAGE_TITLE = '賞状 - テンプレート';
$JS_SCRIPT = ['<link href="./award.css" rel="stylesheet" type="text/css">'];
$IncludeFA = true;
require_once('Common/Templates/head.php');

echo awTabs('index');
if(!$Writable) {
	echo '<div class="AwErr">' . awH(AW_DATA_DIR) . ' に書き込めません。フォルダを作って、Web サーバーが書き込めるようにしてください。</div>';
}
if($Msg !== '') {
	echo '<div class="AwMsg">' . awH($Msg) . '</div>';
}
foreach($Errors as $e) {
	echo '<div class="AwErr">' . awH($e) . '</div>';
}


if(!$Templates) {
	echo '<p>テンプレートがまだありません。' . ($CanEdit ? '「新しいテンプレート」から作ってください。' : '') . '</p>';
} else {
	echo '<table class="Tabella freeWidth AwTable">';
	echo '<tr><th>名前</th><th>書き方</th><th>用紙</th><th>項目</th><th>更新</th>' . ($CanEdit ? '<th></th>' : '') . '</tr>';
	foreach($Templates as $t) {
		$texts = count(array_filter($t['items'], function($i) { return $i['type'] == 'text'; }));
		$images = count($t['items']) - $texts;
		echo '<tr>';
		// 名前を押すと、編集の画面へ（編集できない人は発行の画面へ）
		$Link = $CanEdit ? 'Edit.php?id=' . rawurlencode($t['id']) : 'Issue.php?tpl=' . rawurlencode($t['id']);
		echo '<td><a href="' . awH($Link) . '"><b>' . awH($t['name']) . '</b></a>' . ($t['note'] !== '' ? '<br><span class="AwNote">' . nl2br(awH($t['note'])) . '</span>' : '') . '</td>';
		echo '<td>' . ($t['direction'] == 'vertical' ? '縦書き' : '横書き') . '</td>';
		echo '<td>' . awH($t['paper']['size'] == 'custom' ? $t['paper']['width'] . '×' . $t['paper']['height'] . 'mm' : $t['paper']['size'] . ($t['paper']['orientation'] == 'L' ? ' 横' : ' 縦'))
			. ($t['paper']['image'] ? '<br><img class="AwThumb" src="' . awH(awImageUrl($t['paper']['image'])) . '" alt="">' : '') . '</td>';
		echo '<td>テキスト ' . $texts . ($images ? '<br>画像 ' . $images : '') . '</td>';
		echo '<td>' . awH($t['updatedAt']) . '</td>';
		if($CanEdit) {
			// 複製・削除・書き出しの 3 つのボタン
			echo '<td class="AwBtns">';
			echo '<form method="post">' . awTokenField() . '<input type="hidden" name="act" value="copy"><input type="hidden" name="id" value="' . awH($t['id']) . '"><button type="submit">複製</button></form>';
			echo '<form method="post" onsubmit="return confirm(\'「' . awH(addslashes($t['name'])) . '」を削除しますか？（発行履歴は残ります）\')">' . awTokenField() . '<input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="' . awH($t['id']) . '"><button type="submit" class="AwDanger">削除</button></form>';
			echo '<form method="get"><input type="hidden" name="export" value="' . awH($t['id']) . '"><button type="submit">書き出し</button></form>';
			echo '</td>';
		}
		echo '</tr>';
	}
	echo '</table>';
}

if($CanEdit and $Writable) {
	echo '<p><form method="post">' . awTokenField() . '<input type="hidden" name="act" value="new"><button type="submit">新しいテンプレート</button></form></p>';
	echo '<form method="post" enctype="multipart/form-data">' . awTokenField() . '<input type="hidden" name="act" value="import">';
	echo 'テンプレートの読み込み（「書き出し」で保存した .json）: <input type="file" name="file" accept=".json,application/json" required> <button type="submit">読み込む</button>';
	echo '</form>';
}

include('Common/Templates/tail.php');
