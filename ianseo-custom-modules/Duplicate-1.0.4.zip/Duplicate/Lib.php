<?php
/*
既存の大会をテンプレートにして新しい大会を作るための関数。

本体の大会エクスポート（export_tournament）で元の大会を配列に書き出し、
設定にあたるテーブルだけを残してから、本体の大会インポート（tour_import）で新しい大会として取り込む。
- 選手・所属・スタッフ、点数・順位・組み合わせ、ISK の受信データ、ログなどはコピーしない
- 残すテーブルはホワイトリスト（DUP_COPY_TABLES）。ianseo の更新で増えたテーブルは、ここに足すまでコピーされない
- 日付の入った設定（セッション、距離ごとの時刻、スケジュール、決勝の時刻、練習）は、開始日のずれの分だけ日付をずらす
- 決勝の空の組み合わせ表（Finals / TeamFinals）は、取り込んだあとに本体の CreateFinals で作る
- ラウンドロビンの対戦（RoundRobinMatches）と参加枠（RoundRobinParticipants）は、設定にあたる列（DUP_KEEP_COLUMNS）だけを残してコピーする

ianseo 本体の更新への備え:
- 本体のファイルは変更せず、本体の関数（export_tournament / tour_import / CreateFinals）を使う
- 列の値を書き換えるときは、その列があるときだけ書き換える（本体の更新で列がなくなっても、存在しない列への書き込みで失敗しない）
- 本体の更新でテーブルが増えても、DUP_COPY_TABLES に足すまではコピーしない（コピーされないだけで、失敗はしない）
- テーブルに列が増えた場合、DUP_KEEP_COLUMNS のテーブルでは初期値のまま、それ以外のテーブルでは元の大会の値がコピーされる

tour_import は同じ大会コードの大会があると先に削除してしまうので、新しいコードが使われていないことを必ず確認してから呼ぶ。

変更履歴:
2026/09/26 ラウンドロビンの段階間の進出設定と最終段階の枠をコピーするように修正。本体の更新で列がなくなっても失敗しないようにした
2026/09/25 初版
*/

require_once('Common/Lib/Fun_Export.php');
require_once('Common/Fun_TourDelete.php');
require_once('Modules/Sets/lib.php');

// Tournament 以外にコピーするテーブル
const DUP_COPY_TABLES = [
	'AccColors', 'AccPrice', 'ACL', 'AclDetails', 'AclTemplates',
	'AvailableTarget', 'Awards', 'BackNumber',
	'Classes', 'ClassWaEquivalents', 'Divisions', 'SubClass',
	'DistanceInformation', 'TournamentDistances', 'Session', 'TargetFaces', 'TargetGroups',
	'Events', 'EventClass', 'VegasAwards',
	'Scheduler', 'FinSchedule', 'FinWarmup',
	'RoundRobinLevel', 'RoundRobinGroup', 'RoundRobinGrids', 'RoundRobinMatches', 'RoundRobinParticipants',
	'IdCards', 'IdCardElements', 'Images', 'Emails',
	'ModulesParameters',
	'RecAreas', 'RecTournament', 'TourRecords',
	'TVContents', 'TVParams', 'TVRules', 'TVSequence',
];

// 設定と進行中の状態が同じ行に入っているテーブル。設定の列だけ残し、ほかの列（点数・順位など）は初期値にする
// 選手・チームを指す列（RrMatchAthlete / RrPartParticipant）は、tour_import が読むので 0 にして残す
const DUP_KEEP_COLUMNS = [
	'RoundRobinMatches' => [
		'RrMatchTournament', 'RrMatchTeam', 'RrMatchEvent', 'RrMatchLevel', 'RrMatchGroup', 'RrMatchRound', 'RrMatchMatchNo',
		'RrMatchTarget', 'RrMatchScheduledDate', 'RrMatchScheduledTime', 'RrMatchScheduledLength',
		'RrMatchAthlete',
	],
	'RoundRobinParticipants' => [
		'RrPartTournament', 'RrPartTeam', 'RrPartEvent', 'RrPartLevel', 'RrPartGroup',
		'RrPartSourceLevel', 'RrPartSourceGroup', 'RrPartSourceRank', 'RrPartDestItem',
		'RrPartParticipant',
	],
];

// ModulesParameters のうち、進行中の状態なのでコピーしないもの（モジュール => パラメータ。null はモジュールごと）
const DUP_SKIP_PARAMETERS = [
	'ISK-NG' => ['Sequence', 'AutoImport', 'PartialImport', 'LockedSessions', 'Snapshot'],
	'ISK' => ['Sequence', 'AutoImport', 'PartialImport', 'LockedSessions', 'Snapshot'],
	'ODF' => null,
	'SendToIanseo' => null,
];

/**
 * ログイン認証が有効なとき、このユーザーが扱える大会に絞る SQL の条件。認証が無効なら空文字
 */
function dupAuthFilter() {
	global $CFG;
	if(!($CFG->USERAUTH and !empty($_SESSION['AUTH_ENABLE']) and empty($_SESSION['AUTH_ROOT']))) {
		return '';
	}
	$Filter = [];
	$CompList = [];
	foreach($_SESSION['AUTH_COMP'] ?? [] as $Comp) {
		if(str_contains($Comp, '%')) {
			$Filter[] = 'ToCode LIKE ' . StrSafe_DB($Comp);
		} else {
			$CompList[] = $Comp;
		}
	}
	if($CompList) {
		$Filter[] = 'FIND_IN_SET(ToCode, ' . StrSafe_DB(implode(',', $CompList)) . ') != 0';
	}
	return '(' . ($Filter ? implode(' OR ', $Filter) : 'FALSE') . ')';
}

/**
 * 複製元に選べる大会の一覧（新しい順）
 */
function dupSourceList() {
	$Filter = dupAuthFilter();
	$Ret = [];
	$q = safe_r_sql("select ToId, ToCode, ToName, ToNameShort, ToWhenFrom, ToWhenTo
		from Tournament
		" . ($Filter ? "where $Filter" : '') . "
		order by ToWhenFrom desc, ToCode");
	while($r = safe_fetch($q)) {
		$Ret[$r->ToId] = $r;
	}
	return $Ret;
}

/**
 * 新しい大会コードを作れるか。ログイン認証が有効なときは、そのコードの大会を作る権限が必要
 */
function dupCanCreate($ToCode=null) {
	global $CFG;
	if($CFG->USERAUTH and !empty($_SESSION['AUTH_ENABLE']) and empty($_SESSION['AUTH_ROOT'])) {
		return possibleFeature(AclRoot, AclReadWrite, $ToCode);
	}
	return subFeatureAcl(actualACL(), AclRoot) == AclReadWrite;
}

/**
 * 日付（Y-m-d）または日時（Y-m-d H:i:s）を $Days 日ずらす。空や 0000-00-00 はそのまま
 */
function dupShiftDate($Value, $Days) {
	if(!$Days or !is_string($Value) or !preg_match('/^(\d{4}-\d{2}-\d{2})(.*)$/', $Value, $m) or $m[1] == '0000-00-00') {
		return $Value;
	}
	$Date = DateTime::createFromFormat('!Y-m-d', $m[1]);
	if(!$Date) {
		return $Value;
	}
	$Date->modify(($Days > 0 ? '+' : '') . $Days . ' days');
	return $Date->format('Y-m-d') . $m[2];
}

/**
 * $Rows（行の配列）の各行で、$Values の列を書き換える。行にない列は書き換えない
 */
function dupSetColumns(&$Rows, $Values) {
	foreach($Rows as $k => $r) {
		foreach($Values as $Col => $Value) {
			if(array_key_exists($Col, $r)) {
				$Rows[$k][$Col] = $Value;
			}
		}
	}
}

/**
 * 入力を確かめる。問題があればメッセージの配列を返す
 * $Data: SrcId, ToCode, ToName, ToNameShort, WhenFrom, WhenTo
 */
function dupValidate($Data, $Sources) {
	$Errors = [];
	if(empty($Sources[$Data['SrcId']])) {
		$Errors[] = '複製元の大会を選んでください。';
	}
	if($Data['ToCode'] === '') {
		$Errors[] = '大会コードを入力してください。';
	} elseif(!preg_match('/^[0-9a-z._-]{1,8}$/i', $Data['ToCode'])) {
		$Errors[] = '大会コードは半角の英数字と . _ - で、8文字以内にしてください。';
	} else {
		$q = safe_r_sql("select ToId from Tournament where ToCode=" . StrSafe_DB($Data['ToCode']));
		if(safe_num_rows($q)) {
			$Errors[] = '大会コード「' . $Data['ToCode'] . '」はすでに使われています。別のコードにしてください。';
		} elseif(!dupCanCreate($Data['ToCode'])) {
			$Errors[] = '大会コード「' . $Data['ToCode'] . '」の大会を作る権限がありません。';
		}
	}
	if(trim($Data['ToName']) === '') {
		$Errors[] = '大会名を入力してください。';
	}
	$From = DateTime::createFromFormat('!Y-m-d', $Data['WhenFrom']);
	$To = DateTime::createFromFormat('!Y-m-d', $Data['WhenTo']);
	if(!$From or $From->format('Y-m-d') != $Data['WhenFrom'] or !$To or $To->format('Y-m-d') != $Data['WhenTo']) {
		$Errors[] = '開始日と終了日を正しく入力してください。';
	} elseif($To < $From) {
		$Errors[] = '終了日は開始日と同じか、それより後にしてください。';
	}
	return $Errors;
}

/**
 * 元の大会の設定をコピーして新しい大会を作る。入力は dupValidate で確認済みであること
 * 戻り値: 新しい大会の ToId。失敗したら 0
 */
function dupCloneTournament($Data) {
	$SrcId = intval($Data['SrcId']);
	$Gara = export_tournament($SrcId);
	$SrcCode = $Gara['Tournament']['ToCode'];
	$Days = intval((new DateTime($Gara['Tournament']['ToWhenFrom']))->diff(new DateTime($Data['WhenFrom']))->format('%r%a'));

	// ホワイトリストにないテーブルは捨てる
	foreach(array_keys($Gara) as $Tab) {
		if($Tab != 'Tournament' and !in_array($Tab, DUP_COPY_TABLES)) {
			unset($Gara[$Tab]);
		}
	}

	// 大会の基本情報
	$Gara['Tournament']['ToCode'] = $Data['ToCode'];
	$Gara['Tournament']['ToName'] = $Data['ToName'];
	$Gara['Tournament']['ToNameShort'] = $Data['ToNameShort'];
	$Gara['Tournament']['ToWhenFrom'] = $Data['WhenFrom'];
	$Gara['Tournament']['ToWhenTo'] = $Data['WhenTo'];
	$Tour = [$Gara['Tournament']];
	dupSetColumns($Tour, [
		'ToOnlineId' => 0, // ianseo.net への結果送信先は引き継がない
		'ToBlock' => 0,    // 編集のロックは外す
	]);
	$Gara['Tournament'] = $Tour[0];
	if(!empty($Gara['Tournament']['ToOptions']) and is_array($Options = @unserialize($Gara['Tournament']['ToOptions']))) {
		unset($Options['ActiveSession']);
		$Gara['Tournament']['ToOptions'] = serialize($Options);
	}

	// AccPrice の APId はサーバー全体の通し番号。そのまま入れると元の大会の行を上書きしてしまう
	foreach($Gara['AccPrice'] ?? [] as $k => $r) {
		unset($Gara['AccPrice'][$k]['APId']);
	}

	// 進行中の状態を初期値に戻す
	$Reset = [
		// 種目: シュートオフの解決、結果のロック、最終更新
		'Events' => ['EvShootOff' => 0, 'EvE1ShootOff' => 0, 'EvE2ShootOff' => 0, 'EvLockResults' => 0, 'EvQualLastUpdate' => null, 'EvFinalLastUpdate' => null],
		'RoundRobinLevel' => ['RrLevSoSolved' => 0],
		'RoundRobinGroup' => ['RrGrSoSolved' => 0],
		'Emails' => ['EmSentDate' => '0000-00-00 00:00:00'],
		// 決勝の審判はスタッフ（コピーしない）を指している
		'FinSchedule' => ['FsLJudge' => 0, 'FsTJudge' => 0],
	];
	foreach($Reset as $Tab => $Values) {
		if(isset($Gara[$Tab])) {
			dupSetColumns($Gara[$Tab], $Values);
		}
	}

	// 設定の列だけ残す。選手・チームを指す列は 0 にする
	foreach(DUP_KEEP_COLUMNS as $Tab => $Cols) {
		foreach($Gara[$Tab] ?? [] as $k => $r) {
			$Gara[$Tab][$k] = array_intersect_key($r, array_flip($Cols));
		}
	}
	if(isset($Gara['RoundRobinMatches'])) {
		dupSetColumns($Gara['RoundRobinMatches'], ['RrMatchAthlete' => 0]);
	}
	if(isset($Gara['RoundRobinParticipants'])) {
		dupSetColumns($Gara['RoundRobinParticipants'], ['RrPartParticipant' => 0]);
	}

	// モジュールの設定。進行中の状態は捨て、大会コードの入った QR 設定は新しいコードにする
	foreach($Gara['ModulesParameters'] ?? [] as $k => $r) {
		$Module = $r['MpModule'];
		if(array_key_exists($Module, DUP_SKIP_PARAMETERS)
				and (DUP_SKIP_PARAMETERS[$Module] === null or in_array($r['MpParameter'], DUP_SKIP_PARAMETERS[$Module]))) {
			unset($Gara['ModulesParameters'][$k]);
			continue;
		}
		if($Module == 'ISK-NG' and $r['MpParameter'] == 'QRCode-Setup'
				and is_array($Value = @unserialize($r['MpValue'])) and isset($Value['c'])) {
			$Parts = explode('|', $Value['c'], 2);
			if($Parts[0] == $SrcCode) {
				$Parts[0] = $Data['ToCode'];
				$Value['c'] = implode('|', $Parts);
				$Gara['ModulesParameters'][$k]['MpValue'] = serialize($Value);
			}
		}
	}

	// 日付を開始日のずれの分だけずらす
	$DateFields = [
		'Session' => ['SesDtStart', 'SesDtEnd'],
		'DistanceInformation' => ['DiDay'],
		'Scheduler' => ['SchDay', 'SchDateStart', 'SchDateEnd'],
		'FinSchedule' => ['FSScheduledDate'],
		'FinWarmup' => ['FwDay'],
		'RoundRobinMatches' => ['RrMatchScheduledDate'],
	];
	foreach($DateFields as $Tab => $Fields) {
		foreach($Gara[$Tab] ?? [] as $k => $r) {
			foreach($Fields as $Field) {
				if(isset($r[$Field])) {
					$Gara[$Tab][$k][$Field] = dupShiftDate($r[$Field], $Days);
				}
			}
		}
	}

	// ここまでで新しいコードが使われていないことは確認済み（使われていると tour_import が先に削除してしまう）
	$NewId = tour_import(gzcompress(serialize($Gara), 9), true);
	if(!$NewId) {
		return 0;
	}

	// 決勝の空の組み合わせ表
	CreateFinals($NewId);

	return $NewId;
}
