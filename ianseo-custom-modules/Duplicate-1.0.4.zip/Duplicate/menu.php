<?php
/*
大会メニューに「既存の大会から複製」を追加する。
大会情報が選ばれていないとき（大会を開いていないとき）だけ、「大会情報をインポート」のすぐ下に出す。
大会を新規作成できる権限（Common/Menu.php の「新規作成」と同じ条件）があるときだけ表示する。

変更履歴:
2026/11/10 名前を「既存の試合から新規作成」から「既存の大会から複製」に変える
2026/11/10 大会を開いていないときだけ、「大会情報をインポート」のすぐ下に出す
2026/09/25 初版
*/
if(empty($on) and isset($acl) and (subFeatureAcl($acl, AclRoot) == AclReadWrite or possibleFeature(AclRoot, AclReadWrite))) {
	$DuplicateItem = '既存の大会から複製' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/Duplicate/index.php';
	$DuplicateMenu = [];
	$DuplicateDone = false;
	foreach($ret['COMP'] ?? [] as $k => $v) {
		if(is_int($k)) {
			$DuplicateMenu[] = $v;
		} else {
			$DuplicateMenu[$k] = $v;
		}
		if(!$DuplicateDone and is_string($v) and strpos($v, 'Tournament/TournamentImport.php') !== false) {
			$DuplicateMenu[] = $DuplicateItem;
			$DuplicateDone = true;
		}
	}
	if(!$DuplicateDone) {
		$DuplicateMenu[] = MENU_DIVIDER;
		$DuplicateMenu[] = $DuplicateItem;
	}
	$ret['COMP'] = $DuplicateMenu;
}
