<?php
/*
カスタムモジュール管理: インストール済みのモジュール（WordPress の「インストール済みプラグイン」のような画面）。
- Modules/Custom の下のモジュールを一覧にして、有効・無効を切り替える
- 無効にしたモジュールを削除する
- 配布サイトのカタログに新しい版があれば、そのモジュールの下にお知らせを出し、「今すぐ更新」で更新する
  （WordPress と同じく、更新は確認するだけで、自動では入れない。確認は State.php・CheckUpdates.php）
- 「更新を確認」で、配布サイトのカタログを受信し直す
モジュールの追加は Add.php、パッケージ（配布用 zip）の作成は Package.php。
管理者（本体の「更新」を使える人）だけが使える。

変更履歴:
2026/09/26 更新のお知らせと「更新を確認」を追加、状態の列を折り返さないようにする
2026/09/26 パッケージ情報（動作確認した ianseo の版など）を表示、追加の画面を Add.php に分ける
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');

if(!cmCanManage()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	cmRequireToken('index.php');
	@set_time_limit(600);
	$Id = (string)($_POST['id'] ?? '');
	switch($_POST['act'] ?? '') {
		case 'enable':
			$Ret = cmSetEnabled($Id, true);
			break;
		case 'disable':
			$Ret = cmSetEnabled($Id, false);
			break;
		case 'delete':
			$Ret = cmDelete($Id);
			break;
		case 'update':
			$Ret = cmInstallFromCatalog($Id);
			break;
		case 'check':
			$Ret = cmCheckUpdates(true) ?? [false, 'ほかで更新を確認中です。しばらくしてから開き直してください。'];
			if($Ret[0]) {
				$Count = count(cmUpdates());
				$Ret[1] = $Count ? '更新があるモジュールが ' . $Count . ' 件あります。' : 'すべてのモジュールが最新です。';
			}
			break;
		default:
			$Ret = [false, 'わからない操作です。'];
	}
	cmDone($Ret, 'index.php');
}

$Mods = cmModules();
$Catalog = cmLoadCatalog();
$Check = cmLoadCheck();
$Updates = cmUpdates();

cmPageHead('カスタムモジュール', 'index.php');

// 更新の確認（WordPress の「更新」画面の「最終確認日時」と「再確認」）
echo '<div class="cmCheck">';
if(cmCatalogUrl() === '') {
	echo '配布サイトのカタログの URL がないため、更新を確認できません。<a href="' . htmlspecialchars(cmUrl('Add.php')) . '">「新規追加」で入れてください。</a>';
} else {
	echo '最終確認日時: ' . ($Check['lastCheck'] ? htmlspecialchars(date('Y-m-d H:i', $Check['lastCheck'])) : 'まだ') . ' ';
	echo cmButton('check', '更新を確認');
	if($Check['error'] !== '') {
		echo '<div class="cmErr">前回の確認: ' . htmlspecialchars($Check['error']) . '</div>';
	}
	echo '<div class="cmNote">' . (CM_CHECK_INTERVAL / 3600) . ' 時間ごとに、管理者が ianseo の画面を開いたとき、バックグラウンドで確認します（確認するだけで、入れるのは「今すぐ更新」を押したときです）。</div>';
}
echo '</div>';
if($Updates) {
	echo '<div class="cmUpdateNotice">更新があるモジュールが ' . count($Updates) . ' 件あります: '
		. htmlspecialchars(implode('、', array_map(fn($u) => $u['name'] . ' ' . $u['to'], $Updates))) . '</div>';
}

echo '<table class="Tabella cmTable">';
echo '<tr><th colspan="4" class="Main">インストール済みのカスタムモジュール</th></tr>';
echo '<tr><th class="Title cmNowrap">状態</th><th class="Title">パッケージ</th><th class="Title">説明</th><th class="Title">操作</th></tr>';
foreach($Mods as $m) {
	$Meta = $m['meta'];
	$Newer = cmNewer($Catalog, $m);
	echo '<tr class="' . ($m['disabled'] ? 'cmOff' : '') . ($Newer ? ' cmHasUpdate' : '') . '">';

	echo '<td class="Center cmNowrap">' . ($m['disabled'] ? '<span class="cmBadge cmBadgeOff">無効</span>' : '<span class="cmBadge cmBadgeOn">有効</span>') . '</td>';

	echo '<td class="Left"><span class="cmName">' . htmlspecialchars($m['name']) . '</span>'
		. ($m['version'] !== '' ? ' ' . htmlspecialchars($m['version']) : '')
		. '<br><span class="cmId">' . htmlspecialchars($m['id']) . '</span>'
		. '</td>';

	echo '<td class="Left">' . nl2br(htmlspecialchars($Meta['description']));
	$Info = [];
	if($Meta['author'] !== '') {
		$Info[] = '作者: ' . (cmHttpUrl($Meta['authorUrl']) ? '<a href="' . htmlspecialchars($Meta['authorUrl']) . '" target="_blank" rel="noopener">' . htmlspecialchars($Meta['author']) . '</a>' : htmlspecialchars($Meta['author']));
	}
	if(cmHttpUrl($Meta['homepage'])) {
		$Info[] = '<a href="' . htmlspecialchars($Meta['homepage']) . '" target="_blank" rel="noopener">配布ページ</a>';
	}
	if(!$m['hasMenu']) {
		$Info[] = 'メニューなし';
	}
	if(!$m['hasMeta']) {
		$Info[] = 'module.json なし';
	}
	if($Info) {
		echo '<div class="cmNote">' . implode('　', $Info) . '</div>';
	}
	if($m['hasMeta']) {
		echo '<div>' . cmCompatBadge($m['compat']) . '</div>';
	}
	if($m['error'] !== '') {
		echo '<div class="cmErr">' . htmlspecialchars($m['error']) . '</div>';
	}
	echo '</td>';

	echo '<td class="Left">';
	if($m['self']) {
		echo '<span class="cmNote">無効・削除はできません</span><br>';
	} elseif($m['disabled']) {
		if(!$m['compat']['problems']) {
			echo cmButton('enable', '有効にする', ['id' => $m['id']]);
		}
	} else {
		echo cmButton('disable', '無効にする', ['id' => $m['id']]);
	}
	echo '<a class="cmInline" href="' . htmlspecialchars(cmUrl('Package.php', ['id' => $m['id']])) . '">パッケージ</a>';
	if($m['disabled'] and !$m['self']) {
		echo cmButton('delete', '削除', ['id' => $m['id']], '「' . $m['name'] . '」のフォルダ（Modules/Custom/' . $m['id'] . '）を削除します。元に戻せません。よろしいですか？');
	}
	echo '</td>';

	echo '</tr>';

	// 更新のお知らせ（WordPress の「新しいバージョンの〇〇が利用可能です」の行）
	if($Newer) {
		$Compat = cmCompat($Newer);
		echo '<tr class="cmUpdateRow' . ($m['disabled'] ? ' cmOff' : '') . '"><td></td><td colspan="3" class="Left"><div class="cmUpdateNotice">';
		echo '「' . htmlspecialchars($m['name']) . '」の新しい版 <b>' . htmlspecialchars($Newer['version']) . '</b> があります（今は ' . htmlspecialchars($m['version']) . '）。';
		if($Compat['problems']) {
			echo ' <span class="cmErr">この ianseo には入れられません。</span>';
		} else {
			echo ' ' . cmButton('update', '今すぐ更新', ['id' => $m['id']],
				'「' . $m['name'] . '」を ' . $m['version'] . ' から ' . $Newer['version'] . ' に更新します。' . ($Compat['tested'] == 'no' ? "\n注意: " . $Compat['note'] : '') . "\nよろしいですか？");
		}
		echo '<div>' . cmCompatBadge($Compat) . '</div>';
		// 今の版より新しい変更履歴
		$Log = array_filter($Newer['changelog'], fn($c) => version_compare($c['version'], $m['version'], '>'));
		if($Log) {
			echo '<details><summary>' . htmlspecialchars($Newer['version']) . ' の詳細（変更履歴）</summary><ul class="cmLog">';
			foreach($Log as $c) {
				echo '<li><b>' . htmlspecialchars($c['version']) . '</b>' . ($c['date'] !== '' ? ' (' . htmlspecialchars($c['date']) . ')' : '') . "\n" . htmlspecialchars($c['notes']) . '</li>';
			}
			echo '</ul></details>';
		}
		echo '</div></td></tr>';
	}
}
echo '<tr><td colspan="4" class="Left cmNote">'
	. '無効にしたモジュールは、メニューに出なくなり、ページも開けなくなります（ファイルは残ります）。削除するときは、先に無効にしてください。'
	. '<br>更新しても、有効・無効はそのまま、module.json の keep に書いたデータも残ります。'
	. '<br>必要な ianseo・PHP の版に足りないモジュールは、有効にできません。'
	. '</td></tr>';
echo '</table>';

require_once('Common/Templates/tail.php');
