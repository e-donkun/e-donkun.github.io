<?php
/*
カスタムモジュール管理: パッケージ作成（配布サイトに置く zip と catalog.json を作る）。
- モジュールのパッケージ情報（module.json）を編集する
  パッケージ名、説明、パッケージの版、作者、動作確認した ianseo の版、必要な ianseo・PHP の版、変更履歴など
  動作確認した ianseo の版には、この ianseo の版をボタンで入れられる
- パッケージ（＜id＞-＜版＞.zip）を作り、Modules/Custom/.modules/packages/ に置く
- 作ったパッケージから catalog.json を作る
- 配布サイトのダウンロードページ（site/index.html）をダウンロードする
zip と catalog.json と index.html をダウンロードして、配布サイトの同じ場所に置く。
管理者（本体の「更新」を使える人）だけが使える。

変更履歴:
2026/09/26 配布サイトのダウンロードページ（index.html）のダウンロードを追加
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');

if(!cmCanManage()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}

$Id = (string)($_REQUEST['id'] ?? '');
$Back = ($Id !== '' ? ['id' => $Id] : []);

// ダウンロード
if(isset($_GET['download'])) {
	$File = basename((string)$_GET['download']);
	if(substr($File, -4) == '.zip' and is_file(cmPackagesDir() . $File)) {
		cmSendDownload(cmPackagesDir() . $File, $File, 'application/zip');
		exit;
	}
	cmDone([false, 'パッケージが見つかりません。'], 'Package.php', $Back);
}
if(isset($_GET['site'])) {
	cmSendDownload(__DIR__ . '/site/index.html', 'index.html', 'text/html; charset=utf-8');
	exit;
}
if(isset($_GET['catalog'])) {
	$Tmp = cmTmpDir();
	file_put_contents($Tmp . 'catalog.json', cmCatalogJson(trim((string)($_GET['title'] ?? ''))));
	cmSendDownload($Tmp . 'catalog.json', 'catalog.json', 'application/json');
	cmCleanTmp($Tmp);
	exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	cmRequireToken('Package.php', $Back);
	@set_time_limit(600);
	switch($_POST['act'] ?? '') {
		case 'save':
		case 'saveBuild':
			$Ret = cmSaveModuleMeta($Id, $_POST, (string)($_POST['notes'] ?? ''));
			if($Ret[0] and $_POST['act'] == 'saveBuild') {
				$Build = cmBuildPackage($Id);
				$Ret = [$Build[0], $Ret[1] . $Build[1]];
			}
			if(!$Ret[0]) {
				// 入れたものを消さないように、もう一度出す
				$_SESSION['cmForm'] = $_POST;
			}
			break;
		case 'deletePackage':
			$File = basename((string)($_POST['file'] ?? ''));
			$Ret = (substr($File, -4) == '.zip' and @unlink(cmPackagesDir() . $File)) ? [true, $File . ' を消しました。'] : [false, $File . ' を消せませんでした。'];
			break;
		default:
			$Ret = [false, 'わからない操作です。'];
	}
	cmDone($Ret, 'Package.php', $Back);
}

$Mods = cmModules();
$Current = cmIanseoCurrent();

cmPageHead('パッケージ作成', 'Package.php');

// モジュールを選ぶ
echo '<form method="get" class="cmInline">モジュール: <select name="id" onchange="this.form.submit()">';
echo '<option value="">--- 選んでください ---</option>';
foreach($Mods as $m) {
	echo '<option value="' . htmlspecialchars($m['id']) . '"' . ($m['id'] === $Id ? ' selected' : '') . '>' . htmlspecialchars($m['name'] . ($m['version'] !== '' ? ' ' . $m['version'] : '') . '（' . $m['id'] . '）') . '</option>';
}
echo '</select> <noscript><input type="submit" value="開く"></noscript></form>';

// パッケージ情報
if(isset($Mods[$Id])) {
	$m = $Mods[$Id];
	$Meta = $m['meta'];
	$Form = $_SESSION['cmForm'] ?? null;
	unset($_SESSION['cmForm']);
	$Val = function($k) use ($Form, $Meta) {
		return (string)($Form[$k] ?? $Meta[$k] ?? '');
	};
	$Notes = (string)($Form['notes'] ?? '');
	if(!$Form) {
		foreach($Meta['changelog'] as $c) {
			if($c['version'] === $Meta['version']) {
				$Notes = $c['notes'];
			}
		}
	}

	$Labels = cmMetaLabels();
	echo '<form method="post">';
	echo '<input type="hidden" name="token" value="' . htmlspecialchars(cmToken()) . '">';
	echo '<input type="hidden" name="id" value="' . htmlspecialchars($Id) . '">';
	echo '<table class="Tabella cmTable">';
	echo '<tr><th colspan="2" class="Main">パッケージ情報（' . htmlspecialchars($Id) . '/module.json）</th></tr>';
	if($m['error'] !== '') {
		echo '<tr><td colspan="2" class="cmErr">' . htmlspecialchars($m['error']) . '</td></tr>';
	}
	$Row = function($k, $Input, $Note = '') use ($Labels) {
		echo '<tr><th class="SubTitle">' . $Labels[$k] . '</th><td class="Left">' . $Input . ($Note !== '' ? '<div class="cmNote">' . $Note . '</div>' : '') . '</td></tr>';
	};
	$Text = fn($k, $Attr = '') => '<input type="text" name="' . $k . '" value="' . htmlspecialchars($Val($k)) . '" ' . $Attr . '>';
	$Row('id', htmlspecialchars($Id), 'Modules/Custom の下のフォルダ名。変えられません。');
	$Row('name', $Text('name', 'class="cmWide" required'));
	$Row('description', '<textarea name="description" rows="3">' . htmlspecialchars($Val('description')) . '</textarea>');
	$Row('version', $Text('version', 'size="12" required placeholder="1.0.0"'), '1.2.0 のような形。新しい版を出すときは上げる（配布サイトのカタログと比べて「更新」を出すのに使う）。');
	$Row('author', $Text('author', 'class="cmWide"'));
	$Row('authorUrl', $Text('authorUrl', 'class="cmWide" placeholder="https://"'));
	$Row('homepage', $Text('homepage', 'class="cmWide" placeholder="https://"'), 'このパッケージの説明やダウンロードのページ。');
	$Row('license', $Text('license', 'size="20"'));
	$Row('testedIanseo', $Text('testedIanseo', 'id="cmTested" size="24" required placeholder="2026-03-01 rev 255"')
		. ' <button type="button" onclick="document.getElementById(\'cmTested\').value=' . htmlspecialchars(json_encode($Current)) . '">この ianseo の版（' . htmlspecialchars($Current ?: '不明') . '）を入れる</button>',
		'このパッケージの動作を確かめた ianseo の版。これより新しい ianseo では「未確認」と出る。');
	$Row('requiresIanseo', $Text('requiresIanseo', 'size="24" placeholder="2025-09-03"'), 'これより古い ianseo には入れられない。なければ空。');
	$Row('requiresPhp', $Text('requiresPhp', 'size="10" placeholder="8.0"'), 'これより古い PHP では入れられない。なければ空。');
	echo '<tr><th class="SubTitle">この版の変更点</th><td class="Left"><textarea name="notes" rows="4">' . htmlspecialchars($Notes) . '</textarea>'
		. '<div class="cmNote">変更履歴（changelog）の、上の「パッケージの版」のところに書く。</div></td></tr>';
	if($Meta['changelog']) {
		echo '<tr><th class="SubTitle">変更履歴</th><td class="Left"><ul class="cmLog">';
		foreach($Meta['changelog'] as $c) {
			echo '<li><b>' . htmlspecialchars($c['version']) . '</b>' . ($c['date'] !== '' ? ' (' . htmlspecialchars($c['date']) . ')' : '') . "\n" . htmlspecialchars($c['notes']) . '</li>';
		}
		echo '</ul></td></tr>';
	}
	if($Meta['keep']) {
		echo '<tr><th class="SubTitle">更新しても残すもの（keep）</th><td class="Left">' . htmlspecialchars(implode('、', $Meta['keep'])) . '<div class="cmNote">パッケージには入れません。変えるときは module.json を直接書き換えてください。</div></td></tr>';
	}
	echo '<tr><td colspan="2" class="Center">'
		. '<button type="submit" name="act" value="save">保存</button> '
		. '<button type="submit" name="act" value="saveBuild">保存してパッケージを作る</button>'
		. '</td></tr>';
	echo '</table>';
	echo '</form>';
}

// 作ったパッケージ
$Packages = cmPackages();
echo '<br><table class="Tabella cmTable">';
echo '<tr><th colspan="5" class="Main">作ったパッケージ（Modules/Custom/.modules/packages/）</th></tr>';
if($Packages) {
	echo '<tr><th class="Title">パッケージ</th><th class="Title">動作確認した ianseo</th><th class="Title">作った日</th><th class="Title">大きさ・sha256</th><th class="Title">操作</th></tr>';
	foreach($Packages as $p) {
		echo '<tr>';
		echo '<td class="Left"><span class="cmName">' . htmlspecialchars($p['meta']['name']) . '</span> ' . htmlspecialchars($p['meta']['version']) . '<br><span class="cmId">' . htmlspecialchars($p['file']) . '</span></td>';
		echo '<td class="Center">' . htmlspecialchars($p['meta']['testedIanseo']) . '</td>';
		echo '<td class="Center">' . htmlspecialchars($p['updated']) . '</td>';
		echo '<td class="Left cmNote">' . htmlspecialchars(ceil($p['size'] / 1024) . 'KB') . '<br>' . htmlspecialchars(substr($p['sha256'], 0, 16)) . '…</td>';
		echo '<td class="Left">'
			. '<a class="cmInline" href="' . htmlspecialchars(cmUrl('Package.php', ['download' => $p['file']])) . '">zip をダウンロード</a>'
			. cmButton('deletePackage', '消す', ['file' => $p['file'], 'id' => $Id], $p['file'] . ' を消します。よろしいですか？')
			. '</td>';
		echo '</tr>';
	}
	echo '<tr><td colspan="5" class="Left">'
		. '<form method="get" class="cmInline">'
		. '<input type="hidden" name="catalog" value="1">'
		. 'カタログの名前: <input type="text" name="title" size="30" placeholder="〇〇のianseoモジュール"> '
		. '<input type="submit" value="catalog.json をダウンロード">'
		. '</form>'
		. ' <a class="cmInline" href="' . htmlspecialchars(cmUrl('Package.php', ['site' => 1])) . '">ダウンロードページ（index.html）をダウンロード</a>'
		. '<div class="cmNote">catalog.json には、モジュールごとに一番新しい版を載せます。catalog.json の名前（title）は、ダウンロードページの見出しになります。'
		. '<br>zip と catalog.json と index.html を、配布サイトの同じフォルダに置いてください。index.html を開くと、catalog.json を読んでモジュールを一覧にします。</div>'
		. '</td></tr>';
} else {
	echo '<tr><td colspan="5" class="Center cmNote">まだありません。上でモジュールを選んで「保存してパッケージを作る」を押してください。</td></tr>';
}
echo '</table>';

require_once('Common/Templates/tail.php');
