<?php
/*
ISK接続診断: 通信の記録に使う関数。
ianseo 本体（config.php）を読み込まずに動くようにしてある。
tap/ の中継ファイルは ISK-NG の API（Api/ISK-NG/index.php）より先に動くため、
ここで本体を読み込むと $SKIP_AUTH などの前提が崩れるから。

記録は log/requests.log.php に 1 行 1 件の JSON で追記する。
先頭行を「<?php exit; ?>」にしてあるので、URL で開かれても中身は見えない。
log/ に書き込めないときは一時フォルダ（sys_get_temp_dir()）の ianseo-IskConnDiag/ を使う。

変更履歴:
2026/10/12 初版
*/

const ISKDIAG_LOG_MAX = 5242880;   // これを超えたら requests-old.log.php に回す
const ISKDIAG_BODY_MAX = 8192;     // 記録する要求本文の上限
const ISKDIAG_RESP_MAX = 4096;     // 記録する応答本文の上限
const ISKDIAG_LOG_HEADER = "<?php exit; ?>\n";

/**
 * ianseo のルートフォルダ（末尾に / 付き）
 */
function iskDiagIanseoRoot() {
	return dirname(__DIR__, 3) . DIRECTORY_SEPARATOR;
}

/**
 * 記録を置くフォルダ。書き込めるところがなければ空文字
 */
function iskDiagLogDir() {
	static $Dir = null;
	if($Dir !== null) {
		return $Dir;
	}
	foreach([__DIR__ . '/log', rtrim(sys_get_temp_dir(), '/\\') . '/ianseo-IskConnDiag'] as $d) {
		if(!is_dir($d)) {
			@mkdir($d, 0775, true);
		}
		if(is_dir($d) and is_writable($d)) {
			if(!file_exists($d . '/.htaccess')) {
				@file_put_contents($d . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
			}
			if(!file_exists($d . '/index.html')) {
				@file_put_contents($d . '/index.html', '');
			}
			return $Dir = $d;
		}
	}
	return $Dir = '';
}

function iskDiagLogFile() {
	$d = iskDiagLogDir();
	return $d ? $d . '/requests.log.php' : '';
}

function iskDiagWrite($Entry) {
	if(!($File = iskDiagLogFile())) {
		return false;
	}
	clearstatcache(true, $File);
	if(is_file($File) and filesize($File) > ISKDIAG_LOG_MAX) {
		@rename($File, dirname($File) . '/requests-old.log.php');
	}
	$Line = json_encode($Entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) . "\n";
	if(!is_file($File)) {
		$Line = ISKDIAG_LOG_HEADER . $Line;
	}
	return @file_put_contents($File, $Line, FILE_APPEND | LOCK_EX) !== false;
}

/**
 * 新しい順に最大 $Limit 件
 */
function iskDiagReadLog($Limit = 200) {
	$File = iskDiagLogFile();
	if(!$File or !is_file($File)) {
		return [];
	}
	$Lines = @file($File, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
	if($Lines and $Lines[0] . "\n" == ISKDIAG_LOG_HEADER) {
		array_shift($Lines);
	}
	$Ret = [];
	foreach(array_reverse(array_slice($Lines, -$Limit)) as $l) {
		if($e = json_decode($l, true)) {
			$Ret[] = $e;
		}
	}
	return $Ret;
}

function iskDiagClearLog() {
	if($File = iskDiagLogFile()) {
		@unlink($File);
		@unlink(dirname($File) . '/requests-old.log.php');
	}
}

/**
 * 大会コードの後ろの PIN（「コード|PIN」）を伏せる。JSON の中の JSON（\" で囲まれた値）にも効く
 */
function iskDiagMask($Text) {
	$Text = preg_replace('/(\\\\?"(?:tournament|tocode|c)\\\\?"\s*:\s*\\\\?"[^"|\\\\]*\|)[^"\\\\]*/', '$1****', $Text);
	// requests=... の形（フォーム送信）で URL エンコードされている場合
	return preg_replace('/((?:tournament|tocode)%22%3A%22[^%|]*(?:%7C|\|))[^%]*/i', '$1****', $Text);
}

function iskDiagCut($Text, $Max) {
	$Text = (string)$Text;
	if(strlen($Text) <= $Max) {
		return $Text;
	}
	return substr($Text, 0, $Max) . '…（' . strlen($Text) . ' バイト中 ' . $Max . ' バイトまで記録）';
}

function iskDiagRequestHeaders() {
	$Ret = [];
	if(function_exists('getallheaders')) {
		$Ret = getallheaders() ?: [];
	} else {
		foreach($_SERVER as $k => $v) {
			if(substr($k, 0, 5) == 'HTTP_') {
				$Ret[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($k, 5)))))] = $v;
			} elseif(in_array($k, ['CONTENT_TYPE', 'CONTENT_LENGTH'])) {
				$Ret[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', $k))))] = $v;
			}
		}
	}
	foreach($Ret as $k => &$v) {
		if(in_array(strtolower($k), ['cookie', 'authorization', 'proxy-authorization'])) {
			$v = '（' . strlen($v) . ' 文字・記録しない）';
		}
	}
	unset($v);
	return $Ret;
}

/**
 * いま受けている要求の内容
 */
function iskDiagRequestInfo($Kind) {
	$Https = (!empty($_SERVER['HTTPS']) and strtolower($_SERVER['HTTPS']) != 'off');
	$Body = file_get_contents('php://input');
	if($Body === '' and !empty($_POST)) {
		$Body = http_build_query($_POST);
	}
	return [
		'id' => bin2hex(random_bytes(6)),
		'kind' => $Kind,
		'ts' => microtime(true),
		'remote' => ($_SERVER['REMOTE_ADDR'] ?? '') . ':' . ($_SERVER['REMOTE_PORT'] ?? ''),
		'server' => ($_SERVER['SERVER_ADDR'] ?? '') . ':' . ($_SERVER['SERVER_PORT'] ?? ''),
		'scheme' => $Https ? 'https' : 'http',
		'protocol' => $_SERVER['SERVER_PROTOCOL'] ?? '',
		'method' => $_SERVER['REQUEST_METHOD'] ?? '',
		'host' => $_SERVER['HTTP_HOST'] ?? '',
		'uri' => iskDiagMask($_SERVER['REQUEST_URI'] ?? ''),
		'ua' => $_SERVER['HTTP_USER_AGENT'] ?? '',
		'headers' => iskDiagRequestHeaders(),
		'body' => iskDiagCut(iskDiagMask($Body), ISKDIAG_BODY_MAX),
		'bodyLen' => strlen($Body),
	];
}

/**
 * tap/ の中継ファイルの最初に呼ぶ。要求を覚えておき、応答を出し終えたところで記録する。
 * ISK-NG の API は JsonOut() の中で die() するので、出力バッファの最後の呼び出しで応答をつかまえる。
 */
function iskDiagTapStart($Kind) {
	$Entry = iskDiagRequestInfo($Kind);
	$Acc = '';
	$Done = false;
	$Handler = function($Buf, $Phase) use (&$Entry, &$Acc, &$Done) {
		if($Phase & PHP_OUTPUT_HANDLER_CLEAN) {
			$Acc = '';
		} else {
			$Acc .= $Buf;
		}
		if(($Phase & PHP_OUTPUT_HANDLER_FINAL) and !$Done) {
			$Done = true;
			$Entry['ms'] = round((microtime(true) - $Entry['ts']) * 1000);
			$Entry['status'] = http_response_code();
			$Entry['respHeaders'] = headers_list();
			$Entry['resp'] = iskDiagCut(iskDiagMask($Acc), ISKDIAG_RESP_MAX);
			$Err = error_get_last();
			if($Err and in_array($Err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
				$Entry['phpError'] = $Err['message'] . ' (' . basename($Err['file']) . ':' . $Err['line'] . ')';
			}
			iskDiagWrite($Entry);
		}
		return $Buf;
	};
	ob_start($Handler);
	$Level = ob_get_level();
	// 終了処理は出力バッファの片付けより先に動くので、ここで自分のバッファを閉じて記録させる
	register_shutdown_function(function() use ($Level) {
		while(ob_get_level() >= $Level) {
			if(!@ob_end_flush()) {
				break;
			}
		}
	});
}

/**
 * 記録の要約（一覧に出す）。本文が ISK-NG の形でなければ空のまま
 */
function iskDiagSummarize($Entry) {
	$Sum = ['actions' => [], 'device' => '', 'iskType' => '', 'appVersion' => '', 'tournament' => '', 'error' => null, 'errorMsg' => '', 'respActions' => []];
	$Body = $Entry['body'] ?? '';
	$Req = json_decode($Body);
	if(!$Req and $Body !== '') {
		parse_str($Body, $Form);
		if(!empty($Form['requests'])) {
			$Req = json_decode($Form['requests']);
		}
	}
	if(is_object($Req) and isset($Req->requests)) {
		$Req = $Req->requests;
	}
	if($Req) {
		foreach((is_array($Req) ? $Req : [$Req]) as $r) {
			if(!is_object($r)) {
				continue;
			}
			if(isset($r->action)) {
				$Sum['actions'][] = (string)$r->action;
			}
			$Sum['device'] = $Sum['device'] ?: (string)($r->device ?? $r->uuid ?? '');
			$Sum['iskType'] = $Sum['iskType'] ?: (string)($r->iskType ?? '');
			$Sum['appVersion'] = $Sum['appVersion'] ?: (string)($r->version ?? '');
			$Sum['tournament'] = $Sum['tournament'] ?: (string)($r->tournament ?? $r->tocode ?? '');
		}
	}
	if(($Entry['resp'] ?? '') !== '' and $Resp = json_decode($Entry['resp'])) {
		if(isset($Resp->error)) {
			$Sum['error'] = (bool)$Resp->error;
		}
		$Sum['errorMsg'] = (string)($Resp->errorMsg ?? '');
		foreach(($Resp->responses ?? []) as $r) {
			if(is_object($r) and isset($r->action)) {
				$a = (string)$r->action;
				if($a == 'handshake' and isset($r->error)) {
					$a .= '(error=' . $r->error . ')';
				}
				if($a == 'reset' and !empty($r->resetMessage)) {
					$a .= '(' . $r->resetMessage . ')';
				}
				$Sum['respActions'][] = $a;
			}
		}
	}
	return $Sum;
}
