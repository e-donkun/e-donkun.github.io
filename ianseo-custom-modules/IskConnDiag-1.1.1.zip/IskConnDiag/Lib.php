<?php
/*
ISK接続診断: 管理画面（index.php・Probe.php・LogData.php）で使う関数。ianseo 本体を読み込んだあとで使う。

変更履歴:
2026/10/12 初版
*/
require_once(__DIR__ . '/TapLib.php');

const ISKDIAG_PROBE_DEVICE = 'IskConnDiag-probe';

/**
 * このモジュールの URL 上のフォルダ（末尾に / 付き）。例: /ianseo/Modules/Custom/IskConnDiag/
 */
function iskDiagWebDir() {
	global $CFG;
	return $CFG->ROOT_DIR . 'Modules/Custom/' . basename(__DIR__) . '/';
}

/**
 * 管理画面をいま開いているブラウザから見た ianseo の URL（末尾に / 付き）
 */
function iskDiagCurrentRootUrl() {
	global $CFG;
	$Https = (!empty($_SERVER['HTTPS']) and strtolower($_SERVER['HTTPS']) != 'off');
	return ($Https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $CFG->ROOT_DIR;
}

/**
 * このサーバーの IP アドレス（ループバックを除く）
 */
function iskDiagServerAddresses() {
	$Ips = [];
	if(!empty($_SERVER['SERVER_ADDR'])) {
		$Ips[] = $_SERVER['SERVER_ADDR'];
	}
	if(($h = gethostname()) and ($l = @gethostbynamel($h))) {
		$Ips = array_merge($Ips, $l);
	}
	$Ret = [];
	foreach(array_unique($Ips) as $ip) {
		if(!preg_match('/^(127\.|::1$)/', $ip)) {
			$Ret[] = $ip;
		}
	}
	return $Ret;
}

/**
 * ISK-NG の設定の「サーバーURL」そのものの書き方を確かめる
 * @return array [['ng'|'warn'|'info'|'ok', '文'], ...]
 */
function iskDiagCheckServerUrl($ServerUrl) {
	global $CFG;
	if($ServerUrl === '') {
		return [['ng', '「サーバーURL」が空です。Lite / Pro では QR コードが作れず、アプリに接続先が伝わりません（スコアキーパー → 設定 で入れます）。']];
	}
	$p = parse_url($ServerUrl);
	if(!$p or empty($p['scheme']) or empty($p['host']) or !in_array(strtolower($p['scheme']), ['http', 'https'])) {
		return [['ng', '「サーバーURL」は http:// か https:// から始まる形で入れます（例: http://192.168.0.10）。']];
	}
	$Ret = [];
	if(isset($p['query']) or isset($p['fragment'])) {
		$Ret[] = ['ng', '「サーバーURL」に ? や # が入っています。QR コードの URL が壊れます。'];
	}
	if(!empty($p['path']) and $p['path'] != '/') {
		$Ret[] = ['warn', '「サーバーURL」にパス（' . $p['path'] . '）が入っています。QR コードの URL は「サーバーURL ＋ ianseo のフォルダ（' . $CFG->ROOT_DIR . '）」なので、フォルダが二重になることがあります。サーバーURLはホスト名か IP まで（例: http://192.168.0.10）にします。'];
	} elseif(substr($ServerUrl, -1) == '/') {
		$Ret[] = ['info', '「サーバーURL」の末尾の / と ianseo のフォルダの先頭の / が重なって「//」になります。たいていは動きますが、末尾の / は外したほうが安全です。'];
	}
	return $Ret;
}

/**
 * アプリが使う URL（QR コードの u）を、スマホから届くかどうかの観点で確かめる
 * @return array [['ng'|'warn'|'info'|'ok', '文'], ...]
 */
function iskDiagCheckBase($Base, $ServerIps) {
	$p = parse_url($Base);
	if(!$p or empty($p['host'])) {
		return [['ng', 'URL として読めません。']];
	}
	$Ret = [];
	$Scheme = strtolower($p['scheme'] ?? '');
	$Host = strtolower(trim($p['host'], '[]'));
	$Port = $p['port'] ?? ($Scheme == 'https' ? 443 : 80);

	if(substr($Base, -1) != '/') {
		$Ret[] = ['ng', '末尾が / で終わっていません。アプリはこの後ろに「Api/ISK-NG/」を付けるので、URL がつながってしまいます。'];
	}
	if(strpos($p['path'] ?? '', '//') !== false) {
		$Ret[] = ['warn', 'パスに「//」があります。サーバーによっては転送（リダイレクト）や 404 になります。'];
	}

	if(filter_var($Host, FILTER_VALIDATE_IP)) {
		if(preg_match('/^(127\.|::1$)/', $Host)) {
			$Ret[] = ['ng', $Host . ' はスマホから見るとスマホ自身です。サーバーの LAN 側の IP にします。'];
		} elseif(preg_match('/^169\.254\./', $Host)) {
			$Ret[] = ['ng', $Host . ' は DHCP で IP をもらえなかったときの自動割り当てのアドレスです。'];
		} else {
			$Ret[] = ['ok', 'IP アドレスで指定しています（名前解決の問題は起きません）。'];
			if($ServerIps and !in_array($Host, $ServerIps)) {
				$Ret[] = ['warn', 'このサーバーで見えている IP（' . implode(', ', $ServerIps) . '）と違います。IP が変わったか、NAT・リバースプロキシ越しの可能性があります。'];
			}
		}
	} elseif($Host == 'localhost') {
		$Ret[] = ['ng', 'localhost はスマホから見るとスマホ自身です。サーバーの LAN 側の IP にします。'];
	} elseif(substr($Host, -6) == '.local') {
		$Ret[] = ['warn', '.local（mDNS）の名前です。スマホの OS やアプリの通信部品によっては引けません。IP アドレスで試してください。'];
	} elseif(strpos($Host, '.') === false) {
		$Ret[] = ['warn', 'ドットのないホスト名（' . $Host . '）です。Windows の名前（NetBIOS / LLMNR）はスマホでは引けないことが多く、社内 DNS の検索ドメインもスマホには付かないことがあります。IP アドレスで試してください。'];
	} else {
		$Resolved = @gethostbynamel($Host);
		$Ret[] = [$Resolved ? 'info' : 'warn', 'ホスト名（' . $Host . '）で指定しています。このサーバーでの名前解決: ' . ($Resolved ? implode(', ', $Resolved) : '引けません') . '。スマホが同じ社内 DNS を使っていないと引けません（Android の「プライベート DNS」が有効だと社内の名前は引けません）。'];
		if($Scheme == 'http') {
			$Ret[] = ['warn', 'http でホスト名（FQDN）を指定しています。iOS アプリは、IP アドレスと .local・ドットなしの名前以外への http 通信を OS（ATS）に止められることがあります（アプリ側の設定次第）。IP アドレスで試すと切り分けられます。'];
		}
	}

	if($Scheme == 'https') {
		$Ret[] = ['warn', 'https です。証明書が自己署名や社内 CA のものだと、ブラウザでは警告を承認して開けても、アプリは接続を拒否するのが普通です（Android のアプリは、利用者が入れた CA 証明書を標準では信用しません）。下の「サーバーからの到達テスト」で証明書の検証結果を確かめてください。'];
	}
	if(!in_array($Port, [80, 443])) {
		$Ret[] = ['info', 'ポート ' . $Port . ' を使っています。社内のファイアウォールや Wi-Fi 側でこのポートが閉じられていないか確かめてください。'];
	}
	return $Ret;
}

/**
 * サーバー自身から URL に要求を送る（転送はたどらない・プロキシは使わない）
 */
function iskDiagHttp($Url, $Body = null, $Verify = true) {
	$Ret = ['url' => $Url, 'method' => $Body === null ? 'GET' : 'POST', 'verify' => $Verify, 'status' => 0, 'ms' => 0, 'ip' => '', 'location' => '', 'error' => '', 'sslError' => false, 'body' => '', 'apiOk' => false];
	if(!function_exists('curl_init')) {
		$Ret['error'] = 'PHP の curl 拡張が無効なので試せません。';
		return $Ret;
	}
	$ch = curl_init($Url);
	curl_setopt_array($ch, [
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_HEADER => true,
		CURLOPT_FOLLOWLOCATION => false,
		CURLOPT_CONNECTTIMEOUT => 5,
		CURLOPT_TIMEOUT => 10,
		CURLOPT_SSL_VERIFYPEER => $Verify,
		CURLOPT_SSL_VERIFYHOST => $Verify ? 2 : 0,
		CURLOPT_NOPROXY => '*',
		CURLOPT_USERAGENT => 'IskConnDiag (server self-test)',
	]);
	if($Body !== null) {
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $Body);
		curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
	}
	$Raw = curl_exec($ch);
	$Info = curl_getinfo($ch);
	$Ret['status'] = intval($Info['http_code'] ?? 0);
	$Ret['ms'] = round(($Info['total_time'] ?? 0) * 1000);
	$Ret['ip'] = $Info['primary_ip'] ?? '';
	$Ret['location'] = $Info['redirect_url'] ?? '';
	if($Raw === false) {
		$No = curl_errno($ch);
		$Ret['error'] = curl_error($ch) . ' (curl ' . $No . ')';
		// 35: TLS の接続, 51/60: 証明書の検証, 58/77/83/90/91: 証明書まわり
		$Ret['sslError'] = in_array($No, [35, 51, 53, 54, 58, 59, 60, 64, 66, 77, 80, 82, 83, 90, 91]);
	} else {
		$Text = substr($Raw, intval($Info['header_size'] ?? 0));
		$Ret['body'] = iskDiagCut($Text, 600);
		$j = json_decode($Text);
		$Ret['apiOk'] = (is_object($j) and isset($j->error) and $j->error === false);
	}
	curl_close($ch);
	return $Ret;
}

/**
 * 到達テストの結果を ['ng'|'warn'|'ok', '文'] にする
 */
function iskDiagJudge($r) {
	if($r['error']) {
		if($r['sslError']) {
			return ['ng', '証明書の検証で失敗しました。アプリもほぼ確実に接続を拒否します（正式な証明書にするか、http・IP アドレスで運用してください）。'];
		}
		return ['ng', '接続できません。'];
	}
	if($r['status'] >= 300 and $r['status'] < 400) {
		$Msg = '転送（リダイレクト）されます → ' . $r['location'] . '。';
		if(stripos($r['location'], 'https://') === 0 and stripos($r['url'], 'http://') === 0) {
			$Msg .= 'http から https への強制転送です。';
		}
		return ['warn', $Msg . 'アプリの通信部品によっては転送をたどらず、たどっても POST の中身が落ちて失敗します。転送先の URL をサーバーURLにしてください。'];
	}
	if($r['status'] == 200 and $r['apiOk']) {
		return ['ok', 'ISK-NG の API が正しく返事をしました。'];
	}
	if($r['status'] == 200) {
		return ['warn', '返事は来ましたが ISK-NG の API の形ではありません（ログイン画面・プロキシの画面・別のサイトなど）。'];
	}
	return ['ng', 'HTTP ' . $r['status'] . ' が返りました' . ($r['status'] == 403 ? '（アクセス制限・WAF・プロキシで止められている可能性）' : '') . '。'];
}

/**
 * 管理画面の「サーバーからの到達テスト」で試す内容
 */
function iskDiagProbes($Base) {
	global $CFG;
	$Ping = json_encode(['action' => 'ping', 'device' => ISKDIAG_PROBE_DEVICE, 'apiVersion' => 1]);
	$Https = (!empty($_SERVER['HTTPS']) and strtolower($_SERVER['HTTPS']) != 'off');
	$Local = ($Https ? 'https' : 'http') . '://127.0.0.1:' . intval($_SERVER['SERVER_PORT'] ?? ($Https ? 443 : 80)) . $CFG->ROOT_DIR;

	$Ret = [];
	$Ret[] = ['name' => 'サーバー内部（127.0.0.1）の API', 'note' => 'ネットワークを通さずに API そのものが動くか', 'r' => iskDiagHttp($Local . 'Api/ISK-NG/', $Ping, false)];
	$r = iskDiagHttp($Base . 'Api/ISK-NG/', $Ping);
	$Ret[] = ['name' => 'サーバーURL の API', 'note' => 'アプリと同じ URL。サーバー自身から自分の外向きの名前・IP に届くか（ルーターによっては自分あては届かないので参考）', 'r' => $r];
	if($r['sslError']) {
		$Ret[] = ['name' => 'サーバーURL の API（証明書を確かめない）', 'note' => '証明書の問題だけかどうかの切り分け', 'r' => iskDiagHttp($Base . 'Api/ISK-NG/', $Ping, false)];
	}
	$Ret[] = ['name' => 'サーバーURL の API（末尾の / なし）', 'note' => 'アプリが / を付けずに送った場合。Apache は / 付きに転送するので、それ自体は異常ではありません', 'r' => iskDiagHttp($Base . 'Api/ISK-NG', $Ping)];
	$Ret[] = ['name' => '検証用の中継（tap）', 'note' => '中継が動くか。成功すると通信ログに 1 件増えます', 'r' => iskDiagHttp($Base . 'Modules/Custom/' . basename(__DIR__) . '/tap/Api/ISK-NG/', $Ping, !$r['sslError'])];
	foreach($Ret as &$p) {
		$p['judge'] = iskDiagJudge($p['r']);
	}
	unset($p);
	return $Ret;
}

/**
 * QR コード（SVG）
 */
function iskDiagQrSvg($Text, $Cell = 4) {
	require_once('Common/tcpdf/tcpdf_barcodes_2d.php');
	$Qr = new TCPDF2DBarcode($Text, 'QRCODE,M');
	$Svg = $Qr->getBarcodeSVGcode($Cell, $Cell);
	// HTML の中に直接置くので、XML 宣言と DOCTYPE は外す
	$Svg = preg_replace('/^.*?(<svg )/s', '$1', $Svg);
	// viewBox を付けて、ianseo の CSS などで表示の大きさが変わっても中身ごと縮むようにする（ないと右下が切れる）
	return preg_replace_callback('/^<svg width="([\d.]+)" height="([\d.]+)"/', function($m) {
		return '<svg width="' . $m[1] . '" height="' . $m[2] . '" viewBox="0 0 ' . $m[1] . ' ' . $m[2] . '" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges"';
	}, $Svg);
}

/**
 * Windows PC 用の中継プログラムのファイル（proxy/ の中。ダウンロードできるもの）
 */
function iskDiagProxyFiles() {
	return ['isk_proxy.py', 'start_proxy.bat', 'README.txt'];
}

/**
 * 中継プログラムを配るときの中身。isk_proxy.py の既定の中継先をこのサーバーにし、.bat と .txt は CRLF にする
 */
function iskDiagProxyContent($Name) {
	$Data = (string)file_get_contents(__DIR__ . '/proxy/' . $Name);
	if($Name == 'isk_proxy.py') {
		$Https = (!empty($_SERVER['HTTPS']) and strtolower($_SERVER['HTTPS']) != 'off');
		$Origin = ($Https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
		$Data = str_replace("DEFAULT_UPSTREAM = '__ISKDIAG_UPSTREAM__'", "DEFAULT_UPSTREAM = '" . addslashes($Origin) . "'", $Data);
	}
	if(preg_match('/\.(bat|txt)$/', $Name)) {
		$Data = str_replace(["\r\n", "\n"], ["\n", "\r\n"], $Data);
	}
	if(substr($Name, -4) == '.txt') {
		$Data = "\xEF\xBB\xBF" . $Data;
	}
	return $Data;
}
