<?php
/*
ISK接続診断: 管理画面のページで最初に読み込む。ianseo 本体と ISK-NG の定数を読み込み、権限を確かめる。
kyoto-ianseo では Modules/Custom/config.php（無効にしたモジュールを止める処理つき）を使い、
本家の ianseo のようにそれがなければ ianseo の config.php を直接読む。
*/
if(is_file(dirname(__DIR__) . '/config.php')) {
	require_once(dirname(__DIR__) . '/config.php');
} else {
	require_once(dirname(__DIR__, 3) . '/config.php');
}
require_once('Common/Lib/CommonLib.php');
require_once('Common/Lib/Fun_Modules.php');
require_once($CFG->DOCUMENT_PATH . 'Api/ISK-NG/config.php');
require_once(__DIR__ . '/Lib.php');
