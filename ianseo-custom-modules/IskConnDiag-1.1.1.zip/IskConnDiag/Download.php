<?php
/*
ISK接続診断: Windows PC 用の中継プログラム（proxy/）をダウンロードさせる。
?f=isk_proxy.py / start_proxy.bat / README.txt で 1 つずつ、?f=zip でまとめて（ZipArchive があるとき）。
- isk_proxy.py の既定の中継先を、この画面を開いているサーバー（https://ホスト名）に書き換える
- .bat と .txt は Windows のメモ帳・コマンドプロンプト向けに改行を CRLF にする（.txt は UTF-8 の BOM も付ける）
*/
require_once(__DIR__ . '/Bootstrap.php');

CheckTourSession(true);
checkFullACL(AclISKServer, 'iskManagement', AclReadOnly);

$Files = iskDiagProxyFiles();
$F = (string)($_GET['f'] ?? '');

if($F == 'zip') {
	if(!class_exists('ZipArchive')) {
		die('この PHP では zip を作れません（ZipArchive がありません）。ファイルを 1 つずつダウンロードしてください。');
	}
	$Tmp = tempnam(sys_get_temp_dir(), 'iskproxy');
	$Zip = new ZipArchive();
	$Zip->open($Tmp, ZipArchive::OVERWRITE);
	foreach($Files as $Name) {
		$Zip->addFromString('isk_proxy/' . $Name, iskDiagProxyContent($Name));
	}
	$Zip->close();
	header('Content-Type: application/zip');
	header('Content-Disposition: attachment; filename="isk_proxy.zip"');
	header('Content-Length: ' . filesize($Tmp));
	header('Cache-Control: no-store');
	readfile($Tmp);
	@unlink($Tmp);
	exit;
}

if(!in_array($F, $Files, true)) {
	http_response_code(404);
	die('Not found');
}
$Data = iskDiagProxyContent($F);
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $F . '"');
header('Content-Length: ' . strlen($Data));
header('Cache-Control: no-store');
echo $Data;
