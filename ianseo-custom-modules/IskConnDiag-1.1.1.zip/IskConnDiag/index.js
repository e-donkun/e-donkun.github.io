/*
ISK接続診断: 管理画面（index.php）の動き。通信ログの表示と、サーバーからの到達テスト。
*/
var IskConnDiag = (function() {
	var Cfg = {};
	var Timer = null;
	var Open = {};
	var KindNames = {
		'tap': 'アプリ（tap）',
		'tap-other': 'アプリ（API 以外）',
		'phone-open': 'ブラウザ（開いた）',
		'phone-report': 'ブラウザ（結果）',
		'probe': 'サーバーのテスト',
		'phone-tap': 'ブラウザ（tap）'
	};
	var JudgeMark = {ng: '✖', warn: '⚠', info: 'ℹ', ok: '✔'};

	function esc(s) {
		return String(s == null ? '' : s).replace(/[&<>"]/g, function(c) {
			return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c];
		});
	}

	function pretty(txt) {
		try {
			return JSON.stringify(JSON.parse(txt), null, 2);
		} catch(e) {
			return txt;
		}
	}

	function kindOf(e) {
		if(e.kind == 'tap' && /IskConnDiag/.test(e.ua || '')) {
			return 'probe';
		}
		if(e.kind == 'tap' && e.sum && e.sum.device == 'IskConnDiag-phone') {
			return 'phone-tap';
		}
		return e.kind;
	}

	function phoneSummary(e) {
		var j = null;
		try { j = JSON.parse(e.body); } catch(x) {}
		if(!j || !j.tests) {
			return '';
		}
		return j.tests.map(function(t) {
			var r = t.result || {};
			return (r.ok ? '<span class="IcdOk">✔</span> ' : '<span class="IcdErr">✖</span> ') + esc(t.name) + '：' + esc(r.msg || '') + (r.ms != null ? '（' + r.ms + 'ms）' : '');
		}).join('<br>');
	}

	function row(e) {
		var k = kindOf(e);
		var s = e.sum || {};
		var t = new Date(e.ts * 1000);
		var html = '<tr class="IcdRow" data-id="' + esc(e.id) + '">';
		html += '<td nowrap>' + esc(t.toLocaleDateString('ja-JP')) + '<br>' + esc(t.toLocaleTimeString('ja-JP')) + '</td>';
		html += '<td><span class="IcdKind ' + esc(k) + '">' + esc(KindNames[k] || k) + '</span></td>';
		html += '<td class="IcdMono" nowrap>' + esc(e.remote) + '<br><span class="IcdSmall">' + esc(e.scheme) + ' / ' + esc(e.protocol) + '</span></td>';
		html += '<td class="IcdMono IcdUri">' + esc(e.method) + ' ' + esc(e.uri) + '<br><span class="IcdSmall">' + esc(e.host) + '</span></td>';
		// 内容
		html += '<td>';
		if(k == 'phone-report') {
			html += phoneSummary(e);
		} else if(k == 'phone-open') {
			html += '<span class="IcdSmall">' + esc(e.ua) + '</span>';
		} else {
			if(s.actions && s.actions.length) html += 'action: <b>' + esc(s.actions.join(', ')) + '</b><br>';
			if(s.iskType) html += 'アプリ: ' + esc(s.iskType) + (s.appVersion ? ' v' + esc(s.appVersion) : '') + '<br>';
			if(s.device) html += '<span class="IcdSmall IcdMono">端末 ' + esc(s.device) + '</span><br>';
			if(s.tournament) html += '<span class="IcdSmall">大会 ' + esc(s.tournament) + '</span><br>';
			if(!(s.actions && s.actions.length)) html += '<span class="IcdSmall">' + esc(e.bodyLen ? e.bodyLen + ' バイト（ISK の形ではない）' : '本文なし') + '</span>';
		}
		html += '</td>';
		// 応答
		html += '<td>';
		if(e.status != null) {
			var bad = e.status != 200 || s.error === true || e.phpError;
			html += '<span class="' + (bad ? 'IcdErr' : 'IcdOk') + '">HTTP ' + esc(e.status) + (s.error === true ? ' error' : '') + '</span> <span class="IcdSmall">' + esc(e.ms) + 'ms</span>';
			if(s.errorMsg) html += '<br><span class="IcdErr">' + esc(s.errorMsg) + '</span>';
			if(s.respActions && s.respActions.length) html += '<br>' + esc(s.respActions.join(', '));
			if(e.phpError) html += '<br><span class="IcdErr">PHP: ' + esc(e.phpError) + '</span>';
		}
		html += '</td></tr>';
		// 詳細
		html += '<tr class="IcdDetail" data-for="' + esc(e.id) + '"' + (Open[e.id] ? '' : ' style="display:none"') + '><td colspan="6">';
		html += '<b>要求ヘッダー</b><pre>' + esc(Object.keys(e.headers || {}).map(function(h) { return h + ': ' + e.headers[h]; }).join('\n')) + '</pre>';
		html += '<b>要求本文</b>（' + esc(e.bodyLen) + ' バイト）<pre>' + esc(pretty(e.body)) + '</pre>';
		if(e.status != null) {
			html += '<b>応答ヘッダー</b><pre>' + esc((e.respHeaders || []).join('\n')) + '</pre>';
			html += '<b>応答本文</b><pre>' + esc(pretty(e.resp)) + '</pre>';
		}
		html += '</td></tr>';
		return html;
	}

	function render(data) {
		var body = document.getElementById('IcdLogBody');
		if(data.error) {
			body.innerHTML = '<tr><td colspan="6" class="IcdErr">' + esc(data.errorMsg || '読み込めません') + '</td></tr>';
			return;
		}
		if(data.file) {
			document.getElementById('IcdFile').textContent = data.file;
		}
		if(!data.entries.length) {
			body.innerHTML = '<tr><td colspan="6" class="IcdSmall">まだ記録はありません。</td></tr>';
			return;
		}
		body.innerHTML = data.entries.map(row).join('');
	}

	function load(extra) {
		var opt = {credentials: 'same-origin', cache: 'no-store'};
		if(extra) {
			opt.method = 'POST';
			opt.body = new URLSearchParams(extra);
		}
		return fetch(Cfg.logUrl, opt).then(function(r) { return r.json(); }).then(render).catch(function(e) {
			document.getElementById('IcdLogBody').innerHTML = '<tr><td colspan="6" class="IcdErr">読み込めません: ' + esc(e) + '</td></tr>';
		});
	}

	function schedule() {
		clearTimeout(Timer);
		if(document.getElementById('IcdAuto').checked) {
			Timer = setTimeout(function() { load().then(schedule); }, 3000);
		}
	}

	function probe(btn) {
		var tb = document.getElementById('IcdProbe');
		btn.disabled = true;
		tb.innerHTML = '<tr><td colspan="4" class="IcdSmall">試しています…（つながらない URL があると十数秒かかります）</td></tr>';
		fetch(Cfg.probeUrl, {method: 'POST', credentials: 'same-origin', body: new URLSearchParams({base: btn.dataset.base})})
			.then(function(r) { return r.json(); })
			.then(function(d) {
				if(d.error) {
					tb.innerHTML = '<tr><td colspan="4" class="IcdErr">' + esc(d.errorMsg) + '</td></tr>';
					return;
				}
				var html = '<tr><th>テスト</th><th>URL</th><th>結果</th><th>判定</th></tr>';
				d.probes.forEach(function(p) {
					var r = p.r;
					html += '<tr><td><b>' + esc(p.name) + '</b><div class="IcdSmall">' + esc(p.note) + '</div></td>';
					html += '<td class="IcdMono IcdSmall">' + esc(r.method) + ' ' + esc(r.url) + (r.verify ? '' : '<br>（証明書は確かめない）') + '</td>';
					html += '<td class="IcdSmall">' + (r.error ? '<span class="IcdErr">' + esc(r.error) + '</span>' : 'HTTP ' + esc(r.status))
						+ ' / ' + esc(r.ms) + 'ms' + (r.ip ? ' / ' + esc(r.ip) : '')
						+ (r.body ? '<pre>' + esc(r.body) + '</pre>' : '') + '</td>';
					html += '<td><div class="IcdChk ' + esc(p.judge[0]) + '">' + JudgeMark[p.judge[0]] + ' ' + esc(p.judge[1]) + '</div></td></tr>';
				});
				tb.innerHTML = html;
				load();
			})
			.catch(function(e) {
				tb.innerHTML = '<tr><td colspan="4" class="IcdErr">実行できません: ' + esc(e) + '</td></tr>';
			})
			.then(function() { btn.disabled = false; });
	}

	function init(cfg) {
		Cfg = cfg;
		document.getElementById('IcdLogBody').addEventListener('click', function(ev) {
			var tr = ev.target.closest('tr.IcdRow');
			if(!tr) return;
			var id = tr.dataset.id;
			var d = document.querySelector('tr.IcdDetail[data-for="' + id + '"]');
			Open[id] = !Open[id];
			if(d) d.style.display = Open[id] ? '' : 'none';
		});
		document.getElementById('IcdAuto').addEventListener('change', schedule);
		document.getElementById('IcdReload').addEventListener('click', function() { load(); });
		var clr = document.getElementById('IcdClear');
		if(clr) {
			clr.addEventListener('click', function() {
				if(confirm('通信ログを消しますか？')) {
					Open = {};
					load({act: 'clear'});
				}
			});
		}
		document.getElementById('IcdProbeBtn').addEventListener('click', function() { probe(this); });
		load().then(schedule);
	}

	return {init: init};
})();
