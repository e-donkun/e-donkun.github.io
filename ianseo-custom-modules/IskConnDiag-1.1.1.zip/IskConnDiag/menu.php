<?php
/*
ISK接続診断: Scorekeeper NG（Lite / Pro / Live）の大会で、スコアキーパーメニューに「ISK接続診断」を追加する。

変更履歴:
2026/10/12 初版
*/
// 11 / 12 / 13 = ISK_NG_LITE_CODE / ISK_NG_PRO_CODE / ISK_NG_LIVE_CODE（Api/ISK-NG/config_defines.php）
if(!empty($on) and in_array(intval($_SESSION['UseApi'] ?? 0), [11, 12, 13]) and isset($acl) and subFeatureAcl($acl, AclISKServer, 'iskManagement') >= AclReadOnly) {
	$ret['API'][] = MENU_DIVIDER;
	$ret['API'][] = 'ISK接続診断' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/IskConnDiag/index.php';
}
