<?php
/*
ISK接続診断: 「サーバーからの到達テスト」を実行して結果を JSON で返す。
*/
require_once(__DIR__ . '/Bootstrap.php');

CheckTourSession(true);
checkFullACL(AclISKServer, 'iskManagement', AclReadOnly);

$Base = (string)($_POST['base'] ?? '');
if(!preg_match('#^https?://[^\s"<>?\#]+/$#i', $Base)) {
	JsonOut(['error' => true, 'errorMsg' => 'URL は http:// か https:// で始まり / で終わる形にしてください。']);
}

JsonOut(['error' => false, 'base' => $Base, 'probes' => iskDiagProbes($Base)]);
