#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ISK接続診断: Scorekeeper の通信を記録する中継プログラム（Windows PC 用）

Windows PC のモバイルホットスポット（外のインターネットには出られない Wi-Fi）に
スマホをつなぎ、Scorekeeper のサーバーURLをこの PC（例 http://192.168.137.1:8080/ianseo/）にすると、
受けた要求をそのまま上流（例 https://doshisha.click）に送り、要求と応答を記録する。

- Python 3.8 以上の標準ライブラリだけで動く（https で待ち受けるときの証明書づくりだけ cryptography を使う）
- 記録: logs/proxy-YYYYMMDD.jsonl（1 行 1 件の JSON）
- 閲覧: ブラウザで http://<この PC>:8080/__proxy/
- https で待ち受けると、アプリが証明書を拒否したとき（TLS の失敗）も記録する

使いかた:
    python isk_proxy.py                       # http :8080 で待ち受け、上流は既定の URL
    python isk_proxy.py --https 8443          # https :8443 でも待ち受け（自己署名証明書を作る）
    python isk_proxy.py --upstream https://example.com --http 8080
    python isk_proxy.py --help

変更履歴:
2026/10/12 初版
"""
import argparse
import datetime
import http.client
import http.server
import ipaddress
import json
import os
import re
import socket
import socketserver
import ssl
import sys
import threading
import time
import traceback
import urllib.parse
import uuid

VERSION = '1.0.0'

# ダウンロードしたサーバーの URL がここに入る（IskConnDiag の Download.php が書き換える）
DEFAULT_UPSTREAM = '__ISKDIAG_UPSTREAM__'
if DEFAULT_UPSTREAM.startswith('__'):
    DEFAULT_UPSTREAM = 'https://doshisha.click'

HOP_BY_HOP = {
    'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization', 'te', 'trailer', 'trailers',
    'transfer-encoding', 'upgrade', 'proxy-connection',
}
HERE = os.path.dirname(os.path.abspath(__file__))

ARGS = None
LOG_LOCK = threading.Lock()
RECENT = []          # 閲覧画面用（新しいものが後ろ）
RECENT_MAX = 300


# ---------------------------------------------------------------- 記録

def now_ts():
    return time.time()


def log_path():
    return os.path.join(ARGS.log_dir, 'proxy-' + datetime.datetime.now().strftime('%Y%m%d') + '.jsonl')


def mask(text):
    """大会コードの後ろの PIN（「コード|PIN」）を伏せる。JSON の中の JSON（\\" で囲まれた値）にも効く"""
    if not text:
        return text
    text = re.sub(r'(\\?"(?:tournament|tocode|c)\\?"\s*:\s*\\?"[^"|\\]*\|)[^"\\]*', r'\1****', text)
    return re.sub(r'((?:tournament|tocode)%22%3A%22[^%|]*(?:%7C|\|))[^%]*', r'\1****', text, flags=re.I)


def body_text(data, limit):
    """記録用に本文を文字列にする（長すぎるものは切る、文字でなければ大きさだけ）"""
    if data is None:
        return ''
    cut = data[:limit]
    try:
        text = cut.decode('utf-8')
    except UnicodeDecodeError:
        return '（バイナリ %d バイト）' % len(data)
    text = mask(text)
    if len(data) > limit:
        text += '…（%d バイト中 %d バイトまで記録）' % (len(data), limit)
    return text


def summarize(entry):
    """ISK-NG の要求・応答なら action などを取り出す"""
    s = {'actions': [], 'device': '', 'iskType': '', 'appVersion': '', 'error': None, 'errorMsg': '', 'respActions': []}
    req = None
    body = entry.get('body') or ''
    try:
        req = json.loads(body)
    except ValueError:
        form = urllib.parse.parse_qs(body)
        if form.get('requests'):
            try:
                req = json.loads(form['requests'][0])
            except ValueError:
                pass
    if isinstance(req, dict) and 'requests' in req:
        req = req['requests']
    for r in (req if isinstance(req, list) else [req]):
        if not isinstance(r, dict):
            continue
        if 'action' in r:
            s['actions'].append(str(r['action']))
        s['device'] = s['device'] or str(r.get('device') or r.get('uuid') or '')
        s['iskType'] = s['iskType'] or str(r.get('iskType') or '')
        s['appVersion'] = s['appVersion'] or str(r.get('version') or '')
    try:
        resp = json.loads(entry.get('resp') or '')
    except ValueError:
        resp = None
    if isinstance(resp, dict):
        if 'error' in resp:
            s['error'] = bool(resp['error'])
        s['errorMsg'] = str(resp.get('errorMsg') or '')
        for r in resp.get('responses') or []:
            if isinstance(r, dict) and 'action' in r:
                a = str(r['action'])
                if a == 'handshake' and 'error' in r:
                    a += '(error=%s)' % r['error']
                if a == 'reset' and r.get('resetMessage'):
                    a += '(%s)' % r['resetMessage']
                s['respActions'].append(a)
    return s


def write_log(entry):
    entry['sum'] = summarize(entry)
    line = json.dumps(entry, ensure_ascii=False)
    with LOG_LOCK:
        try:
            with open(log_path(), 'a', encoding='utf-8') as f:
                f.write(line + '\n')
        except OSError as e:
            print('記録を書けません:', e, file=sys.stderr)
        RECENT.append(entry)
        del RECENT[:-RECENT_MAX]
    # 画面にも 1 行で出す
    t = datetime.datetime.fromtimestamp(entry['ts']).strftime('%H:%M:%S')
    if entry['kind'] == 'tls-error':
        print('%s  %-21s  TLS の失敗: %s' % (t, entry['client'], entry.get('error', '')))
        return
    s = entry['sum']
    what = ','.join(s['actions']) or '-'
    res = entry.get('error') or ('HTTP %s' % entry.get('status'))
    extra = ' '.join(x for x in [s['errorMsg'], ','.join(s['respActions'])] if x)
    print('%s  %-21s  %-6s %-40s %-12s -> %s %s  %sms' % (
        t, entry['client'], entry['method'], entry['path'][:40], what, res, extra, entry.get('ms', '')))


# ---------------------------------------------------------------- 中継

class ProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'IskProxy/' + VERSION

    def log_message(self, fmt, *args):
        pass  # 自前で記録するので、標準の出力は止める

    def do_GET(self):
        if self.path.startswith('/__proxy/'):
            return self.viewer()
        self.do_relay()

    def read_body(self):
        if 'chunked' in (self.headers.get('Transfer-Encoding') or '').lower():
            data = b''
            while True:
                size = int(self.rfile.readline().split(b';')[0].strip() or b'0', 16)
                if size == 0:
                    while self.rfile.readline() not in (b'\r\n', b'\n', b''):
                        pass
                    return data
                data += self.rfile.read(size)
                self.rfile.readline()
        length = int(self.headers.get('Content-Length') or 0)
        return self.rfile.read(length) if length > 0 else b''

    def do_relay(self):
        t0 = now_ts()
        up = ARGS.upstream_parts
        body = self.read_body()
        client = '%s:%s' % self.client_address[:2]
        scheme = 'https' if self.server.is_https else 'http'
        entry = {
            'id': uuid.uuid4().hex[:12], 'kind': 'relay', 'ts': t0, 'client': client, 'scheme': scheme,
            'method': self.command, 'path': mask(self.path), 'protocol': self.request_version,
            'host': self.headers.get('Host', ''), 'ua': self.headers.get('User-Agent', ''),
            'headers': {k: (v if k.lower() not in ('cookie', 'authorization') else '（%d 文字・記録しない）' % len(v))
                        for k, v in self.headers.items()},
            'body': body_text(body, ARGS.max_body), 'bodyLen': len(body),
            'upstream': up.scheme + '://' + up.netloc + self.path,
        }

        # 上流に送るヘッダー
        headers = {}
        for k, v in self.headers.items():
            lk = k.lower()
            if lk in HOP_BY_HOP or lk == 'host' or lk == 'content-length':
                continue
            if lk == 'accept-encoding' and not ARGS.keep_encoding:
                continue  # 記録を読めるように圧縮させない
            headers[k] = v
        headers['Host'] = up.netloc
        if body or self.command in ('POST', 'PUT', 'PATCH'):
            headers['Content-Length'] = str(len(body))
        xff = self.headers.get('X-Forwarded-For')
        headers['X-Forwarded-For'] = (xff + ', ' if xff else '') + self.client_address[0]
        headers['X-Forwarded-Proto'] = scheme

        try:
            if up.scheme == 'https':
                ctx = ssl._create_unverified_context() if ARGS.insecure_upstream else ssl.create_default_context()
                conn = http.client.HTTPSConnection(up.hostname, up.port or 443, timeout=ARGS.timeout, context=ctx)
            else:
                conn = http.client.HTTPConnection(up.hostname, up.port or 80, timeout=ARGS.timeout)
            conn.request(self.command, self.path, body=body if body else None, headers=headers)
            resp = conn.getresponse()
            data = resp.read()
            conn.close()
        except Exception as e:
            entry['ms'] = round((now_ts() - t0) * 1000)
            entry['error'] = '上流につながりません: %s: %s' % (type(e).__name__, e)
            entry['status'] = 502
            write_log(entry)
            msg = json.dumps({'error': True, 'errorMsg': 'IskProxy: ' + entry['error']}, ensure_ascii=False).encode('utf-8')
            self.send_response(502)
            self.send_header('Content-Type', 'application/json; charset=UTF-8')
            self.send_header('Content-Length', str(len(msg)))
            self.end_headers()
            if self.command != 'HEAD':
                self.wfile.write(msg)
            return

        # アプリに返す
        self.send_response(resp.status, resp.reason)
        resp_headers = []
        for k, v in resp.getheaders():
            lk = k.lower()
            if lk in HOP_BY_HOP or lk == 'content-length':
                continue
            if lk == 'location' and ARGS.rewrite_location:
                origin = up.scheme + '://' + up.netloc
                if v.startswith(origin):
                    v = scheme + '://' + (self.headers.get('Host') or '') + v[len(origin):]
            self.send_header(k, v)
            resp_headers.append('%s: %s' % (k, v))
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data)

        entry['ms'] = round((now_ts() - t0) * 1000)
        entry['status'] = resp.status
        entry['respHeaders'] = resp_headers
        entry['resp'] = body_text(data, ARGS.max_body)
        entry['respLen'] = len(data)
        write_log(entry)

    # ------------------------------------------------------------ 閲覧画面

    def viewer(self):
        if self.path.startswith('/__proxy/log.json'):
            with LOG_LOCK:
                data = list(reversed(RECENT))
            out = json.dumps({'upstream': ARGS.upstream, 'entries': data}, ensure_ascii=False).encode('utf-8')
            ctype = 'application/json; charset=UTF-8'
        else:
            out = VIEWER_HTML.replace('__UPSTREAM__', ARGS.upstream).encode('utf-8')
            ctype = 'text/html; charset=UTF-8'
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(out)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(out)


# GET 以外のメソッドもすべて中継する
for _m in ('do_POST', 'do_PUT', 'do_DELETE', 'do_PATCH', 'do_OPTIONS', 'do_HEAD'):
    setattr(ProxyHandler, _m, ProxyHandler.do_relay)


class ProxyServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, addr, ssl_ctx=None):
        self.ssl_ctx = ssl_ctx
        self.is_https = ssl_ctx is not None
        super().__init__(addr, ProxyHandler)

    def finish_request(self, request, client_address):
        # https は接続ごとにここで TLS を始める。アプリが証明書を拒否するとここで失敗するので、それを記録する
        if self.ssl_ctx:
            try:
                request.settimeout(ARGS.timeout)
                request = self.ssl_ctx.wrap_socket(request, server_side=True)
            except (ssl.SSLError, OSError) as e:
                write_log({'id': uuid.uuid4().hex[:12], 'kind': 'tls-error', 'ts': now_ts(),
                           'client': '%s:%s' % client_address[:2], 'scheme': 'https', 'method': '', 'path': '',
                           'error': '%s: %s' % (type(e).__name__, e)})
                try:
                    request.close()
                except OSError:
                    pass
                return
        super().finish_request(request, client_address)

    def handle_error(self, request, client_address):
        if ARGS.verbose:
            traceback.print_exc()


# ---------------------------------------------------------------- 証明書

def ensure_cert(names):
    cert = os.path.join(HERE, 'cert.pem')
    key = os.path.join(HERE, 'key.pem')
    if ARGS.cert and ARGS.key:
        return ARGS.cert, ARGS.key
    if os.path.exists(cert) and os.path.exists(key):
        return cert, key
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
    except ImportError:
        sys.exit('https で待ち受けるには証明書が必要です。\n'
                 '  pip install cryptography  をしてからもう一度起動するか、--cert と --key で証明書を指定してください。')
    pk = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'IskProxy self-signed')])
    alt = []
    for n in names:
        try:
            alt.append(x509.IPAddress(ipaddress.ip_address(n)))
        except ValueError:
            alt.append(x509.DNSName(n))
    now = datetime.datetime.now(datetime.timezone.utc)
    crt = (x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(pk.public_key())
           .serial_number(x509.random_serial_number())
           .not_valid_before(now - datetime.timedelta(days=1)).not_valid_after(now + datetime.timedelta(days=365))
           .add_extension(x509.SubjectAlternativeName(alt), critical=False)
           .sign(pk, hashes.SHA256()))
    with open(key, 'wb') as f:
        f.write(pk.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                 serialization.NoEncryption()))
    with open(cert, 'wb') as f:
        f.write(crt.public_bytes(serialization.Encoding.PEM))
    print('自己署名証明書を作りました:', cert)
    return cert, key


# ---------------------------------------------------------------- 起動

def local_ips():
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    try:
        # 外向きに使う IP（実際には送らない）
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(('192.0.2.1', 9))
            ips.add(s.getsockname()[0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith('127.'))


def main():
    global ARGS
    p = argparse.ArgumentParser(description='Scorekeeper の通信を記録して上流の ianseo に中継する')
    p.add_argument('--upstream', default=DEFAULT_UPSTREAM, help='中継先（既定: %(default)s）')
    p.add_argument('--bind', default='0.0.0.0', help='待ち受ける IP（既定: すべて）')
    p.add_argument('--http', type=int, default=8080, help='http で待ち受けるポート（0 で使わない。既定: 8080）')
    p.add_argument('--https', type=int, default=0, help='https で待ち受けるポート（例 8443。既定: 使わない）')
    p.add_argument('--cert', help='https の証明書（PEM）。なければ自己署名証明書を作る')
    p.add_argument('--key', help='https の秘密鍵（PEM）')
    p.add_argument('--log-dir', default=os.path.join(HERE, 'logs'), help='記録を置くフォルダ')
    p.add_argument('--max-body', type=int, default=65536, help='記録する本文の上限バイト数')
    p.add_argument('--timeout', type=float, default=20, help='上流の応答を待つ秒数')
    p.add_argument('--rewrite-location', action='store_true', help='上流の転送先（Location）をこの中継の URL に書き換える')
    p.add_argument('--keep-encoding', action='store_true', help='Accept-Encoding をそのまま渡す（記録が圧縮されて読めなくなる）')
    p.add_argument('--insecure-upstream', action='store_true', help='上流の証明書を確かめない')
    p.add_argument('--verbose', action='store_true', help='内部のエラーを詳しく出す')
    ARGS = p.parse_args()

    ARGS.upstream = ARGS.upstream.rstrip('/')
    ARGS.upstream_parts = urllib.parse.urlsplit(ARGS.upstream)
    if ARGS.upstream_parts.scheme not in ('http', 'https') or not ARGS.upstream_parts.hostname:
        sys.exit('--upstream は http:// か https:// から始まる URL にしてください')
    if ARGS.upstream_parts.path not in ('', '/'):
        sys.exit('--upstream はホスト名まで（例 https://doshisha.click）。ianseo のフォルダはアプリの URL の側に付けます')
    os.makedirs(ARGS.log_dir, exist_ok=True)

    ips = local_ips()
    servers = []
    if ARGS.http:
        servers.append(('http', ARGS.http, ProxyServer((ARGS.bind, ARGS.http))))
    if ARGS.https:
        cert, key = ensure_cert(ips + ['localhost', '192.168.137.1'])
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert, key)
        servers.append(('https', ARGS.https, ProxyServer((ARGS.bind, ARGS.https), ctx)))
    if not servers:
        sys.exit('--http か --https のどちらかは使ってください')

    print('ISK 中継プログラム %s' % VERSION)
    print('中継先: %s' % ARGS.upstream)
    print('記録先: %s' % os.path.abspath(ARGS.log_dir))
    print('この PC の IP: %s（モバイルホットスポットはふつう 192.168.137.1）' % (', '.join(ips) or '不明'))
    for scheme, port, _ in servers:
        print('  アプリのサーバーURL例: %s://192.168.137.1:%d/ianseo/' % (scheme, port))
    print('  記録の閲覧: http://localhost:%d/__proxy/' % (ARGS.http or ARGS.https))
    print('止めるときは Ctrl+C')
    print('-' * 70)

    for scheme, port, srv in servers[1:]:
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        servers[0][2].serve_forever()
    except KeyboardInterrupt:
        print('\n止めました')


VIEWER_HTML = r'''<!DOCTYPE html>
<html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>ISK 中継の記録</title>
<style>
body { font-family: sans-serif; margin: 0; padding: 12px; font-size: 14px; }
h1 { font-size: 1.2em; margin: 0 0 .5em; }
table { border-collapse: collapse; width: 100%; }
th, td { border-bottom: 1px solid #ddd; padding: 4px 6px; text-align: left; vertical-align: top; }
th { background: #003f87; color: #fff; }
tr.row { cursor: pointer; } tr.row:hover { background: #f0f4ff; }
.mono { font-family: monospace; word-break: break-all; }
.small { font-size: .85em; color: #555; }
.ok { color: #2e7d32; font-weight: bold; } .ng { color: #c62828; font-weight: bold; }
pre { white-space: pre-wrap; word-break: break-all; background: #fafafa; margin: 2px 0; max-height: 25em; overflow: auto; font-size: .85em; }
</style></head><body>
<h1>ISK 中継の記録 <span class="small">中継先 __UPSTREAM__</span></h1>
<label><input type="checkbox" id="auto" checked> 2 秒ごとに更新</label>
<span class="small">（この画面はこのプログラムを起動してからの分。全部は logs フォルダの jsonl にあります。行をクリックで詳細）</span>
<table><thead><tr><th>時刻</th><th>端末</th><th>要求</th><th>内容</th><th>応答</th></tr></thead><tbody id="b"></tbody></table>
<script>
var open = {};
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function(c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
function pretty(t) { try { return JSON.stringify(JSON.parse(t), null, 2); } catch(e) { return t; } }
function row(e) {
  var s = e.sum || {}, t = new Date(e.ts * 1000), h = '';
  h += '<tr class="row" data-id="' + e.id + '"><td>' + esc(t.toLocaleTimeString('ja-JP')) + '</td>';
  h += '<td class="mono">' + esc(e.client) + '<br><span class="small">' + esc(e.scheme) + '</span></td>';
  if (e.kind == 'tls-error') {
    return h + '<td colspan="3" class="ng">TLS の失敗（アプリが証明書を拒否した可能性）: ' + esc(e.error) + '</td></tr>';
  }
  h += '<td class="mono">' + esc(e.method) + ' ' + esc(e.path) + '</td><td>';
  if (s.actions && s.actions.length) h += 'action: <b>' + esc(s.actions.join(', ')) + '</b><br>';
  if (s.iskType) h += 'アプリ: ' + esc(s.iskType) + (s.appVersion ? ' v' + esc(s.appVersion) : '') + '<br>';
  if (s.device) h += '<span class="small mono">端末 ' + esc(s.device) + '</span>';
  h += '</td><td>';
  var bad = e.error || e.status != 200 || s.error === true;
  h += '<span class="' + (bad ? 'ng' : 'ok') + '">' + esc(e.error || ('HTTP ' + e.status)) + '</span> <span class="small">' + esc(e.ms) + 'ms</span>';
  if (s.errorMsg) h += '<br><span class="ng">' + esc(s.errorMsg) + '</span>';
  if (s.respActions && s.respActions.length) h += '<br>' + esc(s.respActions.join(', '));
  h += '</td></tr>';
  h += '<tr data-for="' + e.id + '"' + (open[e.id] ? '' : ' style="display:none"') + '><td colspan="5">';
  h += '<b>中継先</b> <span class="mono">' + esc(e.upstream) + '</span>';
  h += '<br><b>要求ヘッダー</b><pre>' + esc(Object.keys(e.headers || {}).map(function(k) { return k + ': ' + e.headers[k]; }).join('\n')) + '</pre>';
  h += '<b>要求本文</b>（' + esc(e.bodyLen) + ' バイト）<pre>' + esc(pretty(e.body)) + '</pre>';
  h += '<b>応答ヘッダー</b><pre>' + esc((e.respHeaders || []).join('\n')) + '</pre>';
  h += '<b>応答本文</b>（' + esc(e.respLen) + ' バイト）<pre>' + esc(pretty(e.resp)) + '</pre></td></tr>';
  return h;
}
function load() {
  return fetch('log.json', {cache: 'no-store'}).then(function(r) { return r.json(); }).then(function(d) {
    document.getElementById('b').innerHTML = d.entries.length ? d.entries.map(row).join('') : '<tr><td colspan="5" class="small">まだ記録はありません</td></tr>';
  });
}
document.getElementById('b').addEventListener('click', function(ev) {
  var tr = ev.target.closest('tr.row'); if (!tr) return;
  var id = tr.dataset.id; open[id] = !open[id];
  var d = document.querySelector('tr[data-for="' + id + '"]'); if (d) d.style.display = open[id] ? '' : 'none';
});
function tick() { if (document.getElementById('auto').checked) load(); setTimeout(tick, 2000); }
load(); setTimeout(tick, 2000);
</script></body></html>
'''

if __name__ == '__main__':
    main()
