ISK 中継プログラム（IskConnDiag）  Windows PC 用の手順
======================================================================

Windows PC で「外のインターネットには出られない Wi-Fi」を作ってスマホをつなぎ、
Scorekeeper の通信をこの PC で記録しながら、本番の ianseo サーバーに中継します。

  [スマホ: Scorekeeper]
     │ Wi-Fi（PC のモバイルホットスポット。インターネットには出られない）
     ▼
  [Windows PC] 192.168.137.1
     ├ isk_proxy.py   :8080 (http) / :8443 (https・自己署名証明書)
     │    要求と応答を logs\proxy-YYYYMMDD.jsonl に記録
     │    ブラウザで http://localhost:8080/__proxy/ を開くと一覧が見られる
     └ PC 自身の回線（有線 LAN 推奨）
            │ https
            ▼
     本番の ianseo サーバー（ダウンロードしたサーバーが既定の中継先）


■ ファイル
  isk_proxy.py      中継プログラム本体（Python 3.8 以上・標準ライブラリだけで動く）
  start_proxy.bat   起動用。ダブルクリックで http :8080 で待ち受ける
                    （cryptography が入っていれば https :8443 も）
  README.txt        この手順


■ 1. Python を入れる
  https://www.python.org/downloads/ から入れる。
  インストール画面で「Add python.exe to PATH」にチェックを入れる。
  https（:8443）も試すときは、コマンドプロンプトで
      py -3 -m pip install cryptography


■ 2. 外に出られない Wi-Fi（モバイルホットスポット）を作る
  方法 A（おすすめ）: ループバックアダプターを共有の元にする
    1) デバイスマネージャー → 操作 → レガシ ハードウェアの追加
       → 一覧から選択 → ネットワーク アダプター
       → Microsoft → 「Microsoft KM-TEST ループバック アダプター」を追加
    2) 設定 → ネットワークとインターネット → モバイルホットスポット
       「インターネット接続を共有する元」にループバックアダプター（イーサネット 2 など）を選ぶ
    3) ネットワーク名・パスワードを決めてオンにする
    4) Windows 11 は「省電力」（端末がつながっていないと自動で切れる）をオフにする
  方法 B（A がうまくいかないとき）: 旅行用ルーターを AP モードにして PC と有線でつなぐ
    （WAN はつながない。PC の有線側は固定 IP、ルーターの DHCP は PC を指さない）

  PC 自身の上流の回線は有線 LAN をおすすめします。
  同じ Wi-Fi カードで「上流の Wi-Fi」と「ホットスポット」を同時に使うと不安定になりがちです。

  ホットスポットの PC 側の IP はふつう 192.168.137.1 です（ipconfig で確かめる）。


■ 3. ファイアウォールで待ち受けを許可する
  管理者のコマンドプロンプトで:
      netsh advfirewall firewall add rule name="ISK proxy" dir=in action=allow protocol=TCP localport=8080,8443
  （初めて起動したときに出る「アクセスを許可する」の画面では「パブリック」にもチェックを入れる）


■ 4. 起動する
  start_proxy.bat をダブルクリック。黒い画面に通信が 1 行ずつ出ます。止めるときは Ctrl+C。
  別の中継先にするとき:
      start_proxy.bat --upstream https://example.com
  そのほかの設定:
      py -3 isk_proxy.py --help


■ 5. つながることを確かめる
  スマホをホットスポットにつなぎ、スマホのブラウザで
    - http://192.168.137.1:8080/__proxy/         → 記録の画面が開く（中継プログラムに届いている）
    - https://www.google.com                      → 開けない（外に出られない）
  ※ Android はインターネットのない Wi-Fi だと「接続を維持しますか」と聞いたり、
    モバイルデータで通信したりします。これもイントラネットで起きうる現象なので、
    下の試験 3 で確かめます。


■ 6. Scorekeeper をつなぐ
  ianseo の「ISK接続診断」の画面で、「検証に使うサーバーURL」を
      http://192.168.137.1:8080/ianseo/
  にして作り直し（画面の候補に出ます）、① の QR をアプリで読ませます。
  ① を使うと、この中継プログラムとサーバーの通信ログの両方に記録が残ります。


■ 7. 試す内容
  1) http://192.168.137.1:8080/ianseo/
       基準。これが通れば、アプリ・中継・本番サーバーは正常。
  2) https://192.168.137.1:8443/ianseo/（自己署名証明書）
       証明書の仮説。記録の画面に「TLS の失敗（…UNKNOWN_CA など）」が出れば、
       アプリが自己署名・社内 CA の証明書を拒否している。
  3) 1) と同じ URL で、Android のモバイルデータをオン / オフ
       オンのときだけ失敗し、記録に何も出なければ、
       「インターネットのない Wi-Fi を避けてモバイルデータで通信している」。
  4) start_proxy.bat --rewrite-location（転送先を中継の URL に書き換える）
       本番サーバーが転送（3xx）を返す場合の動きを比べる。

  何も記録されないときは、要求がこの PC に届いていません。
  Wireshark（Npcap）でホットスポットの仮想アダプター
  （Microsoft Wi-Fi Direct Virtual Adapter）をキャプチャすると、
  スマホが DNS を引いているか、どこに接続しようとしているかが見えます。
  Windows 標準の pktmon でも取れます:
      pktmon start --capture
      （操作する）
      pktmon stop
      pktmon etl2pcap PktMon.etl      → Wireshark で開ける


■ 記録の扱い
  logs\ の記録には端末 ID や選手のデータが入ります（大会コードの PIN は **** に伏せます）。
  終わったら消してください。
