@echo off
rem ISK proxy launcher (IskConnDiag)
rem Starts isk_proxy.py with http :8080, and https :8443 when the "cryptography" package is installed.
rem Extra options can be given, e.g.:  start_proxy.bat --upstream https://example.com
cd /d "%~dp0"

set PY=python
where py >nul 2>nul
if %errorlevel%==0 set PY=py -3

%PY% --version >nul 2>nul
if not %errorlevel%==0 (
	echo Python is not installed. Install it from https://www.python.org/downloads/
	pause
	exit /b 1
)

set HTTPS=
%PY% -c "import cryptography" >nul 2>nul
if %errorlevel%==0 set HTTPS=--https 8443

%PY% isk_proxy.py --http 8080 %HTTPS% %*
pause
