<?php
/*
ISK接続診断: 通信ログを JSON で返す。act=clear（POST）で消す。
*/
require_once(__DIR__ . '/Bootstrap.php');

CheckTourSession(true);
checkFullACL(AclISKServer, 'iskManagement', AclReadOnly);

if(($_POST['act'] ?? '') == 'clear') {
	checkFullACL(AclISKServer, 'iskManagement', AclReadWrite);
	iskDiagClearLog();
}

$Entries = iskDiagReadLog(200);
foreach($Entries as &$e) {
	$e['sum'] = iskDiagSummarize($e);
	if(isset(AppNames[intval($e['sum']['iskType'])])) {
		$e['sum']['iskType'] .= ' ' . AppNames[intval($e['sum']['iskType'])];
	}
}
unset($e);

JsonOut(['error' => false, 'file' => iskDiagLogFile(), 'entries' => $Entries]);
