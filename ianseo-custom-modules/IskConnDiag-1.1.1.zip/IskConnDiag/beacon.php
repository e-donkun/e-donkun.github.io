<?php
/*
ISK接続診断: スマホのブラウザで開いた phone.php が、テストの結果を送ってくる先。
送られてきた内容をそのまま記録する（ianseo 本体は読み込まない）。
*/
require_once(__DIR__ . '/TapLib.php');

$Entry = iskDiagRequestInfo('phone-report');
iskDiagWrite($Entry);

header('Content-type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
echo json_encode(['error' => false, 'id' => $Entry['id']]);
