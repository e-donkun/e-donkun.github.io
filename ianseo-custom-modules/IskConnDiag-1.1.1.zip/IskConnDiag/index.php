<?php
/*
ISK接続診断: Scorekeeper（ISK-NG）がサーバーにつながらないときの切り分け用の画面。
1. ISK-NG の設定（サーバーURL・PIN）と、QR コードに入る URL の書き方を確かめる
2. サーバー自身から API に要求を送って、転送・証明書・アクセス制限がないか確かめる
3. 検証用 QR コード（tap 経由）をアプリで読ませ、アプリが実際に送ってきた要求と応答を記録して見る
4. スマホのブラウザ用のテストページ（phone.php）で、ブラウザからは届くかを確かめる
ISK-NG の設定やデータは変えない（記録は log/ のファイルだけ）。

変更履歴:
2026/10/12 初版
*/
require_once(__DIR__ . '/Bootstrap.php');

CheckTourSession(true);
checkFullACL(AclISKServer, 'iskManagement', AclReadOnly);
$CanClear = hasFullACL(AclISKServer, 'iskManagement', AclReadWrite);

$UseApi = intval($_SESSION['UseApi'] ?? 0);
$TourCode = $_SESSION['TourCode'];
$ServerUrl = (string)getModuleParameter('ISK-NG', 'ServerUrl', '');
$Pin = (string)getModuleParameter('ISK-NG', 'ServerUrlPin', '');
$QrBase = $ServerUrl !== '' ? $ServerUrl . $CFG->ROOT_DIR : '';
$ServerIps = iskDiagServerAddresses();

// 検証に使う URL（画面で選び直せる）
$Base = (string)($_GET['base'] ?? '');
if(!preg_match('#^https?://[^\s"<>?\#]+/$#i', $Base)) {
	$Base = $QrBase !== '' ? $QrBase : iskDiagCurrentRootUrl();
}
$Candidates = [];
if($QrBase !== '') {
	$Candidates[$QrBase] = 'ISK-NG の設定のサーバーURL';
}
$Https = (!empty($_SERVER['HTTPS']) and strtolower($_SERVER['HTTPS']) != 'off');
$PortPart = in_array(intval($_SERVER['SERVER_PORT'] ?? 80), [80, 443]) ? '' : ':' . intval($_SERVER['SERVER_PORT']);
foreach($ServerIps as $ip) {
	$u = ($Https ? 'https' : 'http') . '://' . (strpos($ip, ':') !== false ? '[' . $ip . ']' : $ip) . $PortPart . $CFG->ROOT_DIR;
	$Candidates[$u] = $Candidates[$u] ?? 'このサーバーの IP';
}
$Cur = iskDiagCurrentRootUrl();
$Candidates[$Cur] = $Candidates[$Cur] ?? 'この画面を開いている URL';
// Windows PC の中継プログラム（proxy/isk_proxy.py）をモバイルホットスポットで動かすとき
$ProxyBase = 'http://192.168.137.1:8080' . $CFG->ROOT_DIR;
$ProxyBaseTls = 'https://192.168.137.1:8443' . $CFG->ROOT_DIR;
$Candidates[$ProxyBase] = $Candidates[$ProxyBase] ?? 'Windows PC の中継プログラム（http）';
$Candidates[$ProxyBaseTls] = $Candidates[$ProxyBaseTls] ?? 'Windows PC の中継プログラム（https・自己署名証明書）';

$CodeWithPin = $TourCode . ($Pin !== '' ? '|' . $Pin : '');
$TapBase = $Base . 'Modules/Custom/' . basename(__DIR__) . '/tap/';
$PhoneUrl = $Base . 'Modules/Custom/' . basename(__DIR__) . '/phone.php?base=' . rawurlencode($Base);
$QrTap = json_encode(['u' => $TapBase, 'c' => $CodeWithPin], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
$QrNormal = json_encode(['u' => $Base, 'c' => $CodeWithPin], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

$ModeName = AppNames[$UseApi] ?? '';
$Checks = [];
if(!in_array($UseApi, [ISK_NG_LITE_CODE, ISK_NG_PRO_CODE, ISK_NG_LIVE_CODE])) {
	$Checks[] = ['ng', 'この大会は Scorekeeper NG（Lite / Pro / Live）を使う設定になっていません（大会の設定 → 「使う API」）。アプリはハンドシェイクで拒否されます（error=1）。'];
} elseif($UseApi == ISK_NG_LIVE_CODE) {
	$Checks[] = ['warn', 'Live モードです。Live はサーバーURLではなくソケット（' . getModuleParameter('ISK-NG', 'SocketIP', '') . ':' . getModuleParameter('ISK-NG', 'SocketPort', '') . '）につなぎます。この画面の tap による記録は Lite / Pro 向けです。社内ネットワークではソケットのポートが閉じられていることが多いので、そちらも確かめてください。'];
}
if($UseApi != ISK_NG_LIVE_CODE) {
	$Checks = array_merge($Checks, iskDiagCheckServerUrl($ServerUrl));
}
$BaseChecks = iskDiagCheckBase($Base, $ServerIps);

$IskDebug = (($CFG->DEBUG ?? false) and is_dir($CFG->DOCUMENT_PATH . 'Api/ISK-NG/log') and is_writable($CFG->DOCUMENT_PATH . 'Api/ISK-NG/log'));

function iskDiagChecksHtml($Checks) {
	if(!$Checks) {
		return '<div class="IcdChk ok">気になる点はありません。</div>';
	}
	$Mark = ['ng' => '✖', 'warn' => '⚠', 'info' => 'ℹ', 'ok' => '✔'];
	$Ret = '';
	foreach($Checks as $c) {
		$Ret .= '<div class="IcdChk ' . $c[0] . '">' . $Mark[$c[0]] . ' ' . htmlspecialchars($c[1]) . '</div>';
	}
	return $Ret;
}

$PAGE_TITLE = 'ISK接続診断';
$JS_SCRIPT = [
	'<style>
		.IcdChk { padding: 0.2em 0.5em; margin: 0.15em 0; border-left: 4px solid #999; }
		.IcdChk.ng { border-color: #c62828; background: #ffebee; }
		.IcdChk.warn { border-color: #f9a825; background: #fff8e1; }
		.IcdChk.info { border-color: #1565c0; background: #e3f2fd; }
		.IcdChk.ok { border-color: #2e7d32; background: #e8f5e9; }
		.IcdMono { font-family: monospace; word-break: break-all; }
		.IcdQrs { display: flex; flex-wrap: wrap; gap: 1em; }
		.IcdQr { flex: 1 1 260px; text-align: center; padding: 0.5em; border: 1px solid #ccc; border-radius: 0.3em; }
		.IcdQrImg { display: inline-block; background: #fff; padding: 12px; max-width: 100%; box-sizing: border-box; line-height: 0; }
		.IcdQrImg svg { display: block; width: 220px; max-width: 100%; height: auto; padding: 0; margin: 0; box-sizing: content-box; }
		.IcdQr h4 { margin: 0.2em 0; }
		.IcdSmall { font-size: 0.85em; color: #555; }
		.IcdLog td { vertical-align: top; padding: 0.2em 0.4em; font-size: 0.9em; }
		.IcdLog td.IcdUri { min-width: 16em; }
		.IcdLog tr.IcdRow { cursor: pointer; }
		.IcdLog tr.IcdRow:hover { background: #f0f4ff; }
		.IcdLog pre { white-space: pre-wrap; word-break: break-all; margin: 0.2em 0; font-size: 0.85em; max-height: 25em; overflow: auto; background: #fafafa; }
		.IcdKind { display: inline-block; padding: 0 0.4em; border-radius: 0.3em; color: #fff; font-size: 0.85em; white-space: nowrap; }
		.IcdKind.tap { background: #1565c0; }
		.IcdKind.tap-other { background: #6a1b9a; }
		.IcdKind.phone-open, .IcdKind.phone-report, .IcdKind.phone-tap { background: #00838f; }
		.IcdKind.probe { background: #757575; }
		.IcdErr { color: #c62828; font-weight: bold; }
		.IcdOk { color: #2e7d32; font-weight: bold; }
	</style>',
	'<script src="' . iskDiagWebDir() . 'index.js"></script>',
];

require_once('Common/Templates/head.php');

echo '<table class="Tabella">';
echo '<tr><th class="Title" colspan="2">ISK接続診断</th></tr>';
echo '<tr><th class="TitleLeft w-25">大会</th><td>' . htmlspecialchars($TourCode) . '（' . ($ModeName ? htmlspecialchars($ModeName) : 'Scorekeeper NG を使わない設定') . '）</td></tr>';
if($UseApi != ISK_NG_LIVE_CODE) {
	echo '<tr><th class="TitleLeft">サーバーURL（ISK-NG の設定）</th><td class="IcdMono">' . htmlspecialchars($ServerUrl !== '' ? $ServerUrl : '（未設定）') . '</td></tr>';
	echo '<tr><th class="TitleLeft">PIN</th><td>' . ($Pin !== '' ? '設定あり（QR コードの大会コードは「' . htmlspecialchars($TourCode) . '|' . str_repeat('*', strlen($Pin)) . '」）' : 'なし') . '</td></tr>';
	echo '<tr><th class="TitleLeft">ianseo のフォルダ（ROOT_DIR）</th><td class="IcdMono">' . htmlspecialchars($CFG->ROOT_DIR) . '</td></tr>';
	echo '<tr><th class="TitleLeft">QR コードに入る URL</th><td class="IcdMono">' . htmlspecialchars($QrBase !== '' ? $QrBase : '（作れません）') . '<div class="IcdSmall">アプリはこの後ろに「Api/ISK-NG/」を付けて送ってきます。</div></td></tr>';
}
echo '<tr><th class="TitleLeft">設定の確認</th><td>' . iskDiagChecksHtml($Checks) . '</td></tr>';
echo '<tr><th class="TitleLeft">このサーバー</th><td>IP: <span class="IcdMono">' . htmlspecialchars(implode(', ', $ServerIps) ?: '（取れません）') . '</span>'
	. '<br>ホスト名: <span class="IcdMono">' . htmlspecialchars(gethostname() ?: '') . '</span>'
	. '<br>Web サーバー: ' . htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? '') . ' / PHP ' . PHP_VERSION . (function_exists('curl_init') ? '' : '（curl 拡張なし）')
	. '<br>ianseo: ' . ProgramVersion . (defined('ProgramBuild') ? ' ' . ProgramBuild : '')
	. '<br>ISK-NG 本体のデバッグ記録: ' . ($IskDebug ? '<span class="IcdOk">有効</span>（Api/ISK-NG/log/）' : '無効（Api/ISK-NG/README.md の手順で有効にできます）')
	. '</td></tr>';
echo '</table>';

echo '<br><form method="get"><table class="Tabella">';
echo '<tr><th class="Title" colspan="2">検証に使うサーバーURL</th></tr>';
echo '<tr><th class="TitleLeft w-25">URL</th><td><input type="text" name="base" class="w-75 IcdMono" value="' . htmlspecialchars($Base) . '"> <input type="submit" value="この URL で作り直す">'
	. '<div class="IcdSmall">http(s):// から ianseo のフォルダまで、末尾は /。IP とホスト名、http と https などを入れ替えて比べると切り分けられます。</div>';
foreach($Candidates as $u => $Label) {
	echo '<div><a href="?base=' . rawurlencode($u) . '" class="IcdMono">' . htmlspecialchars($u) . '</a> <span class="IcdSmall">（' . htmlspecialchars($Label) . '）</span></div>';
}
echo '</td></tr>';
echo '<tr><th class="TitleLeft">この URL の確認</th><td>' . iskDiagChecksHtml($BaseChecks) . '</td></tr>';
echo '</table></form>';

echo '<br><table class="Tabella"><tr><th class="Title">検証用 QR コード</th></tr><tr><td><div class="IcdQrs">';
echo '<div class="IcdQr"><h4>① Scorekeeper 用（記録つき）</h4><div class="IcdQrImg">' . iskDiagQrSvg($QrTap) . '</div>'
	. '<div class="IcdSmall">アプリの設定 QR として読ませます。アプリの通信を記録してから、本物の API に渡します。</div><div class="IcdMono IcdSmall">' . htmlspecialchars(iskDiagMask($QrTap)) . '</div></div>';
echo '<div class="IcdQr"><h4>② Scorekeeper 用（通常・比較用）</h4><div class="IcdQrImg">' . iskDiagQrSvg($QrNormal) . '</div>'
	. '<div class="IcdSmall">ISK-NG の設定 QR と同じ内容（URL だけ上で選んだもの）。記録はされません。</div><div class="IcdMono IcdSmall">' . htmlspecialchars(iskDiagMask($QrNormal)) . '</div></div>';
echo '<div class="IcdQr"><h4>③ スマホのブラウザ用</h4><div class="IcdQrImg">' . iskDiagQrSvg($PhoneUrl) . '</div>'
	. '<div class="IcdSmall">スマホのカメラで読んでブラウザで開きます。ブラウザからなら届くかを試して記録します。</div><div class="IcdMono IcdSmall"><a href="' . htmlspecialchars($PhoneUrl) . '" target="_blank">' . htmlspecialchars($PhoneUrl) . '</a></div></div>';
echo '</div></td></tr></table>';

$Dl = iskDiagWebDir() . 'Download.php?f=';
echo '<br><table class="Tabella">';
echo '<tr><th class="Title" colspan="2">中継プログラム（Windows PC 用）</th></tr>';
echo '<tr><th class="TitleLeft w-25">内容</th><td>Windows PC で外のインターネットには出られない Wi-Fi（モバイルホットスポット）を作ってスマホをつなぎ、'
	. 'Scorekeeper の通信をその PC で記録しながら、このサーバー（<span class="IcdMono">' . htmlspecialchars(preg_replace('#^(https?://[^/]+).*$#', '$1', $Cur)) . '</span>）に中継します。'
	. 'https（自己署名証明書）でも待ち受けられるので、アプリが証明書を拒否するかも確かめられます。Python 3.8 以上が必要です。</td></tr>';
echo '<tr><th class="TitleLeft">ダウンロード</th><td>'
	. (class_exists('ZipArchive') ? '<div><a href="' . $Dl . 'zip"><b>まとめてダウンロード（isk_proxy.zip）</b></a></div>' : '')
	. '<div><a href="' . $Dl . 'isk_proxy.py">isk_proxy.py</a> <span class="IcdSmall">中継プログラム本体（既定の中継先はこのサーバー）</span></div>'
	. '<div><a href="' . $Dl . 'start_proxy.bat">start_proxy.bat</a> <span class="IcdSmall">起動用（ダブルクリック）</span></div>'
	. '<div><a href="' . $Dl . 'README.txt">README.txt</a> <span class="IcdSmall">Windows での手順（ホットスポットの作りかた・試す内容）</span></div>'
	. '</td></tr>';
echo '<tr><th class="TitleLeft">使いかた</th><td>'
	. '1. 3 つのファイルを PC の同じフォルダに置き、README.txt の手順でホットスポットを作って start_proxy.bat を起動します。<br>'
	. '2. 「検証に使うサーバーURL」を <a href="?base=' . rawurlencode($ProxyBase) . '" class="IcdMono">' . htmlspecialchars($ProxyBase) . '</a>'
	. '（https は <a href="?base=' . rawurlencode($ProxyBaseTls) . '" class="IcdMono">' . htmlspecialchars($ProxyBaseTls) . '</a>）にして、① の QR をアプリで読ませます。<br>'
	. '3. PC のブラウザで <span class="IcdMono">http://localhost:8080/__proxy/</span> を開くと、中継した通信が見られます。① を使うと、下の通信ログにも記録されます。'
	. '</td></tr>';
echo '</table>';

echo '<br><table class="Tabella">';
echo '<tr><th class="Title" colspan="4">サーバーからの到達テスト <input type="button" id="IcdProbeBtn" value="実行" data-base="' . htmlspecialchars($Base) . '"></th></tr>';
echo '<tbody id="IcdProbe"><tr><td colspan="4" class="IcdSmall">「実行」を押すと、このサーバー自身から上の URL の API に ping を送って、転送・証明書・アクセス制限がないかを確かめます。</td></tr></tbody>';
echo '</table>';

echo '<br><table class="Tabella IcdLog">';
echo '<tr><th class="Title" colspan="6">通信ログ（新しい順・最大 200 件）'
	. ' <label><input type="checkbox" id="IcdAuto" checked> 3 秒ごとに更新</label>'
	. ' <input type="button" id="IcdReload" value="更新">'
	. ($CanClear ? ' <input type="button" id="IcdClear" value="ログを消す">' : '')
	. '</th></tr>';
echo '<tr><td colspan="6" class="IcdSmall">記録先: <span class="IcdMono" id="IcdFile">' . htmlspecialchars(iskDiagLogFile() ?: '（書き込めるフォルダがないため記録できません。log/ フォルダを Web サーバーが書き込めるようにしてください）') . '</span>　行をクリックすると詳しい内容を開きます。</td></tr>';
echo '<tr><th>時刻</th><th>種類</th><th>送信元</th><th>要求</th><th>内容</th><th>応答</th></tr>';
echo '<tbody id="IcdLogBody"></tbody>';
echo '</table>';

echo '<br><table class="Tabella"><tr><th class="Title" colspan="2">結果の見かた</th></tr>
<tr><th class="TitleLeft w-25">③ のページが開けない</th><td>スマホとサーバーの間のネットワークの問題です（別の Wi-Fi・VLAN、ゲスト Wi-Fi、AP の端末間通信の遮断（プライバシーセパレーター）、ファイアウォール、名前が引けない、Web 認証の Wi-Fi）。アプリの問題ではありません。</td></tr>
<tr><th class="TitleLeft">③ は OK なのに ① で通信ログに何も出ない</th><td>要求がサーバーに届く前に、アプリか OS で止まっています。主な原因: https の証明書（自己署名・社内 CA）、iOS の「ローカルネットワーク」の許可がオフ、iOS の ATS（http＋ホスト名）、Android がインターネットのない Wi-Fi を避けてモバイルデータで通信している、Android のプライベート DNS、VPN や MDM。モバイルデータを切る・IP アドレスの URL で ① を作り直す、で切り分けます。</td></tr>
<tr><th class="TitleLeft">① で記録が出る</th><td>応答の列を見ます。3xx は転送（https への強制・/ の付け足し）、403 はアクセス制限や WAF、「Validation failed」は PIN 違い、handshake(error=1) は大会の「使う API」とアプリのモード（Lite / Pro）が合っていない、です。送信元の IP がスマホではなくプロキシになっていれば、プロキシを通っています。</td></tr>
<tr><th class="TitleLeft">① は動くのに ② は動かない</th><td>① と ② は URL の後ろ以外は同じなので、普通は起きません。起きたら ② の URL（Api/ISK-NG/）の前にある Web サーバーの設定（転送・アクセス制限）を疑います。</td></tr>
</table>';

echo '<script>IskConnDiag.init(' . json_encode(['logUrl' => iskDiagWebDir() . 'LogData.php', 'probeUrl' => iskDiagWebDir() . 'Probe.php']) . ');</script>';

require_once('Common/Templates/tail.php');
