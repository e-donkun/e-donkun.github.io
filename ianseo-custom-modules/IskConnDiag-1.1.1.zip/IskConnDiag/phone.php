<?php
/*
ISK接続診断: スマホのブラウザで開く到達テストのページ（ログイン不要）。
- このページを開けたこと自体を記録する（どの IP から、どのブラウザで来たか）
- ブラウザから ISK-NG の API に、アプリと同じように JSON を POST して返事が来るかを試す
  （ping だけを送るので、端末の登録や点数には影響しない）
- 結果を beacon.php に送って記録する。管理画面（index.php）の通信ログで見られる

?base=〇〇 が付いていれば、その URL（QR コードに入るサーバーURL）あての API も試す。
ianseo 本体は読み込まない（ログインや大会の選択がなくても開けるように）。
*/
require_once(__DIR__ . '/TapLib.php');

iskDiagWrite(iskDiagRequestInfo('phone-open'));

$Base = (string)($_GET['base'] ?? '');
if(!preg_match('#^https?://[^\s"<>]+/$#i', $Base)) {
	$Base = '';
}

header('Content-type: text/html; charset=UTF-8');
header('Cache-Control: no-store');
?><!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ISK接続テスト</title>
<style>
	body { font-family: sans-serif; margin: 0; padding: 16px; background: #f5f5f5; color: #222; }
	h1 { font-size: 1.3em; margin: 0 0 0.5em; }
	.box { background: #fff; border-radius: 8px; padding: 12px; margin-bottom: 12px; box-shadow: 0 1px 2px rgba(0,0,0,.15); }
	.row { padding: 8px 0; border-bottom: 1px solid #eee; }
	.row:last-child { border-bottom: 0; }
	.name { font-weight: bold; }
	.url { font-family: monospace; font-size: 0.8em; color: #555; word-break: break-all; }
	.res { margin-top: 4px; }
	.ok { color: #2e7d32; font-weight: bold; }
	.ng { color: #c62828; font-weight: bold; }
	.wait { color: #888; }
	.detail { font-family: monospace; font-size: 0.75em; color: #666; word-break: break-all; white-space: pre-wrap; }
	button { font-size: 1.1em; padding: 0.5em 1em; }
	dl { margin: 0; font-size: 0.85em; }
	dt { font-weight: bold; margin-top: 4px; }
	dd { margin: 0 0 0 1em; word-break: break-all; }
</style>
</head>
<body>
<h1>ISK接続テスト（ブラウザ）</h1>
<div class="box">
	<div class="ok">✔ このページは開けました（スマホ → サーバーの通信はできています）</div>
	<dl>
		<dt>開いたURL</dt><dd id="Here"></dd>
		<dt>ブラウザ</dt><dd id="Ua"></dd>
		<dt>回線</dt><dd id="Net"></dd>
	</dl>
</div>
<div class="box" id="Tests"></div>
<div class="box">
	<button type="button" id="Again">もう一度試す</button>
	<div class="detail" id="Sent"></div>
</div>
<script>
(function() {
	var Base = <?php echo json_encode($Base, JSON_UNESCAPED_SLASHES); ?>;
	var Here = new URL(location.href);
	var Tests = [
		{name: 'ISK-NG の API（このページと同じサーバー）', url: new URL('../../../Api/ISK-NG/', Here).href},
		{name: '検証用の中継（tap）', url: new URL('tap/Api/ISK-NG/', Here).href}
	];
	if(Base) {
		var u = new URL('Api/ISK-NG/', Base).href;
		if(u != Tests[0].url) {
			Tests.push({name: 'QR コードのサーバーURLあての API', url: u});
		}
	}
	var Net = navigator.connection ? (navigator.connection.type || '') + ' ' + (navigator.connection.effectiveType || '') : '（ブラウザが教えてくれない）';
	document.getElementById('Here').textContent = location.href;
	document.getElementById('Ua').textContent = navigator.userAgent;
	document.getElementById('Net').textContent = Net + (navigator.onLine ? '' : '（オフライン表示）');

	function esc(s) {
		return String(s).replace(/[&<>"]/g, function(c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]; });
	}

	function runOne(t) {
		var Ctl = window.AbortController ? new AbortController() : null;
		var Timer = setTimeout(function() { if(Ctl) Ctl.abort(); }, 8000);
		var T0 = Date.now();
		// text/plain にして事前確認（CORS の OPTIONS）が飛ばないようにする。API は Content-Type を見ずに本文を読む
		return fetch(t.url, {
			method: 'POST',
			headers: {'Content-Type': 'text/plain'},
			body: JSON.stringify({action: 'ping', device: 'IskConnDiag-phone', apiVersion: 1}),
			cache: 'no-store',
			redirect: 'manual',
			signal: Ctl ? Ctl.signal : undefined
		}).then(function(r) {
			return r.text().then(function(txt) {
				var j = null;
				try { j = JSON.parse(txt); } catch(e) {}
				var ok = r.status == 200 && j && j.error === false;
				var msg = r.type == 'opaqueredirect' ? '転送（リダイレクト）されました' : 'HTTP ' + r.status;
				return {ok: ok, status: r.status, type: r.type, ms: Date.now() - T0, msg: msg, body: txt.substring(0, 300)};
			});
		}).catch(function(e) {
			return {ok: false, status: 0, ms: Date.now() - T0, msg: (e && e.name == 'AbortError') ? '8 秒待っても返事なし' : '接続できません: ' + e, body: ''};
		}).then(function(res) {
			clearTimeout(Timer);
			t.result = res;
			return res;
		});
	}

	function render() {
		var html = '';
		Tests.forEach(function(t, i) {
			var r = t.result;
			html += '<div class="row"><div class="name">' + esc(t.name) + '</div><div class="url">' + esc(t.url) + '</div><div class="res">';
			if(!r) {
				html += '<span class="wait">試しています…</span>';
			} else {
				html += (r.ok ? '<span class="ok">✔ 返事あり（' : '<span class="ng">✖ だめ（') + esc(r.msg) + '・' + r.ms + 'ms）</span>';
				if(r.body) html += '<div class="detail">' + esc(r.body) + '</div>';
			}
			html += '</div></div>';
		});
		document.getElementById('Tests').innerHTML = html;
	}

	function runAll() {
		Tests.forEach(function(t) { t.result = null; });
		render();
		document.getElementById('Sent').textContent = '';
		var p = Promise.resolve();
		Tests.forEach(function(t) {
			p = p.then(function() { return runOne(t); }).then(render);
		});
		p.then(function() {
			return fetch(new URL('beacon.php', Here).href, {
				method: 'POST',
				headers: {'Content-Type': 'text/plain'},
				body: JSON.stringify({page: location.href, ua: navigator.userAgent, net: Net, online: navigator.onLine, tests: Tests}),
				cache: 'no-store'
			});
		}).then(function() {
			document.getElementById('Sent').textContent = '結果をサーバーに記録しました。管理画面の「通信ログ」で見られます。';
		}).catch(function(e) {
			document.getElementById('Sent').textContent = '結果をサーバーに送れませんでした: ' + e;
		});
	}

	document.getElementById('Again').addEventListener('click', runAll);
	runAll();
})();
</script>
</body>
</html>
