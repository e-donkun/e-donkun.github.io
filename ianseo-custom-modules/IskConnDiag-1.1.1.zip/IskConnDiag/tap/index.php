<?php
/*
ISK接続診断: アプリが Api/ISK-NG/ 以外の場所に要求を送ってきたときに、それを記録するためだけのファイル。
ISK-NG の API ではないので、エラーを返す。
*/
require_once(dirname(__DIR__) . '/TapLib.php');
iskDiagTapStart('tap-other');
header('Content-type: application/json; charset=UTF-8');
echo json_encode(['error' => true, 'errorMsg' => 'IskConnDiag: not an ISK-NG API endpoint', 'path' => $_SERVER['REQUEST_URI'] ?? '']);
