<?php
/*
ISK接続診断: Scorekeeper の通信の中継。
検証用 QR コードではサーバーURLを「…/Modules/Custom/IskConnDiag/tap/」にしてあるので、
アプリはここ（tap/Api/ISK-NG/）に要求を送ってくる。要求と応答を記録して、
処理は本物の ISK-NG の API（Api/ISK-NG/index.php）にそのまま任せる。
*/
require_once(dirname(__DIR__, 3) . '/TapLib.php');
iskDiagTapStart('tap');

// Api/ISK-NG/index.php は ./v1/〇〇.php を相対パスで読むので、本物のフォルダに移ってから読み込む。
// 本体側の変数（$SKIP_AUTH など）がグローバルになるよう、関数の中ではなくここで include する。
$IskDiagApiDir = iskDiagIanseoRoot() . 'Api' . DIRECTORY_SEPARATOR . 'ISK-NG' . DIRECTORY_SEPARATOR;
chdir($IskDiagApiDir);
include($IskDiagApiDir . 'index.php');
