<?php
/*
背景色の設定: ianseo の画面の背景色と文字色を選んで保存する。試合ごとに設定できる。
- 色は 2 つ。背景色（--header-light）と文字色（--header-dark。見出しの帯・リンク・表の文字）
- それぞれ、見本から選ぶか、色の選択・#RRGGBB で入れる。選ぶとすぐこの画面に反映し、「保存」で反映する
- 「この試合」に保存すると、その試合を開いているときだけその色になる。「全試合の標準」は、試合の設定がない試合で使う色
- デバッグモードのときもこの色にするかを選ぶ（しないときは、デバッグモードの色 colors_debug.css のまま）
保存した色は menu.php が画面に出す。
色はこの ianseo の全員の画面が変わるので、管理者（本体の「更新」を使える人）だけが使える。

変更履歴:
2026/10/22 文字色を選べるようにし、試合ごとに設定できるようにした
2026/09/30 初版
*/
require_once(dirname(__DIR__) . '/config.php');
require_once(__DIR__ . '/Lib.php');

/** 色の見本（名前 => [背景色, 文字色]） */
const BGC_PRESETS = [
	'薄い緑' => ['#F0FFF0', '#1B5E20'],
	'薄いクリーム' => ['#FFFDF0', '#5D4037'],
	'薄いグレー' => ['#F4F4F4', '#333333'],
	'薄いピンク' => ['#FFF0F5', '#880E4F'],
	'ianseo の標準（薄い水色）' => [BGC_IANSEO, BGC_IANSEO_DARK],
];

/** 設定を変えられるか（カスタムモジュール管理・本体の「更新」と同じ条件） */
function bgcCanEdit() {
	if(!hasFullACL(AclRoot, '', AclReadWrite)) {
		return false;
	}
	return (empty($_SESSION['AUTH_ENABLE']) or !empty($_SESSION['AUTH_ROOT']));
}

/** フォーム送信の確認用のトークン */
function bgcToken() {
	if(empty($_SESSION['bgcToken'])) {
		$_SESSION['bgcToken'] = bin2hex(random_bytes(16));
	}
	return $_SESSION['bgcToken'];
}

if(!bgcCanEdit()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}

$TourId = (int)($_SESSION['TourId'] ?? 0);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	$Set = bgcLoad();
	if(empty($_SESSION['bgcToken']) or !hash_equals($_SESSION['bgcToken'], (string)($_POST['token'] ?? ''))) {
		$Flash = [false, '画面を開き直してから、もう一度試してください。'];
	} elseif(isset($_POST['reset'])) {
		unset($Set['tours'][$TourId]);
		$Flash = bgcSave($Set) ? [true, 'この試合の設定を消しました。全試合の標準の色になります。'] : [false, '保存できませんでした。' . bgcDataDir() . ' にファイルを書けるか確かめてください。'];
	} elseif(!bgcColor($_POST['light'] ?? '') or !bgcColor($_POST['dark'] ?? '')) {
		$Flash = [false, '色は #RRGGBB の形（例: #F0FFF0）で入れてください。'];
	} else {
		$Pair = ['light' => bgcColor($_POST['light']), 'dark' => bgcColor($_POST['dark'])];
		if(($_POST['scope'] ?? '') == 'tour' and $TourId > 0) {
			$Set['tours'][$TourId] = $Pair;
		} else {
			$Set['default'] = $Pair;
		}
		$Set['debug'] = !empty($_POST['debug']);
		$Flash = bgcSave($Set) ? [true, '保存しました。'] : [false, '保存できませんでした。' . bgcDataDir() . ' にファイルを書けるか確かめてください。'];
	}
	$_SESSION['bgcFlash'] = $Flash;
	CD_redirect($CFG->ROOT_DIR . 'Modules/Custom/' . basename(__DIR__) . '/index.php');
}

$Set = bgcLoad();
$HasOwn = isset($Set['tours'][$TourId]);
$Pair = bgcPairFor($Set, $TourId);

$PAGE_TITLE = '背景色';
$Url = $CFG->ROOT_DIR . 'Modules/Custom/' . basename(__DIR__) . '/';
$JS_SCRIPT = [
	'<link rel="stylesheet" href="' . htmlspecialchars($Url . 'index.css') . '">',
	'<script src="' . htmlspecialchars($Url . 'index.js') . '"></script>',
];
require_once('Common/Templates/head.php');

if($Flash = $_SESSION['bgcFlash'] ?? null) {
	unset($_SESSION['bgcFlash']);
	echo '<p class="' . ($Flash[0] ? 'bgcOk' : 'bgcErr') . '">' . htmlspecialchars($Flash[1]) . '</p>';
}

echo '<form method="post" id="bgcForm">';
echo '<input type="hidden" name="token" value="' . htmlspecialchars(bgcToken()) . '">';
echo '<table class="Tabella bgcTable">';
echo '<tr><th colspan="2" class="Main">背景色・文字色</th></tr>';

echo '<tr><th class="SubTitle">保存先</th><td>';
if($TourId > 0) {
	echo '<label><input type="radio" name="scope" value="tour"' . ($HasOwn ? ' checked' : '') . '> この試合だけ（' . htmlspecialchars($_SESSION['TourName'] ?? '') . '）</label><br>';
}
echo '<label><input type="radio" name="scope" value="default"' . (($HasOwn and $TourId > 0) ? '' : ' checked') . '> 全試合の標準（試合の設定がない試合で使う）</label>';
if($TourId > 0) {
	echo '<div class="bgcNote">この試合は、' . ($HasOwn ? 'この試合の設定' : '全試合の標準') . 'の色を使っています。</div>';
} else {
	echo '<div class="bgcNote">試合を開いていないので、全試合の標準の色を設定します。</div>';
}
echo '</td></tr>';

echo '<tr><th class="SubTitle">見本</th><td>';
foreach(BGC_PRESETS as $Name => $Colors) {
	echo '<button type="button" class="bgcSwatch" data-light="' . $Colors[0] . '" data-dark="' . $Colors[1] . '">'
		. '<span class="bgcChip" style="background-color:' . $Colors[0] . ';color:' . $Colors[1] . '">あいう ABC</span>' . htmlspecialchars($Name) . '<br><span class="bgcNote">' . $Colors[0] . ' / ' . $Colors[1] . '</span>'
		. '</button>';
}
echo '</td></tr>';

echo '<tr><th class="SubTitle">背景色</th><td>';
echo '<input type="color" id="bgcLightPicker" value="' . strtolower($Pair['light']) . '"> ';
echo '<input type="text" name="light" id="bgcLight" value="' . $Pair['light'] . '" size="9" maxlength="7" pattern="#[0-9A-Fa-f]{6}" required>';
echo '</td></tr>';

echo '<tr><th class="SubTitle">文字色</th><td>';
echo '<input type="color" id="bgcDarkPicker" value="' . strtolower($Pair['dark']) . '"> ';
echo '<input type="text" name="dark" id="bgcDark" value="' . $Pair['dark'] . '" size="9" maxlength="7" pattern="#[0-9A-Fa-f]{6}" required>';
echo '<div class="bgcNote">見出しの帯・リンク・表の文字に使う色です。背景色との差が小さいと読みにくくなります。</div>';
echo '<div class="bgcNote">色を選ぶと、この画面がすぐその色になります（ほかの画面は「保存」を押すと変わります）。</div>';
echo '<div class="bgcErr" id="bgcWarn" hidden>背景色と文字色が近くて、文字が読みにくくなることがあります。</div>';
echo '</td></tr>';

echo '<tr><th class="SubTitle">デバッグモード</th><td>';
echo '<label><input type="checkbox" name="debug" value="1"' . ($Set['debug'] ? ' checked' : '') . '> デバッグモードのときもこの色にする</label>';
echo '<div class="bgcNote">チェックしないときは、デバッグ中と分かるように、デバッグモードの色（オレンジ系）のままにします。</div>';
echo '</td></tr>';

echo '<tr><td colspan="2" class="Center"><input type="submit" value="保存">';
if($HasOwn) {
	echo ' <input type="submit" name="reset" value="この試合の設定を消す" formnovalidate onclick="return confirm(\'この試合の色の設定を消して、全試合の標準の色に戻します。よろしいですか？\');">';
}
echo '</td></tr>';
echo '</table>';
echo '</form>';

echo '<div class="bgcNote bgcAbout">メニューのない画面（ポップアップ、TV 表示など）は、ianseo の標準の色のままです。<br>'
	. 'この設定は ' . htmlspecialchars('Modules/Custom/' . basename(__DIR__) . '/data/settings.json') . ' に保存します。ianseo を更新しても残ります。</div>';

include('Common/Templates/tail.php');
