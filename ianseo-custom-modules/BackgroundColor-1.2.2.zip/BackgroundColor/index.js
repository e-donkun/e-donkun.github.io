/*
背景色の設定の画面: 色を選んだら、この画面の背景色・文字色をすぐその色にする。
背景色・文字色それぞれで、見本・色の選択・#RRGGBB の入力をそろえる。

変更履歴:
2026/10/22 文字色（--header-dark）を追加
2026/09/30 初版
*/
window.addEventListener('DOMContentLoaded', function() {
	var fields = {
		light: {picker: document.getElementById('bgcLightPicker'), text: document.getElementById('bgcLight'), prop: '--header-light'},
		dark: {picker: document.getElementById('bgcDarkPicker'), text: document.getElementById('bgcDark'), prop: '--header-dark'}
	};
	var warn = document.getElementById('bgcWarn');
	var swatches = document.querySelectorAll('.bgcSwatch');

	function valid(color) {
		return /^#[0-9A-Fa-f]{6}$/.test(color);
	}

	// 相対輝度（WCAG）
	function luminance(color) {
		var c = [1, 3, 5].map(function(i) {
			var v = parseInt(color.substr(i, 2), 16) / 255;
			return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
		});
		return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
	}

	function check() {
		var l = fields.light.text.value, d = fields.dark.text.value;
		if(!valid(l) || !valid(d)) {
			return;
		}
		var a = luminance(l), b = luminance(d);
		// コントラスト比が 4.5 未満だと読みにくい
		warn.hidden = ((Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)) >= 4.5;
	}

	// preview: この画面の色を変える。開いたときは変えない（デバッグモードの色など、今の画面の色をそのまま見せる）
	function show(key, color, preview) {
		if(!valid(color)) {
			return;
		}
		color = color.toUpperCase();
		var f = fields[key];
		if(preview) {
			document.documentElement.style.setProperty(f.prop, color);
		}
		f.picker.value = color.toLowerCase();
		swatches.forEach(function(b) {
			b.classList.toggle('bgcOn', b.dataset.light == fields.light.text.value.toUpperCase() && b.dataset.dark == fields.dark.text.value.toUpperCase());
		});
		check();
	}

	swatches.forEach(function(b) {
		b.addEventListener('click', function() {
			fields.light.text.value = b.dataset.light;
			fields.dark.text.value = b.dataset.dark;
			show('light', b.dataset.light, true);
			show('dark', b.dataset.dark, true);
		});
	});
	Object.keys(fields).forEach(function(key) {
		var f = fields[key];
		f.picker.addEventListener('input', function() {
			f.text.value = f.picker.value.toUpperCase();
			show(key, f.picker.value, true);
		});
		f.text.addEventListener('input', function() {
			show(key, f.text.value.trim(), true);
		});
		show(key, f.text.value, false);
	});
});
