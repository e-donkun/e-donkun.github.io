<?php
/*
背景色: 設定の読み書き。
設定は data/settings.json に保存する（module.json の keep で、モジュールを更新しても残す）。
色は 2 つ: 背景色（--header-light）と文字色（--header-dark。見出しの帯・リンク・表の文字にも使われる）。
試合ごとに色を決められる。試合の設定がなければ、全試合の標準の色を使う。

このファイルは menu.php（ianseo の画面を開くたび）からも読み込むので、
ianseo 本体の関数を使わない軽い処理だけにする。本体の関数を使う処理は index.php に置く。

変更履歴:
2026/10/22 文字色（--header-dark）を選べるようにし、試合ごとに設定できるようにした
2026/09/30 初版
*/

/** 設定を保存していないときの背景色 */
const BGC_DEFAULT = '#F0FFF0';
/** ianseo の標準の背景色（Common/Styles/colors.css の --header-light） */
const BGC_IANSEO = '#F0F8FF';
/** ianseo の標準の文字色（Common/Styles/colors.css の --header-dark） */
const BGC_IANSEO_DARK = '#004488';

/** 設定を置くフォルダ */
function bgcDataDir() {
	return __DIR__ . '/data/';
}

/** #RRGGBB の形なら大文字にして返す。違えば '' */
function bgcColor($Color) {
	$Color = trim((string)$Color);
	return preg_match('/^#[0-9A-Fa-f]{6}$/', $Color) ? strtoupper($Color) : '';
}

/** 1 組の色（light: 背景色, dark: 文字色）を整える。背景色がなければ null */
function bgcPair($Pair) {
	if(!is_array($Pair) or !($Light = bgcColor($Pair['light'] ?? ''))) {
		return null;
	}
	return ['light' => $Light, 'dark' => bgcColor($Pair['dark'] ?? '') ?: BGC_IANSEO_DARK];
}

/**
 * 設定を読む
 * - default: 全試合の標準の色 ['light', 'dark']
 * - tours: 試合ごとの色（試合の ID => ['light', 'dark']）
 * - debug: デバッグモードのときもこの色にするか（false ならデバッグモードの色 colors_debug.css のまま）
 */
function bgcLoad() {
	$Set = ['default' => ['light' => BGC_DEFAULT, 'dark' => BGC_IANSEO_DARK], 'tours' => [], 'debug' => false];
	$File = bgcDataDir() . 'settings.json';
	if(is_file($File) and is_array($Json = json_decode((string)@file_get_contents($File), true))) {
		// 初版は color に背景色だけを保存していた
		if($Pair = bgcPair($Json['default'] ?? ['light' => $Json['color'] ?? ''])) {
			$Set['default'] = $Pair;
		}
		foreach((array)($Json['tours'] ?? []) as $Id => $Pair) {
			if(($Pair = bgcPair($Pair)) and (int)$Id > 0) {
				$Set['tours'][(int)$Id] = $Pair;
			}
		}
		$Set['debug'] = !empty($Json['debug']);
	}
	return $Set;
}

/** 設定を保存する（保存できたら true） */
function bgcSave($Set) {
	$Dir = bgcDataDir();
	if(!is_dir($Dir)) {
		@mkdir($Dir, 0775, true);
	}
	$Json = json_encode($Set, JSON_PRETTY_PRINT);
	return @file_put_contents($Dir . 'settings.json', $Json, LOCK_EX) !== false;
}

/** 試合 $TourId で使う色（試合の設定があればそれ、なければ標準） */
function bgcPairFor($Set, $TourId) {
	return $Set['tours'][(int)$TourId] ?? $Set['default'];
}

/**
 * 背景色・文字色を上書きする <style>
 * colors.css（と、デバッグモードの colors_debug.css）の後に出して、:root の --header-light と --header-dark を上書きする。
 * デバッグモードで、デバッグモードの色を残す設定なら '' を返す。
 */
function bgcStyle($Set = null) {
	$Set = $Set ?? bgcLoad();
	if(!empty($_SESSION['debug']) and !$Set['debug']) {
		return '';
	}
	$Pair = bgcPairFor($Set, $_SESSION['TourId'] ?? 0);
	return '<style>:root { --header-light:' . $Pair['light'] . '; --header-dark:' . $Pair['dark'] . '; }</style>';
}
