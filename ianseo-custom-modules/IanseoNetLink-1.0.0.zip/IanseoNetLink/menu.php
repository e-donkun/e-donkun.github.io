<?php
/*
大会情報メニューに「ianseo.netを表示」を追加する。
押すと、別ウィンドウで ianseo.net のこの大会のページ（https://www.ianseo.net/Details.php?toId=＜大会コード＞）を開く。
- 大会コードは Tournament.ToOnlineId（「ianseo.netに送信」→「オンラインコードを設定」で確かめたときに入る）。
  0 のときは、オンラインコードを保存してあれば（ModulesParameters の SendToIanseo / Credentials）その OnlineId を使う
- 大会コードがなければ、メニューに出さない
- 「ianseo.netに送信」のすぐ下に出す（そのメニューがなければ、大会情報メニューの最後に出す）

変更履歴:
2026/11/10 初版
*/
if(!empty($on) and !empty($_SESSION['TourId'])) {
	$IanseoNetId = 0;
	$q = safe_r_sql("select ToOnlineId from Tournament where ToId=" . intval($_SESSION['TourId']));
	if($r = safe_fetch($q)) {
		$IanseoNetId = intval($r->ToOnlineId);
	}
	if(!$IanseoNetId) {
		$IanseoNetCred = getModuleParameter('SendToIanseo', 'Credentials', (object)['OnlineId' => 0]);
		$IanseoNetId = intval($IanseoNetCred->OnlineId ?? 0);
	}
	if($IanseoNetId > 0) {
		// 「表示名|URL|||target」（Common/Menu.php の getSubMenuItem）
		$IanseoNetItem = 'ianseo.netを表示|https://www.ianseo.net/Details.php?toId=' . $IanseoNetId . '|||_blank';
		if(isset($ret['COMP']['SEND'])) {
			$IanseoNetMenu = [];
			foreach($ret['COMP'] as $k => $v) {
				if(is_int($k)) {
					$IanseoNetMenu[] = $v;
				} else {
					$IanseoNetMenu[$k] = $v;
				}
				if($k === 'SEND') {
					$IanseoNetMenu[] = $IanseoNetItem;
				}
			}
			$ret['COMP'] = $IanseoNetMenu;
		} else {
			$ret['COMP'][] = MENU_DIVIDER;
			$ret['COMP'][] = $IanseoNetItem;
		}
	}
}
