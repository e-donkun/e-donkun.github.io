<?php
/*
スマホモード: 印刷
よく使う帳票を、本体の印刷のページで開くショートカット。
- 帳票は本体のページをそのまま開く（PDF は別のタブに出る）
- 帳票ごとに本体のページと同じ閲覧権限を確かめ、権限がないものは出さない
- スコアカードは、カスタム版（Modules/Custom/CustomPrintScore/PDFScore.php）で、全セッション・全部の的を
  1 つの PDF にまとめて出す（ボタン 1 つ）。印刷の種類は本体の画面の初期値（Complete）にする。
  QR コード（ISK の設定用）も、本体の画面の初期値どおりに印字する
  - カスタム版は、1 的 5・6 人立ちの両ページに QR を印字し、選手のいないページは出さず、右上にセッション名を印字する
  - カスタム版が入っていない、または「カスタムモジュール管理」で無効のときは、標準の
    Qualification/PDFScore.php でセッションごとのボタンにする（標準は、セッションと的の範囲などを
    引数で受け取る作りで、引数なしだと空の 1 ページしか出ない。全セッションをまとめることもできない）
- 決勝の組合せは、その種目（個人・団体）に決勝の設定（EvFinalFirstPhase が 0 でない）があるときだけ出す
  （本体の Common/Globals.inc.php が決勝のメニューを出す条件と同じ）

変更履歴:
2026/10/01 スコアカードは、カスタム版で全セッションを 1 つの PDF にまとめて出す（ボタン 1 つ）
2026/10/01 スコアカードに QR コードを印字するようにした
2026/10/01 スコアカードをセッション選択にした（引数なしでは空の 1 ページだった）。決勝は種目の設定があるときだけ表示
2026/09/30 ランキングラウンドを PrnCompleteAbs.php（PDF）に変えた
2026/09/30 初版
*/
require_once(__DIR__ . '/Lib.php');
spCheckPage('Print');

require_once('Common/Fun_Sessions.inc.php');

// 決勝の設定がある種目があるか（個人・団体）
$HasFinals = [0 => false, 1 => false];
$q = safe_r_sql("SELECT DISTINCT EvTeamEvent FROM Events WHERE EvTournament=" . intval($_SESSION['TourId']) . " AND EvFinalFirstPhase!=0");
while($r = safe_fetch($q)) {
	$HasFinals[intval($r->EvTeamEvent)] = true;
}

// スコアカードの QR コード。本体の Qualification/PrintScore.php の初期値と同じ判断
// - 連携（API）ごとの設定（Mode）があり、live でないもの。pro のものは本体の画面では初期は選ばれない
// - 個人の端末を使う設定のときは、個人用の QR も印字する
$QrApis = [];
foreach(AvailableApis() as $Api) {
	$Mode = getModuleParameter($Api, 'Mode');
	if(!$Mode or strpos($Mode, 'live') !== false or strpos($Mode, 'pro') !== false) {
		continue;
	}
	$QrApis[] = $Api;
}
$QrPersonal = (bool) getModuleParameter('ISK-NG', 'UsePersonalDevices', '');

// スコアカード
// 共通の指定（印刷の種類、ヘッダー・ロゴなど、QR）
$ScoreBase = [
	'ScoreDraw' => 'Complete', 'ScoreDist' => [0], 'ScoreFlags' => 1,
	'ScoreHeader' => 1, 'ScoreLogos' => 1, 'ScorePageHeaderFooter' => 1,
] + ($QrApis ? ['QRCode' => $QrApis] : []) + ($QrPersonal ? ['ScoreQrPersonal' => 1] : []);
$ScoreNote = '予選のスコアカード・全部の的' . ($QrApis || $QrPersonal ? '・QRコードつき' : '') . '（PDF）';

$CustomDir = dirname(__DIR__) . '/CustomPrintScore/';
$ScoreItems = [];
if(is_file($CustomDir . 'PDFScore.php') and is_file($CustomDir . 'menu.php')) {
	// カスタム版が使える: 全セッションを 1 つの PDF に（セッション -1 = すべて。的の範囲は空）
	$ScoreItems[] = [
		'title' => 'スコアカード',
		'note' => str_replace('全部の的', '全セッション・全部の的', $ScoreNote),
		'url' => 'Modules/Custom/CustomPrintScore/PDFScore.php?' . http_build_query(['x_Session' => -1, 'x_From' => '', 'x_To' => ''] + $ScoreBase),
		'acl' => [AclQualification, '', AclReadOnly],
	];
} else {
	// 標準: セッションごとに、的は全部で印刷する
	$Sessions = GetSessions('Q');
	foreach($Sessions as $ses) {
		$ScoreItems[] = [
			'title' => 'スコアカード' . (count($Sessions) > 1 ? '（' . ($ses->SesName != '' ? $ses->SesName : 'セッション' . $ses->SesOrder) . '）' : ''),
			'note' => $ScoreNote,
			'url' => 'Qualification/PDFScore.php?' . http_build_query(['x_Session' => $ses->SesOrder, 'x_From' => 1, 'x_To' => 999] + $ScoreBase),
			'acl' => [AclQualification, '', AclReadOnly],
		];
	}
}

// 帳票（本体のページ）。acl は本体のページが確かめている権限
$Groups = [
	'予選' => array_merge($ScoreItems, [
		['title' => 'リザルトリスト', 'note' => '部門クラスごとの予選の結果（PDF）', 'url' => 'Qualification/PrnComplete.php', 'acl' => [AclQualification, '', AclReadOnly]],
		['title' => 'ランキングラウンド', 'note' => '種目ごとの予選順位（個人・団体、PDF）', 'url' => 'Qualification/PrnCompleteAbs.php', 'acl' => [AclQualification, '', AclReadOnly]],
	]),
	'決勝' => array_filter([
		$HasFinals[0] ? ['title' => '個人決勝ラウンド組合せ', 'note' => '的番号・日程つきのトーナメント表（PDF）', 'url' => 'Final/Individual/PrnBracket.php?ShowTargetNo=1&ShowSchedule=1', 'acl' => [AclIndividuals, '', AclReadOnly]] : null,
		$HasFinals[1] ? ['title' => '団体決勝ラウンド組合せ', 'note' => '的番号・日程つきのトーナメント表（PDF）', 'url' => 'Final/Team/PrnBracket.php?ShowTargetNo=1&ShowSchedule=1', 'acl' => [AclTeams, '', AclReadOnly]] : null,
	]),
];

spHead('Print');
$Shown = 0;
foreach($Groups as $Group => $Items) {
	$Items = array_filter($Items, fn($i) => hasFullACL($i['acl'][0], $i['acl'][1], $i['acl'][2]));
	if(!$Items) {
		continue;
	}
	echo '<div class="sp-section-title">' . spH($Group) . '</div><div class="sp-list">';
	foreach($Items as $i) {
		$Shown++;
		echo '<a class="sp-card tap sp-print" href="' . spH(spRoot($i['url'])) . '" target="_blank" rel="noopener">'
			. spIcon('print')
			. '<span class="sp-card-main"><span class="sp-name">' . spH($i['title']) . '</span>'
			. '<span class="sp-sub">' . spH($i['note']) . '</span></span>'
			. '</a>';
	}
	echo '</div>';
}
if(!$Shown) {
	echo '<div class="sp-empty">印刷できる帳票がありません（権限がありません）</div>';
}
echo '<p class="sp-note">帳票は別のタブで開きます。PDF は、ブラウザの共有や印刷のボタンから印刷・保存できます。</p>';
spTail('Print');
