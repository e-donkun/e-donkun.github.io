<?php
/*
スマホモード: 参加者リスト・IRM設定
本体の Partecipants/index.php に当たる画面。
- 一覧は本体の GetRows()（Partecipants/Fun_Partecipants.local.inc.php）で取得する
- 項目の変更は本体の Partecipants/Set-UpdateField.php を呼ぶ（本体の一覧で項目をクリックして変更するのと同じ処理）
- 選択肢は本体の Partecipants/Get-Divisions.php などから取得する
- 所属先2 の変更は本体の Partecipants-exp/actions/xmlUpdateCountryCode2.php を呼ぶ（参加者リスト（カスタム）と同じ処理）
- 追加は、部門クラス → チーム → 選手（チェックボックス）の順に、過去の参加者（ほかの試合の選手）から選ぶ
  （Participants-action.php。新しい選手の入力や詳細の変更は本体の Partecipants/PopEdit.php を開く）
- 削除は、的番号が設定される前（点数もない）の参加者だけ（Participants-action.php。本体の DeleteRow.php と同じ流れ）
- 一覧に予選の得点・順位・IRM を出し、的番号順・得点順・順位順に並べ替え、部門クラス・IRM ありで絞り込める
- 編集画面の「IRM」タブで、予選（部門クラス）の IRM・順位・メモを変える（旧 Irm.php の機能）
  一覧の取得は本体の Partecipants/ManIrmStatus-getElements.php、保存は ManIrmStatus-setIrm.php を呼ぶ
  （本体の IRM マネジメントと同じ権限があるときだけ）

変更履歴:
2026/09/30 画面の名前を「参加者リスト・IRM設定」にした
2026/09/30 一覧の得点を「得点/金的/X」の 1 行にまとめた
2026/09/30 基本情報で所属先2 を設定できるようにした
2026/09/30 IRM マネジメント（Irm.php）を統合。予選の得点・順位を表示し、並べ替え・絞り込みを追加
2026/09/26 過去の参加者からの追加と、的番号設定前の参加者の削除を追加
2026/09/26 部門クラス・サブクラスのバッジを名前のうしろに表示
2026/09/26 ローカルコード・キャプション・メールアドレスの項目をなくした
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');
spCheckPage('Participants');

require_once('Common/Fun_FormatText.inc.php');
require_once('Common/Fun_Sessions.inc.php');
require_once('Partecipants/Fun_Partecipants.local.inc.php');

/**
 * 予選の得点・順位・IRM（一覧に出す分）。$Id を渡すとその 1 人だけ
 * IRM の保存は本体の ManIrmStatus-setIrm.php で行う
 */
function spQualInfo($Id=0) {
	$Ret = [];
	$q = safe_r_sql("SELECT QuId, QuScore, QuGold, QuXnine, QuHits, QuClRank, QuIrmType, IrmType, DivViewOrder, ClViewOrder
		FROM Qualifications
		INNER JOIN Entries ON EnId=QuId AND EnTournament=" . intval($_SESSION['TourId']) . "
		LEFT JOIN IrmTypes ON IrmId=QuIrmType
		LEFT JOIN Divisions ON DivId=EnDivision AND DivTournament=EnTournament
		LEFT JOIN Classes ON ClId=EnClass AND ClTournament=EnTournament
		" . ($Id ? "WHERE QuId=" . intval($Id) : ''));
	while($r = safe_fetch($q)) {
		$Ret[intval($r->QuId)] = [
			'score' => intval($r->QuScore),
			'gold' => intval($r->QuGold),
			'xnine' => intval($r->QuXnine),
			'hits' => intval($r->QuHits),
			'rank' => intval($r->QuClRank),
			'irm' => $r->QuIrmType ? (string) $r->IrmType : '',
			'dcorder' => intval($r->DivViewOrder) * 1000 + intval($r->ClViewOrder),
		];
	}
	return $Ret;
}

/**
 * GetRows() の 1 行から、この画面で使う項目だけを取り出す（予選の得点・順位・IRM も加える）
 */
function spParticipantRow($r, $Qual=[]) {
	return ($Qual[intval($r['id'])] ?? ['score' => 0, 'gold' => 0, 'xnine' => 0, 'hits' => 0, 'rank' => 0, 'irm' => '', 'dcorder' => 0]) + [
		'id' => intval($r['id']),
		'status' => intval($r['status']),
		'session' => $r['session'],
		'targetno' => $r['targetno'],
		'code' => $r['code'],
		'firstname' => $r['firstname'],
		'name' => $r['name'],
		'sex' => $r['sex'],
		'country_code' => $r['country_code'],
		'country_name' => $r['country_name'],
		'country_code2' => $r['country_id2'] ? $r['country_code2'] : '',
		'country_name2' => $r['country_id2'] ? $r['country_name2'] : '',
		'division' => $r['division'],
		'ageclass' => $r['ageclass'],
		'class' => $r['class'],
		'subclass' => $r['subclass'],
		'targetface' => $r['targetface_name'] ? get_text($r['targetface_name'], 'Tournament', '', true) : '',
		'wc' => intval($r['wc']),
	];
}

// 1 人分を取り直す（変更した後に表示を更新するため）
if(isset($_REQUEST['row'])) {
	$Rows = GetRows(intval($_REQUEST['row']));
	JsonOut(['error' => $Rows ? 0 : 1, 'row' => $Rows ? spParticipantRow($Rows[0], spQualInfo(intval($_REQUEST['row']))) : null]);
}

// 本体の一覧と同じく、Qualifications に行がない選手を補う
safe_w_sql("insert ignore into Qualifications (QuId) select EnId from Entries left join Qualifications on EnId=QuId where QuId is null and EnTournament={$_SESSION['TourId']}");

$Qual = spQualInfo();
$Rows = [];
foreach(GetRows(null, "`Session` ASC, `Target` ASC, `Letter` ASC, EnFirstName, EnName") as $r) {
	if($r['id'] !== null) {
		$Rows[] = spParticipantRow($r, $Qual);
	}
}

// 所属先2 の選択肢（この試合の所属）
$Countries = [];
$q = safe_r_sql("SELECT CoCode, CoName FROM Countries WHERE CoTournament=" . intval($_SESSION['TourId']) . " AND CoCode!='' ORDER BY CoCode");
while($r = safe_fetch($q)) {
	$Countries[] = ['code' => $r->CoCode, 'name' => $r->CoName];
}

// IRM（本体の IRM マネジメントと同じ権限のときだけ）
$CanIrm = hasFullACL(AclParticipants, 'pAdvancedEntries', AclReadWrite);
$IrmTypes = [];
if($CanIrm) {
	$q = safe_r_sql("select * from IrmTypes order by IrmId");
	while($r = safe_fetch($q)) {
		$IrmTypes[] = [
			'id' => intval($r->IrmId),
			'code' => $r->IrmType,
			'label' => $r->IrmType ? ($r->IrmType . ' - ' . get_text('IRM-' . $r->IrmId, 'Tournament')) : '（なし）',
		];
	}
}

$Sessions = [];
foreach(GetSessions('Q') as $s) {
	$Sessions[] = ['id' => intval($s->SesOrder), 'name' => $s->Descr];
}

$Status = [];
foreach([1, 5, 6, 7, 8, 9] as $s) {
	$Status[$s] = get_text('Status_' . $s);
}

$DivClasses = [];
foreach(spDivClasses() as $Key => $d) {
	$DivClasses[] = ['key' => $Key, 'label' => $d->DivId . ' ' . $d->ClId . ' - ' . get_text($d->DivDescription, '', '', true) . ' ' . get_text($d->ClDescription, '', '', true)];
}

spHead('Participants', [
	'SpRows' => $Rows,
	'SpDivClasses' => $DivClasses,
	'SpSessions' => $Sessions,
	'SpStatus' => $Status,
	'SpCountries' => $Countries,
	'SpCanIrm' => $CanIrm,
	'SpIrmTypes' => $IrmTypes,
	'SpIrmHelp' => $CanIrm ? get_text('IrmHelp', 'ODF') : '',
	'SpRankValues' => [
		'deranking' => $CFG->DERANKING,
		'disqualify' => $CFG->DISQUALIFIED,
		'didnotstart' => $CFG->DIDNOTSTART,
	],
	'SpLabels' => [
		'firstname' => '姓',
		'name' => '名',
		'division' => '部門',
		'ageclass' => '年齢クラス',
		'class' => 'クラス',
		'subclass' => 'サブクラス',
	],
]);
?>
<div class="sp-toolbar">
	<label class="sp-search"><?php echo spIcon('search'); ?><input type="search" id="SpSearch" placeholder="名前・所属・コードで検索"></label>
	<div class="sp-chips" id="SpSesChips"></div>
	<div class="sp-row" style="flex:1 1 100%">
		<select id="SpDcFilter" aria-label="部門クラスで絞り込み"></select>
		<select id="SpSort" aria-label="並べ替え">
			<option value="target">的番号順</option>
			<option value="score">得点順</option>
			<option value="rank">順位順</option>
		</select>
	</div>
	<label class="sp-switch"><input type="checkbox" id="SpIrmOnly"> IRM がある人だけ</label>
</div>
<div class="sp-row" style="margin-bottom:8px">
	<div class="sp-count" id="SpCount"></div>
	<button type="button" class="sp-btn sub" style="flex:none" id="SpAddBtn">＋ 追加</button>
</div>
<div class="sp-list" id="SpList"></div>
<p class="sp-note">カードをタップすると、名前や部門・クラスなどを変更できます。変更はその場で保存されます（本体の参加者リストと同じ処理）。的番号が未設定の参加者は、そこから削除もできます。<?php echo $CanIrm ? '「IRM」タブでは、予選の IRM・順位・メモを変えられます。' : ''; ?></p>

<script>
const SpFilter = {
	ses: spStore('part_ses') || 'all',
	dc: spStore('part_dc') || '',
	sort: spStore('part_sort') || 'target',
	irmOnly: spStore('part_irm_only') === '1',
};
// 読み込んだときの並び（的番号順）を覚えておく
SpRows.forEach((r, i) => r._ord = i);

function spHasScore(r) {
	return r.hits > 0 || r.score > 0;
}

function spPartSearchText(r) {
	return spNorm([r.code, r.firstname, r.name, r.country_code, r.country_name, r.country_code2, r.country_name2, r.division, r.class, r.ageclass, r.subclass, r.targetno].join(' '));
}

function spPartCard(r) {
	const tgt = r.session ? (r.session + '-' + (r.targetno || '?')) : '未割当';
	// 部門クラスとサブクラスは名前のうしろに並べる
	let nameTags = '';
	if (r.division || r.class) nameTags += '<span class="sp-tag">' + spEsc(r.division + ' ' + r.class) + '</span>';
	if (r.subclass) nameTags += '<span class="sp-tag">' + spEsc(r.subclass) + '</span>';
	if (r.irm) nameTags += '<span class="sp-tag danger">' + spEsc(r.irm) + '</span>';
	let tags = '';
	if (r.ageclass && r.ageclass != r.class) tags += '<span class="sp-tag">年齢:' + spEsc(r.ageclass) + '</span>';
	if (r.country_code2) tags += '<span class="sp-tag">所属先2: ' + spEsc([r.country_code2, r.country_name2].filter(x => x).join(' ')) + '</span>';
	if (r.wc) tags += '<span class="sp-tag">車いす</span>';
	if (r.status && SpStatus[r.status]) tags += '<span class="sp-tag ' + (r.status == 9 ? 'danger' : 'warn') + '">' + spEsc(SpStatus[r.status]) + '</span>';
	const cls = r.status == 9 ? ' status-noshoot' : (r.status > 1 ? ' status-warn' : '');
	// 予選の得点と順位（点数がないときは空欄）
	let score = '';
	if (spHasScore(r)) {
		// 得点/金的/X の数（IRM 画面と同じ書き方）
		score = '<b>' + r.score + '/' + r.gold + '/' + r.xnine + '</b>'
			+ '<div class="sp-sub">' + (r.irm ? spEsc(r.irm) : (r.rank > 0 ? '予選 ' + r.rank + '位' : '')) + '</div>';
	}
	return '<div class="sp-card tap' + cls + '" data-id="' + r.id + '" data-ses="' + spEsc(r.session || 0) + '" data-dc="' + spEsc(r.division + ' ' + r.class) + '" data-irm="' + (r.irm ? 1 : 0) + '" data-search="' + spEsc(spPartSearchText(r)) + '">'
		+ '<div class="sp-card-head">'
		+ '<span class="sp-badge' + (r.session ? '' : ' none') + '">' + spEsc(tgt) + '</span>'
		+ '<div class="sp-card-main">'
		+ '<div class="sp-name">' + spEsc(r.firstname + ' ' + r.name) + nameTags + '</div>'
		+ '<div class="sp-sub">' + spEsc([r.code, r.country_code, r.country_name].filter(x => x).join(' / ')) + '</div>'
		+ '</div>'
		+ '<div class="sp-score">' + score + '</div>'
		+ '</div>'
		+ (tags ? '<div style="margin-top:6px">' + tags + '</div>' : '')
		+ '</div>';
}

/* 並べ替え（的番号順・得点順・順位順） */
function spPartSorted() {
	const rows = SpRows.slice();
	if (SpFilter.sort === 'score') {
		// 点数のある人を得点・金的・X の多い順に。点数のない人はあとに的番号順
		rows.sort((a, b) => (spHasScore(b) - spHasScore(a)) || (b.score - a.score) || (b.gold - a.gold) || (b.xnine - a.xnine) || (a._ord - b._ord));
	} else if (SpFilter.sort === 'rank') {
		// 部門クラスごとに予選順位の順。順位のない人はその部門クラスの最後に的番号順
		const key = r => (r.rank > 0 && (spHasScore(r) || r.irm)) ? r.rank : 1e9;
		rows.sort((a, b) => (a.dcorder - b.dcorder) || String(a.division + a.class).localeCompare(b.division + b.class) || (key(a) - key(b)) || (a._ord - b._ord));
	} else {
		rows.sort((a, b) => a._ord - b._ord);
	}
	return rows;
}

function spPartRender() {
	const list = document.getElementById('SpList');
	list.innerHTML = SpRows.length ? spPartSorted().map(spPartCard).join('') : '<div class="sp-empty">参加者がいません</div>';
	spPartFilter();
}

/* 部門クラスの絞り込みの選択肢（参加者がいる部門クラス） */
function spPartDcOptions() {
	const seen = {};
	SpRows.forEach(r => { const k = r.division + ' ' + r.class; if (k.trim() && !(k in seen)) seen[k] = r.dcorder; });
	const keys = Object.keys(seen).sort((a, b) => (seen[a] - seen[b]) || a.localeCompare(b));
	if (SpFilter.dc && keys.indexOf(SpFilter.dc) < 0) SpFilter.dc = '';
	document.getElementById('SpDcFilter').innerHTML = '<option value="">すべての部門クラス</option>'
		+ keys.map(k => '<option' + (k === SpFilter.dc ? ' selected' : '') + '>' + spEsc(k) + '</option>').join('');
}

function spPartChips() {
	const items = [{id: 'all', name: 'すべて'}].concat(SpSessions.map(s => ({id: String(s.id), name: s.name})), [{id: '0', name: '未割当'}]);
	if (!items.some(i => i.id === SpFilter.ses)) SpFilter.ses = 'all';
	document.getElementById('SpSesChips').innerHTML = items.map(i =>
		'<button type="button" class="sp-chip' + (i.id === SpFilter.ses ? ' active' : '') + '" data-ses="' + spEsc(i.id) + '">' + spEsc(i.name) + '</button>').join('');
}

function spPartFilter() {
	const n = spFilterCards(document.getElementById('SpList'), document.getElementById('SpSearch').value,
		card => (SpFilter.ses === 'all' || card.getAttribute('data-ses') === SpFilter.ses)
			&& (!SpFilter.dc || card.getAttribute('data-dc') === SpFilter.dc)
			&& (!SpFilter.irmOnly || card.getAttribute('data-irm') === '1'));
	document.getElementById('SpCount').textContent = n + ' 人';
}

/* ---- 編集（ボトムシート） ---- */
let SpEdit = null;

function spFieldText(what, value, type) {
	return '<label class="sp-field"><span>' + spEsc(SpLabels[what]) + '</span>'
		+ '<input type="' + (type || 'text') + '" data-what="' + what + '" value="' + spEsc(value) + '" autocomplete="off"></label>';
}
function spFieldSelect(what) {
	return '<label class="sp-field"><span>' + spEsc(SpLabels[what]) + '</span><select data-what="' + what + '"><option>読み込み中…</option></select></label>';
}

function spOpenEdit(id) {
	const r = SpRows.find(x => x.id == id);
	if (!r) return;
	SpEdit = r;
	const tab = (SpCanIrm && spStore('part_tab') === 'irm') ? 'irm' : 'basic';
	const html = '<h2>' + spEsc(r.firstname + ' ' + r.name) + '</h2>'
		+ '<div class="sp-sub">' + spEsc([r.code, r.country_code + ' ' + r.country_name, r.session ? ('セッション' + r.session + ' / 的 ' + (r.targetno || '-')) : '的未割当', r.targetface].filter(x => x && x.trim()).join(' / ')) + '</div>'
		+ (SpCanIrm ? '<div class="sp-seg"><button type="button" data-tab="basic">基本情報</button><button type="button" data-tab="irm">IRM</button></div>' : '')
		+ '<div data-pane="basic">'
		+ '<div class="sp-row">' + spFieldText('firstname', r.firstname) + spFieldText('name', r.name) + '</div>'
		+ '<div class="sp-row">' + spFieldSelect('division') + spFieldSelect('ageclass') + '</div>'
		+ '<div class="sp-row">' + spFieldSelect('class') + spFieldSelect('subclass') + '</div>'
		+ '<label class="sp-field"><span>所属先2</span><select id="SpCountry2">' + spCountry2Options(r.country_code2) + '</select></label>'
		+ (r.targetno
			? '<p class="sp-note">的番号が設定されているため削除できません。</p>'
			: '<button type="button" class="sp-btn danger block" id="SpDelBtn">この参加者を削除</button>')
		+ '</div>'
		+ (SpCanIrm ? '<div data-pane="irm" class="sp-hide" id="SpIrmPane"></div>' : '')
		+ '<div class="sp-sheet-actions">'
		+ '<a class="sp-btn sub" href="' + spEsc(spUrl('Partecipants/PopEdit.php', {id: r.id})) + '" target="_blank" rel="noopener">詳細（PC画面）</a>'
		+ '<button type="button" class="sp-btn" onclick="spSheet.close()">閉じる</button>'
		+ '</div>';
	const el = spSheet.open(html, () => { SpEdit = null; });
	el.querySelectorAll('input[data-what]').forEach(inp => inp.addEventListener('change', () => spSaveField(inp)));
	el.querySelectorAll('select[data-what]').forEach(sel => sel.addEventListener('change', () => spSaveField(sel)));
	['division', 'ageclass', 'class', 'subclass'].forEach(w => spLoadCombo(w));
	const del = el.querySelector('#SpDelBtn');
	if (del) del.addEventListener('click', () => spDelete(r));
	el.querySelector('#SpCountry2').addEventListener('change', ev => spSaveCountry2(ev.target));
	if (SpCanIrm) {
		el.querySelectorAll('.sp-seg [data-tab]').forEach(b => b.addEventListener('click', () => spEditTab(b.dataset.tab)));
		spEditTab(tab);
	}
}

/* ---- 所属先2 ---- */
function spCountry2Options(cur) {
	let html = '<option value="">（なし）</option>';
	let found = !cur;
	SpCountries.forEach(c => {
		if (c.code === cur) found = true;
		html += '<option value="' + spEsc(c.code) + '"' + (c.code === cur ? ' selected' : '') + '>' + spEsc(c.code + (c.name ? ' - ' + c.name : '')) + '</option>';
	});
	if (!found) html += '<option value="' + spEsc(cur) + '" selected>' + spEsc(cur) + '</option>';
	return html + '<option value="*new*">新しい所属コードを入力…</option>';
}

/* 本体の Partecipants-exp/actions/xmlUpdateCountryCode2.php で所属先2 を保存する（空にすると外す） */
async function spSaveCountry2(sel) {
	const r = SpEdit;
	if (!r) return;
	let code = sel.value;
	if (code === '*new*') {
		code = (prompt('所属コードを入力してください（この試合にない所属は、名前なしで作られます）', '') || '').trim().toUpperCase();
		if (!code) {
			sel.innerHTML = spCountry2Options(r.country_code2);
			return;
		}
	}
	sel.classList.add('sp-saving');
	sel.classList.remove('sp-error');
	try {
		const doc = await spGetXml('Partecipants-exp/actions/xmlUpdateCountryCode2.php', {id: r.id, country_code: code, row: 0, col: 0});
		if (spXmlVal(doc, 'error') == '1') {
			sel.classList.add('sp-error');
			spToast('保存できませんでした（ロック中などの理由）', true);
		} else {
			spToast('所属先2 を保存しました');
			// 新しく作った所属は選択肢に加える
			if (code && !SpCountries.some(c => c.code === code)) {
				SpCountries.push({code: code, name: spXmlVal(doc, 'country_name')});
				SpCountries.sort((a, b) => a.code.localeCompare(b.code));
			}
		}
		await spReloadRow(r.id);
		if (SpEdit && SpEdit.id == r.id) sel.innerHTML = spCountry2Options(SpEdit.country_code2);
	} catch (e) {
		sel.classList.add('sp-error');
		spToast('保存できませんでした: ' + e.message, true);
	}
	sel.classList.remove('sp-saving');
}

/* 編集画面のタブ（基本情報／IRM）の切り替え */
function spEditTab(tab) {
	const el = spSheet.el;
	spStore('part_tab', tab);
	el.querySelectorAll('.sp-seg [data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
	el.querySelectorAll('[data-pane]').forEach(p => p.classList.toggle('sp-hide', p.dataset.pane !== tab));
	if (tab === 'irm' && SpEdit) spIrmLoad(SpEdit.id);
}

/* ---- IRM（予選・部門クラス。旧 Irm.php） ---- */
/* 本体の ManIrmStatus-getElements.php から、その選手の部門クラスの一覧を読み、その選手の分を出す */
async function spIrmLoad(id) {
	const pane = spSheet.el && spSheet.el.querySelector('#SpIrmPane');
	const r = SpRows.find(x => x.id == id);
	if (!pane || !r) return;
	if (!r.division || !r.class) {
		pane.innerHTML = '<p class="sp-note">部門・クラスが未設定のため、IRM を設定できません。</p>';
		return;
	}
	pane.innerHTML = '<p class="sp-sub">読み込み中…</p>';
	let d, it;
	try {
		d = await spGetJson('Partecipants/ManIrmStatus-getElements.php', {
			type: 'phase', value: 'Q', team: 0, event: 'Q' + r.division + r.class, order: 'Score', ordertype: 'DESC', search: '',
		});
		it = (d.elements || []).find(x => x.IrmKey === '0-Q-' + id);
	} catch (e) {
		pane.innerHTML = '<p class="sp-note">読み込めませんでした: ' + spEsc(e.message) + '</p>';
		return;
	}
	if (!SpEdit || SpEdit.id != id) return;
	if (!it) {
		pane.innerHTML = '<p class="sp-note">この選手の予選のデータが見つかりません。</p>';
		return;
	}
	const canSub = !d.hideSubClass;
	pane.innerHTML = '<div class="sp-sub">予選 ' + spEsc(it.Score) + '</div>'
		+ '<label class="sp-field"><span>IRM</span><select id="SpIrmSel">'
		+ SpIrmTypes.map(t => '<option value="' + t.id + '"' + (t.id == it.IrmType ? ' selected' : '') + '>' + spEsc(t.label) + '</option>').join('')
		+ '</select></label>'
		+ '<div class="sp-irm-ranks">'
		+ '<label><span>予選順位</span><input type="number" id="SpRankQual" value="' + spEsc(it.QualRank) + '"></label>'
		+ '<label' + (canSub ? '' : ' class="sp-hide"') + '><span>' + spEsc(d.ScTitle) + '</span><input type="number" id="SpRankSub" value="' + spEsc(it.SubClassRank) + '"></label>'
		+ '</div>'
		+ '<div class="sp-sheet-actions"><button type="button" class="sp-btn" id="SpIrmSave">IRM・順位を保存</button></div>'
		+ '<label class="sp-field" style="margin-top:12px"><span>メモ（入力欄から離れると保存）</span><input type="text" id="SpNote" value="' + spEsc(it.Note) + '"></label>'
		+ (SpIrmHelp ? '<details class="sp-note"><summary>IRM について</summary><div>' + SpIrmHelp + '</div></details>' : '');

	// IRM を選ぶと、本体の画面と同じ値を順位欄に入れる（必要なら手で直す）
	pane.querySelector('#SpIrmSel').addEventListener('change', ev => {
		const v = parseInt(ev.target.value, 10);
		let val = null;
		if (v == 20) val = SpRankValues.deranking;
		else if (v != 0) val = (v == 15 ? SpRankValues.disqualify : SpRankValues.didnotstart);
		pane.querySelector('#SpRankQual').value = (val !== null ? val : it.QualRank);
		pane.querySelector('#SpRankSub').value = (val !== null ? val : it.SubClassRank);
	});

	pane.querySelector('#SpIrmSave').addEventListener('click', async () => {
		if (!confirm('IRM と順位を変更します。よろしいですか？')) return;
		try {
			const res = await spGetJson('Partecipants/ManIrmStatus-setIrm.php', {
				item: it.IrmKey,
				irm: pane.querySelector('#SpIrmSel').value,
				qual: pane.querySelector('#SpRankQual').value,
				fin: '',
				// サブクラスがないときは今の値をそのまま送る
				sub: canSub ? pane.querySelector('#SpRankSub').value : (it.SubClassRank || 0),
			});
			if (res.msg) spToast(res.msg, res.error != 0);
			if (res.error == 0) {
				await spReloadRow(id);
				spIrmLoad(id);
			}
		} catch (e) {
			spToast('保存できませんでした: ' + e.message, true);
		}
	});

	pane.querySelector('#SpNote').addEventListener('change', async ev => {
		try {
			const res = await spGetJson('Partecipants/ManIrmStatus-setIrm.php', {item: it.IrmKey, note: ev.target.value});
			if (res.error == 0) {
				it.Note = ev.target.value;
				spToast('メモを保存しました');
			} else {
				spToast('メモを保存できませんでした', true);
			}
		} catch (e) {
			spToast('保存できませんでした: ' + e.message, true);
		}
	});
}

/* ---- 削除（的番号が設定される前だけ） ---- */
async function spDelete(r) {
	if (!confirm((r.firstname + ' ' + r.name).trim() + ' さんを削除します。よろしいですか？')) return;
	try {
		const res = await spPostJson('Modules/Custom/SmartphoneMode/Participants-action.php', {act: 'delete', id: r.id});
		spToast(res.msg, res.error != 0);
		if (res.error == 0) {
			spSheet.close();
			SpRows = SpRows.filter(x => x.id != r.id);
			const card = document.querySelector('#SpList .sp-card[data-id="' + r.id + '"]');
			if (card) card.remove();
			spPartFilter();
		}
	} catch (e) {
		spToast('削除できませんでした: ' + e.message, true);
	}
}

/* ---- 追加（過去の参加者から: 部門クラス → チーム → 選手） ---- */
const SpAdd = {dc: '', team: ''};

function spOpenAdd() {
	SpAdd.dc = spStore('part_add_dc') || '';
	if (!SpDivClasses.some(d => d.key === SpAdd.dc)) SpAdd.dc = '';
	SpAdd.team = '';
	const html = '<h2>参加者を追加</h2>'
		+ '<div class="sp-sub">過去の参加者（ほかの試合の選手）から選びます。</div>'
		+ '<label class="sp-field"><span>1. 部門クラス</span><select id="SpAddDc"><option value="">-- 選んでください --</option>'
		+ SpDivClasses.map(d => '<option value="' + spEsc(d.key) + '"' + (d.key === SpAdd.dc ? ' selected' : '') + '>' + spEsc(d.label) + '</option>').join('')
		+ '</select></label>'
		+ '<label class="sp-field sp-hide" id="SpAddTeamField"><span>2. チーム</span><select id="SpAddTeam"></select></label>'
		+ '<div class="sp-hide" id="SpAddArchersField"><div class="sp-field"><span>3. 追加する選手</span></div>'
		+ '<label class="sp-switch" style="margin-bottom:6px"><input type="checkbox" id="SpAddAll"> すべて選ぶ</label>'
		+ '<div class="sp-check-list" id="SpAddList"></div></div>'
		+ '<div class="sp-sheet-actions"><button type="button" class="sp-btn" id="SpAddGo" disabled>追加する</button></div>'
		+ '<div class="sp-sheet-actions">'
		+ '<a class="sp-btn sub" href="' + spEsc(spUrl('Partecipants/PopEdit.php', {id: 0})) + '" target="_blank" rel="noopener">新しい選手を入力（PC画面）</a>'
		+ '<button type="button" class="sp-btn sub" onclick="spSheet.close()">閉じる</button>'
		+ '</div>';
	const el = spSheet.open(html);
	el.querySelector('#SpAddDc').addEventListener('change', ev => {
		SpAdd.dc = ev.target.value;
		spStore('part_add_dc', SpAdd.dc);
		spAddLoadTeams();
	});
	el.querySelector('#SpAddTeam').addEventListener('change', ev => {
		SpAdd.team = ev.target.value;
		spAddLoadArchers();
	});
	el.querySelector('#SpAddAll').addEventListener('change', ev => {
		el.querySelectorAll('#SpAddList input[type=checkbox]:not(:disabled)').forEach(c => c.checked = ev.target.checked);
		spAddCount();
	});
	el.querySelector('#SpAddList').addEventListener('change', spAddCount);
	el.querySelector('#SpAddGo').addEventListener('click', spAddGo);
	if (SpAdd.dc) spAddLoadTeams();
}

async function spAddLoadTeams() {
	const el = spSheet.el;
	el.querySelector('#SpAddArchersField').classList.add('sp-hide');
	el.querySelector('#SpAddList').innerHTML = '';
	spAddCount();
	const field = el.querySelector('#SpAddTeamField');
	if (!SpAdd.dc) { field.classList.add('sp-hide'); return; }
	field.classList.remove('sp-hide');
	const sel = el.querySelector('#SpAddTeam');
	sel.innerHTML = '<option value="">読み込み中…</option>';
	try {
		const res = await spGetJson('Modules/Custom/SmartphoneMode/Participants-action.php', {act: 'teams', dc: SpAdd.dc});
		if (res.error != 0) { spToast(res.msg, true); return; }
		const last = spStore('part_add_team') || '';
		sel.innerHTML = '<option value="">-- 選んでください --</option>'
			+ res.teams.map(t => '<option value="' + spEsc(t.code) + '">' + spEsc(t.code + ' ' + t.name + '（' + t.count + '人）') + '</option>').join('');
		if (!res.teams.length) sel.innerHTML = '<option value="">過去の参加者がいません</option>';
		if (res.teams.some(t => t.code === last)) {
			sel.value = last;
			SpAdd.team = last;
			spAddLoadArchers();
		}
	} catch (e) {
		spToast('読み込めませんでした: ' + e.message, true);
	}
}

async function spAddLoadArchers() {
	const el = spSheet.el;
	const field = el.querySelector('#SpAddArchersField');
	const list = el.querySelector('#SpAddList');
	el.querySelector('#SpAddAll').checked = false;
	if (!SpAdd.team) { field.classList.add('sp-hide'); list.innerHTML = ''; spAddCount(); return; }
	spStore('part_add_team', SpAdd.team);
	field.classList.remove('sp-hide');
	list.innerHTML = '<div class="sp-sub">読み込み中…</div>';
	try {
		const res = await spGetJson('Modules/Custom/SmartphoneMode/Participants-action.php', {act: 'archers', dc: SpAdd.dc, team: SpAdd.team});
		if (res.error != 0) { spToast(res.msg, true); return; }
		list.innerHTML = res.archers.length ? res.archers.map(a =>
			'<label class="sp-check' + (a.registered ? ' done' : '') + '"><input type="checkbox" value="' + a.src + '"' + (a.registered ? ' disabled' : '') + '>'
			+ '<span><b>' + spEsc(a.name) + '</b>' + (a.registered ? ' <span class="sp-tag">登録済み</span>' : '')
			+ '<small>' + spEsc([a.code, '前回 ' + a.last, a.tour].filter(x => x).join(' / ')) + '</small></span></label>').join('')
			: '<div class="sp-sub">このチームには選べる選手がいません</div>';
	} catch (e) {
		spToast('読み込めませんでした: ' + e.message, true);
	}
	spAddCount();
}

function spAddCount() {
	const el = spSheet.el;
	const n = el.querySelectorAll('#SpAddList input[type=checkbox]:checked').length;
	const go = el.querySelector('#SpAddGo');
	go.disabled = n === 0;
	go.textContent = n ? n + '人を追加する' : '追加する';
}

async function spAddGo() {
	const el = spSheet.el;
	const ids = [...el.querySelectorAll('#SpAddList input[type=checkbox]:checked')].map(c => c.value);
	if (!ids.length) return;
	const go = el.querySelector('#SpAddGo');
	go.disabled = true;
	try {
		const body = new URLSearchParams();
		body.append('act', 'add');
		body.append('dc', SpAdd.dc);
		ids.forEach(id => body.append('src[]', id));
		const r = await fetch(spUrl('Modules/Custom/SmartphoneMode/Participants-action.php'), {
			method: 'POST', credentials: 'same-origin', cache: 'no-store',
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: body.toString(),
		});
		const res = await r.json();
		if (res.error != 0) {
			spToast(res.msg, true);
			go.disabled = false;
			return;
		}
		// 一覧を読み直して、追加した人を表示する
		spStore('part_toast', res.msg);
		location.reload();
	} catch (e) {
		spToast('追加できませんでした: ' + e.message, true);
		go.disabled = false;
	}
}

/* 本体の選択肢ページ（Get-*.php）から選択肢を読み込む */
async function spLoadCombo(what) {
	const r = SpEdit;
	if (!r) return;
	const src = {
		division: ['Partecipants/Get-Divisions.php', {}],
		ageclass: ['Partecipants/Get-AgeClasses.php', {enid: r.id}],
		class: ['Partecipants/Get-Classes.php', {enid: r.id}],
		subclass: ['Partecipants/Get-Subclasses.php', {}],
	}[what];
	const sel = spSheet.el.querySelector('select[data-what="' + what + '"]');
	if (!sel) return;
	try {
		const doc = await spGetXml(src[0], src[1]);
		const cur = {division: r.division, ageclass: r.ageclass, class: r.class, subclass: r.subclass}[what] || '';
		const items = spXmlVal(doc, 'items');
		let html = '<option value="">--</option>';
		let found = false;
		if (items) {
			items.split('---').forEach(f => {
				const kv = f.split(':::');
				if (kv[0] == cur) found = true;
				html += '<option value="' + spEsc(kv[0]) + '"' + (kv[0] == cur ? ' selected' : '') + '>' + spEsc(kv[0] + ' - ' + (kv[1] || '')) + '</option>';
			});
		}
		if (cur && !found) html += '<option value="' + spEsc(cur) + '" selected>' + spEsc(cur) + '</option>';
		if (SpEdit === r) sel.innerHTML = html;
	} catch (e) {
		sel.innerHTML = '<option value="">（読み込めませんでした）</option>';
	}
}

/* 本体の Set-UpdateField.php で 1 項目を保存する */
async function spSaveField(el) {
	const r = SpEdit;
	if (!r) return;
	const what = el.getAttribute('data-what');
	el.classList.add('sp-saving');
	el.classList.remove('sp-error');
	try {
		const doc = await spGetXml('Partecipants/Set-UpdateField.php', {
			id: r.id,
			session: r.session || '',
			targetno: r.targetno || '',
			field: what,
			value: el.value,
		});
		const err = spXmlVal(doc, 'error') == '1';
		if (err) {
			el.classList.add('sp-error');
			spToast('保存できませんでした（ロック中などの理由）', true);
		} else {
			spToast('保存しました');
		}
		if (el.tagName === 'INPUT') el.value = spXmlVal(doc, 'value');
		await spReloadRow(r.id);
		// 部門や年齢クラスを変えると、選べるクラスが変わる（本体と同じく続けて選び直す）
		if (what === 'division') { spLoadCombo('ageclass'); spLoadCombo('class'); }
		if (what === 'ageclass') { spLoadCombo('class'); }
	} catch (e) {
		el.classList.add('sp-error');
		spToast('保存できませんでした: ' + e.message, true);
	}
	el.classList.remove('sp-saving');
}

/* 1 人分を取り直して、一覧の表示を更新する */
async function spReloadRow(id) {
	const data = await spGetJson('Modules/Custom/SmartphoneMode/Participants.php', {row: id});
	if (data.error || !data.row) return;
	const idx = SpRows.findIndex(x => x.id == id);
	if (idx < 0) return;
	data.row._ord = SpRows[idx]._ord;
	SpRows[idx] = data.row;
	if (SpEdit && SpEdit.id == id) SpEdit = data.row;
	if (SpFilter.sort !== 'target') {
		// 得点順・順位順は並びが変わることがあるので並べ直す
		spPartDcOptions();
		spPartRender();
		return;
	}
	const old = document.querySelector('#SpList .sp-card[data-id="' + id + '"]');
	if (old) {
		old.outerHTML = spPartCard(data.row);
		spPartFilter();
	}
}

document.addEventListener('DOMContentLoaded', () => {
	spPartChips();
	spPartDcOptions();
	document.getElementById('SpSort').value = ['target', 'score', 'rank'].indexOf(SpFilter.sort) >= 0 ? SpFilter.sort : 'target';
	document.getElementById('SpIrmOnly').checked = SpFilter.irmOnly;
	spPartRender();
	document.getElementById('SpDcFilter').addEventListener('change', ev => {
		SpFilter.dc = ev.target.value;
		spStore('part_dc', SpFilter.dc);
		spPartFilter();
	});
	document.getElementById('SpSort').addEventListener('change', ev => {
		SpFilter.sort = ev.target.value;
		spStore('part_sort', SpFilter.sort);
		spPartRender();
	});
	document.getElementById('SpIrmOnly').addEventListener('change', ev => {
		SpFilter.irmOnly = ev.target.checked;
		spStore('part_irm_only', SpFilter.irmOnly ? '1' : '0');
		spPartFilter();
	});
	document.getElementById('SpAddBtn').addEventListener('click', spOpenAdd);
	const msg = spStore('part_toast');
	if (msg) { spStore('part_toast', ''); spToast(msg); }
	document.getElementById('SpSearch').addEventListener('input', spPartFilter);
	document.getElementById('SpSesChips').addEventListener('click', ev => {
		const b = ev.target.closest('[data-ses]');
		if (!b) return;
		SpFilter.ses = b.getAttribute('data-ses');
		spStore('part_ses', SpFilter.ses);
		spPartChips();
		spPartFilter();
	});
	document.getElementById('SpList').addEventListener('click', ev => {
		const card = ev.target.closest('.sp-card[data-id]');
		if (card) spOpenEdit(card.getAttribute('data-id'));
	});
});
// PC画面（PopEdit.php）で追加・変更して戻ってきたときは一覧を読み直す
document.addEventListener('click', ev => {
	if (ev.target.closest('a[href*="PopEdit.php"]')) spStore('part_dirty', '1');
});
document.addEventListener('visibilitychange', () => {
	if (document.visibilityState === 'visible' && spStore('part_dirty') === '1') { spStore('part_dirty', '0'); location.reload(); }
});
</script>
<?php
spTail('Participants');
