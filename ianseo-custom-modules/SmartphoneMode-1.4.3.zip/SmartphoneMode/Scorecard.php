<?php
/*
スマホモード: スコアカード修正
本体の Qualification/WriteScoreCard.php（素点を編集（スコアカードビュー））に当たる画面。
- 的番号設定の一覧と同じく、選手の一覧（セッションで絞り込み、名前・所属などで検索）から選手を選ぶ
- スコアカードの取得は本体の画面と同じ条件
- 1 本ごとの保存は本体の Qualification/UpdateArrow.php を呼ぶ（本体の画面と同じ処理。順位・チームも本体と同じく再計算される）
- 入力できる点数は本体の GetGoodLettersFromDist() / GetGoodLettersFromTgtId()（的の種類ごとの点数）から作る
- 順位の再計算・チームの再構築は本体の Qualification/CalcRank.php・MakeTeams.php・MakeTeamsAbs.php を呼ぶ

変更履歴:
2026/11/11 スコアカードは 1 エンドを横 1 行（エンド番号・矢・小計・合計）に並べる
2026/11/11 人数は部門クラスの絞り込みのメニューに出す（「N 人」の表示はなくした）
2026/11/11 セッション名・距離名（70m-前半など）で表示。セッションが 1 つなら絞り込みを出さない。
           一覧に部門クラスの絞り込みと並べ替え（的番号順・ランキング順・矢数順）を追加。
           点数のボタンを的の色にし、「素点削除」と「エンド削除」（確認あり）を置いた
2026/11/10 的番号を入力する代わりに、選手の一覧から選ぶようにした。距離はボタンで切り替える
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');
spCheckPage('Scorecard');

require_once('Common/Lib/ArrTargets.inc.php');
require_once('Common/Fun_FormatText.inc.php');
require_once('Common/Fun_Various.inc.php');
require_once('Common/Fun_Sessions.inc.php');

$q = safe_r_sql("SELECT ToNumSession, ToNumDist, ToGolds, ToXNine FROM Tournament WHERE ToId=" . intval($_SESSION['TourId']));
$Tour = safe_fetch($q);

$Sessions = [];
foreach(GetSessions('Q') as $s) {
	$Sessions[intval($s->SesOrder)] = $s->SesName != '' ? $s->SesName : ('セッション' . $s->SesOrder);
}

// 一覧のセッションの絞り込み（* はすべて）
$Ses = $_REQUEST['s'] ?? '*';
if($Ses !== '*') {
	$Ses = intval($Ses);
	if(!isset($Sessions[$Ses])) {
		$Ses = '*';
	}
}
$Dist = intval($_REQUEST['d'] ?? 0);
if($Dist < 1 or $Dist > $Tour->ToNumDist) {
	$Dist = 1;
}
$ReqEnId = intval($_REQUEST['a'] ?? 0);

// 距離名（大会の距離の設定 TournamentDistances の Td1〜Td8。部門クラスごとに違うことがある）
$TdSel = [];
for($i = 1; $i <= 8; $i++) {
	$TdSel[] = "Td{$i}";
}
$TdJoin = "LEFT JOIN TournamentDistances ON TdTournament=EnTournament AND TdType=(SELECT ToType FROM Tournament WHERE ToId=EnTournament) AND CONCAT(TRIM(EnDivision),TRIM(EnClass)) LIKE TdClasses";

/** 距離名（なければ「N距離目」） */
function spDistName($Name, $Dist) {
	$Name = trim((string) $Name);
	return ($Name !== '' and $Name !== '-') ? $Name : ($Dist . '距離目');
}

// 距離のボタンの名前（その距離の距離名。部門クラスで違えば「/」でつなぐ）
$DistNames = [];
$q = safe_r_sql("SELECT DISTINCT " . implode(', ', $TdSel) . "
	FROM Entries
	INNER JOIN Qualifications ON EnId=QuId
	{$TdJoin}
	WHERE EnTournament=" . intval($_SESSION['TourId']) . " AND EnAthlete=1 AND QuSession>0"
	. ($Ses !== '*' ? " AND QuSession={$Ses}" : ''));
while($r = safe_fetch($q)) {
	for($i = 1; $i <= $Tour->ToNumDist; $i++) {
		$n = trim((string) $r->{"Td{$i}"});
		if($n !== '' and $n !== '-') {
			$DistNames[$i][$n] = true;
		}
	}
}
foreach(range(1, max(1, $Tour->ToNumDist)) as $i) {
	$DistNames[$i] = isset($DistNames[$i]) ? implode('/', array_keys($DistNames[$i])) : ($i . '距離目');
}

// 選手の一覧（セッションが決まっている選手。的番号順）
$Archers = [];
$Rs = safe_r_sql("SELECT EnId, EnCode, EnName, EnFirstName, EnDivision, EnClass, EnStatus, CoCode, CoName,
		QuSession, QuTarget, QuLetter, QuScore, QuHits, QuClRank, QuD{$Dist}Score AS SelScore, QuD{$Dist}Hits AS SelHits,
		Td{$Dist} AS DistName, DivViewOrder, ClViewOrder
	FROM Entries
	INNER JOIN Qualifications ON EnId=QuId
	INNER JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament
	LEFT JOIN Divisions ON DivTournament=EnTournament AND DivId=EnDivision
	LEFT JOIN Classes ON ClTournament=EnTournament AND ClId=EnClass
	{$TdJoin}
	WHERE EnTournament=" . intval($_SESSION['TourId']) . " AND EnAthlete=1 AND QuSession>0"
	. ($Ses !== '*' ? " AND QuSession={$Ses}" : '') . "
	ORDER BY QuSession, QuTarget=0, QuTarget, QuLetter, EnFirstName, EnName");
while($r = safe_fetch($Rs)) {
	$Archers[intval($r->EnId)] = $r;
}

// 選んだ選手（一覧にいなくても、この試合の選手なら開ける）
$EnId = 0;
if($ReqEnId) {
	$q = safe_r_sql("SELECT EnId FROM Entries WHERE EnId={$ReqEnId} AND EnAthlete=1 AND EnTournament=" . intval($_SESSION['TourId']));
	if(safe_fetch($q)) {
		$EnId = $ReqEnId;
	}
}

// 一覧の前後の選手
$PrevId = $NextId = 0;
if($EnId and isset($Archers[$EnId])) {
	$Ids = array_keys($Archers);
	$i = array_search($EnId, $Ids);
	$PrevId = $Ids[$i - 1] ?? 0;
	$NextId = $Ids[$i + 1] ?? 0;
}

// スコアカード（本体の画面で的番号と記号を入れたときと同じ内容）
$Card = null;
if($EnId) {
	$tmpSel = '';
	for($i = 1; $i <= $Tour->ToNumDist; $i++) {
		$tmpSel .= "QuD{$i}Score, QuD{$i}Gold, QuD{$i}Xnine, ";
	}
	$Rs = safe_r_sql("SELECT EnId, EnCode, EnName, EnFirstName, EnDivision, EnClass, CoCode, CoName,
			QuSession, QuTarget, CONCAT(QuTarget, QuLetter) AS Target,
			QuD{$Dist}Score AS SelScore, QuD{$Dist}Gold AS SelGold, QuD{$Dist}Xnine AS SelXNine,
			$tmpSel
			" . implode(', ', $TdSel) . ",
			QuScore, QuGold, QuXnine, QuD{$Dist}ArrowString AS ArrowString,
			IF(TfGolds!='', TfGolds, ToGolds) AS GoldLabel, IF(TfXNine!='', TfXNine, ToXNine) AS XNineLabel,
			coalesce(DiEnds, ToNumEnds) as NumEnds, coalesce(DiArrows, ToMaxDistScore/ToGolds) as NumArrows, coalesce(DiScoringEnds, 0) as ScoringEnds,
			coalesce(DiScoringOffset, 0) as ScoringOffset, ToCategory in (4,8) as IsField3D
		FROM Entries
		INNER JOIN Qualifications ON EnId=QuId
		INNER JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament
		INNER JOIN Tournament ON EnTournament=ToId
		LEFT JOIN DistanceInformation ON DiTournament=EnTournament AND DiSession=QuSession AND DiDistance={$Dist} AND DiType='Q'
		LEFT JOIN TargetFaces ON TfTournament=EnTournament AND EnTargetFace=TfId
		{$TdJoin}
		WHERE EnId={$EnId} AND EnTournament=" . intval($_SESSION['TourId']));
	if($r = safe_fetch($Rs)) {
		$NumEnds = intval($r->NumEnds);
		$NumArrows = intval($r->NumArrows);
		$MaxArrows = $NumEnds * $NumArrows;
		$ArrowString = str_pad($r->ArrowString ?? '', $MaxArrows, ' ', STR_PAD_RIGHT);

		// フィールド・3D は本体と同じく、担当する的のエンドから並べる
		$OffSet = 0;
		$ScoringEnds = $NumEnds;
		if($r->IsField3D and $NumEnds) {
			$OffSet = ((intval($r->QuTarget) - 1) % $NumEnds + intval($r->ScoringOffset)) % $NumEnds;
			$ScoringEnds = intval($r->ScoringEnds) ?: $NumEnds;
		}

		$Ends = [];
		$Running = 0;
		$EndTotals = [];
		for($e = 0; $e < $NumEnds; $e++) {
			$Arr = [];
			$Tot = 0;
			for($j = 0; $j < $NumArrows; $j++) {
				$Idx = $e * $NumArrows + $j;
				$Arr[] = DecodeFromLetter(trim($ArrowString[$Idx]));
				$Tot += ValutaArrowString($ArrowString[$Idx]);
			}
			$Running += $Tot;
			$EndTotals[$e] = ['arrows' => $Arr, 'tot' => $Tot, 'run' => $Running];
		}
		for($i = 0; $i < $NumEnds; $i++) {
			$CurEnd = ($i + $OffSet) % $NumEnds;
			$Ends[] = ['end' => $CurEnd, 'outOfRange' => $i >= $ScoringEnds] + $EndTotals[$CurEnd];
		}

		// 入力できる点数（本体の UpdateArrow.php が受け付ける値と同じ）
		$TgtId = 0;
		GetGoodLettersFromDist($EnId, $Dist, $TgtId);
		$Keys = [];
		foreach(GetGoodLettersFromTgtId($TgtId, -1) as $l) {
			$p = $GLOBALS['LetterPoint'][$l]['P'] ?? '';
			if($p !== '' and !in_array($p, $Keys)) {
				$Keys[] = $p;
			}
		}
		if(!$Keys) {
			$Keys = ['X', '10', '9', '8', '7', '6', '5', '4', '3', '2', '1', 'M'];
		}

		$Dists = [];
		for($i = 1; $i <= $Tour->ToNumDist; $i++) {
			$Dists[] = ['name' => spDistName($r->{"Td{$i}"} ?? '', $i), 'score' => $r->{"QuD{$i}Score"}, 'gold' => $r->{"QuD{$i}Gold"}, 'xnine' => $r->{"QuD{$i}Xnine"}];
		}

		$Card = [
			'id' => intval($r->EnId),
			'name' => trim($r->EnFirstName . ' ' . $r->EnName),
			'code' => $r->EnCode,
			'country' => trim($r->CoCode . ' ' . $r->CoName),
			'divcl' => $r->EnDivision . ' ' . $r->EnClass,
			'target' => $r->Target,
			'dist' => $Dist,
			'distName' => spDistName($r->{"Td{$Dist}"} ?? '', $Dist),
			'numArrows' => $NumArrows,
			'ends' => $Ends,
			'keys' => $Keys,
			'goldLabel' => $r->GoldLabel,
			'xnineLabel' => $r->XNineLabel,
			'cur' => ['score' => $r->SelScore, 'gold' => $r->SelGold, 'xnine' => $r->SelXNine],
			'tot' => ['score' => $r->QuScore, 'gold' => $r->QuGold, 'xnine' => $r->QuXnine],
			'dists' => $Dists,
		];
	}
}

spHead('Scorecard', ['SpCard' => $Card, 'SpDist' => $Dist, 'SpSes' => (string) $Ses, 'SpHasDist' => isset($_REQUEST['d']), 'SpHasSes' => isset($_REQUEST['s'])]);

function spScoreLink($Ses, $Dist, $EnId=0) {
	return '?s=' . $Ses . '&d=' . $Dist . ($EnId ? '&a=' . $EnId : '');
}
?>
<div class="sp-toolbar">
<?php if(count($Sessions) > 1) { ?>
	<div class="sp-chips">
		<a class="sp-chip<?php echo $Ses === '*' ? ' active' : ''; ?>" href="<?php echo spScoreLink('*', $Dist, $EnId); ?>" data-ses="*">すべて</a>
<?php foreach($Sessions as $k => $v) { ?>
		<a class="sp-chip<?php echo $Ses === $k ? ' active' : ''; ?>" href="<?php echo spScoreLink($k, $Dist, $EnId); ?>" data-ses="<?php echo $k; ?>"><?php echo spH($v); ?></a>
<?php } ?>
	</div>
<?php } ?>
	<div class="sp-chips">
<?php for($i = 1; $i <= $Tour->ToNumDist; $i++) { ?>
		<a class="sp-chip<?php echo $i == $Dist ? ' active' : ''; ?>" href="<?php echo spScoreLink($Ses, $i, $EnId); ?>" data-dist="<?php echo $i; ?>"><?php echo spH($DistNames[$i]); ?></a>
<?php } ?>
	</div>
</div>

<?php if($EnId) { ?>
<div class="sp-row" style="margin-bottom:4px">
	<a class="sp-btn sub" href="<?php echo spScoreLink($Ses, $Dist) . '#sc' . $EnId; ?>">☰ 選手一覧</a>
	<a class="sp-btn sub<?php echo $PrevId ? '' : ' sp-hide'; ?>" style="flex:none" id="SpPrev" href="<?php echo spScoreLink($Ses, $Dist, $PrevId); ?>" title="前の選手">◀</a>
	<a class="sp-btn sub<?php echo $NextId ? '' : ' sp-hide'; ?>" style="flex:none" id="SpNext" href="<?php echo spScoreLink($Ses, $Dist, $NextId); ?>" title="次の選手">▶</a>
</div>
	<?php if(!$Card) { ?>
<div class="sp-empty">スコアカードを読み込めませんでした</div>
	<?php } ?>
<?php } else { ?>
<div class="sp-toolbar">
	<label class="sp-search"><?php echo spIcon('search'); ?><input type="search" id="SpSearch" placeholder="名前・所属・部門クラス・的番号で検索"></label>
</div>
<div class="sp-row" style="margin-bottom:8px;align-items:center">
	<select id="SpDcFilter" aria-label="部門クラスで絞り込み">
		<option value="" data-label="すべての部門クラス">すべての部門クラス</option>
<?php
	$Dcs = [];
	foreach($Archers as $a) {
		$Dcs[$a->EnDivision . ' ' . $a->EnClass] = [intval($a->DivViewOrder), intval($a->ClViewOrder)];
	}
	uksort($Dcs, fn($x, $y) => ($Dcs[$x] <=> $Dcs[$y]) ?: strcmp($x, $y));
	foreach($Dcs as $k => $v) { ?>
		<option value="<?php echo spH($k); ?>" data-label="<?php echo spH($k); ?>"><?php echo spH($k); ?></option>
<?php } ?>
	</select>
	<select id="SpSort" aria-label="並べ替え">
		<option value="target">的番号順</option>
		<option value="rank">ランキング順</option>
		<option value="hits">矢数順</option>
	</select>
</div>
<div class="sp-list" id="SpList">
	<?php $Ord = 0; foreach($Archers as $a) {
		$Tg = $a->QuTarget ? $a->QuTarget . $a->QuLetter : '';
		$Search = mb_strtolower(mb_convert_kana(implode(' ', [$a->EnCode, $a->EnFirstName, $a->EnName, $a->CoCode, $a->CoName, $a->EnDivision . $a->EnClass, $a->EnDivision, $a->EnClass, $Tg]), 'as', 'UTF-8'), 'UTF-8');
		$Cls = $a->EnStatus == 9 ? ' status-noshoot' : ($a->EnStatus > 1 ? ' status-warn' : '');
	?>
	<a class="sp-card tap<?php echo $Cls; ?>" id="sc<?php echo intval($a->EnId); ?>" style="display:block;color:inherit;text-decoration:none" href="<?php echo spScoreLink($Ses, $Dist, $a->EnId); ?>" data-search="<?php echo spH($Search); ?>"
		data-id="<?php echo intval($a->EnId); ?>" data-ord="<?php echo $Ord++; ?>" data-dc="<?php echo spH($a->EnDivision . ' ' . $a->EnClass); ?>"
		data-dcord="<?php echo intval($a->DivViewOrder) * 1000 + intval($a->ClViewOrder); ?>" data-rank="<?php echo ($a->QuClRank > 0 and $a->QuScore > 0) ? intval($a->QuClRank) : 0; ?>"
		data-hits="<?php echo intval($a->SelHits); ?>" data-thits="<?php echo intval($a->QuHits); ?>">
		<div class="sp-card-head">
			<span class="sp-badge<?php echo $Tg ? '' : ' none'; ?>"><?php echo spH($Tg ?: '-'); ?></span>
			<div class="sp-card-main">
				<div class="sp-name"><?php echo spH(trim($a->EnFirstName . ' ' . $a->EnName)); ?></div>
				<div class="sp-sub"><?php echo spH(implode(' / ', array_filter([$a->EnCode, $a->CoCode, $a->CoName]))); ?></div>
				<div style="margin-top:4px"><span class="sp-tag"><?php echo spH($a->EnDivision . ' ' . $a->EnClass); ?></span><?php
					if($Ses === '*') { ?><span class="sp-tag"><?php echo spH($Sessions[intval($a->QuSession)] ?? ''); ?></span><?php }
				?><span class="sp-tag"><?php echo spH(spDistName($a->DistName, $Dist)); ?> <?php echo intval($a->SelScore); ?>点<?php echo $a->SelHits ? '（' . intval($a->SelHits) . '射）' : ''; ?></span><span class="sp-tag">計 <?php echo intval($a->QuScore); ?>点</span><?php
					if($a->QuClRank > 0 and $a->QuScore > 0) { ?><span class="sp-tag"><?php echo intval($a->QuClRank); ?>位</span><?php } ?></div>
			</div>
		</div>
	</a>
	<?php } ?>
</div>
	<?php if(!$Archers) { ?>
<div class="sp-empty">セッションが決まっている選手がいません</div>
	<?php } else { ?>
<p class="sp-note">選手をタップすると、スコアカードを開きます。距離は上のボタンで切り替えます。</p>
	<?php } ?>
<?php } ?>

<div id="SpCardArea"></div>

<details class="sp-card" style="margin-top:12px">
	<summary>順位の計算・チーム</summary>
	<label class="sp-switch" style="margin:12px 0"><input type="checkbox" id="SpNoRecalc"> 入力中は順位計算を止める（止めるのをやめたときにまとめて計算）</label>
	<div class="sp-list">
		<button type="button" class="sp-btn sub block" data-act="calcDist"><?php echo spH(get_text('CalcRankDist', 'Tournament')); ?></button>
		<button type="button" class="sp-btn sub block" data-act="calc"><?php echo spH(get_text('CalcRank', 'Tournament')); ?></button>
		<button type="button" class="sp-btn sub block" data-act="teams"><?php echo spH(get_text('MakeTeams', 'Tournament')); ?></button>
	</div>
</details>

<script>
const SpSc = {sel: -1, cells: [], busy: false};

/* 一覧の並べ替え（的番号順・ランキング順・矢数順） */
function spScSortList(list, sort) {
	const n = (el, k) => parseInt(el.dataset[k], 10) || 0;
	const cards = [...list.querySelectorAll('.sp-card[data-id]')];
	cards.sort((a, b) => {
		if (sort === 'rank') {
			// 部門クラスごとに順位の順。順位のない人はその部門クラスの最後に的番号順
			const ra = n(a, 'rank') || 1e9, rb = n(b, 'rank') || 1e9;
			return (n(a, 'dcord') - n(b, 'dcord')) || a.dataset.dc.localeCompare(b.dataset.dc) || (ra - rb) || (n(a, 'ord') - n(b, 'ord'));
		}
		if (sort === 'hits') {
			// 選んでいる距離の射数の多い順（同じなら全体の射数の多い順）
			return (n(b, 'hits') - n(a, 'hits')) || (n(b, 'thits') - n(a, 'thits')) || (n(a, 'ord') - n(b, 'ord'));
		}
		return n(a, 'ord') - n(b, 'ord');
	});
	cards.forEach(c => list.appendChild(c));
}

/* 一覧で見えている選手の順（スコアカードの前後の選手に使う） */
function spScSaveOrder(list) {
	spStore('sc_order', JSON.stringify([...list.querySelectorAll('.sp-card[data-id]:not(.sp-hide)')].map(c => parseInt(c.dataset.id, 10))));
}

/* スコアカードの ◀ ▶ を、一覧で見えていた順にする */
function spScPrevNext() {
	let order = null;
	try { order = JSON.parse(spStore('sc_order') || 'null'); } catch (e) {}
	if (!Array.isArray(order) || !SpCard) return;
	const i = order.indexOf(SpCard.id);
	if (i < 0) return;
	[['SpPrev', order[i - 1]], ['SpNext', order[i + 1]]].forEach(([id, to]) => {
		const a = document.getElementById(id);
		if (!a) return;
		a.classList.toggle('sp-hide', !to);
		if (to) {
			const u = new URL(a.href, location.href);
			u.searchParams.set('a', to);
			a.href = u.toString();
		}
	});
}

function spScRender() {
	const c = SpCard;
	const area = document.getElementById('SpCardArea');
	if (!c) return;
	// 1 エンドを横 1 行に並べる（エンド番号・矢・小計・合計）
	const cols = c.numArrows;
	let html = '<div class="sp-card" style="margin-top:4px">'
		+ '<div class="sp-card-head"><span class="sp-badge">' + spEsc(c.target) + '</span><div class="sp-card-main">'
		+ '<div class="sp-name">' + spEsc(c.name) + '</div>'
		+ '<div class="sp-sub">' + spEsc([c.code, c.country, c.divcl].filter(x => x).join(' / ')) + '</div>'
		+ '</div></div>'
		+ '<div class="sp-totals">'
		+ '<div><small>' + spEsc(c.distName) + '</small><b id="SpCur">' + spEsc(c.cur.score) + '</b></div>'
		+ '<div><small>' + spEsc(c.goldLabel) + '</small><b id="SpCurG">' + spEsc(c.cur.gold) + '</b></div>'
		+ '<div><small>' + spEsc(c.xnineLabel) + '</small><b id="SpCurX">' + spEsc(c.cur.xnine) + '</b></div>'
		+ '<div><small>総合計</small><b id="SpTot">' + spEsc(c.tot.score) + '</b></div>'
		+ '</div>'
		+ '<div class="sp-sub" style="white-space:normal">' + c.dists.map((d, i) => spEsc(d.name) + ': <span id="SpD' + (i + 1) + '">' + spEsc(d.score) + '</span>').join('　') + '</div>'
		+ '</div>'
		+ '<div class="sp-ends" style="margin-top:8px">'
		+ '<div class="sp-end sp-end-head"><div class="sp-end-no"></div><div class="sp-arrows" style="--cols:' + cols + '">'
		+ Array.from({length: c.numArrows}, (_, j) => '<div>' + (j + 1) + '</div>').join('')
		+ '</div><div class="sp-end-sub">小計</div><div class="sp-end-run">合計</div></div>';
	c.ends.forEach(e => {
		html += '<div class="sp-end' + (e.outOfRange ? ' out-of-range' : '') + '">'
			+ '<div class="sp-end-no">' + (e.end + 1) + '</div>'
			+ '<div class="sp-arrows" style="--cols:' + cols + '">';
		e.arrows.forEach((a, j) => {
			const idx = e.end * c.numArrows + j;
			html += '<div class="sp-arrow" data-idx="' + idx + '">' + spEsc(a) + '</div>';
		});
		html += '</div><div class="sp-end-sub" id="SpEnd' + e.end + '">' + e.tot + '</div><div class="sp-end-run" id="SpRun' + e.end + '">' + e.run + '</div></div>';
	});
	html += '</div>';
	area.innerHTML = html;

	// 表示順（フィールド・3D ではエンドの並びが変わる）に入力欄を並べる
	SpSc.cells = [...area.querySelectorAll('.sp-arrow')];

	const pad = document.createElement('div');
	pad.className = 'sp-keypad';
	pad.style.setProperty('--kcols', Math.min(6, Math.max(3, Math.ceil(c.keys.length / 2))));
	pad.innerHTML = c.keys.map(k => '<button type="button" class="' + spScKeyColor(k) + '" data-key="' + spEsc(k) + '">' + spEsc(k) + '</button>').join('')
		+ '<div class="sp-keypad-fn">'
		+ '<button type="button" class="fn" data-fn="clear">素点削除</button>'
		+ '<button type="button" class="fn" data-fn="clearEnd">エンド削除</button>'
		+ '<button type="button" class="fn" data-fn="prev">◀ 前</button>'
		+ '<button type="button" class="fn" data-fn="next">次 ▶</button>'
		+ '</div>';
	document.body.appendChild(pad);
	document.body.classList.add('sp-has-keypad');

	area.addEventListener('click', ev => {
		const cell = ev.target.closest('.sp-arrow');
		if (cell) spScSelect(SpSc.cells.indexOf(cell));
	});
	pad.addEventListener('click', ev => {
		const b = ev.target.closest('button');
		if (!b) return;
		if (b.dataset.key !== undefined) spScWrite(b.dataset.key);
		else if (b.dataset.fn === 'clear') spScWrite('');
		else if (b.dataset.fn === 'clearEnd') spScClearEnd();
		else if (b.dataset.fn === 'prev') spScSelect(SpSc.sel - 1);
		else if (b.dataset.fn === 'next') spScSelect(SpSc.sel + 1);
	});

	// 最初の未入力の矢を選ぶ
	const first = SpSc.cells.findIndex(x => x.textContent.trim() === '');
	spScSelect(first >= 0 ? first : 0, true);
}

/* 点数のボタンの色（的の色: X〜9 黄、8・7 赤、6・5 青、4・3 黒、2・1 白、M 灰） */
function spScKeyColor(k) {
	const u = String(k).toUpperCase();
	if (u === 'M') return 'k-miss';
	if (u === 'X' || u === '10' || u === '9') return 'k-gold';
	if (u === '8' || u === '7') return 'k-red';
	if (u === '6' || u === '5') return 'k-blue';
	if (u === '4' || u === '3') return 'k-black';
	if (u === '2' || u === '1') return 'k-white';
	return '';
}

/* 選んでいる矢のエンドの点数をすべて消す（1 本ずつ本体の UpdateArrow.php で消す） */
async function spScClearEnd() {
	const cell = SpSc.cells[SpSc.sel];
	if (!cell || SpSc.busy) return;
	const end = Math.floor(parseInt(cell.getAttribute('data-idx'), 10) / SpCard.numArrows);
	const cells = SpSc.cells.filter(x => Math.floor(parseInt(x.getAttribute('data-idx'), 10) / SpCard.numArrows) === end);
	const filled = cells.filter(x => x.textContent.trim() !== '');
	if (!filled.length) { spToast('このエンドには点数がありません'); return; }
	if (!confirm('第' + (end + 1) + 'エンドの点数（' + filled.length + '本）をすべて削除しますか？')) return;
	SpSc.busy = true;
	try {
		for (const x of filled) {
			if (!await spScSave(x, '')) break;
		}
	} finally {
		SpSc.busy = false;
	}
	spScSelect(SpSc.cells.indexOf(cells[0]));
}

function spScSelect(i, noScroll) {
	if (i < 0 || i >= SpSc.cells.length) return;
	if (SpSc.sel >= 0 && SpSc.cells[SpSc.sel]) SpSc.cells[SpSc.sel].classList.remove('sel');
	SpSc.sel = i;
	const cell = SpSc.cells[i];
	cell.classList.add('sel');
	if (!noScroll) {
		const r = cell.getBoundingClientRect();
		const pad = document.querySelector('.sp-keypad');
		const limit = pad ? pad.getBoundingClientRect().top : window.innerHeight;
		if (r.bottom > limit - 8 || r.top < 70) cell.scrollIntoView({block: 'center', behavior: 'smooth'});
	}
}

/* 本体の UpdateArrow.php で 1 本を保存する */
async function spScWrite(point) {
	const cell = SpSc.cells[SpSc.sel];
	if (!cell || SpSc.busy) return;
	const pos = SpSc.sel;
	if (await spScSave(cell, point) && SpSc.sel === pos && point !== '') spScSelect(pos + 1);
}

/* 1 本を保存する（保存できたら true） */
async function spScSave(cell, point) {
	const idx = cell.getAttribute('data-idx');
	let ok = false;
	cell.classList.add('sp-saving');
	cell.classList.remove('sp-error');
	try {
		const d = await spPostJson('Qualification/UpdateArrow.php', {
			Dist: SpCard.dist,
			Index: idx,
			Id: SpCard.id,
			NoRecalc: document.getElementById('SpNoRecalc').checked ? 1 : 0,
			Point: point,
		});
		if (d.error && d.error != 0) {
			cell.classList.add('sp-error');
			spToast('保存できませんでした（入力できない値、またはロック中）', true);
		} else {
			cell.textContent = d.arrowsymbol;
			document.getElementById('SpCur').textContent = d.curscore;
			document.getElementById('SpCurG').textContent = d.curgold;
			document.getElementById('SpCurX').textContent = d.curxnine;
			document.getElementById('SpTot').textContent = d.score;
			const dd = document.getElementById('SpD' + SpCard.dist);
			if (dd) dd.textContent = d.curscore;
			(d.endscore || []).forEach((v, e) => { const x = document.getElementById('SpEnd' + e); if (x) x.textContent = v; });
			(d.runscore || []).forEach((v, e) => { const x = document.getElementById('SpRun' + e); if (x) x.textContent = v; });
			ok = true;
		}
	} catch (e) {
		cell.classList.add('sp-error');
		spToast('保存できませんでした: ' + e.message, true);
	}
	cell.classList.remove('sp-saving');
	return ok;
}

/* 本体の CalcRank.php / MakeTeams.php / MakeTeamsAbs.php を呼ぶ */
async function spScAct(act) {
	const dist = SpCard ? SpCard.dist : SpDist;
	try {
		if (act === 'calcDist') {
			if (!dist) { spToast('距離を選んでください', true); return; }
			const r = await spGetJson('Qualification/CalcRank.php', {Dist: dist});
			spToast(r.msg, r.error != 0);
		} else if (act === 'calc') {
			const r = await spGetJson('Qualification/CalcRank.php');
			spToast(r.msg, r.error != 0);
		} else if (act === 'teams') {
			const r = await spGetJson('Qualification/MakeTeams.php');
			if (r.error != 0) { spToast(r.msg, true); return; }
			const r2 = await spGetJson('Qualification/MakeTeamsAbs.php');
			spToast(r.msg + ' / ' + r2.msg, r2.error != 0);
		}
	} catch (e) {
		spToast('処理できませんでした: ' + e.message, true);
	}
}

document.addEventListener('DOMContentLoaded', () => {
	// セッションと距離は前回の選択を初期値にする（URL で指定されていないとき）
	const url = new URL(location.href);
	const lastD = spStore('sc_d'), lastS = spStore('sc_s');
	let redirect = false;
	if (!SpHasDist && lastD && lastD != SpDist) { url.searchParams.set('d', lastD); redirect = true; }
	if (!SpHasSes && lastS && lastS != SpSes) { url.searchParams.set('s', lastS); redirect = true; }
	if (redirect) { location.replace(url.toString()); return; }
	spStore('sc_d', SpDist);
	spStore('sc_s', SpSes);

	// 一覧の検索（前回の検索語を残す）
	const search = document.getElementById('SpSearch');
	if (search) {
		const list = document.getElementById('SpList');
		const dc = document.getElementById('SpDcFilter');
		const sort = document.getElementById('SpSort');
		const run = () => {
			spStore('sc_q', search.value);
			spStore('sc_dc', dc.value);
			spFilterCards(list, search.value, c => !dc.value || c.dataset.dc === dc.value);
			// 人数は絞り込みのメニューに出す（検索語に合う人の数）
			const words = spNorm(search.value).split(/\s+/).filter(w => w);
			const cnt = {'': 0};
			list.querySelectorAll('.sp-card[data-id]').forEach(c => {
				if (!words.every(w => c.dataset.search.indexOf(w) >= 0)) return;
				cnt[''] += 1;
				cnt[c.dataset.dc] = (cnt[c.dataset.dc] || 0) + 1;
			});
			[...dc.options].forEach(o => { o.textContent = o.dataset.label + '(' + (cnt[o.value] || 0) + '人)'; });
			spScSaveOrder(list);
		};
		search.value = spStore('sc_q') || '';
		dc.value = spStore('sc_dc') || '';
		if (dc.selectedIndex < 0) dc.value = '';
		sort.value = ['target', 'rank', 'hits'].indexOf(spStore('sc_sort')) >= 0 ? spStore('sc_sort') : 'target';
		spScSortList(list, sort.value);
		search.addEventListener('input', run);
		dc.addEventListener('change', run);
		sort.addEventListener('change', () => {
			spStore('sc_sort', sort.value);
			spScSortList(list, sort.value);
			spScSaveOrder(list);
		});
		run();
		// 一覧に戻ったときは、開いていた選手を見えるところに
		if (location.hash) {
			const el = document.querySelector(location.hash);
			if (el) el.scrollIntoView({block: 'center'});
		}
	}

	const chk = document.getElementById('SpNoRecalc');
	chk.checked = spStore('sc_norecalc') === '1';
	chk.addEventListener('change', async () => {
		spStore('sc_norecalc', chk.checked ? '1' : '0');
		if (!chk.checked) {
			// 本体の「後で更新」をやめたときと同じく、まとめて計算する
			spToast('順位とチームを計算しています…');
			await spScAct('calcDist');
			await spScAct('calc');
			await spScAct('teams');
		}
	});
	document.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', () => spScAct(b.dataset.act)));
	spScPrevNext();
	spScRender();
});
</script>
<?php
spTail('Scorecard');
