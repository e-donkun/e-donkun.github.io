<?php
/*
スマホモード: 共通の部品（画面の枠、下部タブ、権限の確認など）。
各画面の登録・更新は ianseo 本体の処理（Partecipants/ や Qualification/ の Ajax ページ、ライブラリ関数）をそのまま使う。
この画面群は表示だけをスマホ向けに作り直したもの。

変更履歴:
2026/11/10 下のタブに「端末」（ランキングラウンドのセッションのロック）を追加。色を背景色の設定（BackgroundColor）から引き継ぐ
2026/09/26 初版
*/
require_once(dirname(dirname(__FILE__)) . '/config.php');
require_once('Common/Lib/CommonLib.php');

/**
 * スマホモードの画面（タブ）一覧。
 * acl は本体のメニュー（Common/Menu.php）と、呼び出す本体ページが確認している権限と同じもの。
 */
function spPages() {
	return [
		'Participants' => ['label' => '参加者', 'title' => '参加者リスト・IRM設定', 'file' => 'Participants.php', 'icon' => 'users', 'acl' => [AclParticipants, 'pEntries', AclReadWrite]],
		'Targets' => ['label' => '的番号', 'title' => '的番号設定', 'file' => 'Targets.php', 'icon' => 'target', 'acl' => [AclParticipants, 'pTarget', AclReadWrite]],
		'Scorecard' => ['label' => 'スコア', 'title' => 'スコアカード修正', 'file' => 'Scorecard.php', 'icon' => 'edit', 'acl' => [AclQualification, '', AclReadWrite]],
		'Terminals' => ['label' => '端末', 'title' => '端末のロック', 'file' => 'Terminals.php', 'icon' => 'lock', 'acl' => [AclISKServer, 'iskManagement', AclReadWrite]],
		'Live' => ['label' => 'ライブ', 'title' => 'ライブ得点集計', 'file' => 'Live.php', 'icon' => 'chart', 'acl' => null],
		// 帳票ごとの権限は Print.php で確かめる
		'Print' => ['label' => '印刷', 'title' => '印刷', 'file' => 'Print.php', 'icon' => 'print', 'acl' => null],
		// 試合の選択（下のタブには出さない。試合を開いていなくても使える）
		'Select' => ['label' => '試合', 'title' => '試合の選択', 'file' => 'Select.php', 'icon' => '', 'acl' => null, 'tab' => false],
	];
}

/**
 * その画面を使えるか
 */
function spCanUse($Page) {
	$p = spPages()[$Page] ?? null;
	if(!$p) {
		return false;
	}
	if(!$p['acl']) {
		return true;
	}
	return hasFullACL($p['acl'][0], $p['acl'][1], $p['acl'][2]);
}

/**
 * 試合が開かれていて、その画面の権限があることを確認する（なければ本体と同じ扱い）
 */
function spCheckPage($Page) {
	global $CFG;
	if(!CheckTourSession()) {
		// 試合を開いていなければ、スマホモードの試合の選択へ
		CD_redirect($CFG->ROOT_DIR . 'Modules/Custom/SmartphoneMode/Select.php');
	}
	$p = spPages()[$Page];
	if($p['acl']) {
		checkFullACL($p['acl'][0], $p['acl'][1], $p['acl'][2]);
	}
}

/**
 * 本体ページへの URL
 */
function spRoot($Path='') {
	global $CFG;
	return $CFG->ROOT_DIR . $Path;
}

/**
 * この試合で選べる部門クラス（選手として出られるもの）。キーは「部門|クラス」
 */
function spDivClasses() {
	$Ret = [];
	$q = safe_r_sql("SELECT DivId, DivDescription, ClId, ClDescription, ClSex
		FROM Divisions
		INNER JOIN Classes ON ClTournament=DivTournament AND (ClDivisionsAllowed='' OR find_in_set(DivId, ClDivisionsAllowed))
		WHERE DivTournament=" . intval($_SESSION['TourId']) . " AND DivAthlete=1 AND ClAthlete=1
		ORDER BY DivViewOrder, ClViewOrder");
	while($r = safe_fetch($q)) {
		$Ret[$r->DivId . '|' . $r->ClId] = $r;
	}
	return $Ret;
}

/**
 * データベースの日時（UTC で保存されている）を、大会のタイムゾーン設定（ToTimeZone、例: +09:00）の時刻にする
 * 同じ日なら「時:分」、違う日なら「月/日 時:分」
 */
function spLocalTime($Utc) {
	if(!$Utc or str_starts_with($Utc, '0000')) {
		return '';
	}
	$Tz = $_SESSION['TourTimezone'] ?? '';
	try {
		$Zone = new DateTimeZone($Tz ?: 'UTC');
	} catch(Exception $e) {
		$Zone = new DateTimeZone('UTC');
	}
	$d = new DateTime($Utc, new DateTimeZone('UTC'));
	$d->setTimezone($Zone);
	$Now = new DateTime('now', $Zone);
	return $d->format($d->format('Y-m-d') == $Now->format('Y-m-d') ? 'H:i' : 'n/j H:i');
}

/**
 * ログイン認証が有効なとき、このユーザーが扱える試合に絞る SQL の条件（Duplicate/Lib.php の dupAuthFilter() と同じ考え方）
 */
function spAuthFilter() {
	global $CFG;
	if(!($CFG->USERAUTH and !empty($_SESSION['AUTH_ENABLE']) and empty($_SESSION['AUTH_ROOT']))) {
		return '';
	}
	$Filter = [];
	$CompList = [];
	foreach($_SESSION['AUTH_COMP'] ?? [] as $Comp) {
		if(str_contains($Comp, '%')) {
			$Filter[] = 'ToCode LIKE ' . StrSafe_DB($Comp);
		} else {
			$CompList[] = $Comp;
		}
	}
	if($CompList) {
		$Filter[] = 'FIND_IN_SET(ToCode, ' . StrSafe_DB(implode(',', $CompList)) . ') != 0';
	}
	return '(' . ($Filter ? implode(' OR ', $Filter) : 'FALSE') . ')';
}

/**
 * HTML エスケープ
 */
function spH($Text) {
	return htmlspecialchars((string) $Text, ENT_QUOTES, 'UTF-8');
}

/**
 * PHP の値を JavaScript の変数にする（本体の phpVars2js() と同じ形。名前などに </script> が入っても壊れないようにしている）
 */
function spJsVars($Vars) {
	$Out = '<script>';
	foreach($Vars as $k => $v) {
		$Out .= 'var ' . $k . '=' . json_encode($v, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) . ';';
	}
	return $Out . '</script>';
}

/**
 * アイコン（SVG）
 */
function spIcon($Name) {
	$Paths = [
		'users' => '<path d="M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zM8 11a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm0 2c-2.7 0-8 1.3-8 4v3h8v-3c0-1.1.5-2.1 1.4-2.9A12 12 0 0 0 8 13zm8 0c-2.7 0-8 1.3-8 4v3h16v-3c0-2.7-5.3-4-8-4z"/>',
		'target' => '<path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8zm0-14a6 6 0 1 0 6 6 6 6 0 0 0-6-6zm0 10a4 4 0 1 1 4-4 4 4 0 0 1-4 4zm0-6a2 2 0 1 0 2 2 2 2 0 0 0-2-2z"/>',
		'flag' => '<path d="M5 3h2v18H5zM8 4h11l-2.5 4L19 12H8z"/>',
		'edit' => '<path d="M3 17.3V21h3.8l11-11-3.8-3.8zM20.7 7a1 1 0 0 0 0-1.4l-2.3-2.3a1 1 0 0 0-1.4 0l-1.8 1.8 3.8 3.8z"/>',
		'chart' => '<path d="M4 20h16v2H4zM5 10h3v8H5zm5-6h3v14h-3zm5 3h3v11h-3z"/>',
		'pc' => '<path d="M3 4h18a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1h-7v2h3v2H7v-2h3v-2H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zm1 2v9h16V6z"/>',
		'reload' => '<path d="M17.6 6.4A8 8 0 1 0 20 12h-2a6 6 0 1 1-1.8-4.2L13 11h7V4z"/>',
		'print' => '<path d="M6 2h12v5H6zM4 8h16a2 2 0 0 1 2 2v7h-4v5H6v-5H2v-7a2 2 0 0 1 2-2zm4 9v3h8v-3zm10-6a1 1 0 1 0 1 1 1 1 0 0 0-1-1z"/>',
		'lock' => '<path d="M12 2a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V7a5 5 0 0 0-5-5zm-3 8V7a3 3 0 0 1 6 0v3zm3 4a2 2 0 0 1 1 3.7V20h-2v-2.3A2 2 0 0 1 12 14z"/>',
		'unlock' => '<path d="M12 2a5 5 0 0 0-5 5h2a3 3 0 0 1 6 0v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V7a5 5 0 0 0-5-5zm0 12a2 2 0 0 1 1 3.7V20h-2v-2.3A2 2 0 0 1 12 14z"/>',
		'search' => '<path d="M10 2a8 8 0 0 1 6.3 12.9l5.4 5.4-1.4 1.4-5.4-5.4A8 8 0 1 1 10 2zm0 2a6 6 0 1 0 6 6 6 6 0 0 0-6-6z"/>',
	];
	return '<svg class="sp-icon" viewBox="0 0 24 24" aria-hidden="true">' . ($Paths[$Name] ?? '') . '</svg>';
}

/**
 * 画面の色（濃い色・薄い色）。背景色の設定（カスタムモジュール BackgroundColor）があれば、
 * 開いている試合の色（なければ全試合の標準の色）を使う。
 * 濃い色（BackgroundColor の文字色 --header-dark）は上部バー・ボタンなど、薄い色（背景色 --header-light）は画面の背景に使う。
 * BackgroundColor が入っていなければ null（sp.css の色のまま）
 */
function spColors() {
	$File = dirname(__DIR__) . '/BackgroundColor/Lib.php';
	if(!is_file($File)) {
		return null;
	}
	require_once($File);
	if(!function_exists('bgcLoad') or !function_exists('bgcPairFor')) {
		return null;
	}
	$Pair = bgcPairFor(bgcLoad(), $_SESSION['TourId'] ?? 0);
	if(empty($Pair['light']) or empty($Pair['dark'])) {
		return null;
	}
	return ['dark' => $Pair['dark'], 'light' => $Pair['light']];
}

/**
 * spColors() の色で sp.css の色を上書きする <style>
 */
function spColorStyle($Colors) {
	if(!$Colors) {
		return '';
	}
	$D = $Colors['dark'];
	$L = $Colors['light'];
	return '<style>:root { --sp-primary:' . $D . '; --sp-primary-dark:color-mix(in srgb, ' . $D . ' 75%, #000); --sp-primary-light:' . $L . '; --sp-bg:' . $L . '; }</style>';
}

/**
 * 画面の上部（HTML の head、上部バー）を出力する
 * @param string $Page 画面のキー（spPages() のキー）
 * @param array $JsVars JavaScript に渡す変数
 */
function spHead($Page, $JsVars=[]) {
	global $CFG;
	$p = spPages()[$Page];
	$Base = $CFG->ROOT_DIR . 'Modules/Custom/SmartphoneMode/';
	$Ver = '?v=' . filemtime(__DIR__ . '/sp.js') . '-' . filemtime(__DIR__ . '/sp.css');
	$Colors = spColors();
	$JsVars = array_merge([
		'SP_ROOT' => $CFG->ROOT_DIR,
		'SP_BASE' => $Base,
	], $JsVars);

	echo '<!DOCTYPE html>
<html lang="ja" translate="no">
<head>
<meta charset="UTF-8">
<meta name="google" content="notranslate">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="' . spH($Colors['dark'] ?? '#1e4d8c') . '">
<title>' . spH($p['title']) . '</title>
<link rel="icon" href="' . $CFG->ROOT_DIR . 'favicon.ico">
<link rel="stylesheet" href="' . $Base . 'sp.css' . $Ver . '">
' . spColorStyle($Colors) . '
' . spJsVars($JsVars) . '
<script src="' . $Base . 'sp.js' . $Ver . '"></script>
</head>
<body class="sp-page-' . strtolower($Page) . '">
<header class="sp-appbar">
	<div class="sp-appbar-title">
		<a class="sp-tour" href="' . $Base . 'Select.php" title="試合を選び直す">' . spH(($_SESSION['TourName'] ?? '') ?: '試合を選んでください') . ' ▸</a>
		<h1>' . spH($p['title']) . '</h1>
	</div>
	<a class="sp-appbar-btn" href="' . $CFG->ROOT_DIR . (CheckTourSession() ? 'Main.php' : 'index.php') . '" title="PCモードに戻る">' . spIcon('pc') . '<span>PC</span></a>
</header>
<main class="sp-main">
';
}

/**
 * 画面の下部（下部タブ、HTML の終わり）を出力する
 */
function spTail($Page) {
	echo '
</main>';
	// 下のタブは試合を開いているときだけ
	if(CheckTourSession()) {
		echo '
<nav class="sp-tabbar">';
	}
	foreach(spPages() as $Key => $p) {
		if(($p['tab'] ?? true) === false or !CheckTourSession() or !spCanUse($Key)) {
			continue;
		}
		echo '<a href="' . $p['file'] . '" class="' . ($Key == $Page ? 'active' : '') . '">' . spIcon($p['icon']) . '<span>' . spH($p['label']) . '</span></a>';
	}
	echo (CheckTourSession() ? '</nav>' : '') . '
<div id="sp-toast" class="sp-toast" role="status"></div>
</body>
</html>';
}
