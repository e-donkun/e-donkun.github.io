<?php
/*
スマホモード: 試合の選択
本体のトップページ（index.php）の試合の一覧に当たる画面。試合を選ぶと、本体の Common/TourOn.php で
試合を開き、スマホモード（index.php）に入る。
- 一覧に出す試合は本体のトップページと同じ（ログイン認証が有効なときは、そのユーザーが扱える試合だけ）
- ログイン認証が有効で、まだログインしていなければ、本体のログインの画面へのリンクを出す

変更履歴:
2026/10/01 初版
*/
require_once(__DIR__ . '/Lib.php');
require_once('Common/Fun_FormatText.inc.php');

$Filter = spAuthFilter();
$Tours = [];
$q = safe_r_sql("SELECT ToId, ToCode, ToName, ToWhere, ToWhenFrom, ToWhenTo
	FROM Tournament
	" . ($Filter ? "WHERE $Filter" : '') . "
	ORDER BY ToWhenTo DESC, ToWhenFrom DESC, ToCode ASC");
while($r = safe_fetch($q)) {
	$Tours[] = $r;
}

// ログイン認証が有効で、まだログインしていない（本体のトップページと同じ判断）
$NeedLogin = (AuthModule and empty($_SESSION['AUTH_User'])
	and !(in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1']) and in_array($_SERVER['SERVER_ADDR'] ?? '', ['127.0.0.1', '::1'])));

$CurId = CheckTourSession() ? intval($_SESSION['TourId']) : 0;
$Back = $CFG->ROOT_DIR . 'Modules/Custom/SmartphoneMode/index.php';

spHead('Select');

if($NeedLogin) {
	echo '<a class="sp-btn block" style="margin-bottom:12px" href="' . spH($CFG->ROOT_DIR . 'Modules/Authentication/LogIn.php') . '">' . spH(get_text('Login', 'Tournament')) . '</a>';
}

if(!$Tours) {
	echo '<div class="sp-empty">開ける試合がありません</div>';
} else {
	echo '<p class="sp-note">試合を選ぶと、スマホモードで開きます。</p><div class="sp-list">';
	foreach($Tours as $t) {
		$When = $t->ToWhenFrom . ($t->ToWhenTo != $t->ToWhenFrom ? ' 〜 ' . $t->ToWhenTo : '');
		echo '<a class="sp-card tap sp-tour-item' . ($t->ToId == $CurId ? ' current' : '') . '" href="'
			. spH($CFG->ROOT_DIR . 'Common/TourOn.php?ToId=' . intval($t->ToId) . '&BackTo=' . urlencode($Back)) . '">'
			. '<div class="sp-name">' . spH($t->ToName) . ($t->ToId == $CurId ? ' <span class="sp-tag">開いている試合</span>' : '') . '</div>'
			. '<div class="sp-sub">' . spH(implode(' / ', array_filter([$t->ToCode, $When, $t->ToWhere]))) . '</div>'
			. '</a>';
	}
	echo '</div>';
}
echo '<p class="sp-note"><a href="' . spH($CFG->ROOT_DIR . 'index.php') . '">PC 向けのトップページを開く</a></p>';

spTail('Select');
