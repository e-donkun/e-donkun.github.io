<?php
/*
スマホモード: 参加者の追加（過去の参加者から）と削除
Participants.php から呼ぶ。結果は JSON で返す。

act=teams   : 部門クラス（dc=部門|クラス）を選んだときの、過去の参加者のチーム一覧
act=archers : チーム（team=所属コード）の、過去の参加者の一覧（この試合に登録済みかどうか付き）
act=add     : 選んだ過去の参加者（src[]=元の EnId）を、選んだ部門クラスで追加する
act=delete  : 参加者（id）を削除する。的番号が設定される前（点数もない）ときだけ

過去の参加者 = このサーバーにある、この試合以外の試合の選手（同じ選手は一番新しい試合のもの）。
ログイン認証が有効なときは、そのユーザーが扱える試合だけを見る。

追加・削除は本体と同じ流れで行う:
- 追加: 本体の Partecipants/PopEdit.php・ListLoad.php と同じく Countries・Entries・Qualifications を作り、
  本体の checkAgainstLUE()、RecalculateShootoffAndTeams()、CalcQualRank()、MakeIndAbs() を呼ぶ
- 削除: 本体の Partecipants/DeleteRow.php と同じく deleteArcher() と再計算の関数を呼ぶ

変更履歴:
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');

$JSON = ['error' => 1, 'msg' => ''];
if(!CheckTourSession() or !hasFullACL(AclParticipants, 'pEntries', AclReadWrite)) {
	$JSON['msg'] = '権限がありません';
	JsonOut($JSON);
}

require_once('Common/Fun_FormatText.inc.php');
require_once('Common/Fun_Various.inc.php');
require_once('Common/Fun_Sessions.inc.php');
require_once('Qualification/Fun_Qualification.local.inc.php');
require_once('Partecipants/Fun_Partecipants.local.inc.php');

$TourId = intval($_SESSION['TourId']);

/**
 * 過去の参加者（同じ選手は一番新しい試合のものだけ）。$Sex が 0/1 のときはその性別だけ
 */
function spPastArchers($Sex=-1, $Team=null) {
	$TourId = intval($_SESSION['TourId']);
	$Filter = spAuthFilter();
	$q = safe_r_sql("SELECT EnId, EnCode, EnFirstName, EnName, EnSex, EnDivision, EnClass, CoCode, CoName,
			ToName, ToWhenFrom
		FROM Entries
		INNER JOIN Tournament ON ToId=EnTournament
		INNER JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament
		WHERE EnTournament!={$TourId} AND EnAthlete=1 AND CoCode!=''
			" . ($Filter ? "AND $Filter" : '') . "
		ORDER BY ToWhenFrom DESC, EnTournament DESC, EnId DESC");
	$Ret = [];
	while($r = safe_fetch($q)) {
		$Key = ($r->EnCode !== '' ? 'C:' . $r->EnCode : spNameKey($r->EnFirstName, $r->EnName, $r->CoCode));
		if(isset($Ret[$Key])) {
			continue;
		}
		$Ret[$Key] = $r;
	}
	return array_filter($Ret, function($r) use ($Sex, $Team) {
		return ($Sex < 0 or $r->EnSex == $Sex) and ($Team === null or $r->CoCode === $Team);
	});
}

/**
 * 名前と所属で同じ選手かを見るためのキー（姓名の間の空白の違いは無視する）
 */
function spNameKey($FirstName, $Name, $CoCode) {
	return 'N:' . preg_replace('/[\s\x{3000}]+/u', '', $FirstName . $Name) . '|' . $CoCode;
}

/**
 * この試合に同じ部門で登録済みの選手のキー（選手コードと、名前＋所属の両方）
 * 選手コードは試合（年度）ごとに変わることがあるので、名前と所属が同じなら登録済みとみなす
 */
function spRegisteredKeys($Division) {
	$Keys = [];
	$q = safe_r_sql("SELECT EnCode, EnFirstName, EnName, CoCode
		FROM Entries
		LEFT JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament
		WHERE EnTournament=" . intval($_SESSION['TourId']) . " AND EnDivision=" . StrSafe_DB($Division));
	while($r = safe_fetch($q)) {
		if($r->EnCode !== '') {
			$Keys['C:' . $r->EnCode] = true;
		}
		$Keys[spNameKey($r->EnFirstName, $r->EnName, $r->CoCode)] = true;
	}
	return $Keys;
}

/**
 * 過去の参加者が、この試合に登録済みか
 */
function spIsRegistered($r, $Registered) {
	return ($r->EnCode !== '' and isset($Registered['C:' . $r->EnCode])) or isset($Registered[spNameKey($r->EnFirstName, $r->EnName, $r->CoCode)]);
}

/**
 * 選んだ部門クラス（「部門|クラス」）を確かめて返す
 */
function spGetDivClass() {
	$DivClasses = spDivClasses();
	$Dc = $_REQUEST['dc'] ?? '';
	if(!isset($DivClasses[$Dc])) {
		JsonOut(['error' => 1, 'msg' => '部門クラスを選んでください']);
	}
	return $DivClasses[$Dc];
}

switch($_REQUEST['act'] ?? '') {
	case 'teams':
		$Dc = spGetDivClass();
		$Teams = [];
		foreach(spPastArchers(intval($Dc->ClSex)) as $r) {
			if(!isset($Teams[$r->CoCode])) {
				$Teams[$r->CoCode] = ['code' => $r->CoCode, 'name' => $r->CoName, 'count' => 0];
			}
			$Teams[$r->CoCode]['count']++;
		}
		uasort($Teams, fn($a, $b) => strcmp($a['code'], $b['code']));
		JsonOut(['error' => 0, 'teams' => array_values($Teams)]);

	case 'archers':
		$Dc = spGetDivClass();
		$Registered = spRegisteredKeys($Dc->DivId);
		$List = [];
		foreach(spPastArchers(intval($Dc->ClSex), (string) ($_REQUEST['team'] ?? '')) as $r) {
			$List[] = [
				'src' => intval($r->EnId),
				'code' => $r->EnCode,
				'name' => trim($r->EnFirstName . ' ' . $r->EnName),
				'last' => $r->EnDivision . ' ' . $r->EnClass,
				'tour' => $r->ToName,
				'registered' => spIsRegistered($r, $Registered),
			];
		}
		usort($List, fn($a, $b) => strcmp($a['code'] . $a['name'], $b['code'] . $b['name']));
		JsonOut(['error' => 0, 'archers' => $List]);

	case 'add':
		if(IsBlocked(BIT_BLOCK_PARTICIPANT)) {
			JsonOut(['error' => 1, 'msg' => '参加者の変更がロックされています']);
		}
		$Dc = spGetDivClass();
		$Src = array_filter(array_map('intval', (array) ($_REQUEST['src'] ?? [])));
		if(!$Src) {
			JsonOut(['error' => 1, 'msg' => '追加する選手を選んでください']);
		}

		// 選べる選手（過去の参加者）だけを受け付ける
		$Past = [];
		foreach(spPastArchers(intval($Dc->ClSex)) as $r) {
			$Past[intval($r->EnId)] = true;
		}
		$Registered = spRegisteredKeys($Dc->DivId);

		// 部門クラスの既定の的の種類（本体の getTargets() と同じ選び方）
		$Targets = getTargets();
		$TargetFace = 0;
		if(!empty($Targets[$Dc->DivId][$Dc->ClId])) {
			$TargetFace = intval(array_key_first($Targets[$Dc->DivId][$Dc->ClId]));
		}

		$Now = date('Y-m-d H:i:s');
		$Added = [];
		$Skipped = 0;
		foreach($Src as $SrcId) {
			if(!isset($Past[$SrcId])) {
				$Skipped++;
				continue;
			}
			$q = safe_r_sql("SELECT Entries.*, CoCode, CoName, CoNameComplete
				FROM Entries
				INNER JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament
				WHERE EnId={$SrcId}");
			if(!($r = safe_fetch($q)) or spIsRegistered($r, $Registered)) {
				$Skipped++;
				continue;
			}

			// 所属（なければ作る。本体の ListLoad.php と同じ）
			$q = safe_r_sql("SELECT CoId FROM Countries WHERE CoTournament={$TourId} AND CoCode=" . StrSafe_DB($r->CoCode));
			if($c = safe_fetch($q)) {
				$CoId = $c->CoId;
			} else {
				safe_w_sql("INSERT INTO Countries SET CoTournament={$TourId}, CoCode=" . StrSafe_DB($r->CoCode)
					. ", CoName=" . StrSafe_DB($r->CoName) . ", CoNameComplete=" . StrSafe_DB($r->CoNameComplete));
				$CoId = safe_w_last_id();
			}

			// サブクラスはこの試合にあるときだけ引き継ぐ
			$SubClass = '';
			if($r->EnSubClass !== '') {
				$q = safe_r_sql("SELECT ScId FROM SubClass WHERE ScTournament={$TourId} AND ScId=" . StrSafe_DB($r->EnSubClass));
				if(safe_num_rows($q)) {
					$SubClass = $r->EnSubClass;
				}
			}

			// 選手（出場する種目の区分などは、本体の新規登録と同じくデータベースの既定値）
			safe_w_sql("INSERT INTO Entries SET EnTimestamp='{$Now}', EnMainInfoUpdate='{$Now}',
				EnTournament={$TourId},
				EnIocCode=" . StrSafe_DB($r->EnIocCode) . ",
				EnCode=" . StrSafe_DB($r->EnCode) . ",
				EnFirstName=" . StrSafe_DB($r->EnFirstName) . ",
				EnName=" . StrSafe_DB($r->EnName) . ",
				EnNameOrder=" . intval($r->EnNameOrder) . ",
				EnOdfShortname=" . StrSafe_DB($r->EnOdfShortname) . ",
				EnSex=" . intval($r->EnSex) . ",
				EnDob=" . StrSafe_DB($r->EnDob) . ",
				EnCtrlCode=" . StrSafe_DB($r->EnCtrlCode) . ",
				EnCountry={$CoId},
				EnDivision=" . StrSafe_DB($Dc->DivId) . ",
				EnClass=" . StrSafe_DB($Dc->ClId) . ",
				EnAgeClass=" . StrSafe_DB($Dc->ClId) . ",
				EnSubClass=" . StrSafe_DB($SubClass) . ",
				EnAthlete=1,
				EnStatus=0,
				EnTargetFace={$TargetFace}");
			$Id = safe_w_last_id();
			safe_w_sql("INSERT INTO Qualifications SET QuId={$Id}, QuSession=0");
			checkAgainstLUE($Id);
			if($r->EnCode !== '') {
				$Registered['C:' . $r->EnCode] = true;
			}
			$Registered[spNameKey($r->EnFirstName, $r->EnName, $r->CoCode)] = true;
			$Added[] = $Id;
		}

		// 本体の PopEdit.php で新しく登録したときと同じ再計算
		if($Added and $x = Params4Recalc($Added[0])) {
			list($indFEvent, $teamFEvent, $country, $div, $cl, $subCl, $zero) = $x;
			RecalculateShootoffAndTeams($indFEvent, $teamFEvent, $country, $div, $cl, $subCl, $zero);
			$q = safe_r_sql("SELECT ToNumDist FROM Tournament WHERE ToId={$TourId}");
			$t = safe_fetch($q);
			for($i = 0; $i < $t->ToNumDist; ++$i) {
				CalcQualRank($i, $div . $cl);
			}
			MakeIndAbs();
		}

		JsonOut([
			'error' => 0,
			'added' => count($Added),
			'msg' => count($Added) . '人を追加しました' . ($Skipped ? '（' . $Skipped . '人は登録済みなどのため追加しませんでした）' : ''),
		]);

	case 'delete':
		if(IsBlocked(BIT_BLOCK_PARTICIPANT)) {
			JsonOut(['error' => 1, 'msg' => '参加者の変更がロックされています']);
		}
		$Id = intval($_REQUEST['id'] ?? 0);
		$q = safe_r_sql("SELECT QuTarget, (QuScore>0 OR QuHits>0) AS HasScore
			FROM Entries
			INNER JOIN Qualifications ON QuId=EnId
			WHERE EnId={$Id} AND EnTournament={$TourId}");
		if(!($r = safe_fetch($q))) {
			JsonOut(['error' => 1, 'msg' => '参加者が見つかりません']);
		}
		if($r->QuTarget) {
			JsonOut(['error' => 1, 'msg' => '的番号が設定されているため削除できません']);
		}
		if($r->HasScore) {
			JsonOut(['error' => 1, 'msg' => '点数が入力済みのため削除できません']);
		}

		// 本体の Partecipants/DeleteRow.php と同じ流れ
		$Recalc = Params4Recalc($Id);
		deleteArcher($Id, true, true);
		if($Recalc !== false) {
			list($indFEvent, $teamFEvent, $country, $div, $cl, $subCl, $zero) = $Recalc;
			RecalculateShootoffAndTeams($indFEvent, $teamFEvent, $country, $div, $cl, $subCl, $zero);
			$q = safe_r_sql("SELECT ToNumDist FROM Tournament WHERE ToId={$TourId}");
			$t = safe_fetch($q);
			for($i = 0; $i < $t->ToNumDist; ++$i) {
				CalcQualRank($i, $div . $cl);
			}
			MakeIndAbs();
		}
		JsonOut(['error' => 0, 'msg' => '削除しました']);
}

JsonOut($JSON);
