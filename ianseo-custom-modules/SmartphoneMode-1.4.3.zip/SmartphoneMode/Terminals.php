<?php
/*
スマホモード: 端末のロック
本体の Api/ISK-NG/Sessions.php（ロックするセッションの管理）のうち、ランキングラウンド（予選）の分をスマホ向けにした画面。
- セッションと距離ごとに、端末（ISK-NG）からの点数の受け取りをロック・アンロックする
- 設定は本体と同じモジュールパラメータ（ISK-NG / LockedSessions）に保存する。キーも本体と同じ「Q|セッション|距離」
  （本体の GetLockableSessions() の予選の部分と同じ条件で一覧を作る）
- 決勝・エリミネーションなどのロックは変えない（「すべてロック」「すべて解除」もランキングラウンドの分だけ）
- 権限は本体の画面と同じ（ISK の管理 iskManagement の書き込み）

変更履歴:
2026/11/10 初版
*/
require_once(__DIR__ . '/Lib.php');
spCheckPage('Terminals');

require_once('Common/Lib/Fun_Modules.php');

/**
 * ランキングラウンドのロックできるセッション・距離（本体の GetLockableSessions() の予選の部分と同じ条件）
 * セッションの番号 => ['name' => セッション名, 'dists' => [距離 => キー]]
 */
function spLockableQ() {
	$TourId = intval($_SESSION['TourId']);
	$Ret = [];
	$q = safe_r_sql("SELECT QuSession, DiDistance, SesName, CONCAT_WS('|', 'Q', QuSession, DiDistance) AS LockKey
		FROM Qualifications
		INNER JOIN Entries ON EnId=QuId AND EnTournament={$TourId}
		INNER JOIN DistanceInformation ON DiTournament=EnTournament AND DiSession=QuSession AND DiType='Q'
		LEFT JOIN Session ON SesTournament=EnTournament AND SesType='Q' AND SesOrder=QuSession
		WHERE QuSession>0
		GROUP BY QuSession, DiDistance
		ORDER BY QuSession, DiDistance");
	while($r = safe_fetch($q)) {
		$s = intval($r->QuSession);
		if(!isset($Ret[$s])) {
			$Ret[$s] = ['name' => ($r->SesName ?? '') != '' ? $r->SesName : ('セッション' . $s), 'dists' => []];
		}
		$Ret[$s]['dists'][intval($r->DiDistance)] = $r->LockKey;
	}
	return $Ret;
}

// ロック・アンロック（act=set: keys のキーを lock の状態にする）
if(($_REQUEST['act'] ?? '') == 'set') {
	$Valid = [];
	foreach(spLockableQ() as $s) {
		foreach($s['dists'] as $Key) {
			$Valid[$Key] = true;
		}
	}
	$Keys = array_values(array_filter((array)($_REQUEST['keys'] ?? []), fn($k) => is_string($k) and isset($Valid[$k])));
	$Lock = !empty($_REQUEST['lock']);
	$Locked = getModuleParameter('ISK-NG', 'LockedSessions', []);
	foreach($Keys as $Key) {
		$i = array_search($Key, $Locked);
		if($Lock and $i === false) {
			$Locked[] = $Key;
		} elseif(!$Lock and $i !== false) {
			unset($Locked[$i]);
		}
	}
	setModuleParameter('ISK-NG', 'LockedSessions', array_values($Locked));
	$Status = [];
	foreach($Keys as $Key) {
		$Status[$Key] = $Lock ? 1 : 0;
	}
	JsonOut(['error' => 0, 'status' => $Status]);
}

$Sessions = spLockableQ();
$Locked = getModuleParameter('ISK-NG', 'LockedSessions', []);

// 本体のメニューでは、ロックの管理は ISK-NG Lite の大会でだけ出している
$IsLite = (($_SESSION['UseApi'] ?? 0) == 11);

spHead('Terminals');

if(!$IsLite) {
	echo '<div class="sp-card status-warn" style="margin-bottom:12px"><div class="sp-sub" style="white-space:normal">この大会は、得点の取り込みが ISK-NG Lite の設定ではありません。ロックは ISK-NG の端末から届く点数に使われます。</div></div>';
}

if(!$Sessions) {
	echo '<div class="sp-empty">ロックできるセッションがありません。<br>選手のセッションと、セッションごとの距離（エンド数・矢数）を設定してください。</div>';
} else {
	$AllKeys = [];
	foreach($Sessions as $s) {
		$AllKeys = array_merge($AllKeys, array_values($s['dists']));
	}
	echo '<div class="sp-row" style="margin-bottom:8px">
	<button type="button" class="sp-btn danger" data-lock="1" data-keys="' . spH(json_encode($AllKeys)) . '">' . spIcon('lock') . 'すべてロック</button>
	<button type="button" class="sp-btn sub" data-lock="0" data-keys="' . spH(json_encode($AllKeys)) . '">' . spIcon('unlock') . 'すべて解除</button>
</div>';
	echo '<div class="sp-list" id="SpLockList">';
	foreach($Sessions as $s) {
		$Keys = array_values($s['dists']);
		echo '<div class="sp-card">
	<div class="sp-card-head"><div class="sp-card-main"><div class="sp-name">' . spH($s['name']) . '</div></div>
		<button type="button" class="sp-chip" data-lock="1" data-keys="' . spH(json_encode($Keys)) . '">全部ロック</button>
		<button type="button" class="sp-chip" data-lock="0" data-keys="' . spH(json_encode($Keys)) . '">全部解除</button>
	</div>
	<div class="sp-lock-grid">';
		foreach($s['dists'] as $Dist => $Key) {
			$On = in_array($Key, $Locked);
			echo '<button type="button" class="sp-lock' . ($On ? ' locked' : '') . '" data-key="' . spH($Key) . '">'
				. '<small>' . $Dist . '距離目</small>'
				. '<span class="on">' . spIcon('lock') . 'ロック中</span><span class="off">' . spIcon('unlock') . '受付中</span>'
				. '</button>';
		}
		echo '</div>
</div>';
	}
	echo '</div>';
	echo '<p class="sp-note">ロックしたセッション・距離は、端末から点数を送っても受け付けません（本体の「ロックするセッションの管理」と同じ設定です）。ボタンをタップすると切り替わります。</p>';
}
?>
<script>
async function spLockSet(keys, lock) {
	try {
		const d = await spPostJson('Modules/Custom/SmartphoneMode/Terminals.php', {act: 'set', lock: lock ? 1 : 0, 'keys[]': keys});
		if (d.error != 0) throw new Error(d.msg || '');
		Object.keys(d.status || {}).forEach(k => {
			document.querySelectorAll('.sp-lock[data-key]').forEach(b => {
				if (b.dataset.key === k) b.classList.toggle('locked', d.status[k] == 1);
			});
		});
		spToast(lock ? 'ロックしました' : 'ロックを解除しました');
	} catch (e) {
		spToast('保存できませんでした: ' + e.message, true);
	}
}

document.addEventListener('DOMContentLoaded', () => {
	document.querySelectorAll('[data-lock][data-keys]').forEach(b => b.addEventListener('click', () => {
		const keys = JSON.parse(b.dataset.keys);
		if (keys.length > 1 && !confirm((b.dataset.lock == '1' ? 'ロック' : 'ロックを解除') + 'しますか？')) return;
		spLockSet(keys, b.dataset.lock == '1');
	}));
	document.querySelectorAll('.sp-lock[data-key]').forEach(b => b.addEventListener('click', () => {
		spLockSet([b.dataset.key], !b.classList.contains('locked'));
	}));
});
</script>
<?php
spTail('Terminals');
