<?php
/*
モジュールメニューに「スマホモード」を追加する。試合を開いていないときも表示する（そのときは試合の選択を開く）。
また、本体のトップページ（index.php）をスマホで開いたときは、スマホモード（試合の選択）への大きいボタンを出す。
（本体のファイルは変えず、メニューを作るときに読み込まれるこのファイルから差し込む）

変更履歴:
2026/11/10 大会を開いていないときもモジュールメニューに出す。トップページのボタンの色を背景色の設定にあわせる
2026/10/01 トップページをスマホで開いたときに、スマホモードへのボタンを出す
2026/09/26 初版
*/
$ret['MODS'][] = MENU_DIVIDER;
$ret['MODS'][] = 'スマホモード' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/SmartphoneMode/' . (empty($on) ? 'Select.php' : 'index.php');

// 本体のトップページのときだけ（1 回だけ出す）
if(($_SERVER['SCRIPT_NAME'] ?? '') === $CFG->ROOT_DIR . 'index.php' and !defined('SP_TOP_BUTTON')) {
	define('SP_TOP_BUTTON', true);
	$SpSelectUrl = $CFG->ROOT_DIR . 'Modules/Custom/SmartphoneMode/Select.php';
	// ボタンの色は背景色の設定（BackgroundColor）の濃い色にする
	$SpBtnColor = '#1e4d8c';
	if(is_file($SpBgcLib = dirname(__DIR__) . '/BackgroundColor/Lib.php')) {
		require_once($SpBgcLib);
		if(function_exists('bgcLoad') and function_exists('bgcPairFor')) {
			$SpBtnColor = bgcPairFor(bgcLoad(), $_SESSION['TourId'] ?? 0)['dark'] ?? $SpBtnColor;
		}
	}
	// 本体の画面はスマホでも PC と同じ幅で縮小して表示されるので、
	// 画面幅ではなく端末の画面の大きさでスマホかどうかを見て、ボタンの大きさは画面の幅（vw）にあわせる
	echo '<style>
#sp-top-btn { display: block; margin: 2vw 1vw 3vw; padding: 3.5vw 3vw; border-radius: 2.5vw; background: ' . htmlspecialchars($SpBtnColor) . ';
	color: #fff !important; font-size: 6vw; font-weight: bold; line-height: 1.3; text-align: center; text-decoration: none;
	box-shadow: 0 .5vw 1.5vw rgba(0,0,0,.3); }
#sp-top-btn small { display: block; margin-top: 1vw; font-size: 3.4vw; font-weight: normal; opacity: .9; }
</style>
<script>
document.addEventListener("DOMContentLoaded", function() {
	var isPhone = Math.min(screen.width, screen.height) <= 700 || /iPhone|Android.+Mobile/.test(navigator.userAgent);
	var content = document.getElementById("Content");
	// ianseo のライセンスの同意の画面が出ているときは出さない（先に同意してもらう）
	if (!isPhone || !content || document.getElementById("sp-top-btn") || document.querySelector(".AgreeLicense")) return;
	var a = document.createElement("a");
	a.id = "sp-top-btn";
	a.href = ' . json_encode($SpSelectUrl) . ';
	a.innerHTML = "📱 スマホモード<small>試合を選んで、スマホ向けの画面で操作します</small>";
	content.insertBefore(a, content.firstChild);
});
</script>';
}
