<?php
/*
スマホモードの入口。使える画面のうち最初のものを開く。試合を開いていなければ、試合の選択を開く。

変更履歴:
2026/10/01 試合を開いていなければ、スマホモードの試合の選択（Select.php）を開く
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');

if(!CheckTourSession()) {
	CD_redirect('Select.php');
}

foreach(spPages() as $Key => $p) {
	if(($p['tab'] ?? true) !== false and spCanUse($Key)) {
		CD_redirect($p['file']);
	}
}
CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
