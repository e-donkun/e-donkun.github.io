<?php
/*
スマホモード: 的番号設定
本体の Partecipants/SetTarget_default.php に当たる画面。
- 一覧の取得は本体の画面と同じ条件（選手のみ、選んだセッションとセッション未設定の選手）
- セッションの変更は本体の Partecipants/UpdateSession.php、的番号の変更は Partecipants/UpdateTargetNo.php、
  的番号の重複の確認は Partecipants/FindRedTarget.php を呼ぶ（本体の画面と同じ処理）
- 点数が入っている選手は、セッションも的番号も変えられない
  （端末から届いてまだ取り込んでいない点数が、その選手の的にある場合も同じ）
- 点数が入っている的（そこにいる選手に点数がある、または端末から届いた点数がある）へは移せない
- 保存の直前にこの画面で確かめてから、本体の処理を呼ぶ
- 表示は「一覧」と「割り当て表」を切り替えられる。割り当て表では、下の未割当の選手をタップし、
  空いている枠をタップすると割り当てる（セッションが違えば先にそのセッションに入れる）。
  的の種類が違う選手と同じ的になるときは警告を出す

変更履歴:
2026/09/30 割り当て表の枠に所属先コード（略称）を出した
2026/09/30 画面の名前を「的番号設定」にした
2026/09/26 割り当て表（タップ2回で割り当て）を追加。的番号を空にしても外れなかったのを直した
2026/09/26 点数が入っている選手・的は、セッションと的番号を変えられないようにした
2026/09/26 セッション番号ではなくセッション名を表示
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');
spCheckPage('Targets');

require_once('Common/Fun_FormatText.inc.php');
require_once('Common/Fun_Sessions.inc.php');

$Sessions = [];
foreach(GetSessions('Q') as $s) {
	// セッション番号ではなくセッション名を表示する（名前がなければ「セッション N」）
	$Sessions[] = ['id' => intval($s->SesOrder), 'name' => $s->SesName != '' ? $s->SesName : ('セッション' . $s->SesOrder)];
}

/**
 * 端末（ISK-NG）から届いて、まだ取り込んでいない予選の点数がある的の一覧（キーは「セッション.的番号記号」）
 */
function spIskPendingKeys() {
	$Keys = [];
	$q = safe_r_sql("SELECT DISTINCT IskDtTargetNo FROM IskData WHERE IskDtTournament=" . intval($_SESSION['TourId']) . " AND IskDtType='Q'");
	while($r = safe_fetch($q)) {
		$Keys[$r->IskDtTargetNo] = true;
	}
	return $Keys;
}

/**
 * 選手のセッション・的番号を変えられない理由（変えられるときは空文字）
 */
function spLockReason($EnId, $Pending=null) {
	$q = safe_r_sql("SELECT QuSession, QuTarget, QuLetter, (QuScore>0 OR QuHits>0) AS HasScore
		FROM Qualifications
		INNER JOIN Entries ON EnId=QuId AND EnTournament=" . intval($_SESSION['TourId']) . "
		WHERE QuId=" . intval($EnId));
	if(!($r = safe_fetch($q))) {
		return '選手が見つかりません';
	}
	if($r->HasScore) {
		return '点数が入力済みのため変更できません';
	}
	if($Pending === null) {
		$Pending = spIskPendingKeys();
	}
	if($r->QuTarget and isset($Pending[$r->QuSession . '.' . $r->QuTarget . $r->QuLetter])) {
		return '端末から届いた点数があるため変更できません';
	}
	return '';
}

/**
 * 移動先の的に点数が入っていて移せない理由（移せるときは空文字）
 */
function spTargetBusyReason($Session, $Target, $Letter, $EnId) {
	$q = safe_r_sql("SELECT EnId FROM Qualifications
		INNER JOIN Entries ON EnId=QuId AND EnTournament=" . intval($_SESSION['TourId']) . "
		WHERE QuSession=" . intval($Session) . " AND QuTarget=" . intval($Target) . " AND QuLetter=" . StrSafe_DB($Letter) . "
			AND EnId!=" . intval($EnId) . " AND (QuScore>0 OR QuHits>0)");
	if(safe_num_rows($q)) {
		return 'この的には点数が入力済みの選手がいるため移せません';
	}
	if(isset(spIskPendingKeys()[intval($Session) . '.' . intval($Target) . $Letter])) {
		return 'この的には端末から届いた点数があるため移せません';
	}
	return '';
}

// 保存の直前の確認（kind=ses: セッションの変更、kind=tgt: 的番号の変更）
if(isset($_REQUEST['check'])) {
	$EnId = intval($_REQUEST['id'] ?? 0);
	$Reason = spLockReason($EnId);
	$JSON = ['ok' => $Reason === '', 'locked' => $Reason !== '', 'msg' => $Reason];
	if($Reason === '' and ($_REQUEST['kind'] ?? '') == 'tgt') {
		$Value = strtoupper(str_replace(' ', '', $_REQUEST['value'] ?? ''));
		if(preg_match('/^([0-9]+)([A-Z])$/', $Value, $m) and intval($m[1])) {
			$q = safe_r_sql("SELECT QuSession FROM Qualifications WHERE QuId={$EnId}");
			$r = safe_fetch($q);
			if($r and $Busy = spTargetBusyReason($r->QuSession, $m[1], $m[2], $EnId)) {
				$JSON = ['ok' => false, 'locked' => false, 'msg' => $Busy];
			}
		}
	}
	JsonOut($JSON);
}

$Ses = $_REQUEST['Ses'] ?? '*';
if($Ses != '*') {
	$Ses = intval($Ses);
	if(!in_array($Ses, array_column($Sessions, 'id'))) {
		$Ses = '*';
	}
}

$Rows = [];
if($Sessions) {
	$Pending = spIskPendingKeys();
	$Select = "SELECT EnId, EnCode, EnName, EnFirstName, EnDivision, EnClass, EnStatus, EnWChair, EnTargetFace,
			CoCode, CoName, QuSession, CONCAT(QuTarget, QuLetter) AS TargetNo, QuTarget, TfName, QuScore, QuGold, QuXNine,
			(QuScore>0 OR QuHits>0) AS HasScore
		FROM Entries
		INNER JOIN Qualifications ON EnId=QuId
		INNER JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament
		LEFT JOIN TargetFaces ON EnTournament=TfTournament AND EnTargetFace=TfId
		WHERE EnTournament=" . StrSafe_DB($_SESSION['TourId']) . " AND EnAthlete=1 "
		. ($Ses != '*' ? "AND QuSession in (0, {$Ses}) " : '')
		. "ORDER BY QuSession=0, QuSession, QuTarget=0, QuTarget, QuLetter, EnDivision, EnClass, EnFirstName, EnName";
	$Rs = safe_r_sql($Select);
	while($r = safe_fetch($Rs)) {
		$Lock = '';
		if($r->HasScore) {
			$Lock = '点数入力済み';
		} elseif($r->QuTarget and isset($Pending[$r->QuSession . '.' . $r->TargetNo])) {
			$Lock = '端末の点数あり';
		}
		$Rows[] = [
			'id' => intval($r->EnId),
			'code' => $r->EnCode,
			'name' => trim($r->EnFirstName . ' ' . $r->EnName),
			'country_code' => $r->CoCode,
			'country_name' => $r->CoName,
			'division' => $r->EnDivision,
			'class' => $r->EnClass,
			'status' => intval($r->EnStatus),
			'wc' => intval($r->EnWChair),
			'session' => intval($r->QuSession),
			'targetno' => $r->QuTarget ? $r->TargetNo : '',
			'targetface' => $r->TfName ? get_text($r->TfName, 'Tournament', '', true) : '',
			'tfid' => intval($r->EnTargetFace),
			'score' => $r->QuScore ? ($r->QuScore . ' / ' . $r->QuGold . ' / ' . $r->QuXNine) : '',
			'lock' => $Lock,
		];
	}
}

// 割り当て表の枠（選んだセッションの的番号と記号。本体の createAvailableTargetSQL() で作る）
$Slots = [];
if($Ses !== '*') {
	$q = safe_r_sql("SELECT FullTgtTarget, FullTgtLetter FROM (" . createAvailableTargetSQL($Ses, $_SESSION['TourId']) . ") at ORDER BY FullTgtTarget, FullTgtLetter");
	while($r = safe_fetch($q)) {
		$t = intval($r->FullTgtTarget);
		if(!isset($Slots[$t])) {
			$Slots[$t] = ['t' => $t, 'letters' => []];
		}
		$Slots[$t]['letters'][] = $r->FullTgtLetter;
	}
}

spHead('Targets', [
	'SpSlots' => array_values($Slots),
	'SpRows' => $Rows,
	'SpSessions' => $Sessions,
	'SpSes' => (string) $Ses,
]);
?>
<div class="sp-toolbar">
	<div class="sp-chips">
		<a class="sp-chip<?php echo $Ses == '*' ? ' active' : ''; ?>" href="?Ses=*">すべて</a>
<?php foreach($Sessions as $s) { ?>
		<a class="sp-chip<?php echo $Ses === $s['id'] ? ' active' : ''; ?>" href="?Ses=<?php echo $s['id']; ?>"><?php echo spH($s['name']); ?></a>
<?php } ?>
	</div>
	<div class="sp-chips" id="SpViewChips">
		<button type="button" class="sp-chip" data-view="list">一覧</button>
		<button type="button" class="sp-chip" data-view="grid">割り当て表</button>
	</div>
</div>
<?php if(!$Sessions) { ?>
<div class="sp-empty">予選のセッションが設定されていません。</div>
<?php } ?>
<div id="SpListView">
	<div class="sp-toolbar">
		<label class="sp-search"><?php echo spIcon('search'); ?><input type="search" id="SpSearch" placeholder="名前・所属・部門クラスで検索"></label>
		<label class="sp-switch"><input type="checkbox" id="SpOnlyEmpty"> 的番号が未設定の人だけ</label>
	</div>
	<div class="sp-count" id="SpCount"></div>
	<div class="sp-list" id="SpList"></div>
	<p class="sp-note">的番号は「12A」のように番号と記号で入力します。空にすると的番号を外します。入力欄から離れると保存されます。赤い的番号は重複しています。<br>点数が入っている選手（🔒）はセッションも的番号も変えられません。点数が入っている的へも移せません。</p>
</div>
<div id="SpGridView" class="sp-hide">
	<div id="SpGrid"></div>
	<p class="sp-note">下の未割当の選手をタップしてから、空いている枠をタップすると割り当てます。枠の選手をタップすると、別の空き枠へ移したり、割り当てを外したりできます。🔒の選手（点数が入っている）は動かせません。</p>
</div>
<div id="SpTray" class="sp-tray sp-hide">
	<div class="sp-tray-head">
		<span id="SpTrayInfo"></span>
		<select id="SpTrayFilter" aria-label="部門クラスで絞り込み"></select>
	</div>
	<div class="sp-tray-sel sp-hide" id="SpTraySel">
		<span id="SpTraySelText"></span>
		<button type="button" class="sp-btn sub" id="SpUnassign">割り当てを外す</button>
		<button type="button" class="sp-btn sub" id="SpCancelSel">やめる</button>
	</div>
	<div class="sp-tray-list" id="SpTrayList"></div>
</div>

<script>
function spTgtCard(r) {
	let opts = '<option value="0"' + (r.session == 0 ? ' selected' : '') + '>--</option>';
	SpSessions.forEach(s => {
		opts += '<option value="' + s.id + '"' + (r.session == s.id ? ' selected' : '') + '>' + spEsc(s.name) + '</option>';
	});
	const disabled = r.status > 8 || !!r.lock;
	const cls = r.status == 9 ? ' status-noshoot' : (r.status > 1 ? ' status-warn' : '');
	const search = spNorm([r.code, r.name, r.country_code, r.country_name, r.division + r.class, r.division, r.class, r.targetno].join(' '));
	return '<div class="sp-card' + cls + '" data-id="' + r.id + '" data-ses="' + r.session + '" data-tgt="' + spEsc(r.targetno) + '" data-search="' + spEsc(search) + '">'
		+ '<div class="sp-card-head"><div class="sp-card-main">'
		+ '<div class="sp-name">' + spEsc(r.name) + '</div>'
		+ '<div class="sp-sub">' + spEsc([r.code, r.country_code, r.country_name].filter(x => x).join(' / ')) + '</div>'
		+ '<div style="margin-top:4px"><span class="sp-tag">' + spEsc(r.division + ' ' + r.class) + '</span>'
		+ (r.targetface ? '<span class="sp-tag">' + spEsc(r.targetface) + '</span>' : '')
		+ (r.wc ? '<span class="sp-tag">車いす</span>' : '')
		+ (r.score ? '<span class="sp-tag">' + spEsc(r.score) + '</span>' : '')
		+ (r.lock ? '<span class="sp-tag danger">🔒 ' + spEsc(r.lock) + '</span>' : '')
		+ '</div>'
		+ '</div></div>'
		+ '<div class="sp-target-edit">'
		+ '<select data-role="ses"' + (disabled ? ' disabled' : '') + ' aria-label="セッション">' + opts + '</select>'
		+ '<input type="text" data-role="tgt" value="' + spEsc(r.targetno) + '" maxlength="5" autocomplete="off" autocapitalize="characters" inputmode="text" placeholder="的"'
		+ (r.session == 0 || disabled ? ' readonly' : '') + ' aria-label="的番号">'
		+ '</div>'
		+ '</div>';
}

/* 保存の直前に、変えてよいかをこの画面（Targets.php?check=1）で確かめる。だめなら元に戻す */
async function spCheckChange(card, kind, value) {
	try {
		const res = await spGetJson('Modules/Custom/SmartphoneMode/Targets.php', {check: 1, id: card.getAttribute('data-id'), kind: kind, value: value});
		if (res.ok) return true;
		spToast(res.msg, true);
		if (res.locked) spLockCard(card, '点数入力済み');
	} catch (e) {
		spToast('確認できませんでした: ' + e.message, true);
	}
	card.querySelector('[data-role="ses"]').value = card.getAttribute('data-ses');
	card.querySelector('[data-role="tgt"]').value = card.getAttribute('data-tgt');
	return false;
}

/* 点数が入った選手のカードを変更できない状態にする */
function spLockCard(card, label) {
	const r = SpRows.find(x => x.id == card.getAttribute('data-id'));
	if (!r) return;
	r.lock = label;
	r.session = parseInt(card.getAttribute('data-ses'), 10) || 0;
	r.targetno = card.getAttribute('data-tgt');
	card.outerHTML = spTgtCard(r);
	spFindRed();
}

function spTgtFilter() {
	const onlyEmpty = document.getElementById('SpOnlyEmpty').checked;
	const n = spFilterCards(document.getElementById('SpList'), document.getElementById('SpSearch').value,
		card => !onlyEmpty || card.querySelector('[data-role="tgt"]').value === '' || card.hasAttribute('data-keep'));
	document.getElementById('SpCount').textContent = n + ' 人';
}

/* 本体の UpdateSession.php でセッションを変更する */
async function spSaveSession(card, sel) {
	const id = card.getAttribute('data-id');
	const tgt = card.querySelector('[data-role="tgt"]');
	const params = {};
	params['d_q_QuSession_' + id] = sel.value;
	sel.classList.add('sp-saving');
	try {
		if (!await spCheckChange(card, 'ses', sel.value)) {
			sel.classList.remove('sp-saving');
			return;
		}
		const doc = await spGetXml('Partecipants/UpdateSession.php', params);
		if (spXmlVal(doc, 'error') == '1') {
			sel.classList.add('sp-error');
			spToast('保存できませんでした（ロック中などの理由）', true);
		} else {
			sel.classList.remove('sp-error');
			if (spXmlVal(doc, 'troppi') == '1') {
				// 定員を超えるので変わっていない
				sel.value = card.getAttribute('data-ses');
				alert(spXmlVal(doc, 'msg'));
			} else {
				spToast('セッションを保存しました');
			}
			if (sel.value == '0') {
				tgt.value = '';
				tgt.readOnly = true;
			} else {
				tgt.readOnly = false;
			}
			if (spXmlVal(doc, 'new_targetno') == '#') tgt.value = '';
			card.setAttribute('data-ses', sel.value);
			card.setAttribute('data-tgt', tgt.value);
			spRowSet(id, {session: parseInt(sel.value, 10) || 0, targetno: tgt.value});
			card.setAttribute('data-keep', '1');
			spFindRed();
		}
	} catch (e) {
		sel.classList.add('sp-error');
		spToast('保存できませんでした: ' + e.message, true);
	}
	sel.classList.remove('sp-saving');
}

/* 本体の UpdateTargetNo.php で的番号を変更する */
async function spSaveTarget(card, inp) {
	const id = card.getAttribute('data-id');
	const params = {Ses: SpSes};
	// 空にしたときは 0 を送る（本体の UpdateTargetNo.php は 0 で的番号を外す。空だと何もしない）
	params['d_q_QuTargetNo_' + id] = inp.value.trim().toUpperCase() || '0';
	inp.classList.add('sp-saving');
	try {
		if (!await spCheckChange(card, 'tgt', params['d_q_QuTargetNo_' + id])) {
			inp.classList.remove('sp-saving');
			return;
		}
		const doc = await spGetXml('Partecipants/UpdateTargetNo.php', params);
		if (spXmlVal(doc, 'error') == '1') {
			inp.classList.add('sp-error');
			spToast('この的番号は使えません', true);
		} else {
			inp.classList.remove('sp-error');
			const pad = spXmlVal(doc, 'pad_value');
			inp.value = (pad != '#' ? pad : '');
			card.setAttribute('data-tgt', inp.value);
			card.setAttribute('data-keep', '1');
			spRowSet(id, {targetno: inp.value});
			spToast('的番号を保存しました');
			spFindRed();
		}
	} catch (e) {
		inp.classList.add('sp-error');
		spToast('保存できませんでした: ' + e.message, true);
	}
	inp.classList.remove('sp-saving');
}

/* 本体の FindRedTarget.php で重複した的番号に印を付ける */
async function spFindRed() {
	try {
		const doc = await spGetXml('Partecipants/FindRedTarget.php', {Ses: SpSes});
		const ids = doc.getElementsByTagName('id');
		const nums = doc.getElementsByTagName('num');
		document.querySelectorAll('#SpList [data-role="tgt"]').forEach(i => i.classList.remove('sp-dup'));
		for (let i = 0; i < ids.length; i++) {
			const inp = document.querySelector('#SpList .sp-card[data-id="' + ids[i].textContent + '"] [data-role="tgt"]');
			if (inp && nums[i].textContent != '1') inp.classList.add('sp-dup');
		}
	} catch (e) {
	}
}

/* 画面のデータ（SpRows）を更新する */
function spRowSet(id, values) {
	const r = SpRows.find(x => x.id == id);
	if (r) Object.assign(r, values);
}

/* ---- 本体の処理を呼ぶ（割り当て表用） ---- */
async function spApiCheck(id, kind, value) {
	return spGetJson('Modules/Custom/SmartphoneMode/Targets.php', {check: 1, id: id, kind: kind, value: value});
}
async function spApiSession(id, ses) {
	const params = {};
	params['d_q_QuSession_' + id] = ses;
	const doc = await spGetXml('Partecipants/UpdateSession.php', params);
	if (spXmlVal(doc, 'error') == '1') return {ok: false, msg: 'セッションを保存できませんでした（ロック中などの理由）'};
	if (spXmlVal(doc, 'troppi') == '1') return {ok: false, msg: spXmlVal(doc, 'msg')};
	return {ok: true};
}
async function spApiTarget(id, value) {
	const params = {Ses: SpSes};
	params['d_q_QuTargetNo_' + id] = value;
	const doc = await spGetXml('Partecipants/UpdateTargetNo.php', params);
	if (spXmlVal(doc, 'error') == '1') return {ok: false, msg: 'この的番号は使えません'};
	const pad = spXmlVal(doc, 'pad_value');
	return {ok: true, targetno: pad != '#' ? pad : ''};
}

/* ---- 割り当て表 ---- */
const SpGrid = {sel: null, busy: false, filter: spStore('tgt_tray_filter') || ''};

function spTrayRows() {
	return SpRows.filter(r => !r.targetno && r.status <= 8 && !r.lock);
}

function spGridRender() {
	const grid = document.getElementById('SpGrid');
	if (SpSes === '*') {
		grid.innerHTML = '<div class="sp-empty">上のボタンでセッションを選ぶと、割り当て表を表示します。</div>';
		document.getElementById('SpTray').classList.add('sp-hide');
		document.body.classList.remove('sp-has-tray');
		return;
	}
	const occ = {};
	SpRows.forEach(r => {
		if (r.session == SpSes && r.targetno) (occ[r.targetno] = occ[r.targetno] || []).push(r);
	});
	const sel = SpGrid.sel ? SpRows.find(x => x.id == SpGrid.sel) : null;
	let html = '';
	SpSlots.forEach(s => {
		html += '<div class="sp-grid-row"><div class="sp-grid-no">' + s.t + '</div><div class="sp-grid-cells" style="--cols:' + s.letters.length + '">';
		s.letters.forEach(l => {
			const key = s.t + l;
			const list = occ[key] || [];
			if (!list.length) {
				html += '<button type="button" class="sp-slot empty' + (sel ? ' target' : '') + '" data-slot="' + key + '"><small>' + l + '</small></button>';
				return;
			}
			const r = list[0];
			const cls = (r.lock ? ' locked' : '') + (list.length > 1 ? ' dup' : '') + (sel && sel.id == r.id ? ' sel' : '');
			html += '<button type="button" class="sp-slot' + cls + '" data-slot="' + key + '" data-id="' + r.id + '"><small>' + l + (r.lock ? ' 🔒' : '') + '</small>'
				+ list.map(x => '<b>' + spEsc(x.name) + '</b><i>' + spEsc(x.division + x.class + (x.country_code ? '　' + x.country_code : '')) + '</i>').join('') + '</button>';
		});
		html += '</div></div>';
	});
	grid.innerHTML = html || '<div class="sp-empty">このセッションには的がありません</div>';
	spTrayRender();
}

function spTrayRender() {
	const tray = document.getElementById('SpTray');
	tray.classList.remove('sp-hide');
	document.body.classList.add('sp-has-tray');
	const all = spTrayRows();
	// 部門クラスの絞り込み
	const dcs = [...new Set(all.map(r => r.division + ' ' + r.class))].sort();
	if (SpGrid.filter && dcs.indexOf(SpGrid.filter) < 0) SpGrid.filter = '';
	document.getElementById('SpTrayFilter').innerHTML = '<option value="">すべての部門クラス</option>'
		+ dcs.map(d => '<option' + (d === SpGrid.filter ? ' selected' : '') + '>' + spEsc(d) + '</option>').join('');
	const items = all.filter(r => !SpGrid.filter || r.division + ' ' + r.class === SpGrid.filter);
	document.getElementById('SpTrayInfo').textContent = '未割当 ' + all.length + '人';
	document.getElementById('SpTrayList').innerHTML = items.length
		? items.map(r => '<button type="button" class="sp-tray-chip' + (SpGrid.sel == r.id ? ' sel' : '') + '" data-id="' + r.id + '"><b>' + spEsc(r.name) + '</b><i>' + spEsc(r.division + ' ' + r.class + (r.session && r.session != SpSes ? ' / 別セッション' : '')) + '</i></button>').join('')
		: '<span class="sp-sub">未割当の選手はいません</span>';
	// 選択中の表示
	const sel = SpGrid.sel ? SpRows.find(x => x.id == SpGrid.sel) : null;
	document.getElementById('SpTraySel').classList.toggle('sp-hide', !sel);
	document.getElementById('SpTrayInfo').parentNode.classList.toggle('sp-hide', !!sel);
	if (sel) {
		document.getElementById('SpTraySelText').textContent = sel.name + (sel.targetno ? '（' + sel.targetno + '）' : '') + ' → 空いている枠をタップ';
		document.getElementById('SpUnassign').classList.toggle('sp-hide', !sel.targetno);
	}
}

function spGridSelect(id) {
	SpGrid.sel = (SpGrid.sel == id ? null : id);
	spGridRender();
}

/* 確認で止められたとき */
function spGridRefused(r, res) {
	spToast(res.msg, true);
	if (res.locked) {
		r.lock = '点数入力済み';
		SpGrid.sel = null;
	}
}

/* 選んだ選手を枠に割り当てる */
async function spGridPlace(key) {
	const r = SpRows.find(x => x.id == SpGrid.sel);
	if (!r || SpGrid.busy) return;
	// 的の種類が違う選手と同じ的になるときは警告
	const tnum = parseInt(key, 10);
	const others = SpRows.filter(x => x.id != r.id && x.session == SpSes && x.targetno && parseInt(x.targetno, 10) === tnum && x.tfid != r.tfid);
	if (others.length && !confirm(tnum + '番の的には、的の種類が違う選手がいます。\n'
		+ others.map(x => x.name + '（' + (x.targetface || '-') + '）').join('\n')
		+ '\n\n' + r.name + '（' + (r.targetface || '-') + '）を ' + key + ' に割り当てますか？')) return;
	SpGrid.busy = true;
	try {
		if (r.session != SpSes) {
			// 先に表示中のセッションに入れる
			const c = await spApiCheck(r.id, 'ses', SpSes);
			if (!c.ok) { spGridRefused(r, c); return; }
			const s = await spApiSession(r.id, SpSes);
			if (!s.ok) { spToast(s.msg, true); return; }
			r.session = parseInt(SpSes, 10);
			r.targetno = '';
		}
		const c2 = await spApiCheck(r.id, 'tgt', key);
		if (!c2.ok) { spGridRefused(r, c2); return; }
		const t = await spApiTarget(r.id, key);
		if (!t.ok) { spToast(t.msg, true); return; }
		r.targetno = t.targetno;
		SpGrid.sel = null;
		spToast(r.name + ' を ' + r.targetno + ' に割り当てました');
	} catch (e) {
		spToast('保存できませんでした: ' + e.message, true);
	} finally {
		SpGrid.busy = false;
		spGridRender();
	}
}

/* 選んだ選手の割り当てを外す */
async function spGridUnassign() {
	const r = SpRows.find(x => x.id == SpGrid.sel);
	if (!r || !r.targetno || SpGrid.busy) return;
	SpGrid.busy = true;
	try {
		const c = await spApiCheck(r.id, 'tgt', '0');
		if (!c.ok) { spGridRefused(r, c); return; }
		const t = await spApiTarget(r.id, '0');
		if (!t.ok) { spToast(t.msg, true); return; }
		spToast(r.name + ' の割り当てを外しました');
		r.targetno = '';
		SpGrid.sel = null;
	} catch (e) {
		spToast('保存できませんでした: ' + e.message, true);
	} finally {
		SpGrid.busy = false;
		spGridRender();
	}
}

/* 表示の切り替え（一覧／割り当て表） */
function spSetView(view) {
	spStore('tgt_view', view);
	document.querySelectorAll('#SpViewChips [data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === view));
	document.getElementById('SpListView').classList.toggle('sp-hide', view !== 'list');
	document.getElementById('SpGridView').classList.toggle('sp-hide', view !== 'grid');
	if (view === 'grid') {
		// 割り当て表はセッションごと。「すべて」のときは最初のセッションを開く
		if (SpSes === '*' && SpSessions.length) {
			location.href = '?Ses=' + SpSessions[0].id;
			return;
		}
		SpGrid.sel = null;
		spGridRender();
	} else {
		document.getElementById('SpTray').classList.add('sp-hide');
		document.body.classList.remove('sp-has-tray');
		const list = document.getElementById('SpList');
		list.innerHTML = SpRows.map(spTgtCard).join('');
		if (SpSessions.length && !SpRows.length) list.innerHTML = '<div class="sp-empty">選手がいません</div>';
		spTgtFilter();
		spFindRed();
	}
}

document.addEventListener('DOMContentLoaded', () => {
	document.getElementById('SpViewChips').addEventListener('click', ev => {
		const b = ev.target.closest('[data-view]');
		if (b) spSetView(b.dataset.view);
	});
	document.getElementById('SpGrid').addEventListener('click', ev => {
		const b = ev.target.closest('.sp-slot');
		if (!b) return;
		if (!b.hasAttribute('data-id')) {
			if (SpGrid.sel) spGridPlace(b.dataset.slot);
			else spToast('先に下の未割当の選手をタップしてください');
			return;
		}
		const r = SpRows.find(x => x.id == b.dataset.id);
		if (r && r.lock) { spToast('点数が入っているため動かせません', true); return; }
		spGridSelect(b.dataset.id);
	});
	document.getElementById('SpTrayList').addEventListener('click', ev => {
		const b = ev.target.closest('.sp-tray-chip');
		if (b) spGridSelect(b.dataset.id);
	});
	document.getElementById('SpTrayFilter').addEventListener('change', ev => {
		SpGrid.filter = ev.target.value;
		spStore('tgt_tray_filter', SpGrid.filter);
		spTrayRender();
	});
	document.getElementById('SpUnassign').addEventListener('click', spGridUnassign);
	document.getElementById('SpCancelSel').addEventListener('click', () => { SpGrid.sel = null; spGridRender(); });

	const list = document.getElementById('SpList');
	list.innerHTML = SpRows.map(spTgtCard).join('');
	if (SpSessions.length && !SpRows.length) list.innerHTML = '<div class="sp-empty">選手がいません</div>';
	const only = document.getElementById('SpOnlyEmpty');
	only.checked = spStore('tgt_only_empty') === '1';
	only.addEventListener('change', () => {
		spStore('tgt_only_empty', only.checked ? '1' : '0');
		list.querySelectorAll('[data-keep]').forEach(c => c.removeAttribute('data-keep'));
		spTgtFilter();
	});
	document.getElementById('SpSearch').addEventListener('input', spTgtFilter);
	list.addEventListener('change', ev => {
		const card = ev.target.closest('.sp-card[data-id]');
		if (!card) return;
		if (ev.target.matches('[data-role="ses"]')) spSaveSession(card, ev.target);
		if (ev.target.matches('[data-role="tgt"]')) spSaveTarget(card, ev.target);
	});
	list.addEventListener('keydown', ev => {
		if (ev.key === 'Enter' && ev.target.matches('[data-role="tgt"]')) ev.target.blur();
	});
	spTgtFilter();
	spFindRed();
	spSetView(spStore('tgt_view') === 'grid' ? 'grid' : 'list');
});
</script>
<?php
spTail('Targets');
