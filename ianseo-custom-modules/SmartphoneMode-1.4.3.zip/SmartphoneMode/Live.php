<?php
/*
スマホモード: ライブ得点集計
カスタムの LiveScoreboard/LiveScoreboard.php をスマホ向けに表示する画面。
- 順位・得点は本体の Obj_RankFactory::create('DivClass')（予選の部門・クラス別順位）で読み出す
- 矢ごとの点数の表示は本体の DecodeFromLetter() / ValutaArrowString() を使う
- ランキング順・ターゲット順、セッションの絞り込み（複数可）、自動更新、スコアカード表示ができる
- 点数がまだない選手も、的番号が設定されていれば表示する（ランキングでは順位なしで最後に並べ、点数欄は空欄）
- 最終入力の時刻は、大会のタイムゾーン設定にあわせて表示する
- 部門クラスで絞り込める

変更履歴:
2026/09/30 部門クラスの絞り込みを追加
2026/09/30 距離ごとの点数・射数のバッジを右に寄せた
2026/09/26 的番号がある選手は点数がなくても表示。時刻を大会のタイムゾーンにあわせた
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');
spCheckPage('Live');

require_once('Common/Lib/Obj_RankFactory.php');
require_once('Common/Lib/ArrTargets.inc.php');
require_once('Common/Fun_FormatText.inc.php');

/**
 * 画面で使う形に整えた順位データ
 */
function spLiveData() {
	$TourId = intval($_SESSION['TourId']);

	// セッション・距離ごとのエンド数と 1 エンドの矢数
	$DistInfo = [];
	$q = safe_r_sql("SELECT DiSession, DiDistance, DiEnds, DiArrows FROM DistanceInformation WHERE DiTournament={$TourId} AND DiType='Q'");
	while($r = safe_fetch($q)) {
		$DistInfo[intval($r->DiSession)][intval($r->DiDistance)] = [intval($r->DiEnds), intval($r->DiArrows)];
	}

	// includeAll: 点数がない選手も読む（本体の Obj_Rank_DivClass のオプション）
	$Rank = Obj_RankFactory::create('DivClass', ['tournament' => $TourId, 'includeAll' => 1]);
	$Rank->read();
	$Data = $Rank->getData();

	$Ret = ['sections' => [], 'sessions' => [], 'goldLabel' => '', 'xnineLabel' => '', 'lastUpdate' => spLocalTime($Data['meta']['lastUpdate'] ?? '')];
	$NumDist = intval($Data['meta']['numDist'] ?? 0);
	if($NumDist < 1) {
		$NumDist = 0;
	}

	foreach($Data['sections'] ?? [] as $Event => $Section) {
		$Fields = $Section['meta']['fields'];
		if(!$Ret['goldLabel']) {
			$Ret['goldLabel'] = $Fields['gold'] ?? '';
			$Ret['xnineLabel'] = $Fields['xnine'] ?? '';
		}
		$Dists = [];
		for($n = 1; $n <= $NumDist; $n++) {
			$Name = $Fields['dist_' . $n] ?? '';
			$Dists[] = ($Name === '-' ? '' : $Name);
		}
		$Items = [];
		$NoScoreItems = [];
		foreach($Section['items'] as $Item) {
			// 点数がない選手は、的番号が設定されているときだけ表示する
			$NoScore = (!intval($Item['hits']) and !intval($Item['score']));
			if($NoScore and !intval($Item['target'])) {
				continue;
			}
			$Ses = intval($Item['session']);
			if($Ses) {
				$Ret['sessions'][$Ses] = $Item['sessionName'];
			}
			$DistScores = [];
			$Cards = [];
			for($n = 1; $n <= $NumDist; $n++) {
				if($Dists[$n - 1] === '') {
					$DistScores[] = null;
					$Cards[] = null;
					continue;
				}
				list($dRank, $dScore, $dGold, $dXnine) = array_pad(explode('|', $Item['dist_' . $n]), 4, '');
				$DistScores[] = ['rank' => $dRank, 'score' => $dScore, 'gold' => $dGold, 'xnine' => $dXnine];

				// スコアカード（エンドごとの点数）
				$Str = $Item["D{$n}Arrowstring"] ?? '';
				if(trim($Str) === '') {
					$Cards[] = null;
					continue;
				}
				list($Ends, $Arrows) = $DistInfo[$Ses][$n] ?? [0, 0];
				if(!$Arrows) {
					$Arrows = 6;
					$Ends = intval(ceil(strlen(rtrim($Str)) / $Arrows));
				}
				$Str = str_pad($Str, $Ends * $Arrows, ' ');
				$EndList = [];
				for($e = 0; $e < $Ends; $e++) {
					$Part = substr($Str, $e * $Arrows, $Arrows);
					$Arr = [];
					for($j = 0; $j < $Arrows; $j++) {
						$Arr[] = DecodeFromLetter(trim($Part[$j] ?? ''));
					}
					$EndList[] = ['a' => $Arr, 't' => ValutaArrowString($Part)];
				}
				$Cards[] = $EndList;
			}
			$Row = [
				'id' => intval($Item['id']),
				'bib' => $Item['bib'],
				'ses' => $Ses,
				'tgt' => $Item['target'],
				'name' => $Item['athlete'],
				'cc' => $Item['countryCode'],
				'cn' => $Item['countryName'],
				// 点数がない選手の順位は出さない（前の計算の値が残っていることがある）
				'rank' => $NoScore ? ($Item['irm'] ? $Item['irmText'] : '') : $Item['rank'],
				'noscore' => $NoScore,
				'score' => $Item['score'],
				'gold' => $Item['gold'],
				'xnine' => $Item['xnine'],
				'hits' => intval($Item['hits']),
				'irm' => $Item['irm'] ? $Item['irmText'] : '',
				'dists' => $DistScores,
				'cards' => $Cards,
			];
			if($NoScore) {
				$NoScoreItems[] = $Row;
			} else {
				$Items[] = $Row;
			}
		}
		// 点数がない選手は、順位のある選手のあとに的番号順で並べる
		usort($NoScoreItems, fn($a, $b) => [$a['ses'], intval($a['tgt']), $a['tgt']] <=> [$b['ses'], intval($b['tgt']), $b['tgt']]);
		$Items = array_merge($Items, $NoScoreItems);
		if(!$Items) {
			continue;
		}
		$Ret['sections'][] = [
			'event' => $Event,
			'descr' => $Section['meta']['descr'],
			'dists' => $Dists,
			'items' => $Items,
		];
	}
	ksort($Ret['sessions']);
	$Sessions = [];
	foreach($Ret['sessions'] as $k => $v) {
		$Sessions[] = ['id' => $k, 'name' => $v];
	}
	$Ret['sessions'] = $Sessions;
	return $Ret;
}

if(!empty($_REQUEST['json'])) {
	JsonOut(spLiveData());
}

spHead('Live', ['SpLive' => spLiveData()]);
?>
<div class="sp-toolbar">
	<div class="sp-chips" id="SpOrder">
		<button type="button" class="sp-chip" data-order="rank">ランキング</button>
		<button type="button" class="sp-chip" data-order="target">ターゲット順</button>
	</div>
	<div class="sp-chips" id="SpSes"></div>
	<select id="SpDc" style="flex:1 1 100%" aria-label="部門クラスで絞り込み"></select>
	<label class="sp-search"><?php echo spIcon('search'); ?><input type="search" id="SpSearch" placeholder="名前・所属で検索"></label>
	<div class="sp-live-bar">
		<label class="sp-switch"><input type="checkbox" id="SpAuto"> 自動更新（30秒）</label>
		<span id="SpUpdated"></span>
		<button type="button" class="sp-btn sub" id="SpReload" style="padding:6px 10px"><?php echo spIcon('reload'); ?></button>
	</div>
</div>
<div class="sp-list" id="SpList"></div>
<p class="sp-note">カードをタップするとスコアカードを表示します。
	<a href="<?php echo spRoot('Modules/Custom/LiveScoreboard/LiveScoreboard.php'); ?>">PC向けのライブ得点集計を開く</a></p>

<script>
const SpLv = {
	order: spStore('live_order') || 'rank',
	ses: [],
	dc: spStore('live_dc') || '',
	open: new Set(),
	timer: null,
	count: 30,
};
try { SpLv.ses = JSON.parse(spStore('live_ses') || '[]'); } catch (e) { SpLv.ses = []; }

function spLvChips() {
	document.querySelectorAll('#SpOrder [data-order]').forEach(b => b.classList.toggle('active', b.dataset.order === SpLv.order));
	const valid = SpLive.sessions.map(s => s.id);
	SpLv.ses = SpLv.ses.filter(s => valid.indexOf(s) >= 0);
	let html = '';
	if (SpLive.sessions.length > 1) {
		html = '<button type="button" class="sp-chip' + (SpLv.ses.length ? '' : ' active') + '" data-ses="all">全セッション</button>'
			+ SpLive.sessions.map(s => '<button type="button" class="sp-chip' + (SpLv.ses.indexOf(s.id) >= 0 ? ' active' : '') + '" data-ses="' + s.id + '">' + spEsc(s.name) + '</button>').join('');
	}
	document.getElementById('SpSes').innerHTML = html;
	// 部門クラスの絞り込み（部門クラスのまとまりごと）
	if (SpLv.dc && !SpLive.sections.some(sec => sec.event === SpLv.dc)) SpLv.dc = '';
	document.getElementById('SpDc').innerHTML = '<option value="">すべての部門クラス</option>'
		+ SpLive.sections.map(sec => '<option value="' + spEsc(sec.event) + '"' + (sec.event === SpLv.dc ? ' selected' : '') + '>'
			+ spEsc(sec.event + '（' + sec.descr + '）') + '</option>').join('');
}

function spLvCard(it, dists, showCat) {
	let distHtml = '';
	it.dists.forEach((d, i) => {
		if (d && dists[i]) distHtml += '<span>' + spEsc(dists[i]) + ': ' + spEsc(d.score) + '</span>';
	});
	let detail = '';
	it.cards.forEach((card, i) => {
		if (!card) return;
		const nArr = card.length ? card[0].a.length : 0;
		let run = 0;
		detail += '<table class="sp-sc"><thead><tr><th colspan="' + (nArr + 3) + '">' + spEsc(dists[i] || ((i + 1) + '距離目'))
			+ '　' + spEsc(it.dists[i] ? it.dists[i].score : '') + '</th></tr></thead><tbody>';
		card.forEach((e, k) => {
			run += e.t;
			detail += '<tr><th>' + (k + 1) + '</th>' + e.a.map(a => '<td>' + spEsc(a) + '</td>').join('')
				+ '<td class="tot">' + e.t + '</td><td>' + run + '</td></tr>';
		});
		detail += '</tbody></table>';
	});
	if (!detail) detail = '<div class="sp-sub">スコアカードはまだありません</div>';
	const search = spNorm([it.bib, it.name, it.cc, it.cn, it.tgt].join(' '));
	return '<div class="sp-card tap' + (SpLv.open.has(it.id) ? ' open' : '') + '" data-id="' + it.id + '" data-search="' + spEsc(search) + '">'
		+ '<div class="sp-card-head">'
		+ (SpLv.order === 'rank'
			? '<div class="sp-rank">' + spEsc(it.rank || '') + '</div>'
			: '<span class="sp-badge">' + spEsc(it.ses + '-' + it.tgt) + '</span>')
		+ '<div class="sp-card-main">'
		+ '<div class="sp-name">' + spEsc(it.name) + '</div>'
		+ '<div class="sp-sub">' + spEsc([it.cc, it.cn].filter(x => x).join(' ')) + (showCat ? ' / ' + spEsc(showCat) : '')
		+ (SpLv.order === 'rank' && it.tgt ? ' / ' + spEsc(it.ses + '-' + it.tgt) : '') + '</div>'
		+ '</div>'
		+ (it.noscore
			? '<div class="sp-score"></div>'
			: '<div class="sp-score"><b>' + spEsc(it.score) + '</b>'
				+ '<div class="sp-sub">' + spEsc(SpLive.goldLabel) + ':' + spEsc(it.gold) + ' ' + spEsc(SpLive.xnineLabel) + ':' + spEsc(it.xnine) + '</div></div>')
		+ '</div>'
		+ (!it.noscore && (distHtml || it.irm) ? '<div class="sp-dists">' + (it.irm ? '<span class="sp-tag danger">' + spEsc(it.irm) + '</span>' : '') + distHtml + '<span>' + it.hits + '射</span></div>' : '')
		+ (it.noscore && it.irm ? '<div class="sp-dists"><span class="sp-tag danger">' + spEsc(it.irm) + '</span></div>' : '')
		+ '<div class="sp-detail">' + detail + '</div>'
		+ '</div>';
}

function spLvRender() {
	const list = document.getElementById('SpList');
	const inSes = it => !SpLv.ses.length || SpLv.ses.indexOf(it.ses) >= 0;
	const sections = SpLive.sections.filter(sec => !SpLv.dc || sec.event === SpLv.dc);
	let html = '';
	if (SpLv.order === 'rank') {
		sections.forEach(sec => {
			const items = sec.items.filter(inSes);
			if (!items.length) return;
			html += '<div class="sp-section-title" data-section>' + spEsc(sec.descr) + '</div>';
			html += items.map(it => spLvCard(it, sec.dists, '')).join('');
		});
	} else {
		const all = [];
		sections.forEach(sec => sec.items.filter(inSes).forEach(it => all.push({it: it, sec: sec})));
		const tNum = t => parseInt(t, 10) || 0;
		all.sort((a, b) => (a.it.ses - b.it.ses) || (tNum(a.it.tgt) - tNum(b.it.tgt)) || String(a.it.tgt).localeCompare(String(b.it.tgt)));
		html = all.map(x => spLvCard(x.it, x.sec.dists, x.sec.event)).join('');
	}
	list.innerHTML = html || '<div class="sp-empty">表示する選手がいません</div>';
	spLvFilter();
	document.getElementById('SpUpdated').textContent = SpLive.lastUpdate ? '最終入力 ' + SpLive.lastUpdate : '';
}

function spLvFilter() {
	const list = document.getElementById('SpList');
	spFilterCards(list, document.getElementById('SpSearch').value);
	// 選手が 1 人も見えない部門・クラスの見出しを隠す
	list.querySelectorAll('[data-section]').forEach(h => {
		let n = h.nextElementSibling, any = false;
		while (n && !n.hasAttribute('data-section')) {
			if (!n.classList.contains('sp-hide')) any = true;
			n = n.nextElementSibling;
		}
		h.classList.toggle('sp-hide', !any);
	});
}

async function spLvReload() {
	try {
		SpLive = await spGetJson('Modules/Custom/SmartphoneMode/Live.php', {json: 1});
		spLvChips();
		spLvRender();
	} catch (e) {
		spToast('更新できませんでした: ' + e.message, true);
	}
}

function spLvAuto(on) {
	clearInterval(SpLv.timer);
	SpLv.timer = null;
	if (on) SpLv.timer = setInterval(() => { if (document.visibilityState === 'visible') spLvReload(); }, 30000);
}

document.addEventListener('DOMContentLoaded', () => {
	spLvChips();
	spLvRender();
	document.getElementById('SpDc').addEventListener('change', ev => {
		SpLv.dc = ev.target.value;
		spStore('live_dc', SpLv.dc);
		spLvRender();
	});
	document.getElementById('SpOrder').addEventListener('click', ev => {
		const b = ev.target.closest('[data-order]');
		if (!b) return;
		SpLv.order = b.dataset.order;
		spStore('live_order', SpLv.order);
		spLvChips();
		spLvRender();
	});
	document.getElementById('SpSes').addEventListener('click', ev => {
		const b = ev.target.closest('[data-ses]');
		if (!b) return;
		if (b.dataset.ses === 'all') {
			SpLv.ses = [];
		} else {
			const id = parseInt(b.dataset.ses, 10);
			const i = SpLv.ses.indexOf(id);
			if (i >= 0) SpLv.ses.splice(i, 1); else SpLv.ses.push(id);
		}
		spStore('live_ses', JSON.stringify(SpLv.ses));
		spLvChips();
		spLvRender();
	});
	document.getElementById('SpSearch').addEventListener('input', spLvFilter);
	document.getElementById('SpList').addEventListener('click', ev => {
		const card = ev.target.closest('.sp-card[data-id]');
		if (!card) return;
		const id = parseInt(card.dataset.id, 10);
		card.classList.toggle('open');
		if (card.classList.contains('open')) SpLv.open.add(id); else SpLv.open.delete(id);
	});
	document.getElementById('SpReload').addEventListener('click', spLvReload);
	const auto = document.getElementById('SpAuto');
	auto.checked = spStore('live_auto') === '1';
	spLvAuto(auto.checked);
	auto.addEventListener('change', () => {
		spStore('live_auto', auto.checked ? '1' : '0');
		spLvAuto(auto.checked);
	});
});
</script>
<?php
spTail('Live');
