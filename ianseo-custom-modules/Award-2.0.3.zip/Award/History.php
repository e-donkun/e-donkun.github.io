<?php
/*
賞状の発行履歴。
発行したときのテンプレートの写しと、1 枚ごとの差し込み値を記録してあるので、あとから同じ賞状を印刷し直せる。
- 一覧: 開いている試合の発行（「すべての試合」でほかの試合のものも）
- 詳細: 発行した賞状の一覧。選んで再印刷（発行したときのテンプレートか、今のテンプレートで）、CSV の書き出し
- 削除は、大会のデータを変えられる人（awCanEdit）だけ

変更履歴:
2026/09/30 再印刷の PDF は、いつも同じウィンドウ（target=preview）に開く
2026/09/26 初版
*/
require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php
require_once('Common/Lib/CommonLib.php');
require_once(__DIR__ . '/Lib.php');

CheckTourSession(true);
if(!awCanView()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}
$CanEdit = awCanEdit();
$Tour = awTournament($_SESSION['TourId']);
$Errors = [];
$Msg = $_GET['msg'] ?? '';

if($_SERVER['REQUEST_METHOD'] == 'POST' and ($_POST['act'] ?? '') == 'delete') {
	if(!$CanEdit) {
		$Errors[] = '発行履歴を削除する権限がありません。';
	} elseif(!awCheckToken()) {
		$Errors[] = '画面の有効期限が切れました。もう一度操作してください。';
	} elseif(awDeleteHistory($_POST['id'] ?? '')) {
		CD_redirect('History.php?msg=' . rawurlencode('発行履歴を削除しました。'));
	} else {
		$Errors[] = '発行履歴を削除できませんでした。';
	}
}

$H = isset($_GET['id']) ? awLoadHistory($_GET['id']) : null;

// 再印刷
if($H and isset($_GET['pdf'])) {
	$Pick = isset($_GET['c']) ? array_flip(array_map('intval', (array)$_GET['c'])) : null;
	$Tpl = $H['template'];
	if(($_GET['tplMode'] ?? '') == 'current') {
		$Tpl = awLoadTemplate($H['template']['id'] ?? '') ?: $Tpl;
	}
	$List = [];
	foreach($H['certificates'] as $i => $c) {
		if($Pick === null or isset($Pick[$i])) {
			$List[] = $c['values'];
		}
	}
	if($List) {
		awMakePdf($Tpl, $List, false, $Tpl['name'])->Output('賞状_再印刷_' . $H['id'] . '.pdf', 'I');
		exit;
	}
	$Errors[] = '再印刷する賞状を選んでください。';
}

// 賞状の台帳として CSV で書き出す
if($H and isset($_GET['csv'])) {
	header('Content-Type: text/csv; charset=utf-8');
	header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode('賞状発行履歴_' . $H['id'] . '.csv'));
	$out = fopen('php://output', 'w');
	fwrite($out, "\xEF\xBB\xBF");
	$cols = ['氏名', '所属', '部門', 'クラス', '順位', '得点'];
	fputcsv($out, array_merge(['発行日時', '発行日', '大会', 'テンプレート'], $cols, ['区分']), ',', '"', '');
	foreach($H['certificates'] as $c) {
		$row = [$H['issuedAt'], $H['issueDate'], $H['tournament']['name'] ?? '', $H['template']['name']];
		foreach($cols as $k) {
			$row[] = $c['values'][$k] ?? '';
		}
		$row[] = ($c['source'] ?? '') == 'manual' ? '手入力' : '予選順位';
		fputcsv($out, $row, ',', '"', '');
	}
	fclose($out);
	exit;
}

$PAGE_TITLE = '賞状 - 発行履歴';
$JS_SCRIPT = [
	'<link href="./award.css" rel="stylesheet" type="text/css">',
	'<script>
		// PDF は、いつも同じ名前（preview）のウィンドウに開く。すでに開いていれば、そのウィンドウを前に出す
		function awFocusPreview() {
			var w = window.open("", "preview");
			if(w) { w.focus(); }
		}
		function awCheckAll(cb) {
			document.querySelectorAll("input[name=\'c[]\']").forEach(function(c) { c.checked = cb.checked; });
		}
	</script>',
];
$IncludeFA = true;
require_once('Common/Templates/head.php');

echo awTabs('history');
if($Msg !== '') {
	echo '<div class="AwMsg">' . awH($Msg) . '</div>';
}
foreach($Errors as $e) {
	echo '<div class="AwErr">' . awH($e) . '</div>';
}

if($H) {
	// 詳細
	echo '<p><a class="AwBtn" href="History.php">一覧へ戻る</a></p>';
	echo '<table class="Tabella freeWidth AwTable">';
	echo '<tr><th class="Left">発行日時</th><td>' . awH($H['issuedAt']) . '</td></tr>';
	echo '<tr><th class="Left">発行日</th><td>' . awH(awFormatDate($H['issueDate'], 'western')) . '</td></tr>';
	echo '<tr><th class="Left">大会</th><td>' . awH(($H['tournament']['code'] ?? '') . '　' . ($H['tournament']['name'] ?? '')) . '</td></tr>';
	echo '<tr><th class="Left">テンプレート</th><td>' . awH($H['template']['name']) . '</td></tr>';
	echo '<tr><th class="Left">枚数</th><td>' . count($H['certificates']) . '</td></tr>';
	if(($H['note'] ?? '') !== '') {
		echo '<tr><th class="Left">メモ</th><td>' . awH($H['note']) . '</td></tr>';
	}
	echo '</table>';

	echo '<form method="get" target="preview" onsubmit="awFocusPreview()">';
	echo '<input type="hidden" name="id" value="' . awH($H['id']) . '"><input type="hidden" name="pdf" value="1">';
	echo '<table class="Tabella freeWidth AwTable">';
	echo '<tr><th><input type="checkbox" onclick="awCheckAll(this)" checked></th><th>氏名</th><th>所属</th><th>部門・クラス</th><th>順位</th><th>得点</th><th></th></tr>';
	foreach($H['certificates'] as $i => $c) {
		$v = $c['values'];
		echo '<tr><td><input type="checkbox" name="c[]" value="' . $i . '" checked></td>'
			. '<td>' . awH($v['氏名'] ?? '') . '</td>'
			. '<td>' . awH($v['所属'] ?? '') . '</td>'
			. '<td>' . awH(trim(($v['部門'] ?? '') . ' ' . ($v['クラス'] ?? ''))) . '</td>'
			. '<td class="AwNum">' . awH($v['順位'] ?? '') . '</td>'
			. '<td class="AwNum">' . awH($v['得点'] ?? '') . '</td>'
			. '<td>' . (($c['source'] ?? '') == 'manual' ? '<span class="AwBadge AwBadgeTest">手入力</span>' : '') . '</td></tr>';
	}
	echo '</table>';
	$CurTpl = awLoadTemplate($H['template']['id'] ?? '');
	echo '<p>印刷に使うテンプレート: ';
	echo '<label><input type="radio" name="tplMode" value="snapshot" checked>発行したときのもの</label> ';
	echo '<label><input type="radio" name="tplMode" value="current"' . ($CurTpl ? '' : ' disabled') . '>今のもの' . ($CurTpl ? '' : '（削除されています）') . '</label>';
	echo '</p>';
	echo '<p><button type="submit"><b>選んだ賞状を再印刷</b></button> <span class="AwNote">再印刷は記録しません。</span></p>';
	echo '</form>';
	echo '<p class="AwBtns"><a class="AwBtn" href="History.php?id=' . awH($H['id']) . '&csv=1">CSV で書き出す</a>';
	if($CanEdit) {
		echo ' <form method="post" onsubmit="return confirm(\'この発行履歴を削除しますか？\')">' . awTokenField()
			. '<input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="' . awH($H['id']) . '"><button type="submit" class="AwDanger">この発行履歴を削除</button></form>';
	}
	echo '</p>';
} else {
	// 一覧
	$All = !empty($_GET['all']);
	$List = awListHistory($All ? null : $Tour['code']);
	echo '<p>' . ($All
		? '<a class="AwBtn" href="History.php">この試合の発行だけ</a> すべての試合の発行を表示しています。'
		: '「' . awH($Tour['name']) . '」の発行を表示しています。 <a class="AwBtn" href="History.php?all=1">すべての試合</a>') . '</p>';
	if(!$List) {
		echo '<p>発行履歴はありません。</p>';
	} else {
		echo '<table class="Tabella freeWidth AwTable">';
		echo '<tr><th>発行日時</th>' . ($All ? '<th>大会</th>' : '') . '<th>テンプレート</th><th>枚数</th><th>発行日</th><th>メモ</th><th></th></tr>';
		foreach($List as $h) {
			$certs = $h['certificates'] ?? [];
			$names = array_slice(array_map(function($c) { return $c['values']['氏名'] ?? ''; }, $certs), 0, 3);
			echo '<tr>';
			echo '<td>' . awH($h['issuedAt'] ?? '') . '</td>';
			if($All) {
				echo '<td>' . awH(($h['tournament']['code'] ?? '') . ' ' . ($h['tournament']['name'] ?? '')) . '</td>';
			}
			echo '<td>' . awH($h['template']['name'] ?? '') . '</td>';
			echo '<td class="AwNum" title="' . awH(implode('、', $names) . (count($certs) > 3 ? ' …' : '')) . '">' . count($certs) . '</td>';
			echo '<td>' . awH(awFormatDate($h['issueDate'] ?? '', 'western')) . '</td>';
			echo '<td>' . awH($h['note'] ?? '') . '</td>';
			echo '<td class="AwBtns"><a class="AwBtn" href="History.php?id=' . awH($h['id']) . '">詳細</a>'
				. '<a class="AwBtn" href="History.php?id=' . awH($h['id']) . '&pdf=1" target="preview" onclick="awFocusPreview()">再印刷</a></td>';
			echo '</tr>';
		}
		echo '</table>';
	}
}

include('Common/Templates/tail.php');
