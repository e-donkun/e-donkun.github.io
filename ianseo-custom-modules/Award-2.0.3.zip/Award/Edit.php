<?php
/*
賞状のテンプレートの設定画面。
賞状用紙の画像の上に、テキストボックスと公印などの画像を置いて、位置と大きさをマウスか数値で決める。
- 用紙の画像は、この画面で位置合わせに使うだけで、印刷しない（「PDF で確認」では重ねて出せる）
- テキストには {氏名} のような差し込みの項目を書ける（Lib.php の AW_PLACEHOLDERS）
- 画面のプレビューは award.js で、PDF と同じ計算で文字を並べている

POST
- act=save     テンプレートを保存する（Template に JSON）
- act=upload   画像を受け取って data/images に入れ、名前を JSON で返す（award.js から）
- act=preview  見本の値で PDF を出す（保存はしない）

変更履歴:
2026/09/30 PDF で確認は、いつも同じウィンドウ（target=preview）に開く
2026/09/26 初版
*/
require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php
require_once('Common/Lib/CommonLib.php');
require_once(__DIR__ . '/Lib.php');

CheckTourSession(true);
if(!awCanEdit()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}
awEnsureDirs();

$Id = $_REQUEST['id'] ?? '';
$Tpl = awLoadTemplate($Id);
if(!$Tpl) {
	CD_redirect('index.php?msg=' . rawurlencode('テンプレートが見つかりません。'));
}
$Errors = [];
$Msg = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	$Act = $_POST['act'] ?? '';
	if(!awCheckToken()) {
		if($Act == 'upload') {
			header('Content-Type: application/json');
			die(awJson(['error' => '画面の有効期限が切れました。画面を読み込み直してください。']));
		}
		$Errors[] = '画面の有効期限が切れました。もう一度保存してください。';
	} elseif($Act == 'upload') {
		header('Content-Type: application/json');
		$r = awStoreUploadedImage($_FILES['file'] ?? null);
		die(awJson(is_array($r) ? $r : ['error' => $r]));
	} elseif($Act == 'preview') {
		$t = awNormalizeTemplate(json_decode($_POST['Template'] ?? '', true));
		$Samples = awSampleList($t);
		$v = $Samples[intval($_POST['sample'] ?? 0)]['values'] ?? $Samples[0]['values'];
		$pdf = awMakePdf($t, [$v], !empty($_POST['withPaper']), $t['name']);
		$pdf->Output('preview.pdf', 'I');
		exit;
	} elseif($Act == 'save') {
		$New = json_decode($_POST['Template'] ?? '', true);
		if(!is_array($New)) {
			$Errors[] = '保存する内容を受け取れませんでした。';
		} else {
			$New['id'] = $Id;
			$New['createdAt'] = $Tpl['createdAt'];
			$Saved = awSaveTemplate($New);
			if($Saved) {
				awGcImages();
				CD_redirect('Edit.php?id=' . rawurlencode($Id) . '&saved=1');
			}
			$Errors[] = 'テンプレートを保存できませんでした。';
			$Tpl = awNormalizeTemplate($New);
		}
	}
}
if(!empty($_GET['saved'])) {
	$Msg = '保存しました。';
}

// 見本の差し込み値（見本の人と、開いている試合の上位の選手）
// $t['source']（予選・個人戦・団体戦）にあわせて、開いている試合の上位 3 位までを入れる
function awSampleList($t) {
	$Tour = awTournament($_SESSION['TourId'] ?? 0);
	$ret = [['label' => '見本（' . ($t['source'] == 'team' ? '京都チーム' : '京都 太郎') . '）', 'values' => awSampleValues($t, $Tour)]];
	if($Tour) {
		$common = awCommonValues($Tour, date('Y-m-d'));
		$rows = $t['source'] == 'qual' ? awQualificationRanking($Tour['id']) : awEventRanking($Tour['id'], $t['source'] == 'team');
		foreach($rows as $r) {
			if(intval($r['Ranking']) > 3) {
				continue;
			}
			$v = $common + awEntryValues($r, $t);
			$ret[] = ['label' => ($t['source'] == 'qual' ? $r['Class'] : $r['EventName']) . ' ' . $r['Ranking'] . '位 ' . $v['氏名'] . '（' . $v['所属'] . '）', 'values' => $v];
			if(count($ret) > 60) {
				break;
			}
		}
	}
	return $ret;
}

// 順位のもとごとの見本（設定画面で順位のもとを変えたときに切り替える）
$Samples = [];
foreach(AW_SOURCES as $k => $label) {
	$Samples[$k] = awSampleList(['source' => $k] + $Tpl);
}
$Fonts = awFonts();

$Config = [
	'template' => $Tpl,
	'fonts' => $Fonts,
	'fontAsc' => array_map('awFontAscent', $Fonts),
	'papers' => AW_PAPER_SIZES,
	'samples' => $Samples,
	'sources' => AW_SOURCES,
	'placeholders' => AW_PLACEHOLDERS,
	'rotate' => AW_TATE_ROTATE,
	'punct' => AW_TATE_PUNCT,
	'small' => AW_TATE_SMALL,
	'kinsokuStart' => AW_KINSOKU_START,
	'kinsokuEnd' => AW_KINSOKU_END,
	'token' => awToken(),
];

$FontFaces = '';
foreach($Fonts as $i => $f) {
	$FontFaces .= '@font-face { font-family: "AwF' . $i . '"; src: url("fonts/' . rawurlencode($f) . '") format("truetype"); font-display: block; }' . "\n";
}

$PAGE_TITLE = '賞状 - ' . $Tpl['name'];
$JS_SCRIPT = [
	'<link href="./award.css" rel="stylesheet" type="text/css">',
	// ianseo の #Content は高さが決まっていて中でスクロールするので、この画面では高さだけ外す（3 つの欄を画面の高さに合わせるのは award.js）。overflow は残す（メニューは float なので、残さないと #Content がメニューに重なる）
	'<style>' . $FontFaces . '#Content { height: auto; padding-bottom: 0; }</style>',
	'<script>var AwConfig = ' . awJson($Config) . ';</script>',
	'<script src="./award.js"></script>',
];
$IncludeFA = true;
require_once('Common/Templates/head.php');

echo awTabs('edit', $Id);
foreach($Errors as $e) {
	echo '<div class="AwErr">' . awH($e) . '</div>';
}

// 保存と PDF の確認に使うフォーム（中身は award.js が入れる）
echo '<form id="AwSaveForm" method="post" action="Edit.php?id=' . awH(rawurlencode($Id)) . '">' . awTokenField()
	. '<input type="hidden" name="act" value="save"><input type="hidden" name="Template" value=""></form>';
echo '<form id="AwPreviewForm" method="post" action="Edit.php?id=' . awH(rawurlencode($Id)) . '" target="preview">' . awTokenField()
	. '<input type="hidden" name="act" value="preview"><input type="hidden" name="Template" value="">'
	. '<input type="hidden" name="sample" value="0"><input type="hidden" name="withPaper" value=""></form>';

?>
<div class="AwEditor">
	<div class="AwPaneL" id="AwPaneL">
<?php
if($Msg !== '') {
	// 左の欄の上に出し、10 秒たったら消す
	echo '<div class="AwMsg" id="AwMsg">' . awH($Msg) . '</div>';
	echo '<script>setTimeout(function() { var m = document.getElementById("AwMsg"); if(m) { m.style.display = "none"; } }, 10000);</script>';
}
?>
		<div class="AwToolbar">
			<button type="button" onclick="awSave()"><b>保存</b></button>
			<button type="button" onclick="awPreviewPdf(false)">PDF で確認</button>
			<button type="button" onclick="awPreviewPdf(true)">PDF で確認（用紙の画像を重ねる）</button>
		</div>
		<fieldset>
			<legend>テンプレートの設定</legend>
			<div class="AwRow"><span class="AwKey">名前</span><input type="text" class="AwWide" data-tpl="name" maxlength="100"></div>
			<div class="AwRow"><span class="AwKey">メモ</span><textarea rows="2" data-tpl="note"></textarea></div>
			<div class="AwRow"><span class="AwKey">書き方</span>
				<label><input type="radio" name="AwDir" value="vertical" data-tpl="direction">縦書き</label>
				<label><input type="radio" name="AwDir" value="horizontal" data-tpl="direction">横書き</label>
			</div>
			<div class="AwRow"><span class="AwKey">順位</span><select data-tpl="source" id="AwSource"></select></div>
			<div class="AwRow"><span class="AwKey">用紙</span>
				<select data-tpl="paper.size" id="AwPaperSize"></select>
				<label><input type="radio" name="AwOrient" value="P" data-tpl="paper.orientation">縦長</label>
				<label><input type="radio" name="AwOrient" value="L" data-tpl="paper.orientation">横長</label>
			</div>
			<div class="AwRow" id="AwCustomSize"><span class="AwKey"></span>
				幅 <input type="number" step="1" min="20" data-tpl="paper.width"> × 高さ <input type="number" step="1" min="20" data-tpl="paper.height"> mm
			</div>
			<div class="AwRow"><span class="AwKey">用紙の画像</span>
				<input type="file" accept="image/png,image/jpeg" onchange="awUploadPaper(this)">
				<button type="button" onclick="awRemovePaper()">外す</button>
				<div class="AwNote">賞状用紙をスキャンした画像（PNG か JPEG）。位置合わせのために画面に出すだけで、印刷はしません。用紙全体が写るように切り抜いてください。</div>
			</div>
			<div class="AwRow"><span class="AwKey">印刷位置の補正</span>
				右へ <input type="number" step="0.1" data-tpl="paper.offsetX"> mm　下へ <input type="number" step="0.1" data-tpl="paper.offsetY"> mm
				<div class="AwNote">プリンターで印刷した位置がずれるときに使います（マイナスは左・上）。</div>
			</div>
			<div class="AwRow"><span class="AwKey">フォント</span><select data-tpl="font" id="AwFont"></select></div>
			<div class="AwRow"><span class="AwKey">表彰数の決め方</span><textarea rows="3" data-tpl="awardRule" placeholder="3=1&#10;8=3&#10;*=8"></textarea>
				<div class="AwNote">発行の画面で、種目ごとの参加数から表彰する順位を出して、初めから選んでおきます。「参加数=表彰数」（参加数がその数以下のとき）を 1 行に 1 つ、最後に「*=表彰数」。</div>
			</div>
			<div class="AwRow"><span class="AwKey">順位の表記</span><textarea rows="3" data-tpl="rankNames" placeholder="1=優勝&#10;2=準優勝"></textarea>
				<div class="AwNote">{順位表記} に入る言葉。「順位=表記」を 1 行に 1 つ。書いていない順位は「第三位」のようになります。</div>
			</div>
		</fieldset>
	</div>

	<div class="AwPaneC">
		<div class="AwToolbar">
			<label>見本: <select id="AwSample" onchange="awRender()"></select></label>
			<label><input type="checkbox" id="AwShowPaper" checked onchange="awRender()">用紙の画像</label>
			<label><input type="checkbox" id="AwShowFrames" checked onchange="awRender()">枠</label>
			<label>表示の倍率 <select id="AwZoom" onchange="awRender()"><option value="0">画面に合わせる</option><option value="2">2px/mm</option><option value="3">3px/mm</option><option value="4">4px/mm</option><option value="6">6px/mm</option></select></label>
		</div>
		<div class="AwStageWrap" id="AwStageWrap">
			<div class="AwStage" id="AwStage"><img class="AwPaperImg" id="AwPaperImg" alt=""></div>
		</div>
	</div>

	<div class="AwSide" id="AwSide">
		<fieldset>
			<legend>項目</legend>
			<ul class="AwItems" id="AwItems"></ul>
			<div class="AwRow">
				<button type="button" onclick="awAddText()">テキストを追加</button>
				<button type="button" onclick="awAddImage()">公印・画像を追加</button>
			</div>
			<div class="AwRow">
				<button type="button" onclick="awMoveItem(-1)" title="下に描く">↑ 前へ</button>
				<button type="button" onclick="awMoveItem(1)" title="上に重ねて描く">↓ 後へ</button>
				<button type="button" onclick="awCopyItem()">複製</button>
				<button type="button" class="AwDanger" onclick="awDeleteItem()">削除</button>
			</div>
		</fieldset>

		<fieldset id="AwItemProps">
			<legend>プロパティ</legend>
			<div id="AwSingleProps">
			<div class="AwRow"><span class="AwKey">名前</span><input type="text" class="AwWide" data-it="label" maxlength="50"></div>
			<div class="AwRow"><span class="AwKey">位置</span>
				左 <input type="number" step="0.1" data-it="x"> 上 <input type="number" step="0.1" data-it="y"> mm</div>
			<div class="AwRow"><span class="AwKey">大きさ</span>
				幅 <input type="number" step="0.1" min="1" data-it="w"> 高さ <input type="number" step="0.1" min="1" data-it="h"> mm</div>

			<div class="AwForText">
				<div class="AwRow"><span class="AwKey">文字</span><textarea rows="4" data-it="text"></textarea>
					<div id="AwPhList"></div>
				</div>
				<div class="AwRow"><span class="AwKey">文字の大きさ</span><input type="number" step="0.5" min="2" data-it="size"> pt
					<span id="AwStretchBox"><span class="AwKey" style="width:auto;margin-left:0.6em">文字の幅</span><input type="number" step="1" min="10" max="500" data-it="stretch"> %</span></div>
				<div class="AwRow"><span class="AwKey">書き方</span>
					<select data-it="dir"><option value="">テンプレートと同じ</option><option value="vertical">縦書き</option><option value="horizontal">横書き</option></select></div>
				<div class="AwRow"><span class="AwKey">行の中の位置</span><select data-it="align" id="AwAlign"></select></div>
				<div class="AwRow"><span class="AwKey">行の位置</span><select data-it="cross" id="AwCross"></select></div>
				<div class="AwRow"><span class="AwKey">行の間隔</span><input type="number" step="0.1" min="0.5" data-it="lineHeight"> 文字分
					<span class="AwKey" style="width:auto">字間</span><input type="number" step="0.05" min="-0.5" data-it="spacing"> 文字分</div>
				<div class="AwRow">
					<label><input type="checkbox" data-it="wrap">枠の端で折り返す</label>
					<label><input type="checkbox" data-it="fit">入りきらないときは縮める</label>
					<span id="AwSqueezeBox"><label title="枠の幅に入りきらない行は、文字の高さはそのままで横に縮める"><input type="checkbox" data-it="squeeze">横に縮めて収める（長体）</label></span>
					<label><input type="checkbox" data-it="zenkaku">半角を全角にする</label>
					<label><input type="checkbox" data-it="skipEmpty">差し込みの値が空なら出さない</label>
					<label title="2026 → 二〇二六、10 → 一〇"><input type="checkbox" data-kanji="digit">漢数字にする（一〇方式）</label>
					<label title="10 → 十、648 → 六百四十八（4 桁以上は 2026 → 二〇二六）"><input type="checkbox" data-kanji="unit">漢数字にする（十方式）</label>
				</div>
				<div class="AwRow"><span class="AwKey">フォント</span><select data-it="font" id="AwItemFont"></select></div>
				<div class="AwRow"><span class="AwKey">色</span><input type="color" data-it="color"></div>
			</div>

			<div class="AwForImage">
				<div class="AwRow"><span class="AwKey">画像</span>
					<input type="file" accept="image/png,image/jpeg" id="AwItemFile" onchange="awUploadItemImage(this)">
					<div class="AwNote">背景を透明にした PNG がきれいに重なります。</div></div>
				<div class="AwRow"><label><input type="checkbox" data-it="multiply">白い部分を透かす（乗算で重ねる）</label></div>
				<div class="AwRow"><button type="button" onclick="awImageRatio()">画像の縦横比に合わせる</button></div>
			</div>
			</div>
			<div id="AwMultiProps" style="display:none">
				<div class="AwMultiTitle">配置 <span class="AwNote" id="AwMultiCount"></span></div>
				<div class="AwIconRow">
					<button type="button" class="AwIconBtn" data-align="left" title="左揃え" aria-label="左揃え"><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M2 1v14" fill="none"/><rect x="4" y="3" width="10" height="3.5" stroke="none"/><rect x="4" y="9.5" width="6" height="3.5" stroke="none"/></svg></button>
					<button type="button" class="AwIconBtn" data-align="hcenter" title="左右中央揃え" aria-label="左右中央揃え"><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M8 1v14" fill="none"/><rect x="3" y="3" width="10" height="3.5" stroke="none"/><rect x="5" y="9.5" width="6" height="3.5" stroke="none"/></svg></button>
					<button type="button" class="AwIconBtn" data-align="right" title="右揃え" aria-label="右揃え"><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M14 1v14" fill="none"/><rect x="2" y="3" width="10" height="3.5" stroke="none"/><rect x="6" y="9.5" width="6" height="3.5" stroke="none"/></svg></button>
					<span class="AwIconGap"></span>
					<button type="button" class="AwIconBtn" data-align="top" title="上揃え" aria-label="上揃え"><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M1 2h14" fill="none"/><rect x="3" y="4" width="3.5" height="10" stroke="none"/><rect x="9.5" y="4" width="3.5" height="6" stroke="none"/></svg></button>
					<button type="button" class="AwIconBtn" data-align="vcenter" title="上下中央揃え" aria-label="上下中央揃え"><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M1 8h14" fill="none"/><rect x="3" y="3" width="3.5" height="10" stroke="none"/><rect x="9.5" y="5" width="3.5" height="6" stroke="none"/></svg></button>
					<button type="button" class="AwIconBtn" data-align="bottom" title="下揃え" aria-label="下揃え"><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M1 14h14" fill="none"/><rect x="3" y="2" width="3.5" height="10" stroke="none"/><rect x="9.5" y="6" width="3.5" height="6" stroke="none"/></svg></button>
				</div>
				<div class="AwMultiTitle">均等配置</div>
				<div class="AwIconRow">
					<button type="button" class="AwWideBtn" data-dist="h" title="左右の間隔をそろえる">水平</button>
					<button type="button" class="AwWideBtn" data-dist="v" title="上下の間隔をそろえる">垂直</button>
				</div>
			</div>
		</fieldset>

	</div>
</div>
<?php

include('Common/Templates/tail.php');
