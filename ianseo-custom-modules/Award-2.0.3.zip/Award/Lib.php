<?php
/*
賞状モジュールで共通に使う関数。

保存するもの（すべて data/ の下。data/.htaccess で直接は開けないようにしている）
- data/templates/<id>.json  テンプレート（用紙・縦書きか横書きか・テキストボックス・公印などの画像）
- data/history/<id>.json    発行履歴（発行した賞状ごとの差し込み値と、発行したときのテンプレートの写し）
- data/images/<ハッシュ>.png|jpg  用紙の画像・公印の画像（Image.php で表示する）

テンプレートの形（awNormalizeTemplate で整える）
{
	"id": "t20260926153000a1b2", "name": "…", "note": "…",
	"direction": "vertical" | "horizontal",        // 縦書きか横書きか（テキストボックスごとに変えることもできる）
	"source": "qual" | "ind" | "team",             // 発行の画面に出す順位（予選 / 個人戦 / 団体戦）。AW_SOURCES
	"font": "YujiSyuku-Regular.ttf",               // fonts/ の TrueType フォント
	"paper": { "size": "A4", "orientation": "L", "width": 297, "height": 210,
	           "image": "…png",                     // 賞状用紙の画像。設定画面で表示するだけで、印刷はしない
	           "offsetX": 0, "offsetY": 0 },        // 印刷位置の補正（mm）
	"rankNames": "1=優勝\n2=準優勝",              // {順位表記} に使う
	"items": [                                     // 並び順に描く（後のものが上に重なる）
		{ "type": "text", "label": "氏名", "text": "{氏名}", "x": 0, "y": 0, "w": 10, "h": 100,
		  "size": 30, "dir": "", "align": "start|center|end|justify", "cross": "start|center|end",
		  "lineHeight": 1.5, "spacing": 0, "fit": true, "zenkaku": true, "skipEmpty": true, "wrap": false, "squeeze": false, "stretch": 100, "kanji": "", "font": "", "color": "#000000" },
		{ "type": "image", "label": "公印", "image": "…png", "x": 0, "y": 0, "w": 25, "h": 25, "multiply": true }
	]
}
位置と大きさは用紙の左上からの mm、文字の大きさは pt。

テキストの並べ方（awLayout）は、設定画面のプレビュー（award.js の awLayout）と同じ計算にしてある。変えるときは両方を直すこと。

変更履歴:
2026/09/30 テキストボックスに「文字の幅（%）」を追加（横書きのとき。setFontStretching）。差し込みの項目 {開催地} をやめた
2026/09/30 発行するときの順位（予選・個人戦・団体戦）を、発行の画面ではなくテンプレートの設定（source）にした
2026/09/30 発行の画面でも「賞状発行」のタブを黄色にした
2026/09/30 「テンプレート編集」「賞状発行」のタブに Font Awesome のアイコン（fa-pen-to-square / fa-print）を付けた
2026/09/30 「賞状発行」のタブを太字・黄色の背景にした
2026/09/30 賞状発行とテンプレート編集の画面のタブを「戻る」「テンプレート編集」「賞状発行」にした
2026/09/30 見本のテンプレート（samples/）から追加する機能をやめ、data/templates に置いた。タブは「テンプレート選択」「発行履歴」の 2 つ
2026/09/29 個人戦・団体戦の決勝の最終順位（awEventRanking）、差し込みの項目 {種目}、表彰数の決め方（awardRule）を追加
2026/09/29 テキストボックスに「横に縮めて収める（長体）」を追加
2026/09/27 文字をフォントの文字の枠（OS/2 の typo の値）で置くようにした（縦書きの長音や括弧が左にずれていた）
2026/09/27 以前のテンプレートの差し込みの項目を置き換える機能（tagVersion）を外した
2026/09/27 {開催年和暦} を {開催年号}（令和）と {開催年和暦}（8）に分けた
2026/09/27 差し込みの項目 {開催年月日和暦} {開催年和暦} を追加
2026/09/27 漢数字の十方式でも、4 桁以上の数字は一〇方式にする
2026/09/27 漢数字の差し込みの項目をやめ、テキストボックスの「漢数字にする（一〇方式／十方式）」にまとめた。日付の項目を 開催年月日・開催年・開催月・開催日・発行年月日・発行年月日和暦 にした
2026/09/27 賞状の番号（{番号}・次の番号）をなくした
2026/09/26 mb_ の関数にすべて UTF-8 を渡すようにした（サーバーの mbstring の内部エンコーディングが EUC-JP などだと、縦書きで普通の漢字を回したり右上にずらしたりしていた）
2026/09/26 初版（index.php の賞状出力を、テンプレートと発行履歴を持てる形に作り直した）
*/

const AW_DATA_DIR = __DIR__ . '/data';
const AW_FONT_DIR = __DIR__ . '/fonts';
const AW_DEFAULT_FONT = 'YujiSyuku-Regular.ttf';

// 発行するときの順位のもと（テンプレートの source）。予選は部門・クラスごと、個人戦・団体戦は決勝の最終順位
const AW_SOURCES = [
	'qual' => '予選の順位（部門・クラス）',
	'ind' => '個人戦（決勝の最終順位）',
	'team' => '団体戦（決勝の最終順位）',
];
const AW_IMAGE_MAX_BYTES = 10 * 1024 * 1024;

// 用紙の大きさ（縦向きの幅・高さ mm）
const AW_PAPER_SIZES = [
	'A3' => [297, 420],
	'A4' => [210, 297],
	'A5' => [148, 210],
	'B4' => [257, 364],
	'B5' => [182, 257],
];

// 差し込みの項目（名前 => 説明）。{名前} の形でテキストに書く
const AW_PLACEHOLDERS = [
	'氏名' => '姓と名（間に空白）',
	'姓' => '',
	'名' => '',
	'所属' => '所属の名前',
	'所属コード' => '',
	'種目' => '個人戦・団体戦の種目の名前（予選の順位のときは「部門 クラス」）',
	'部門' => '部門の名前',
	'クラス' => 'クラスの名前',
	'部門コード' => '',
	'クラスコード' => '',
	'順位' => '例: 3',
	'順位表記' => 'テンプレートの「順位の表記」。なければ「第三位」',
	'得点' => '例: 648',
	'ゴールド数' => '10 点の数など',
	'X数' => 'X の数など',
	'大会名' => '',
	'開催年月日' => '例: 2026年7月29日',
	'開催年月日和暦' => '例: 令和8年7月29日',
	'開催年' => '例: 2026',
	'開催年号' => '例: 令和',
	'開催年和暦' => '例: 8（元年は 元。「{開催年号}{開催年和暦}年」のように書く）',
	'開催月' => '例: 7',
	'開催日' => '例: 29',
	'発行年月日' => '発行のときに選んだ日。例: 2026年9月26日',
	'発行年月日和暦' => '例: 令和8年9月26日',
];

// 縦書きで 90 度回す文字
const AW_TATE_ROTATE = 'ー－―‐‑–—〜～…‥（）()［］[]｛｝{}「」『』【】〔〕〈〉《》＜＞<>＝=→←：:；;｜|';
// 折り返したとき、行頭に置かない文字と、行末に置かない文字
const AW_KINSOKU_START = '、。，．）」』】〕〉》！？!?・：；ーっゃゅょぁぃぅぇぉッャュョァィゥェォ';
const AW_KINSOKU_END = '（「『【〔〈《';
// 縦書きで右上に寄せる句読点
const AW_TATE_PUNCT = '、。，．';
// 縦書きで少し右上に寄せる小さい仮名
const AW_TATE_SMALL = 'ぁぃぅぇぉっゃゅょゎゕゖァィゥェォッャュョヮヵヶㇰㇱㇲㇳㇴㇵㇶㇷㇸㇹㇺㇻㇼㇽㇾㇿ';

/* ---------------------------------------------------------------- 権限 */

// 賞状を発行する、テンプレートと発行履歴を見る権限（予選の印刷ができる人）
function awCanView() {
	return CheckTourSession() and (hasFullACL(AclQualification, '', AclReadOnly) or awCanEdit());
}

// テンプレートを作る・変える、履歴を消す権限（大会のデータを変えられる人）
function awCanEdit() {
	return CheckTourSession() and hasFullACL(AclCompetition, 'cData', AclReadWrite);
}

/* ---------------------------------------------------------------- 保存 */

function awEnsureDirs() {
	foreach(['', '/templates', '/history', '/images'] as $d) {
		if(!is_dir(AW_DATA_DIR . $d)) {
			@mkdir(AW_DATA_DIR . $d, 0775, true);
		}
	}
	// 公印の画像などを直接開けないようにする（Image.php を通して見る）
	if(!is_file(AW_DATA_DIR . '/.htaccess')) {
		@file_put_contents(AW_DATA_DIR . '/.htaccess', "<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tOrder allow,deny\n\tDeny from all\n</IfModule>\n");
	}
	if(!is_file(AW_DATA_DIR . '/index.html')) {
		@file_put_contents(AW_DATA_DIR . '/index.html', '');
	}
	return is_writable(AW_DATA_DIR . '/templates') and is_writable(AW_DATA_DIR . '/history') and is_writable(AW_DATA_DIR . '/images');
}

function awValidId($id) {
	return is_string($id) and preg_match('/^[A-Za-z0-9_-]{1,64}$/', $id);
}

function awNewId($prefix) {
	return $prefix . date('YmdHis') . bin2hex(random_bytes(3));
}

function awReadJson($file) {
	if(!is_file($file)) {
		return null;
	}
	$j = json_decode(file_get_contents($file), true);
	return is_array($j) ? $j : null;
}

// 途中で壊れたファイルができないように、一時ファイルに書いてから置き換える
function awWriteJson($file, $data) {
	$tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
	$json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	if($json === false or file_put_contents($tmp, $json . "\n") === false) {
		@unlink($tmp);
		return false;
	}
	if(!rename($tmp, $file)) {
		@unlink($tmp);
		return false;
	}
	return true;
}

/* ---------------------------------------------------------------- テンプレート */

function awListTemplates() {
	$ret = [];
	foreach(glob(AW_DATA_DIR . '/templates/*.json') ?: [] as $f) {
		if($t = awReadJson($f)) {
			$t = awNormalizeTemplate($t);
			$t['id'] = basename($f, '.json');
			$ret[$t['id']] = $t;
		}
	}
	uasort($ret, function($a, $b) {
		return strcmp($a['name'], $b['name']) ?: strcmp($a['id'], $b['id']);
	});
	return $ret;
}

function awLoadTemplate($id) {
	if(!awValidId($id) or !($t = awReadJson(AW_DATA_DIR . '/templates/' . $id . '.json'))) {
		return null;
	}
	$t = awNormalizeTemplate($t);
	$t['id'] = $id;
	return $t;
}

function awSaveTemplate($t) {
	awEnsureDirs();
	$t = awNormalizeTemplate($t);
	if(!awValidId($t['id'])) {
		$t['id'] = awNewId('t');
	}
	$t['updatedAt'] = date('Y-m-d H:i:s');
	if(empty($t['createdAt'])) {
		$t['createdAt'] = $t['updatedAt'];
	}
	return awWriteJson(AW_DATA_DIR . '/templates/' . $t['id'] . '.json', $t) ? $t : false;
}

function awDeleteTemplate($id) {
	if(!awValidId($id)) {
		return false;
	}
	$ok = @unlink(AW_DATA_DIR . '/templates/' . $id . '.json');
	awGcImages();
	return $ok;
}

// 書き出した JSON（index.php の「書き出し」）を読み込んで、新しいテンプレートにする。戻り値はテンプレートか、エラーの文字列
function awImportTemplate($json) {
	$j = json_decode((string)$json, true);
	if(!is_array($j) or ($j['format'] ?? '') !== 'ianseo-award-template' or !is_array($j['template'] ?? null)) {
		return '賞状テンプレートのファイルではありません。';
	}
	$names = [];
	foreach((is_array($j['images'] ?? null) ? $j['images'] : []) as $old => $b64) {
		$bin = base64_decode((string)$b64, true);
		$info = $bin ? @getimagesizefromstring($bin) : false;
		if(!$info or !in_array($info[2], [IMAGETYPE_PNG, IMAGETYPE_JPEG]) or strlen($bin) > AW_IMAGE_MAX_BYTES) {
			continue;
		}
		$name = substr(sha1($bin), 0, 24) . ($info[2] == IMAGETYPE_PNG ? '.png' : '.jpg');
		if(is_file(AW_DATA_DIR . '/images/' . $name) or file_put_contents(AW_DATA_DIR . '/images/' . $name, $bin) !== false) {
			$names[$old] = $name;
		}
	}
	$t = $j['template'];
	$t['id'] = '';
	$t['createdAt'] = '';
	if(isset($t['paper']['image'])) {
		$t['paper']['image'] = $names[$t['paper']['image']] ?? '';
	}
	foreach((is_array($t['items'] ?? null) ? $t['items'] : []) as $k => $it) {
		if(is_array($it) and isset($it['image'])) {
			$t['items'][$k]['image'] = $names[$it['image']] ?? '';
		}
	}
	return awSaveTemplate($t) ?: 'テンプレートを保存できませんでした。';
}

// 書き出す形（画像も中に入れた JSON）
function awExportTemplate($t) {
	$images = [];
	foreach(awTemplateImages($t) as $i) {
		if(is_file(awImagePath($i))) {
			$images[$i] = base64_encode(file_get_contents(awImagePath($i)));
		}
	}
	$t['id'] = '';
	return ['format' => 'ianseo-award-template', 'version' => 1, 'template' => $t, 'images' => $images];
}

function awNewTemplate() {
	return awNormalizeTemplate([
		'name' => '新しいテンプレート',
		'direction' => 'vertical',
		'paper' => ['size' => 'A4', 'orientation' => 'L'],
		'items' => [
			['type' => 'text', 'label' => '表題', 'text' => '賞状', 'x' => 240, 'y' => 40, 'w' => 17, 'h' => 70, 'size' => 48, 'align' => 'justify'],
			['type' => 'text', 'label' => '種目', 'text' => '{部門}部門　{クラス}', 'x' => 222, 'y' => 40, 'w' => 6, 'h' => 80, 'size' => 16],
			['type' => 'text', 'label' => '順位', 'text' => '{順位表記}', 'x' => 206, 'y' => 50, 'w' => 11, 'h' => 60, 'size' => 30],
			['type' => 'text', 'label' => '氏名', 'text' => '{氏名}　殿', 'x' => 188, 'y' => 70, 'w' => 11, 'h' => 100, 'size' => 30, 'align' => 'end'],
			['type' => 'text', 'label' => '本文', 'text' => "あなたは{大会名}において\n頭書の成績を収められましたので\nこれを賞します", 'x' => 120, 'y' => 40, 'w' => 50, 'h' => 130, 'size' => 22, 'lineHeight' => 2],
			['type' => 'text', 'label' => '日付', 'text' => '{発行年月日和暦}', 'kanji' => 'unit', 'x' => 95, 'y' => 45, 'w' => 8, 'h' => 100, 'size' => 20],
			['type' => 'text', 'label' => '発行者', 'text' => "〇〇〇〇連盟\n会長　〇〇　〇〇", 'x' => 60, 'y' => 60, 'w' => 25, 'h' => 110, 'size' => 24, 'lineHeight' => 1.8, 'align' => 'end'],
		],
	]);
}

// 画面や JSON から来たテンプレートを、決まった形・範囲の値にそろえる
function awNormalizeTemplate($in) {
	$in = is_array($in) ? $in : [];
	$p = (isset($in['paper']) and is_array($in['paper'])) ? $in['paper'] : [];

	$t = [
		'id' => (isset($in['id']) and awValidId($in['id'])) ? $in['id'] : '',
		'name' => awStr($in['name'] ?? '', 100) ?: '（名前なし）',
		'note' => awStr($in['note'] ?? '', 1000, true),
		'direction' => (($in['direction'] ?? '') == 'horizontal') ? 'horizontal' : 'vertical',
		'source' => isset(AW_SOURCES[$in['source'] ?? '']) ? $in['source'] : 'qual',
		'font' => awValidFont($in['font'] ?? '') ?: AW_DEFAULT_FONT,
		'paper' => [],
		'rankNames' => awStr($in['rankNames'] ?? '', 2000, true),
		'awardRule' => awStr($in['awardRule'] ?? '', 500, true),
		'items' => [],
		'createdAt' => awStr($in['createdAt'] ?? '', 20),
		'updatedAt' => awStr($in['updatedAt'] ?? '', 20),
	];

	$size = strtoupper(awStr($p['size'] ?? 'A4', 10));
	$orient = (($p['orientation'] ?? 'L') == 'P') ? 'P' : 'L';
	if(isset(AW_PAPER_SIZES[$size])) {
		[$w, $h] = AW_PAPER_SIZES[$size];
	} else {
		$size = 'custom';
		$w = awNum($p['width'] ?? 210, 20, 2000);
		$h = awNum($p['height'] ?? 297, 20, 2000);
		[$w, $h] = [min($w, $h), max($w, $h)];
	}
	if($orient == 'L') {
		[$w, $h] = [$h, $w];
	}
	$t['paper'] = [
		'size' => $size,
		'orientation' => $orient,
		'width' => $w,
		'height' => $h,
		'image' => awValidImageName($p['image'] ?? '') ?: '',
		'offsetX' => awNum($p['offsetX'] ?? 0, -50, 50),
		'offsetY' => awNum($p['offsetY'] ?? 0, -50, 50),
	];

	foreach(array_slice((isset($in['items']) and is_array($in['items'])) ? $in['items'] : [], 0, 100) as $it) {
		if(!is_array($it)) {
			continue;
		}
		$base = [
			'label' => awStr($it['label'] ?? '', 50),
			'x' => awNum($it['x'] ?? 10, -1000, 3000),
			'y' => awNum($it['y'] ?? 10, -1000, 3000),
			'w' => awNum($it['w'] ?? 20, 1, 3000),
			'h' => awNum($it['h'] ?? 20, 1, 3000),
		];
		if(($it['type'] ?? 'text') == 'image') {
			$t['items'][] = ['type' => 'image'] + $base + [
				'image' => awValidImageName($it['image'] ?? '') ?: '',
				'multiply' => !empty($it['multiply']),
			];
		} else {
			$color = strtolower(awStr($it['color'] ?? '', 7));
			$text = awStr($it['text'] ?? '', 2000, true);
			$kanji = in_array($it['kanji'] ?? '', ['digit', 'unit'], true) ? $it['kanji'] : '';
			$t['items'][] = ['type' => 'text'] + $base + [
				'text' => $text,
				'size' => awNum($it['size'] ?? 20, 2, 300),
				'dir' => in_array($it['dir'] ?? '', ['vertical', 'horizontal']) ? $it['dir'] : '',
				'align' => in_array($it['align'] ?? '', ['start', 'center', 'end', 'justify']) ? $it['align'] : 'start',
				'cross' => in_array($it['cross'] ?? '', ['start', 'center', 'end']) ? $it['cross'] : 'start',
				'lineHeight' => awNum($it['lineHeight'] ?? 1.5, 0.5, 10),
				'spacing' => awNum($it['spacing'] ?? 0, -0.5, 5),
				'fit' => !isset($it['fit']) || !empty($it['fit']),
				'zenkaku' => !isset($it['zenkaku']) || !empty($it['zenkaku']),
				'skipEmpty' => !isset($it['skipEmpty']) || !empty($it['skipEmpty']),
				'wrap' => !empty($it['wrap']),
				'squeeze' => !empty($it['squeeze']),
				'stretch' => awNum($it['stretch'] ?? 100, 10, 500),
				'kanji' => $kanji,
				'font' => awValidFont($it['font'] ?? '') ?: '',
				'color' => preg_match('/^#[0-9a-f]{6}$/', $color) ? $color : '#000000',
			];
		}
	}
	return $t;
}

function awStr($v, $max, $multiline = false) {
	$v = is_scalar($v) ? (string)$v : '';
	$v = str_replace("\r\n", "\n", $v);
	$v = $multiline ? preg_replace('/[\x00-\x09\x0B-\x1F\x7F]/u', '', $v) : preg_replace('/[\x00-\x1F\x7F]/u', '', $v);
	return mb_substr(trim($v ?? '', $multiline ? "\n" : " \t\n"), 0, $max, 'UTF-8');
}

function awNum($v, $min, $max) {
	$v = is_numeric($v) ? floatval($v) : 0;
	return round(max($min, min($max, $v)), 2);
}

/* ---------------------------------------------------------------- フォント */

// fonts/ にある TrueType フォント（TCPDF は OpenType(CFF) を使えないので .ttf だけ）
function awFonts() {
	$ret = [];
	foreach(glob(AW_FONT_DIR . '/*.[tT][tT][fF]') ?: [] as $f) {
		$ret[] = basename($f);
	}
	sort($ret);
	return $ret;
}

// 文字の枠（全角の四角）の上端が、ベースラインから何文字分上か（OS/2 の sTypoAscender から。日本語のフォントはふつう 0.88）
// 行の高さの基準（hhea の ascent/descent）は文字の枠より大きいフォントが多いので、文字はこの値でベースラインを決めて置く
function awFontAscent($file) {
	static $cache = [];
	if(isset($cache[$file])) {
		return $cache[$file];
	}
	$ret = 0.88;
	$fp = @fopen(AW_FONT_DIR . '/' . $file, 'rb');
	if($fp) {
		$tables = [];
		$head = fread($fp, 12);
		$n = strlen($head) == 12 ? unpack('n', substr($head, 4, 2))[1] : 0;
		for($i = 0; $i < $n and $i < 100; $i++) {
			$rec = fread($fp, 16);
			if(strlen($rec) < 16) {
				break;
			}
			$tables[substr($rec, 0, 4)] = unpack('N', substr($rec, 8, 4))[1];
		}
		if(isset($tables['OS/2'])) {
			fseek($fp, $tables['OS/2'] + 68);
			$b = fread($fp, 4);
			if(strlen($b) == 4) {
				[$asc, $desc] = array_values(unpack('n2', $b));
				$asc = $asc >= 0x8000 ? $asc - 0x10000 : $asc;
				$desc = $desc >= 0x8000 ? $desc - 0x10000 : $desc;
				if($asc > 0 and $asc - $desc > 0) {
					$ret = $asc / ($asc - $desc);
				}
			}
		}
		fclose($fp);
	}
	return $cache[$file] = $ret;
}

function awValidFont($name) {
	return (is_string($name) and $name !== '' and in_array($name, awFonts(), true)) ? $name : '';
}

/* ---------------------------------------------------------------- 画像 */

function awValidImageName($name) {
	return (is_string($name) and preg_match('/^[0-9a-f]{20,40}\.(png|jpg)$/', $name)) ? $name : '';
}

function awImagePath($name) {
	return awValidImageName($name) ? AW_DATA_DIR . '/images/' . $name : '';
}

// アップロードされた画像を data/images に入れる。戻り値は ['file'=>名前, 'width'=>px, 'height'=>px] か、エラーの文字列
function awStoreUploadedImage($f) {
	if(!is_array($f) or ($f['error'] ?? UPLOAD_ERR_NO_FILE) != UPLOAD_ERR_OK or !is_uploaded_file($f['tmp_name'])) {
		return '画像を受け取れませんでした。';
	}
	if($f['size'] > AW_IMAGE_MAX_BYTES) {
		return '画像が大きすぎます（10MB まで）。';
	}
	$info = @getimagesize($f['tmp_name']);
	if(!$info or !in_array($info[2], [IMAGETYPE_PNG, IMAGETYPE_JPEG])) {
		return 'PNG か JPEG の画像を選んでください。';
	}
	if(!awEnsureDirs()) {
		return 'data フォルダに書き込めません。';
	}
	$name = substr(sha1_file($f['tmp_name']), 0, 24) . ($info[2] == IMAGETYPE_PNG ? '.png' : '.jpg');
	$dest = AW_DATA_DIR . '/images/' . $name;
	if(!is_file($dest) and !move_uploaded_file($f['tmp_name'], $dest)) {
		return '画像を保存できませんでした。';
	}
	@touch($dest);
	return ['file' => $name, 'width' => $info[0], 'height' => $info[1]];
}

function awTemplateImages($t) {
	$ret = [];
	if(!empty($t['paper']['image'])) {
		$ret[] = $t['paper']['image'];
	}
	foreach($t['items'] ?? [] as $it) {
		if(($it['type'] ?? '') == 'image' and !empty($it['image'])) {
			$ret[] = $it['image'];
		}
	}
	return $ret;
}

// テンプレートにも発行履歴にも使われていない画像を消す（アップロードしたばかりで、まだ保存していないものは残す）
function awGcImages() {
	$used = [];
	foreach(glob(AW_DATA_DIR . '/templates/*.json') ?: [] as $f) {
		foreach(awTemplateImages(awReadJson($f) ?: []) as $i) {
			$used[$i] = true;
		}
	}
	foreach(glob(AW_DATA_DIR . '/history/*.json') ?: [] as $f) {
		$h = awReadJson($f) ?: [];
		foreach(awTemplateImages($h['template'] ?? []) as $i) {
			$used[$i] = true;
		}
	}
	foreach(glob(AW_DATA_DIR . '/images/*') ?: [] as $f) {
		if(!isset($used[basename($f)]) and filemtime($f) < time() - 86400) {
			@unlink($f);
		}
	}
}

/* ---------------------------------------------------------------- 発行履歴 */

// 発行履歴の一覧（新しい順）。$TourCode を渡すと、その大会のものだけ
function awListHistory($TourCode = null) {
	$ret = [];
	foreach(glob(AW_DATA_DIR . '/history/*.json') ?: [] as $f) {
		if(!($h = awReadJson($f))) {
			continue;
		}
		if($TourCode !== null and ($h['tournament']['code'] ?? '') !== $TourCode) {
			continue;
		}
		$h['id'] = basename($f, '.json');
		$ret[] = $h;
	}
	usort($ret, function($a, $b) {
		return strcmp($b['issuedAt'] ?? '', $a['issuedAt'] ?? '') ?: strcmp($b['id'], $a['id']);
	});
	return $ret;
}

function awLoadHistory($id) {
	if(!awValidId($id) or !($h = awReadJson(AW_DATA_DIR . '/history/' . $id . '.json'))) {
		return null;
	}
	$h['id'] = $id;
	$h['template'] = awNormalizeTemplate($h['template'] ?? []);
	return $h;
}

function awDeleteHistory($id) {
	if(!awValidId($id)) {
		return false;
	}
	$ok = @unlink(AW_DATA_DIR . '/history/' . $id . '.json');
	awGcImages();
	return $ok;
}

// 賞状を発行したことを記録する
// $certs: [['source'=>'qualification'|'manual', 'enId'=>int, 'values'=>[...]], ...]
function awRecordIssue($TemplateId, $certs, $Tour, $IssueDate, $Note) {
	$t = awLoadTemplate($TemplateId);
	if(!$t) {
		return false;
	}
	$id = awNewId('');
	$h = [
		'id' => $id,
		'issuedAt' => date('Y-m-d H:i:s'),
		'issueDate' => $IssueDate,
		'note' => awStr($Note, 500),
		'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
		'tournament' => $Tour,
		'template' => $t,
		'certificates' => $certs,
	];
	return awWriteJson(AW_DATA_DIR . '/history/' . $id . '.json', $h) ? $id : false;
}

// 大会の中で、テンプレートごとに発行済みの選手・チーム（キー => 回数。キーは awQualificationRanking / awEventRanking の Key）
function awIssuedCount($TourCode, $TemplateId) {
	$ret = [];
	foreach(awListHistory($TourCode) as $h) {
		if(($h['template']['id'] ?? '') !== $TemplateId) {
			continue;
		}
		foreach($h['certificates'] ?? [] as $c) {
			$key = $c['key'] ?? (!empty($c['enId']) ? 'q:' . $c['enId'] : '');
			if($key !== '') {
				$ret[$key] = ($ret[$key] ?? 0) + 1;
			}
		}
	}
	return $ret;
}

/* ---------------------------------------------------------------- 大会のデータ */

function awTournament($TourId) {
	$q = safe_r_sql("SELECT ToId, ToCode, ToName, ToWhere, ToWhenFrom, ToWhenTo FROM Tournament WHERE ToId=" . intval($TourId));
	if($r = safe_fetch($q)) {
		return ['id' => intval($r->ToId), 'code' => $r->ToCode, 'name' => $r->ToName, 'where' => $r->ToWhere, 'from' => $r->ToWhenFrom, 'to' => $r->ToWhenTo];
	}
	return null;
}

// 予選の順位（部門・クラスごと）。部門・クラス、得点の高い順
function awQualificationRanking($TourId) {
	$TourId = intval($TourId);
	$Select = "SELECT EnId, EnCode, EnName, EnFirstName, EnDivision, EnClass,
			CoCode, CoName,
			QuScore, QuGold, QuXnine,
			CONCAT(EnDivision, EnClass) AS Class,
			DivDescription, ClDescription,
			RANK() OVER (
				PARTITION BY CONCAT(EnDivision, EnClass)
				ORDER BY QuScore DESC, QuGold DESC, QuXnine DESC
			) AS Ranking
		FROM Entries
		INNER JOIN Qualifications ON EnId=QuId
		LEFT JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament
		LEFT JOIN Tournament ON EnTournament=ToId
		LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType
		INNER JOIN Divisions ON DivTournament=ToId AND DivId=EnDivision
		INNER JOIN Classes ON ClTournament=ToId AND ClId=EnClass
		WHERE EnAthlete=1 AND ToId={$TourId} AND CONCAT(EnDivision, EnClass) LIKE TdClasses";
	$Rs = safe_r_sql($Select);
	$ret = [];
	while($r = safe_fetch($Rs)) {
		$r = (array)$r;
		$r['Key'] = 'q:' . $r['EnId'];
		$r['EventName'] = trim($r['DivDescription'] . ' ' . $r['ClDescription']);
		$ret[] = $r;
	}
	usort($ret, function($a, $b) {
		return strcmp($a['Class'], $b['Class'])
			?: $b['QuScore'] <=> $a['QuScore']
			?: $b['QuGold'] <=> $a['QuGold']
			?: $b['QuXnine'] <=> $a['QuXnine'];
	});
	return $ret;
}

// 決勝の最終順位（種目ごと）。$Team が false なら個人戦、true なら団体戦。予選の得点がない人は入れない
// 団体戦の 氏名 はメンバー（決勝のメンバーを先に）を「・」でつないだもの、得点 は決勝のメンバーの中で上位 3 人の予選の得点の合計
function awEventRanking($TourId, $Team) {
	$TourId = intval($TourId);
	if(!$Team) {
		$Select = "SELECT IndRankFinal AS Ranking, EvCode AS Class, EvEventName AS EventName,
				EnId, EnFirstName, EnName, EnDivision, EnClass, CoCode, CoName, QuScore, QuGold, QuXnine
			FROM Events
			INNER JOIN Entries ON EnTournament=EvTournament AND CONCAT(EnDivision, EnClass)=EvCode
			INNER JOIN Individuals ON EvCode=IndEvent AND EvTournament=IndTournament AND EnId=IndId
			INNER JOIN Countries ON EnCountry=CoId AND EvTournament=CoTournament
			INNER JOIN Qualifications ON EnId=QuId
			WHERE EvTournament={$TourId} AND EvTeamEvent=0 AND QuScore>0
			ORDER BY EvProgr, IndEvent, IndRankFinal";
	} else {
		$Select = "SELECT Ranking, Class, EventName, CoId, SubTeam, CoCode, CoName,
				GROUP_CONCAT(EnName ORDER BY CASE WHEN TfcOrder IS NULL THEN 1 ELSE 0 END, TfcOrder, EnId SEPARATOR '・') AS Members,
				SUM(CASE WHEN TfcOrder IS NOT NULL AND ScoreOrder <= 3 THEN QuScore ELSE 0 END) AS QuScore
			FROM (
				SELECT Ranking, Class, EventName, EvProgr, CoId, SubTeam, CoCode, CoName, EnName, QuScore, EnId, TfcOrder,
					CASE WHEN TfcOrder IS NOT NULL THEN
						ROW_NUMBER() OVER (PARTITION BY Class, CoId, SubTeam, TfcOrder IS NULL ORDER BY QuScore DESC, EnId)
					ELSE NULL END AS ScoreOrder
				FROM (
					SELECT DISTINCT TeRankFinal AS Ranking, TeEvent AS Class, EvEventName AS EventName, EvProgr,
						CoId, TeSubTeam AS SubTeam, CoCode, CoName,
						CONCAT(EnFirstName, ' ', EnName) AS EnName, QuScore, EnId, TfcOrder
					FROM Events
					INNER JOIN TeamFinals ON EvCode=TfEvent AND EvTournament=TfTournament
					INNER JOIN Grids ON TfMatchNo=GrMatchNo
					INNER JOIN Teams ON TfTeam=TeCoId AND TfTournament=TeTournament AND TfEvent=TeEvent AND TfSubTeam=TeSubTeam AND TeFinEvent=1
					INNER JOIN Countries ON TfTeam=CoId AND TfTournament=CoTournament
					INNER JOIN Entries ON EnTournament=EvTournament AND EnCountry=CoId AND CONCAT(EnDivision, EnClass)=EvCode
					INNER JOIN Qualifications ON EnId=QuId
					LEFT JOIN TeamFinComponent ON TfcCoId=CoId AND TfcSubTeam=TeSubTeam AND TfcId=EnId AND TfcEvent=EvCode
					WHERE TeTournament={$TourId} AND TeFinEvent=1 AND EvTeamEvent=1 AND QuScore>0
				) AS Deduped
			) AS Ranked
			GROUP BY Ranking, Class, EventName, EvProgr, CoId, SubTeam, CoCode, CoName
			ORDER BY EvProgr, Class, Ranking";
	}
	$Rs = safe_r_sql($Select);
	$ret = [];
	while($r = safe_fetch($Rs)) {
		$r = (array)$r;
		if($Team) {
			$r['Key'] = 't:' . $r['Class'] . ':' . $r['CoId'] . ':' . $r['SubTeam'];
			$r['EnId'] = 0;
		} else {
			$r['Key'] = 'i:' . $r['Class'] . ':' . $r['EnId'];
		}
		$ret[] = $r;
	}
	return $ret;
}

// 参加数から表彰数を決める。$Rule は「参加数=表彰数」を 1 行に 1 つ（参加数がその数以下なら）、最後に「*=表彰数」
// 例: 3=1 / 5=2 / 7=3 / *=6。書いていなければ null
function awAwardLimit($Rule, $Count) {
	$other = null;
	$rules = [];
	foreach(preg_split('/\R/u', (string)$Rule) as $line) {
		if(preg_match('/^\s*(\d+|\*|＊)\s*[=＝:：]\s*(\d+)\s*$/u', $line, $m)) {
			if($m[1] === '*' or $m[1] === '＊') {
				$other = intval($m[2]);
			} else {
				$rules[intval($m[1])] = intval($m[2]);
			}
		}
	}
	if(!$rules and $other === null) {
		return null;
	}
	ksort($rules);
	foreach($rules as $max => $n) {
		if($Count <= $max) {
			return $n;
		}
	}
	return $other ?? end($rules);
}

/* ---------------------------------------------------------------- 差し込み */

// 大会と発行日の差し込み値
function awCommonValues($Tour, $IssueDate) {
	$v = [
		'大会名' => $Tour['name'] ?? '',
		'開催地' => $Tour['where'] ?? '',
	];
	$v['開催年月日'] = awFormatDate($Tour['from'] ?? '', 'western');
	$v['開催年月日和暦'] = awFormatDate($Tour['from'] ?? '', 'wareki');
	$v['開催年号'] = awFormatDate($Tour['from'] ?? '', 'era');
	$v['開催年和暦'] = awFormatDate($Tour['from'] ?? '', 'warekiYear');
	$v['開催年'] = $v['開催月'] = $v['開催日'] = '';
	if(preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})/', (string)($Tour['from'] ?? ''), $m)) {
		$v['開催年'] = (string)intval($m[1]);
		$v['開催月'] = (string)intval($m[2]);
		$v['開催日'] = (string)intval($m[3]);
	}
	$v['発行年月日'] = awFormatDate($IssueDate, 'western');
	$v['発行年月日和暦'] = awFormatDate($IssueDate, 'wareki');
	return $v;
}

// 選手ごとの差し込み値（予選の順位の行から）
function awEntryValues($r, $Template) {
	$v = [
		'種目' => $r['EventName'] ?? '',
		'姓' => $r['EnFirstName'] ?? '',
		'名' => $r['EnName'] ?? '',
		'所属' => $r['CoName'] ?? '',
		'所属コード' => $r['CoCode'] ?? '',
		'部門' => $r['DivDescription'] ?? '',
		'クラス' => $r['ClDescription'] ?? '',
		'部門コード' => $r['EnDivision'] ?? '',
		'クラスコード' => $r['EnClass'] ?? '',
		'順位' => $r['Ranking'] ?? '',
		'得点' => $r['QuScore'] ?? '',
		'ゴールド数' => $r['QuGold'] ?? '',
		'X数' => $r['QuXnine'] ?? '',
	];
	// 団体戦はメンバーを 氏名 にする
	if(isset($r['Members'])) {
		$v['氏名'] = $r['Members'];
		$v['姓'] = $v['名'] = '';
	}
	return awPersonValues($v, $Template);
}

// 姓・名・順位・得点などから、氏名や順位の表記などの項目を足す
function awPersonValues($v, $Template) {
	$v = array_map('strval', $v);
	if(!isset($v['氏名'])) {
		$v['氏名'] = trim(($v['姓'] ?? '') . ' ' . ($v['名'] ?? ''));
	}
	$rank = $v['順位'] ?? '';
	$v['順位表記'] = awRankName($rank, $Template['rankNames'] ?? '');
	return $v;
}

function awRankName($rank, $rankNames) {
	foreach(preg_split('/\n/', (string)$rankNames) as $line) {
		if(preg_match('/^\s*(\d+)\s*[=＝:：]\s*(.*)$/u', $line, $m) and $m[1] === (string)$rank) {
			return trim($m[2]);
		}
	}
	if($rank === '' or !ctype_digit((string)$rank)) {
		return (string)$rank;
	}
	return '第' . awKanjiNumber($rank) . '位';
}

// 見本の差し込み値（テンプレートの設定画面で使う）
function awSampleValues($Template, $Tour = null) {
	$v = awCommonValues($Tour ?: ['name' => '第〇回〇〇アーチェリー大会', 'where' => '〇〇市', 'from' => date('Y-m-d')], date('Y-m-d'));
	$v += awPersonValues([
		'姓' => '京都', '名' => '太郎', '所属' => '京都アーチェリークラブ', '所属コード' => 'KYO',
		'種目' => 'リカーブ男子個人', '部門' => 'リカーブ', 'クラス' => '一般男子', '部門コード' => 'R', 'クラスコード' => 'M',
		'順位' => '1', '得点' => '648', 'ゴールド数' => '25', 'X数' => '10',
	], $Template);
	// 団体戦は、メンバーを「・」でつないだ氏名と、メンバーの得点の合計
	if(($Template['source'] ?? '') == 'team') {
		$v['氏名'] = '京都 一郎・京都 二郎・京都 三郎';
		$v['姓'] = $v['名'] = '';
		$v['種目'] = 'リカーブ男子団体';
		$v['得点'] = '1890';
	}
	return $v;
}

// 差し込みの項目のどれかが空（手入力で書かなかった欄など）なら true
function awHasEmptyValue($text, $values) {
	preg_match_all('/\{([^{}\s]+)\}/u', $text, $m);
	foreach($m[1] as $k) {
		if(array_key_exists($k, $values) and (string)$values[$k] === '') {
			return true;
		}
	}
	return false;
}

function awSubstitute($text, $values) {
	return preg_replace_callback('/\{([^{}\s]+)\}/u', function($m) use ($values) {
		return array_key_exists($m[1], $values) ? (string)$values[$m[1]] : $m[0];
	}, $text);
}

// 位取りの漢数字（648 → 六百四十八）
function awKanjiNumber($number) {
	$number = (string)intval($number);
	$nums = ['〇', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
	$units = ['', '十', '百', '千'];
	$bigUnits = ['', '万', '億', '兆'];
	if($number === '0') {
		return $nums[0];
	}
	$result = '';
	$groups = str_split(str_pad($number, (int)ceil(strlen($number) / 4) * 4, '0', STR_PAD_LEFT), 4);
	$n = count($groups);
	foreach($groups as $gi => $g) {
		$s = '';
		for($j = 0; $j < 4; $j++) {
			$d = intval($g[$j]);
			if($d) {
				$s .= (($d == 1 and $j < 3) ? '' : $nums[$d]) . $units[3 - $j];
			}
		}
		if($s !== '') {
			$result .= $s . $bigUnits[$n - 1 - $gi];
		}
	}
	return $result;
}

// 一桁ずつの漢数字（2026 → 二〇二六）
function awKanjiDigits($number) {
	return strtr((string)$number, ['0' => '〇', '1' => '一', '2' => '二', '3' => '三', '4' => '四', '5' => '五', '6' => '六', '7' => '七', '8' => '八', '9' => '九']);
}

// 文字の中の数字を漢数字にする。digit: 一〇方式（2026 → 二〇二六、10 → 一〇）、unit: 十方式（10 → 十、648 → 六百四十八）
// 十方式でも、4 桁以上の数字（年など）は一〇方式にする（2026 → 二〇二六）
function awKanjiText($text, $mode) {
	if($mode !== 'digit' and $mode !== 'unit') {
		return $text;
	}
	return preg_replace_callback('/[0-9０-９]+/u', function($m) use ($mode) {
		$n = strtr($m[0], ['０' => '0', '１' => '1', '２' => '2', '３' => '3', '４' => '4', '５' => '5', '６' => '6', '７' => '7', '８' => '8', '９' => '9']);
		return ($mode == 'digit' or strlen($n) >= 4) ? awKanjiDigits($n) : awKanjiNumber($n);
	}, $text);
}

function awFormatDate($ymd, $style) {
	if(!preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})/', (string)$ymd, $m)) {
		return '';
	}
	[$y, $mo, $d] = [intval($m[1]), intval($m[2]), intval($m[3])];
	switch($style) {
		case 'wareki':
		case 'era':
		case 'warekiYear':
			$ymdNum = $y * 10000 + $mo * 100 + $d;
			if($ymdNum >= 20190501) {
				[$era, $ey] = ['令和', $y - 2018];
			} elseif($ymdNum >= 19890108) {
				[$era, $ey] = ['平成', $y - 1988];
			} else {
				[$era, $ey] = ['昭和', $y - 1925];
			}
			if($style == 'era') {
				return $era;
			}
			if($style == 'warekiYear') {
				return $ey == 1 ? '元' : (string)$ey;
			}
			return $era . ($ey == 1 ? '元' : $ey) . '年' . $mo . '月' . $d . '日';
		default:
			return $y . '年' . $mo . '月' . $d . '日';
	}
}

/* ---------------------------------------------------------------- 配置の計算 */

function awPt2mm($pt) {
	return $pt / 72 * 25.4;
}

// 縦書き用に、半角の英数字・記号・空白・カナを全角にする
function awZenkaku($s) {
	return mb_convert_kana($s, 'ASKV', 'UTF-8');
}

// テキストボックスの文字を並べる。award.js の awLayout と同じ計算
// $measure: function($ch, $sizeMm) → 文字の幅 mm（横書きと、縦書きの半角文字に使う）
// 戻り値: [['ch'=>文字, 'x'=>左 mm, 'y'=>上 mm, 's'=>大きさ mm, 'rot'=>0|90], ...]（x, y は回す前の文字の枠の左上）
function awLayout($it, $dir, $text, $measure) {
	$vertical = ($dir == 'vertical');
	$s = awPt2mm($it['size']);
	$sp = $it['spacing'];
	$lh = $it['lineHeight'];
	$paras = [];
	foreach(explode("\n", str_replace("\r", '', $text)) as $l) {
		$paras[] = mb_str_split($l, 1, 'UTF-8');
	}
	$mainAvail = $vertical ? $it['h'] : $it['w'];
	$crossAvail = $vertical ? $it['w'] : $it['h'];

	// 文字の幅（%）。横書きのときだけ。文字の幅を $wk 倍にして、行の長さや折り返しを計算する（PDF は setFontStretching）
	$wk = $vertical ? 1 : $it['stretch'] / 100;
	if($wk != 1) {
		$measure0 = $measure;
		$measure = function($ch, $s) use ($measure0, $wk) {
			return $measure0($ch, $s) * $wk;
		};
	}

	// 大きさ $s のときの、行の長さ
	$lineLen = function($chars, $s) use ($vertical, $sp, $measure) {
		$n = count($chars);
		if(!$n) {
			return 0;
		}
		if($vertical) {
			return ($n - 1) * $s * (1 + $sp) + $s;
		}
		$w = 0;
		foreach($chars as $c) {
			$w += $measure($c, $s);
		}
		return $w + ($n - 1) * $s * $sp;
	};

	// 行に分ける。折り返すときは、枠の長さに入るだけの文字で行を切る
	// 戻り値: [['chars'=>[...], 'last'=>段落の最後の行か, 'split'=>段落を折り返したか], ...]
	$makeLines = function($s) use ($paras, $it, $vertical, $sp, $measure, $mainAvail) {
		$lines = [];
		foreach($paras as $p) {
			$n = count($p);
			if(!$it['wrap'] or !$n) {
				$lines[] = ['chars' => $p, 'last' => true, 'split' => false];
				continue;
			}
			$chunks = [];
			$i = 0;
			while($i < $n) {
				if($vertical) {
					$m = max(1, (int)floor(($mainAvail - $s) / ($s * (1 + $sp)) + 1e-9) + 1);
				} else {
					$m = 0;
					$cur = 0;
					for($j = $i; $j < $n; $j++) {
						$add = $measure($p[$j], $s) + ($m ? $s * $sp : 0);
						if($m and $cur + $add > $mainAvail + 1e-9) {
							break;
						}
						$cur += $add;
						$m++;
					}
					$m = max(1, $m);
				}
				$m = min($m, $n - $i);
				// 行頭に来てはいけない文字（句読点・閉じ括弧・小さい仮名など）は、前の行の終わりにぶら下げる
				$hang = 0;
				while($i + $m < $n and $hang < 2 and mb_strpos(AW_KINSOKU_START, $p[$i + $m], 0, 'UTF-8') !== false) {
					$m++;
					$hang++;
				}
				// 行末に来てはいけない文字（開き括弧）は、次の行へ送る
				if(!$hang and $m > 1 and $i + $m < $n and mb_strpos(AW_KINSOKU_END, $p[$i + $m - 1], 0, 'UTF-8') !== false) {
					$m--;
				}
				$chunks[] = array_slice($p, $i, $m);
				$i += $m;
			}
			foreach($chunks as $k => $c) {
				$lines[] = ['chars' => $c, 'last' => $k == count($chunks) - 1, 'split' => count($chunks) > 1];
			}
		}
		return $lines;
	};

	$lines = $makeLines($s);
	if($it['fit'] and $it['wrap']) {
		// 折り返して行が枠からはみ出すときは、少しずつ小さくして折り返し直す
		for($n = 0; $n < 40 and $s + (count($lines) - 1) * $s * $lh > $crossAvail; $n++) {
			$s *= 0.95;
			$lines = $makeLines($s);
		}
	}
	// 横に縮める（長体）: 横書きで折り返さないとき、入りきらない行は文字を横に縮めて枠の幅に収める
	$squeeze = !empty($it['squeeze']) && !$vertical && !$it['wrap'];
	if($it['fit']) {
		$maxLen = 0;
		if(!$it['wrap'] and !$squeeze) {
			foreach($lines as $l) {
				$maxLen = max($maxLen, $lineLen($l['chars'], $s));
			}
		}
		$crossLen = $s + (count($lines) - 1) * $s * $lh;
		$k = 1;
		if($maxLen > $mainAvail and $maxLen > 0) {
			$k = min($k, $mainAvail / $maxLen);
		}
		if($crossLen > $crossAvail) {
			$k = min($k, $crossAvail / $crossLen);
		}
		$s *= $k;
	}

	$crossLen = $s + (count($lines) - 1) * $s * $lh;
	$crossStart = ['start' => 0, 'center' => ($crossAvail - $crossLen) / 2, 'end' => $crossAvail - $crossLen][$it['cross']];

	$glyphs = [];
	foreach($lines as $i => $line) {
		$chars = $line['chars'];
		$n = count($chars);
		if(!$n) {
			continue;
		}
		$c = $crossStart + $i * $s * $lh;
		$len = $lineLen($chars, $s);
		$sx = 1;
		if($squeeze and $len > $mainAvail and $len > 0) {
			$sx = $mainAvail / $len;
			$len = $mainAvail;
		}
		$gap = 0;
		$off = 0;
		$align = $it['align'];
		// 均等割り付けで折り返したときは、段落の最後の行だけ詰めて並べる
		if($align == 'justify' and $line['split'] and $line['last']) {
			$align = 'start';
		}
		if($align == 'justify' and $n == 1) {
			$align = 'center';
		}
		if($align == 'justify') {
			$gap = ($mainAvail - $len) / ($n - 1);
		} elseif($align == 'center') {
			$off = ($mainAvail - $len) / 2;
		} elseif($align == 'end') {
			$off = $mainAvail - $len;
		}

		if($vertical) {
			$x = $it['x'] + $it['w'] - $c - $s;
			foreach($chars as $j => $ch) {
				$y = $it['y'] + $off + $j * ($s * (1 + $sp) + $gap);
				$g = ['ch' => $ch, 'x' => $x, 'y' => $y, 's' => $s, 'rot' => 0, 'sx' => 1];
				if(mb_strpos(AW_TATE_ROTATE, $ch, 0, 'UTF-8') !== false) {
					$g['rot'] = 90;
				} elseif(mb_strpos(AW_TATE_PUNCT, $ch, 0, 'UTF-8') !== false) {
					$g['x'] += $s * 0.6;
					$g['y'] -= $s * 0.6;
				} elseif(mb_strpos(AW_TATE_SMALL, $ch, 0, 'UTF-8') !== false) {
					$g['x'] += $s * 0.1;
					$g['y'] -= $s * 0.1;
				} else {
					// 全角にしなかった半角の文字は、行の中央に置く
					$w = $measure($ch, $s);
					if($w < $s * 0.9) {
						$g['x'] += ($s - $w) / 2;
					}
				}
				$glyphs[] = $g;
			}
		} else {
			$y = $it['y'] + $c;
			$x = $it['x'] + $off;
			foreach($chars as $ch) {
				// sx: 文字を横に伸び縮みさせる倍率（文字の幅 × 長体で縮めた分）。x を進める幅は、measure が文字の幅の分を含んでいる
				$glyphs[] = ['ch' => $ch, 'x' => $x, 'y' => $y, 's' => $s, 'rot' => 0, 'sx' => $sx * $wk];
				$x += ($measure($ch, $s) + $s * $sp) * $sx + $gap;
			}
		}
	}
	return $glyphs;
}

/* ---------------------------------------------------------------- PDF */

// 賞状の PDF を作る
// $valuesList: 1 枚ごとの差し込み値の配列
// $withPaper: 用紙の画像も重ねる（試し刷り・確認用）
function awMakePdf($Template, $valuesList, $withPaper = false, $Title = '賞状') {
	require_once('Common/tcpdf/tcpdf.php');

	$paper = $Template['paper'];
	$orient = $paper['width'] > $paper['height'] ? 'L' : 'P';
	$pdf = new TCPDF($orient, 'mm', [$paper['width'], $paper['height']], true, 'UTF-8', false);
	$pdf->setTitle($Title);
	$pdf->setCreator('ianseo Award');
	$pdf->setPrintHeader(false);
	$pdf->setPrintFooter(false);
	$pdf->setAutoPageBreak(false, 0);
	$pdf->setMargins(0, 0, 0);
	$pdf->setCellPadding(0);
	$pdf->setCellHeightRatio(1);
	$pdf->setFontSubsetting(true);

	$fonts = [];
	$fontOf = function($file) use (&$fonts) {
		if(!isset($fonts[$file])) {
			$fonts[$file] = TCPDF_FONTS::addTTFfont(AW_FONT_DIR . '/' . $file, 'TrueTypeUnicode', '', 32) ?: 'kozminproregular';
		}
		return $fonts[$file];
	};

	// 用紙の画像を重ねるとき以外は、印刷位置の補正をかける
	$dx = $withPaper ? 0 : $paper['offsetX'];
	$dy = $withPaper ? 0 : $paper['offsetY'];

	foreach($valuesList as $values) {
		$pdf->AddPage($orient, [$paper['width'], $paper['height']]);
		if($withPaper and $paper['image'] and is_file(awImagePath($paper['image']))) {
			$pdf->Image(awImagePath($paper['image']), 0, 0, $paper['width'], $paper['height'], '', '', '', false);
		}
		foreach($Template['items'] as $it) {
			if($it['type'] == 'image') {
				$file = awImagePath($it['image']);
				if(!$file or !is_file($file)) {
					continue;
				}
				if($it['multiply']) {
					$pdf->setAlpha(1, 'Multiply');
				}
				$pdf->Image($file, $it['x'] + $dx, $it['y'] + $dy, $it['w'], $it['h'], '', '', '', false);
				if($it['multiply']) {
					$pdf->setAlpha(1, 'Normal');
				}
				continue;
			}

			if($it['skipEmpty'] and awHasEmptyValue($it['text'], $values)) {
				continue;
			}
			$dir = $it['dir'] ?: $Template['direction'];
			$text = awKanjiText(awSubstitute($it['text'], $values), $it['kanji']);
			if($it['zenkaku']) {
				$text = awZenkaku($text);
			}
			$fontFile = $it['font'] ?: $Template['font'];
			$font = $fontOf($fontFile);
			$asc = awFontAscent($fontFile);
			$measure = function($ch, $s) use ($pdf, $font) {
				return $pdf->GetStringWidth($ch, $font, '', $s * 72 / 25.4);
			};
			$pdf->setTextColorArray(sscanf($it['color'], '#%02x%02x%02x'));
			foreach(awLayout($it, $dir, $text, $measure) as $g) {
				$pdf->SetFont($font, '', $g['s'] * 72 / 25.4);
				$x = $g['x'] + $dx;
				$y = $g['y'] + $dy;
				// 文字の枠の上端が $y になるように、ベースラインの位置を指定して置く（calign L / valign T でベースラインが y になる）
				$base = $y + $asc * $g['s'];
				if($g['rot']) {
					// 回した文字は、横書きのときの幅で中央に置き、文字の枠の中心で右に 90 度回す
					$pdf->StartTransform();
					$pdf->Rotate(-90, $x + $g['s'] / 2, $y + $g['s'] / 2);
					$pdf->Text($x + ($g['s'] - $measure($g['ch'], $g['s'])) / 2, $base, $g['ch'], 0, false, true, 0, 0, '', false, '', 0, false, 'L', 'T');
					$pdf->StopTransform();
				} elseif($g['sx'] != 1) {
					// 横に縮めた文字
					$pdf->setFontStretching($g['sx'] * 100);
					$pdf->Text($x, $base, $g['ch'], 0, false, true, 0, 0, '', false, '', 0, false, 'L', 'T');
					$pdf->setFontStretching(100);
				} else {
					$pdf->Text($x, $base, $g['ch'], 0, false, true, 0, 0, '', false, '', 0, false, 'L', 'T');
				}
			}
		}
	}
	return $pdf;
}

/* ---------------------------------------------------------------- 画面 */

function awH($s) {
	return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function awJson($v) {
	return json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
}

// POST のフォームに入れる、なりすまし防止の合言葉
function awToken() {
	if(empty($_SESSION['AwardToken'])) {
		$_SESSION['AwardToken'] = bin2hex(random_bytes(16));
	}
	return $_SESSION['AwardToken'];
}

function awCheckToken() {
	return !empty($_POST['AwToken']) and !empty($_SESSION['AwardToken']) and hash_equals($_SESSION['AwardToken'], (string)$_POST['AwToken']);
}

function awTokenField() {
	return '<input type="hidden" name="AwToken" value="' . awH(awToken()) . '">';
}

// 画面の上のタブ
// テンプレート選択（index）と発行履歴（history）:  [テンプレート選択] [発行履歴]
// テンプレート編集（edit）と 賞状発行（issue）:     [戻る（テンプレート選択へ）] [テンプレート編集] [賞状発行]
// テンプレート選択でテンプレートの名前を押すと編集の画面へ、そこから「賞状発行」のタブで発行の画面へ移る。$tplId は、そのテンプレートの id
function awTabs($current, $tplId = '') {
	if($current == 'issue' or $current == 'edit') {
		// 4 つめは Font Awesome のアイコン（各画面で $IncludeFA = true にして、ianseo に font-awesome.css を読み込ませる）
		$tabs = [['back', '戻る', 'index.php', '']];
		if(awCanEdit()) {
			$tabs[] = ['edit', 'テンプレート編集', 'Edit.php?id=' . rawurlencode($tplId), 'fa-pen-to-square'];
		}
		$tabs[] = ['issue', '賞状発行', 'Issue.php?tpl=' . rawurlencode($tplId), 'fa-print'];
	} else {
		$tabs = [['index', 'テンプレート選択', 'index.php', ''], ['history', '発行履歴', 'History.php', '']];
	}
	$ret = '<div class="AwTabs">';
	foreach($tabs as $t) {
		// 開いている画面のタブは濃い色。「賞状発行」は、目立つように太字・黄色の背景（発行の画面でも黄色で、濃い枠で今の画面とわかるようにする）
		$class = $t[0] == 'issue' ? ($t[0] == $current ? ' class="AwTabGo AwTabNow"' : ' class="AwTabGo"') : ($t[0] == $current ? ' class="AwTabOn"' : '');
		$icon = $t[3] !== '' ? '<i class="fa-solid ' . $t[3] . '"></i>' : '';
		$ret .= '<a href="' . awH($t[2]) . '"' . $class . '>' . $icon . $t[1] . '</a>';
	}
	return $ret . '</div>';
}

function awImageUrl($name) {
	return $name ? 'Image.php?f=' . rawurlencode($name) : '';
}
