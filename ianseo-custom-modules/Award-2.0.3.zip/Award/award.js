/*
賞状のテンプレートの設定画面（Edit.php）。
用紙の上にテキストボックスと画像を置き、マウスか数値で位置と大きさを決める。
文字の並べ方（awLayout）は Lib.php の awLayout と同じ計算にしてある。変えるときは両方を直すこと。

変更履歴:
2026/09/26 初版
*/

var Aw = {
	tpl: null,
	sel: -1,        // 1 つだけ選んでいるときの項目の番号（複数のときは -1）
	multi: [],      // 選んでいる項目の番号（1 つでも複数でも）
	k: 1,           // 画面の 1mm が何 px か
	dirty: false,
	cache: {},      // 文字の幅（フォントの番号 + 文字 → 1mm の大きさのときの幅 mm）
	imgSize: {},    // 画像の大きさ（名前 → [幅, 高さ] px）
	drag: null
};

function awEl(id) {
	return document.getElementById(id);
}

function awPt2mm(pt) {
	return pt / 72 * 25.4;
}

function awRound(v) {
	return Math.round(v * 10) / 10;
}

// PHP の mb_convert_kana($s, 'ASKV') と同じく、半角の英数字・記号（" ' \ ~ 以外）、空白、カナ（濁点はまとめる）を全角にする
function awZenkaku(s) {
	s = s.replace(/[｡-ﾟ]+/g, function(m) {
		return m.normalize('NFKC');
	});
	return s.replace(/[ -~]/g, function(c) {
		if(c === ' ') {
			return '　';
		}
		if(c === '"' || c === "'" || c === '\\' || c === '~') {
			return c;
		}
		return String.fromCharCode(c.charCodeAt(0) + 0xFEE0);
	});
}

// 差し込みの項目のどれかが空なら true（Lib.php の awHasEmptyValue と同じ）
function awHasEmptyValue(text, values) {
	var re = /\{([^{}\s]+)\}/g, m;
	while((m = re.exec(text))) {
		if(Object.prototype.hasOwnProperty.call(values, m[1]) && String(values[m[1]]) === '') {
			return true;
		}
	}
	return false;
}

// 位取りの漢数字（648 → 六百四十八）。Lib.php の awKanjiNumber と同じ
function awKanjiNumber(num) {
	var nums = ['〇', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
	var units = ['', '十', '百', '千'], bigUnits = ['', '万', '億', '兆'];
	num = String(num).replace(/^0+(?=\d)/, '');
	if(num === '0') {
		return nums[0];
	}
	while(num.length % 4) {
		num = '0' + num;
	}
	var result = '', n = num.length / 4;
	for(var gi = 0; gi < n; gi++) {
		var g = num.substr(gi * 4, 4), s = '';
		for(var j = 0; j < 4; j++) {
			var d = parseInt(g.charAt(j), 10);
			if(d) {
				s += ((d === 1 && j < 3) ? '' : nums[d]) + units[3 - j];
			}
		}
		if(s !== '') {
			result += s + (bigUnits[n - 1 - gi] || '');
		}
	}
	return result;
}

// 文字の中の数字を漢数字にする（Lib.php の awKanjiText と同じ）。digit: 一〇方式、unit: 十方式（4 桁以上は一〇方式）
function awKanjiText(text, mode) {
	if(mode !== 'digit' && mode !== 'unit') {
		return text;
	}
	return text.replace(/[0-9０-９]+/g, function(m) {
		m = m.replace(/[０-９]/g, function(c) {
			return String.fromCharCode(c.charCodeAt(0) - 0xFEE0);
		});
		if(mode === 'digit' || m.length >= 4) {
			return m.replace(/\d/g, function(c) {
				return '〇一二三四五六七八九'.charAt(parseInt(c, 10));
			});
		}
		return awKanjiNumber(m);
	});
}

function awSubstitute(text, values) {
	return text.replace(/\{([^{}\s]+)\}/g, function(m, k) {
		return Object.prototype.hasOwnProperty.call(values, k) ? String(values[k]) : m;
	});
}

// テキストボックスの文字を並べる（Lib.php の awLayout と同じ）
function awLayout(it, dir, text, measure) {
	var vertical = (dir === 'vertical');
	var s = awPt2mm(it.size), sp = it.spacing, lh = it.lineHeight;
	var paras = text.replace(/\r/g, '').split('\n').map(function(l) {
		return Array.from(l);
	});
	var mainAvail = vertical ? it.h : it.w;
	var crossAvail = vertical ? it.w : it.h;

	// 文字の幅（%）。横書きのときだけ。文字の幅を wk 倍にして、行の長さや折り返しを計算する（Lib.php と同じ）
	var wk = vertical ? 1 : (it.stretch || 100) / 100;
	if(wk !== 1) {
		var measure0 = measure;
		measure = function(ch, s) {
			return measure0(ch, s) * wk;
		};
	}

	function lineLen(chars, s) {
		var n = chars.length;
		if(!n) {
			return 0;
		}
		if(vertical) {
			return (n - 1) * s * (1 + sp) + s;
		}
		var w = 0;
		chars.forEach(function(c) {
			w += measure(c, s);
		});
		return w + (n - 1) * s * sp;
	}

	// 行に分ける。折り返すときは、枠の長さに入るだけの文字で行を切る（Lib.php と同じ）
	function makeLines(s) {
		var lines = [];
		paras.forEach(function(p) {
			var n = p.length;
			if(!it.wrap || !n) {
				lines.push({chars: p, last: true, split: false});
				return;
			}
			var chunks = [], i = 0, m;
			while(i < n) {
				if(vertical) {
					m = Math.max(1, Math.floor((mainAvail - s) / (s * (1 + sp)) + 1e-9) + 1);
				} else {
					m = 0;
					var cur = 0;
					for(var j = i; j < n; j++) {
						var add = measure(p[j], s) + (m ? s * sp : 0);
						if(m && cur + add > mainAvail + 1e-9) {
							break;
						}
						cur += add;
						m++;
					}
					m = Math.max(1, m);
				}
				m = Math.min(m, n - i);
				// 行頭に来てはいけない文字は、前の行の終わりにぶら下げる
				var hang = 0;
				while(i + m < n && hang < 2 && AwConfig.kinsokuStart.indexOf(p[i + m]) >= 0) {
					m++;
					hang++;
				}
				// 行末に来てはいけない文字は、次の行へ送る
				if(!hang && m > 1 && i + m < n && AwConfig.kinsokuEnd.indexOf(p[i + m - 1]) >= 0) {
					m--;
				}
				chunks.push(p.slice(i, i + m));
				i += m;
			}
			chunks.forEach(function(c, k) {
				lines.push({chars: c, last: k === chunks.length - 1, split: chunks.length > 1});
			});
		});
		return lines;
	}

	var lines = makeLines(s);
	if(it.fit && it.wrap) {
		// 折り返して行が枠からはみ出すときは、少しずつ小さくして折り返し直す
		for(var t = 0; t < 40 && s + (lines.length - 1) * s * lh > crossAvail; t++) {
			s *= 0.95;
			lines = makeLines(s);
		}
	}
	// 横に縮める（長体）: 横書きで折り返さないとき、入りきらない行は文字を横に縮めて枠の幅に収める
	var squeeze = !!it.squeeze && !vertical && !it.wrap;
	if(it.fit) {
		var maxLen = 0;
		if(!it.wrap && !squeeze) {
			lines.forEach(function(l) {
				maxLen = Math.max(maxLen, lineLen(l.chars, s));
			});
		}
		var crossLen0 = s + (lines.length - 1) * s * lh;
		var k = 1;
		if(maxLen > mainAvail && maxLen > 0) {
			k = Math.min(k, mainAvail / maxLen);
		}
		if(crossLen0 > crossAvail) {
			k = Math.min(k, crossAvail / crossLen0);
		}
		s *= k;
	}

	var crossLen = s + (lines.length - 1) * s * lh;
	var crossStart = {start: 0, center: (crossAvail - crossLen) / 2, end: crossAvail - crossLen}[it.cross];

	var glyphs = [];
	lines.forEach(function(line, i) {
		var chars = line.chars;
		var n = chars.length;
		if(!n) {
			return;
		}
		var c = crossStart + i * s * lh;
		var len = lineLen(chars, s);
		var sx = 1;
		if(squeeze && len > mainAvail && len > 0) {
			sx = mainAvail / len;
			len = mainAvail;
		}
		var gap = 0, off = 0, align = it.align;
		// 均等割り付けで折り返したときは、段落の最後の行だけ詰めて並べる
		if(align === 'justify' && line.split && line.last) {
			align = 'start';
		}
		if(align === 'justify' && n === 1) {
			align = 'center';
		}
		if(align === 'justify') {
			gap = (mainAvail - len) / (n - 1);
		} else if(align === 'center') {
			off = (mainAvail - len) / 2;
		} else if(align === 'end') {
			off = mainAvail - len;
		}

		if(vertical) {
			var x = it.x + it.w - c - s;
			chars.forEach(function(ch, j) {
				var g = {ch: ch, x: x, y: it.y + off + j * (s * (1 + sp) + gap), s: s, rot: 0, sx: 1};
				if(AwConfig.rotate.indexOf(ch) >= 0) {
					g.rot = 90;
				} else if(AwConfig.punct.indexOf(ch) >= 0) {
					g.x += s * 0.6;
					g.y -= s * 0.6;
				} else if(AwConfig.small.indexOf(ch) >= 0) {
					g.x += s * 0.1;
					g.y -= s * 0.1;
				} else {
					var w = measure(ch, s);
					if(w < s * 0.9) {
						g.x += (s - w) / 2;
					}
				}
				glyphs.push(g);
			});
		} else {
			var y = it.y + c, xx = it.x + off;
			chars.forEach(function(ch) {
				glyphs.push({ch: ch, x: xx, y: y, s: s, rot: 0, sx: sx * wk});
				xx += (measure(ch, s) + s * sp) * sx + gap;
			});
		}
	});
	return glyphs;
}

/* ---------------------------------------------------------------- フォント */

function awFontIndex(file) {
	var i = AwConfig.fonts.indexOf(file);
	return i >= 0 ? i : 0;
}

function awFontFamily(i) {
	return '"AwF' + i + '", serif';
}

function awMeasurer(fi) {
	if(!Aw.ctx) {
		Aw.ctx = document.createElement('canvas').getContext('2d');
	}
	return function(ch, s) {
		var key = fi + '\u0000' + ch;
		if(Aw.cache[key] === undefined) {
			Aw.ctx.font = '100px ' + awFontFamily(fi);
			Aw.cache[key] = Aw.ctx.measureText(ch).width / 100;
		}
		return Aw.cache[key] * s;
	};
}

// ブラウザで、行の高さ 1 のときの箱の上端からベースラインまで（文字の大きさに対する割合）。フォントごとに測る
function awCssBaseline(fi) {
	Aw.base = Aw.base || {};
	if(Aw.base[fi] === undefined) {
		var box = document.createElement('div');
		box.style.cssText = 'position:absolute;left:-9999px;top:0;visibility:hidden;line-height:1;white-space:pre;font-size:100px;font-family:' + awFontFamily(fi);
		var mark = document.createElement('span');
		mark.style.cssText = 'display:inline-block;width:1px;height:0;vertical-align:baseline';
		box.appendChild(document.createTextNode('あ'));
		box.appendChild(mark);
		document.body.appendChild(box);
		Aw.base[fi] = (mark.getBoundingClientRect().top - box.getBoundingClientRect().top) / 100;
		box.remove();
	}
	return Aw.base[fi];
}

function awLoadFonts() {
	if(!document.fonts || !document.fonts.load) {
		return;
	}
	var loads = AwConfig.fonts.map(function(f, i) {
		return document.fonts.load('100px "AwF' + i + '"', 'あ');
	});
	Promise.all(loads).then(function() {
		Aw.cache = {};
		Aw.base = {};
		awRender();
	}, function() {});
}

/* ---------------------------------------------------------------- 描画 */

function awValues() {
	var list = awSamples();
	var s = list[parseInt(awEl('AwSample').value, 10) || 0] || list[0];
	return s.values;
}

// 要素の上端から画面の下端までの高さ（ページを一番上までスクロールしたとき）
function awAvailHeight(el) {
	var top = el.getBoundingClientRect().top + (window.scrollY || window.pageYOffset || 0);
	return Math.max(200, Math.floor(window.innerHeight - top - 8));
}

// 今のテンプレートの順位のもと（予選・個人戦・団体戦）の見本
function awSamples() {
	return AwConfig.samples[Aw.tpl.source] || AwConfig.samples.qual;
}

function awFillSamples() {
	var sel = awEl('AwSample');
	sel.innerHTML = '';
	awSamples().forEach(function(s, i) {
		var o = document.createElement('option');
		o.value = String(i);
		o.textContent = s.label;
		sel.appendChild(o);
	});
}

function awRender() {
	var t = Aw.tpl, stage = awEl('AwStage'), wrap = awEl('AwStageWrap');
	var zoom = parseFloat(awEl('AwZoom').value) || 0;
	// ianseo のメニューを出したまま、ページを下へスクロールしなくても用紙全体が見えるように、画面の下端までの高さに収める
	// それでもページがはみ出したら（ianseo の枠の余白など）、はみ出した分だけ縮めてもう一度合わせる
	var wide = window.matchMedia('(min-width: 1101px)').matches;
	var over = 0;
	for(var pass = 0; pass < 3; pass++) {
		var availH = Math.max(200, awAvailHeight(wrap) - over);
		wrap.style.maxHeight = availH + 'px';
		['AwPaneL', 'AwSide'].forEach(function(id) {
			awEl(id).style.maxHeight = Math.max(200, awAvailHeight(awEl(id)) - over) + 'px';
		});
		var k = zoom || Math.max(0.5, Math.min((wrap.clientWidth - 12) / t.paper.width, (availH - 12) / t.paper.height));
		Aw.k = k;
		stage.style.width = (t.paper.width * k) + 'px';
		stage.style.height = (t.paper.height * k) + 'px';
		var extra = document.documentElement.scrollHeight - window.innerHeight;
		if(!wide || extra <= 0) {
			break;
		}
		over += extra;
	}
	var img = awEl('AwPaperImg');
	var src = t.paper.image ? 'Image.php?f=' + encodeURIComponent(t.paper.image) : '';
	if(img.getAttribute('src') !== src) {
		if(src) {
			img.setAttribute('src', src);
		} else {
			img.removeAttribute('src');
		}
	}
	stage.classList.toggle('AwNoPaper', !src || !awEl('AwShowPaper').checked);
	stage.classList.toggle('AwHideFrames', !awEl('AwShowFrames').checked);

	Array.prototype.slice.call(stage.querySelectorAll('.AwBox')).forEach(function(b) {
		b.remove();
	});
	var values = awValues();
	t.items.forEach(function(it, i) {
		stage.appendChild(awBox(it, i, values));
	});
	awRenderList();
}

// 1 つの項目だけ描き直す（大きさや文字を変えたとき）。ドラッグ中の捕捉が切れないように、枠の要素はそのまま使う
function awRenderItem(i) {
	var box = awEl('AwStage').querySelector('.AwBox[data-i="' + i + '"]');
	if(box) {
		awFillBox(box, Aw.tpl.items[i], i, awValues());
	}
}

function awBox(it, i, values) {
	var box = document.createElement('div');
	box.dataset.i = i;
	box.addEventListener('pointerdown', awPointerDown);
	awFillBox(box, it, i, values);
	return box;
}

function awFillBox(box, it, i, values) {
	var k = Aw.k, t = Aw.tpl;
	box.innerHTML = '';
	box.className = 'AwBox' + (awIsSel(i) ? ' AwSel' : '') + (it.type === 'image' && it.multiply ? ' AwMultiply' : '');
	box.style.left = (it.x * k) + 'px';
	box.style.top = (it.y * k) + 'px';
	box.style.width = (it.w * k) + 'px';
	box.style.height = (it.h * k) + 'px';
	box.style.zIndex = i + 1;

	if(it.type === 'image') {
		if(it.image) {
			var im = document.createElement('img');
			im.src = 'Image.php?f=' + encodeURIComponent(it.image);
			im.alt = '';
			box.appendChild(im);
		}
	} else if(!(it.skipEmpty && awHasEmptyValue(it.text, values))) {
		var dir = it.dir || t.direction;
		var text = awKanjiText(awSubstitute(it.text, values), it.kanji);
		if(it.zenkaku) {
			text = awZenkaku(text);
		}
		var fi = awFontIndex(it.font || t.font);
		// PDF と同じく、文字の枠（上端からベースラインまで asc 文字分）の上端が g.y になるように置く
		var asc = AwConfig.fontAsc[fi] || 0.88, cssBase = awCssBaseline(fi);
		awLayout(it, dir, text, awMeasurer(fi)).forEach(function(g) {
			var sp = document.createElement('span');
			var shift = (asc - cssBase) * g.s;
			sp.className = 'AwGlyph';
			sp.textContent = g.ch;
			sp.style.left = ((g.x - it.x) * k) + 'px';
			sp.style.top = ((g.y - it.y + shift) * k) + 'px';
			sp.style.fontSize = (g.s * k) + 'px';
			sp.style.fontFamily = awFontFamily(fi);
			sp.style.color = it.color;
			if(g.rot) {
				// PDF と同じく、文字の枠の中央に置いてから、枠の中心で右に 90 度回す
				sp.style.width = (g.s * k) + 'px';
				sp.style.textAlign = 'center';
				sp.style.transform = 'rotate(90deg)';
				// 文字の枠の中心（箱の中心から shift だけ上）で回す
				sp.style.transformOrigin = '50% ' + ((g.s / 2 - shift) * k) + 'px';
			} else if(g.sx !== 1) {
				// 横に縮めた文字
				sp.style.transform = 'scaleX(' + g.sx + ')';
				sp.style.transformOrigin = '0 0';
			}
			box.appendChild(sp);
		});
	}

	var lb = document.createElement('div');
	lb.className = 'AwLabel';
	lb.textContent = it.label || (it.type === 'image' ? '画像' : 'テキスト');
	box.appendChild(lb);
	var hd = document.createElement('div');
	// 縦書きは右上から書き始めるので、大きさを変えるつまみは左下に置く（右端と上端を動かさない）
	hd.className = 'AwHandle' + (it.type === 'text' && (it.dir || t.direction) === 'vertical' ? ' AwHandleL' : '');
	box.appendChild(hd);
}

function awRenderList() {
	var ul = awEl('AwItems');
	ul.innerHTML = '';
	Aw.tpl.items.forEach(function(it, i) {
		var li = document.createElement('li');
		li.className = awIsSel(i) ? 'AwSel' : '';
		var a = document.createElement('span');
		a.textContent = (it.type === 'image' ? '🖼 ' : '') + (it.label || (it.type === 'image' ? '画像' : 'テキスト'));
		var b = document.createElement('span');
		b.className = 'AwItemText';
		b.textContent = it.type === 'image' ? (it.image ? '' : '（画像なし）') : it.text.replace(/\n/g, ' ／ ');
		li.appendChild(a);
		li.appendChild(b);
		li.onclick = function(e) {
			if(e.shiftKey || e.ctrlKey || e.metaKey) {
				awToggleSel(i);
			} else {
				awSelect(i);
			}
		};
		ul.appendChild(li);
	});
}

/* ---------------------------------------------------------------- 選択とドラッグ */

function awIsSel(i) {
	return Aw.multi.indexOf(i) >= 0;
}

// 選んでいる項目を入れ替える。1 つなら通常の選択（プロパティを出す）、2 つ以上なら複数選択（配置のボタンを出す）
function awSelectMany(list) {
	var n = Aw.tpl.items.length;
	list = list.filter(function(i, k) {
		return i >= 0 && i < n && list.indexOf(i) === k;
	}).sort(function(a, b) {
		return a - b;
	});
	Aw.multi = list;
	Aw.sel = list.length === 1 ? list[0] : -1;
	Array.prototype.forEach.call(document.querySelectorAll('.AwBox'), function(b) {
		b.classList.toggle('AwSel', awIsSel(parseInt(b.dataset.i, 10)));
	});
	Array.prototype.forEach.call(awEl('AwItems').children, function(li, j) {
		li.classList.toggle('AwSel', awIsSel(j));
	});
	awEl('AwStage').classList.toggle('AwMultiSel', list.length > 1);
	awFillItemProps();
}

function awSelect(i) {
	awSelectMany(i >= 0 ? [i] : []);
}

// Shift / Ctrl（Mac は Command）を押しながら押した項目を、選択に足す・外す
function awToggleSel(i) {
	var list = Aw.multi.slice(), k = list.indexOf(i);
	if(k >= 0) {
		list.splice(k, 1);
	} else {
		list.push(i);
	}
	awSelectMany(list);
}

function awPointerDown(e) {
	if(e.button !== 0) {
		return;
	}
	var box = e.currentTarget;
	var i = parseInt(box.dataset.i, 10);
	var collapse = false;
	if(e.shiftKey || e.ctrlKey || e.metaKey) {
		// 選択に足す・外す。外したときは、動かさない
		awToggleSel(i);
		if(!awIsSel(i)) {
			e.preventDefault();
			e.stopPropagation();
			return;
		}
	} else if(Aw.multi.length > 1 && awIsSel(i)) {
		// 複数選んでいるうちの 1 つ: そのままみんなで動かす。動かさずに離したら、この 1 つだけを選ぶ
		collapse = true;
	} else if(!(Aw.multi.length === 1 && Aw.multi[0] === i)) {
		awSelect(i);
	}
	var it = Aw.tpl.items[i];
	var single = Aw.multi.length === 1;
	Aw.drag = {
		i: i,
		group: Aw.multi.slice(),
		starts: Aw.multi.map(function(k) {
			return {x: Aw.tpl.items[k].x, y: Aw.tpl.items[k].y};
		}),
		collapse: collapse,
		resize: single && e.target.classList.contains('AwHandle'),
		left: single && e.target.classList.contains('AwHandleL'),
		sx: e.clientX, sy: e.clientY,
		x: it.x, y: it.y, w: it.w, h: it.h,
		moved: false
	};
	box.setPointerCapture(e.pointerId);
	box.addEventListener('pointermove', awPointerMove);
	box.addEventListener('pointerup', awPointerUp);
	box.addEventListener('pointercancel', awPointerUp);
	e.preventDefault();
	e.stopPropagation();
}

function awPointerMove(e) {
	var d = Aw.drag;
	if(!d) {
		return;
	}
	var dx = (e.clientX - d.sx) / Aw.k, dy = (e.clientY - d.sy) / Aw.k;
	if(!d.moved && Math.abs(e.clientX - d.sx) < 2 && Math.abs(e.clientY - d.sy) < 2) {
		return;
	}
	d.moved = true;
	var it = Aw.tpl.items[d.i];
	var box = e.currentTarget;
	if(d.resize) {
		if(d.left) {
			// 左下のつまみ: 右端はそのままで、左端を動かす
			it.w = Math.max(1, awRound(d.w - dx));
			it.x = awRound(d.x + d.w - it.w);
		} else {
			it.w = Math.max(1, awRound(d.w + dx));
		}
		it.h = Math.max(1, awRound(d.h + dy));
		if(!Aw.raf) {
			Aw.raf = requestAnimationFrame(function() {
				Aw.raf = 0;
				if(Aw.drag) {
					awRenderItem(Aw.drag.i);
				}
			});
		}
	} else {
		// 選んでいる項目をみんなで動かす
		d.group.forEach(function(k, n) {
			var m = Aw.tpl.items[k];
			m.x = awRound(d.starts[n].x + dx);
			m.y = awRound(d.starts[n].y + dy);
			var b = document.querySelector('.AwBox[data-i="' + k + '"]');
			if(b) {
				b.style.left = (m.x * Aw.k) + 'px';
				b.style.top = (m.y * Aw.k) + 'px';
			}
		});
	}
	if(d.group.length === 1) {
		awFillItemProps(true);
	}
}

function awPointerUp(e) {
	var box = e.currentTarget;
	box.removeEventListener('pointermove', awPointerMove);
	box.removeEventListener('pointerup', awPointerUp);
	box.removeEventListener('pointercancel', awPointerUp);
	if(Aw.drag && Aw.drag.moved) {
		Aw.drag.group.forEach(awRenderItem);
		awSetDirty();
	} else if(Aw.drag && Aw.drag.collapse) {
		awSelect(Aw.drag.i);
	}
	Aw.drag = null;
}

/* 用紙の何もないところをドラッグして、枠で囲んだ項目をまとめて選ぶ（Shift / Ctrl を押していれば、いまの選択に足す） */
function awStageDown(e) {
	var stage = awEl('AwStage');
	if(e.button !== 0 || (e.target !== stage && e.target !== awEl('AwPaperImg'))) {
		return;
	}
	var r = stage.getBoundingClientRect();
	var additive = e.shiftKey || e.ctrlKey || e.metaKey;
	Aw.marquee = {x0: e.clientX - r.left, y0: e.clientY - r.top, x1: e.clientX - r.left, y1: e.clientY - r.top, additive: additive, base: additive ? Aw.multi.slice() : [], moved: false, el: null};
	stage.setPointerCapture(e.pointerId);
	stage.addEventListener('pointermove', awStageMove);
	stage.addEventListener('pointerup', awStageUp);
	stage.addEventListener('pointercancel', awStageUp);
	e.preventDefault();
}

function awStageMove(e) {
	var m = Aw.marquee, stage = awEl('AwStage');
	if(!m) {
		return;
	}
	var r = stage.getBoundingClientRect();
	m.x1 = e.clientX - r.left;
	m.y1 = e.clientY - r.top;
	if(!m.moved && Math.abs(m.x1 - m.x0) < 3 && Math.abs(m.y1 - m.y0) < 3) {
		return;
	}
	m.moved = true;
	if(!m.el) {
		m.el = document.createElement('div');
		m.el.className = 'AwMarquee';
		stage.appendChild(m.el);
	}
	var L = Math.min(m.x0, m.x1), T = Math.min(m.y0, m.y1), R = Math.max(m.x0, m.x1), B = Math.max(m.y0, m.y1);
	m.el.style.left = L + 'px';
	m.el.style.top = T + 'px';
	m.el.style.width = (R - L) + 'px';
	m.el.style.height = (B - T) + 'px';
	// 枠にかかっている項目を選ぶ
	var hit = [];
	Aw.tpl.items.forEach(function(it, i) {
		if(it.x * Aw.k < R && (it.x + it.w) * Aw.k > L && it.y * Aw.k < B && (it.y + it.h) * Aw.k > T) {
			hit.push(i);
		}
	});
	awSelectMany(m.base.concat(hit));
}

function awStageUp(e) {
	var m = Aw.marquee, stage = awEl('AwStage');
	stage.removeEventListener('pointermove', awStageMove);
	stage.removeEventListener('pointerup', awStageUp);
	stage.removeEventListener('pointercancel', awStageUp);
	if(m) {
		if(m.el) {
			m.el.remove();
		} else if(!m.additive) {
			// 動かさずに離した: 選択をやめる
			awSelect(-1);
		}
	}
	Aw.marquee = null;
}

function awKeyDown(e) {
	if(!Aw.multi.length) {
		return;
	}
	var tag = (e.target.tagName || '').toLowerCase();
	if(tag === 'input' || tag === 'textarea' || tag === 'select') {
		return;
	}
	var step = e.shiftKey ? 5 : (e.altKey ? 0.1 : 0.5);
	var moves = {ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step]};
	if(moves[e.key]) {
		// 選んでいる項目をみんな動かす
		Aw.multi.forEach(function(k) {
			var it = Aw.tpl.items[k];
			it.x = awRound(it.x + moves[e.key][0]);
			it.y = awRound(it.y + moves[e.key][1]);
			awRenderItem(k);
		});
		if(Aw.multi.length === 1) {
			awFillItemProps(true);
		}
		awSetDirty();
		e.preventDefault();
	} else if(e.key === 'Delete') {
		awDeleteItem();
		e.preventDefault();
	}
}

/* ---------------------------------------------------------------- 右の欄 */

function awGetPath(obj, path) {
	return path.split('.').reduce(function(o, k) {
		return o ? o[k] : undefined;
	}, obj);
}

function awSetPath(obj, path, v) {
	var ks = path.split('.'), last = ks.pop();
	ks.reduce(function(o, k) {
		return o[k];
	}, obj)[last] = v;
}

function awInputValue(el) {
	if(el.type === 'checkbox') {
		return el.checked;
	}
	if(el.type === 'number') {
		var v = parseFloat(el.value);
		return isNaN(v) ? 0 : v;
	}
	return el.value;
}

function awSetInput(el, v) {
	if(el.type === 'checkbox') {
		el.checked = !!v;
	} else if(el.type === 'radio') {
		el.checked = (el.value === String(v));
	} else {
		el.value = (v === undefined || v === null) ? '' : v;
	}
}

function awFillTplProps() {
	Array.prototype.forEach.call(document.querySelectorAll('[data-tpl]'), function(el) {
		awSetInput(el, awGetPath(Aw.tpl, el.dataset.tpl));
	});
	awEl('AwCustomSize').style.display = Aw.tpl.paper.size === 'custom' ? '' : 'none';
}

// Lib.php の awNormalizeTemplate と同じく、用紙の大きさを決める
function awPaperDims() {
	var p = Aw.tpl.paper, w, h;
	if(AwConfig.papers[p.size]) {
		w = AwConfig.papers[p.size][0];
		h = AwConfig.papers[p.size][1];
	} else {
		p.size = 'custom';
		w = Math.min(p.width, p.height) || 210;
		h = Math.max(p.width, p.height) || 297;
	}
	if(p.orientation === 'L') {
		p.width = h;
		p.height = w;
	} else {
		p.width = w;
		p.height = h;
	}
}

function awTplChanged(e) {
	var el = e.target;
	if(el.type === 'radio' && !el.checked) {
		return;
	}
	awSetPath(Aw.tpl, el.dataset.tpl, awInputValue(el));
	if(el.dataset.tpl.indexOf('paper.') === 0 && el.dataset.tpl.indexOf('offset') < 0) {
		awPaperDims();
		awFillTplProps();
	}
	awSetDirty();
	if(el.dataset.tpl === 'direction') {
		awFillItemProps();
	}
	if(el.dataset.tpl === 'source') {
		// 順位のもとを変えたら、見本も切り替える
		awFillSamples();
	}
	if(el.dataset.tpl !== 'name' && el.dataset.tpl !== 'note') {
		awRender();
	}
}

function awAlignLabels() {
	var it = Aw.tpl.items[Aw.sel];
	var vertical = ((it && it.dir) || Aw.tpl.direction) === 'vertical';
	var main = vertical ? {start: '上から', center: '中央', end: '下に寄せる', justify: '均等割り付け'} : {start: '左から', center: '中央', end: '右に寄せる', justify: '均等割り付け'};
	var cross = vertical ? {start: '右から', center: '中央', end: '左に寄せる'} : {start: '上から', center: '中央', end: '下に寄せる'};
	[['AwAlign', main], ['AwCross', cross]].forEach(function(a) {
		var sel = awEl(a[0]);
		sel.innerHTML = '';
		Object.keys(a[1]).forEach(function(v) {
			var o = document.createElement('option');
			o.value = v;
			o.textContent = a[1][v];
			sel.appendChild(o);
		});
	});
}

// $onlyPos: ドラッグ中は位置と大きさだけ入れ直す
function awFillItemProps(onlyPos) {
	var it = Aw.tpl.items[Aw.sel];
	var box = awEl('AwItemProps');
	var many = Aw.multi.length > 1;
	// 2 つ以上選んでいるときは、プロパティの代わりに、配置と均等配置のボタンを出す
	awEl('AwSingleProps').style.display = many ? 'none' : '';
	awEl('AwMultiProps').style.display = many ? '' : 'none';
	box.style.display = (it || many) ? '' : 'none';
	if(many) {
		awEl('AwMultiCount').textContent = '（' + Aw.multi.length + ' 個を選んでいます）';
		Array.prototype.forEach.call(box.querySelectorAll('[data-dist]'), function(b) {
			b.disabled = Aw.multi.length < 3;
			b.title = Aw.multi.length < 3 ? '3 つ以上選ぶと使えます' : (b.dataset.dist === 'h' ? '左右の間隔をそろえる' : '上下の間隔をそろえる');
		});
		return;
	}
	if(!it) {
		return;
	}
	if(!onlyPos) {
		awAlignLabels();
	}
	box.querySelector('.AwForText').style.display = it.type === 'text' ? '' : 'none';
	box.querySelector('.AwForImage').style.display = it.type === 'image' ? '' : 'none';
	Array.prototype.forEach.call(box.querySelectorAll('[data-it]'), function(el) {
		var p = el.dataset.it;
		if(onlyPos && ['x', 'y', 'w', 'h'].indexOf(p) < 0) {
			return;
		}
		if(it[p] !== undefined) {
			awSetInput(el, it[p]);
		}
	});
	Array.prototype.forEach.call(box.querySelectorAll('[data-kanji]'), function(el) {
		el.checked = (it.kanji === el.dataset.kanji);
	});
	awUpdateHorizontalOnly();
}

// 文字の幅と「横に縮めて収める（長体）」は、横書きのときだけ使える（縦書きのときは選べなくする）
function awUpdateHorizontalOnly() {
	var it = Aw.tpl.items[Aw.sel];
	var vertical = !!it && ((it.dir || Aw.tpl.direction) === 'vertical');
	[['AwStretchBox', 'stretch'], ['AwSqueezeBox', 'squeeze']].forEach(function(a) {
		var box = awEl(a[0]);
		var input = box.querySelector('[data-it=' + a[1] + ']');
		input.disabled = vertical;
		box.style.opacity = vertical ? '0.45' : '';
		box.title = vertical ? '横書きのときだけ使えます' : '';
	});
}

// 漢数字にする（一〇方式／十方式）はどちらか一方だけ
function awKanjiChanged(e) {
	var it = Aw.tpl.items[Aw.sel];
	if(!it) {
		return;
	}
	it.kanji = e.target.checked ? e.target.dataset.kanji : '';
	Array.prototype.forEach.call(document.querySelectorAll('[data-kanji]'), function(el) {
		el.checked = (it.kanji === el.dataset.kanji);
	});
	awRenderItem(Aw.sel);
	awSetDirty();
}

function awItemChanged(e) {
	var el = e.target, it = Aw.tpl.items[Aw.sel];
	if(!it) {
		return;
	}
	var p = el.dataset.it;
	var v = awInputValue(el);
	if(['w', 'h', 'size', 'stretch'].indexOf(p) >= 0 && v <= 0) {
		return;
	}
	if(p === 'stretch') {
		// 10〜500%（入力欄の文字はそのままにして、使う値だけ範囲に収める）
		v = Math.max(10, Math.min(500, v));
	}
	var oldDir = it.dir || Aw.tpl.direction;
	it[p] = v;
	if(p === 'dir') {
		// 縦書きと横書きを変えたら、枠の縦横も入れ替える
		var newDir = it.dir || Aw.tpl.direction;
		if(oldDir !== newDir && ((newDir === 'horizontal') === (it.h > it.w))) {
			var w = it.w;
			it.w = it.h;
			it.h = w;
			awFillItemProps(true);
		}
		awAlignLabels();
		awSetInput(awEl('AwAlign'), it.align);
		awSetInput(awEl('AwCross'), it.cross);
		awUpdateHorizontalOnly();
	}
	awRenderItem(Aw.sel);
	if(p === 'label' || p === 'text') {
		awRenderList();
	}
	awSetDirty();
}

function awInsertPlaceholder(name) {
	var ta = document.querySelector('#AwItemProps textarea[data-it=text]');
	var s = ta.selectionStart || 0, e = ta.selectionEnd || 0, ins = '{' + name + '}';
	ta.value = ta.value.substring(0, s) + ins + ta.value.substring(e);
	ta.focus();
	ta.selectionStart = ta.selectionEnd = s + ins.length;
	ta.dispatchEvent(new Event('input', {bubbles: true}));
}

/* ---------------------------------------------------------------- 項目の追加・削除 */

function awNewPos(w, h) {
	var p = Aw.tpl.paper;
	return {x: awRound((p.width - w) / 2), y: awRound((p.height - h) / 2), w: w, h: h};
}

function awAddText() {
	var vertical = Aw.tpl.direction === 'vertical';
	var pos = vertical ? awNewPos(10, 80) : awNewPos(120, 12);
	Aw.tpl.items.push(Object.assign({
		type: 'text', label: 'テキスト', text: '{氏名}', size: 24, dir: '', align: 'start', cross: 'start',
		lineHeight: 1.5, spacing: 0, fit: true, zenkaku: vertical, skipEmpty: true, wrap: false, squeeze: false, stretch: 100, kanji: '', font: '', color: '#000000'
	}, pos));
	awSetDirty();
	awRender();
	awSelect(Aw.tpl.items.length - 1);
}

function awAddImage() {
	Aw.tpl.items.push(Object.assign({type: 'image', label: '公印', image: '', multiply: true}, awNewPos(25, 25)));
	awSetDirty();
	awRender();
	awSelect(Aw.tpl.items.length - 1);
	awEl('AwItemFile').click();
}

function awDeleteItem() {
	var list = Aw.multi.slice();
	if(!list.length) {
		return;
	}
	var it = Aw.tpl.items[list[0]];
	if(!confirm((list.length === 1 ? '「' + (it.label || '項目') + '」' : list.length + ' 個の項目') + 'を削除しますか？')) {
		return;
	}
	// 番号がずれないように、後ろから消す
	list.sort(function(a, b) {
		return b - a;
	}).forEach(function(i) {
		Aw.tpl.items.splice(i, 1);
	});
	awSetDirty();
	awRender();
	awSelect(-1);
}

function awCopyItem() {
	var list = Aw.multi.slice();
	if(!list.length) {
		return;
	}
	var made = [];
	list.forEach(function(i) {
		var c = JSON.parse(JSON.stringify(Aw.tpl.items[i]));
		c.x = awRound(c.x + 5);
		c.y = awRound(c.y + 5);
		c.label = (c.label || '') + ' のコピー';
		Aw.tpl.items.push(c);
		made.push(Aw.tpl.items.length - 1);
	});
	awSetDirty();
	awRender();
	awSelectMany(made);
}

/* ---------------------------------------------------------------- 配置（2 つ以上選んでいるとき） */

// 選んでいる項目の枠全体（いちばん左・右・上・下）にそろえる
function awAlign(kind) {
	var items = Aw.multi.map(function(i) {
		return Aw.tpl.items[i];
	});
	if(items.length < 2) {
		return;
	}
	var minX = Math.min.apply(null, items.map(function(m) { return m.x; }));
	var maxR = Math.max.apply(null, items.map(function(m) { return m.x + m.w; }));
	var minY = Math.min.apply(null, items.map(function(m) { return m.y; }));
	var maxB = Math.max.apply(null, items.map(function(m) { return m.y + m.h; }));
	items.forEach(function(m) {
		if(kind === 'left') {
			m.x = awRound(minX);
		} else if(kind === 'hcenter') {
			m.x = awRound((minX + maxR) / 2 - m.w / 2);
		} else if(kind === 'right') {
			m.x = awRound(maxR - m.w);
		} else if(kind === 'top') {
			m.y = awRound(minY);
		} else if(kind === 'vcenter') {
			m.y = awRound((minY + maxB) / 2 - m.h / 2);
		} else if(kind === 'bottom') {
			m.y = awRound(maxB - m.h);
		}
	});
	Aw.multi.forEach(awRenderItem);
	awSetDirty();
}

// 両端の項目は動かさず、間の項目を等間隔にする（水平: 左右の間隔、垂直: 上下の間隔）
function awDistribute(axis) {
	var pos = axis === 'h' ? 'x' : 'y', size = axis === 'h' ? 'w' : 'h';
	var items = Aw.multi.map(function(i) {
		return Aw.tpl.items[i];
	}).sort(function(a, b) {
		return a[pos] - b[pos];
	});
	var n = items.length;
	if(n < 3) {
		return;
	}
	var start = items[0][pos], end = items[n - 1][pos] + items[n - 1][size];
	var total = items.reduce(function(s, m) {
		return s + m[size];
	}, 0);
	var gap = (end - start - total) / (n - 1), cur = start;
	items.forEach(function(m) {
		m[pos] = awRound(cur);
		cur += m[size] + gap;
	});
	Aw.multi.forEach(awRenderItem);
	awSetDirty();
}

function awMoveItem(d) {
	var i = Aw.sel, j = i + d, items = Aw.tpl.items;
	if(i < 0 || j < 0 || j >= items.length) {
		return;
	}
	var t = items[i];
	items[i] = items[j];
	items[j] = t;
	Aw.sel = j;
	awSetDirty();
	awRender();
	awSelect(j);
}

/* ---------------------------------------------------------------- 画像 */

function awUpload(file, done) {
	var fd = new FormData();
	fd.append('act', 'upload');
	fd.append('AwToken', AwConfig.token);
	fd.append('file', file);
	fetch(awEl('AwSaveForm').action, {method: 'POST', body: fd, credentials: 'same-origin'})
		.then(function(r) {
			return r.json();
		})
		.then(function(j) {
			if(j.error) {
				alert(j.error);
				return;
			}
			Aw.imgSize[j.file] = [j.width, j.height];
			done(j);
		})
		.catch(function() {
			alert('画像を送れませんでした。');
		});
}

function awUploadPaper(input) {
	if(!input.files.length) {
		return;
	}
	awUpload(input.files[0], function(j) {
		Aw.tpl.paper.image = j.file;
		var pr = Aw.tpl.paper.width / Aw.tpl.paper.height, ir = j.width / j.height;
		if(Math.abs(pr - ir) / pr > 0.03) {
			alert('画像の縦横比（' + j.width + '×' + j.height + '）が用紙の大きさと合っていません。用紙の大きさを確かめるか、用紙の端で切り抜いた画像にしてください。');
		}
		awSetDirty();
		awRender();
	});
	input.value = '';
}

function awRemovePaper() {
	Aw.tpl.paper.image = '';
	awSetDirty();
	awRender();
}

function awUploadItemImage(input) {
	var it = Aw.tpl.items[Aw.sel];
	if(!input.files.length || !it || it.type !== 'image') {
		return;
	}
	var i = Aw.sel;
	awUpload(input.files[0], function(j) {
		it.image = j.file;
		it.h = awRound(it.w * j.height / j.width);
		awSetDirty();
		awRenderItem(i);
		awRenderList();
		awFillItemProps();
	});
	input.value = '';
}

function awImageRatio() {
	var it = Aw.tpl.items[Aw.sel];
	if(!it || !it.image) {
		return;
	}
	var set = function(sz) {
		it.h = awRound(it.w * sz[1] / sz[0]);
		awSetDirty();
		awRenderItem(Aw.sel);
		awFillItemProps(true);
	};
	if(Aw.imgSize[it.image]) {
		set(Aw.imgSize[it.image]);
		return;
	}
	var im = new Image();
	im.onload = function() {
		Aw.imgSize[it.image] = [im.naturalWidth, im.naturalHeight];
		set(Aw.imgSize[it.image]);
	};
	im.src = 'Image.php?f=' + encodeURIComponent(it.image);
}

/* ---------------------------------------------------------------- 保存 */

function awSetDirty() {
	Aw.dirty = true;
}

function awSave() {
	var f = awEl('AwSaveForm');
	f.Template.value = JSON.stringify(Aw.tpl);
	Aw.dirty = false;
	f.submit();
}

function awPreviewPdf(withPaper) {
	var f = awEl('AwPreviewForm');
	f.Template.value = JSON.stringify(Aw.tpl);
	f.sample.value = awEl('AwSample').value;
	f.withPaper.value = withPaper ? '1' : '';
	awFocusPreview();
	f.submit();
}

// PDF は、いつも同じ名前（preview）のウィンドウに開く。すでに開いていれば、そのウィンドウを前に出す
function awFocusPreview() {
	var w = window.open('', 'preview');
	if(w) {
		w.focus();
	}
}

/* ---------------------------------------------------------------- 初期化 */

function awEditorInit() {
	Aw.tpl = JSON.parse(JSON.stringify(AwConfig.template));

	var fill = function(sel, list, first) {
		if(first) {
			var o0 = document.createElement('option');
			o0.value = '';
			o0.textContent = first;
			sel.appendChild(o0);
		}
		list.forEach(function(v) {
			var o = document.createElement('option');
			o.value = v[0];
			o.textContent = v[1];
			sel.appendChild(o);
		});
	};
	fill(awEl('AwPaperSize'), Object.keys(AwConfig.papers).map(function(k) {
		return [k, k + '（' + AwConfig.papers[k][0] + '×' + AwConfig.papers[k][1] + 'mm）'];
	}).concat([['custom', '大きさを入れる']]));
	fill(awEl('AwFont'), AwConfig.fonts.map(function(f) {
		return [f, f];
	}));
	fill(awEl('AwItemFont'), AwConfig.fonts.map(function(f) {
		return [f, f];
	}), 'テンプレートと同じ');
	fill(awEl('AwSource'), Object.keys(AwConfig.sources).map(function(k) {
		return [k, AwConfig.sources[k]];
	}));
	awFillSamples();

	var ph = awEl('AwPhList');
	Object.keys(AwConfig.placeholders).forEach(function(k) {
		var b = document.createElement('span');
		b.className = 'AwPh';
		b.textContent = '{' + k + '}';
		b.title = AwConfig.placeholders[k] || k;
		b.onclick = function() {
			awInsertPlaceholder(k);
		};
		ph.appendChild(b);
	});

	// 数値は入れ終わってから（打っている途中で用紙の大きさを直してしまわないように）
	Array.prototype.forEach.call(document.querySelectorAll('[data-tpl]'), function(el) {
		el.addEventListener(el.type === 'radio' || el.type === 'number' || el.tagName === 'SELECT' ? 'change' : 'input', awTplChanged);
	});
	Array.prototype.forEach.call(document.querySelectorAll('[data-it]'), function(el) {
		el.addEventListener(el.type === 'checkbox' || el.tagName === 'SELECT' ? 'change' : 'input', awItemChanged);
	});
	Array.prototype.forEach.call(document.querySelectorAll('[data-kanji]'), function(el) {
		el.addEventListener('change', awKanjiChanged);
	});
	awEl('AwStage').addEventListener('pointerdown', awStageDown);
	Array.prototype.forEach.call(document.querySelectorAll('[data-align]'), function(b) {
		b.addEventListener('click', function() {
			awAlign(b.dataset.align);
		});
	});
	Array.prototype.forEach.call(document.querySelectorAll('[data-dist]'), function(b) {
		b.addEventListener('click', function() {
			awDistribute(b.dataset.dist);
		});
	});
	document.addEventListener('keydown', awKeyDown);
	// 画像やメニューを読み終えて位置が変わったら、合わせ直す
	window.addEventListener('load', function() {
		if(!(parseFloat(awEl('AwZoom').value) > 0)) {
			awRender();
		}
	});
	window.addEventListener('resize', function() {
		if(!(parseFloat(awEl('AwZoom').value) > 0)) {
			awRender();
		}
	});
	window.addEventListener('beforeunload', function(e) {
		if(Aw.dirty) {
			e.preventDefault();
			e.returnValue = '';
		}
	});

	awFillTplProps();
	awRender();
	awSelect(-1);
	awLoadFonts();
}

if(window.AwConfig) {
	document.addEventListener('DOMContentLoaded', awEditorInit);
}
