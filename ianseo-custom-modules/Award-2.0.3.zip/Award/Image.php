<?php
/*
data/images に入れた画像（賞状用紙・公印）を表示する。
data/ は .htaccess で直接開けないようにしているので、ianseo にログインしている人にだけ、ここを通して見せる。

変更履歴:
2026/09/26 初版
*/
require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php
require_once(__DIR__ . '/Lib.php');

if(!awCanView()) {
	http_response_code(403);
	exit;
}

$File = awImagePath($_GET['f'] ?? '');
if(!$File or !is_file($File)) {
	http_response_code(404);
	exit;
}

// 名前は中身のハッシュなので、同じ名前なら中身も同じ
header('Content-Type: ' . (substr($File, -4) == '.png' ? 'image/png' : 'image/jpeg'));
header('Content-Length: ' . filesize($File));
header('Cache-Control: private, max-age=31536000, immutable');
header('X-Content-Type-Options: nosniff');
readfile($File);
