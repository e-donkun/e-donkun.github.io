5<?php

	define('debug',false);
	define('IN_PHP', true);

	require_once(dirname(dirname(__FILE__)) . '/config.php');

	require_once('Common/Fun_FormatText.inc.php');
	require_once('TV/Fun_HTML.local.inc.php');
    require_once('Common/Lib/CommonLib.php');
	require_once('Common/Lib/ArrTargets.inc.php');


	if (empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		
		//printCrackError();
		$Select	= "SELECT ToId,ToCode,ToName,ToWhere 
		FROM Tournament 
		ORDER BY ToWhenTo DESC, ToWhenFrom DESC, ToCode ASC";
		$Rs=safe_r_sql($Select);
		include('Common/Templates/head-min.php');
		echo "<table>";
		if (safe_num_rows($Rs)>0) {
			echo '<tr>
				<th class="Title w-5">&nbsp;</th>
				<th class="Title w-10">'.get_text('TourCode','Tournament').'</th>
				<th class="Title w-30">'.get_text('TourName','Tournament').'</th>
				<th class="Title w-20">'.get_text('TourWhere','Tournament').'</th>
				</tr>';
			while ($MyRow=safe_fetch($Rs)) {
				print '<tr>';
				print '<td><a class="Link" href="?Tour=' . $MyRow->ToCode . '">' . get_text('Open') . '</a></td>';
				print '<td>' . $MyRow->ToCode . '</td>';
				print '<td>' . ManageHTML($MyRow->ToName) . '</td>';
				print '<td>' . ManageHTML($MyRow->ToWhere) . '</td>';
				print '</tr>';
			}
		}
		echo '</table>';
		include('Common/Templates/tail-min-min.php');
		die();
	}


	$TourCode=stripslashes($_REQUEST['Tour']);
	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
  //checkFullACL(AclOutput,'outTv', AclReadOnly,true, $TourId);
	
  if(! ($TourId > 0) ){
    include('Common/Templates/head-min.php');
    echo "error!";
    include('Common/Templates/tail-min-min.php');
    die();
  }
    
	$tmpSel='';
	for ($i=1; $i<=2; $i++) {
		$tmpSel .= "QuD{$i}Score, QuD{$i}Hits, QuD{$i}Gold, QuD{$i}Xnine, QuD{$i}ArrowString, Td{$i},";
	}
		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,
			CoCode,CoName,
			QuTargetNo, QuTarget, SUBSTRING(QuTargetNo,2) AS Target,
			$tmpSel
			QuScore, QuGold, QuXnine,
			ToId,ToGolds AS GoldLabel, ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
		  DivDescription,ClDescription,
		  ToName,ToWhere,ToWhenFrom,ToWhenTo,ToCode,
		  QuIrmType
		FROM Entries 
		INNER JOIN Qualifications ON EnId=QuId 
		LEFT JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament 
		LEFT JOIN Tournament ON EnTournament=ToId
		LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType

    INNER JOIN Divisions ON DivTournament=ToId AND DivId=EnDivision    
    INNER JOIN Classes ON ClTournament=ToId AND ClId=EnClass
  	WHERE EnAthlete=1 AND ToId = {$TourId} AND CONCAT(EnDivision,EnClass) LIKE TdClasses";
	//var_dump($Select);
	$Rs=safe_r_sql($Select);

	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}
  
  
	usort($ArrayData, function($a, $b) {
    return $a['Class'] <=> $b['Class']             // Class は昇順
        ?: $b['QuScore'] <=> $a['QuScore']         // QuScore は降順
        ?: $b['QuGold'] <=> $a['QuGold']           // QuGold は降順
        ?: $b['QuXnine'] <=> $a['QuXnine'];        // QuXnine は降順

	});

  $Tour = $ArrayData[0];

	//include('Common/Templates/head-min.php');
	
	//echo "<pre>";var_dump($ArrayData[0]);echo "</pre>";
	
	echo <<<EOM
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, user-scalable=yes">
<title>{$Tour['ToName']} - {$Tour['ToWhere']} ({$Tour['ToWhenFrom']}) </title>
<script type="text/javascript" src="//webfonts.sakura.ne.jp/js/sakurav3.js"></script>
<style>
html{
   font-size:clamp(10px, 1.3vw, 18px);
   font-family:"UD新ゴ R";
	margin:1vmin;
}

.sticky {
  top: 0;
  left: 0;
}

thead {
  top: 0;
  left: 0;	
}

h1,h2{
  margin-bottom:0;
}
table{
  border-collapse:collapse;
  border-spacing: 0;
}

table th,table td{
  text-align: center;
  white-space:nowrap
}

table th{
  background-color: #c79852;
  color: white;
  border:solid 1px black;
  height:1.3em;
}

table td{
  border:solid 1px black;
  padding: 0.3em 0.5em;
}

td.name {
  font-weight:bold;
  min-width:7em;
}
td.score {
  background:#eee;
  font-weight:bold;
  width:3em;
}
td.goldx9 {
  width:2em;
}
td.s{
  /* display:inline-block; */
  width:1.5em;
  background:#eee;
  margin:1px;
 
}

.boldleft {
  border-left: 2px solid black !important;
}
.boldright {
  border-right: 2px solid black;
}
.doubleleft {
  border-left: 2px double black !important;
}

</style>
</head>
<body>
<h1>{$Tour['ToName']}</h1>
<div>会場:{$Tour['ToWhere']} (日程:{$Tour['ToWhenFrom']}
EOM;


  if($Tour['ToWhenFrom'] != $Tour['ToWhenTo']){
      echo "～{$Tour['ToWhenTo']}";
  }
  echo ")</div>";
  echo "<div class='table_box'>";
  
  $preClass = "";
	
	foreach($ArrayData as $Data){
		
		
	if($Data['QuIrmType']>0){
		$Data['QuScore']='欠';
		$Data['QuXnine']='';
		$Data['QuGold']='';
		$Data['QuD1Score']='';
		$Data['QuD2Score']='';


	}
    
    if($preClass != $Data['Class']){
      if($preClass != ""){
        echo "</table>";
      }
      echo "<h2>{$Data['DivDescription']}{$Data['ClDescription']}</h2>";      
      echo <<<EOM
<table>
<tr class="sticky">
	<th rowspan=2 class="boldleft">的番号</th>
	<th rowspan=2  style="width:4rem;">クラス</th>
	<th rowspan=2 class="sticky" style="width:10rem;">選手名</th>
	<th rowspan=2 class="boldright" style="width:12rem;">所属</th>
  <th colspan=3 class="boldright">総合成績</th>
  <th colspan=7 class="boldright">{$Data['Td1']}</th>    
  <th colspan=7 class="boldright">{$Data['Td2']}</th>
</tr>
<tr class="sticky">
	<th class="sticky boldleft">総合計</th>
	<th class="sticky">{$ArrayData[0]['GoldLabel']}</th>
	<th class="sticky boldright">{$ArrayData[0]['XNineLabel']}</th>
EOM;

      foreach([1,2,3,4,5,6] as $i){
        echo  "<th class='sticky'>{$i}</th>\n";
      }
      echo  "<th class='sticky doubleleft boldright'>合計</th>\n";
      foreach([1,2,3,4,5,6] as $i){
        echo  "<th class='sticky'>{$i}</th>\n";
      }
      echo  "<th class='sticky doubleleft boldright'>合計</th>\n";
      echo  "</tr>\n";
      

    }
		$preClass = $Data['Class'];
    
		$ArrayD1Score = [];
		foreach(str_split($Data['QuD1ArrowString'], 6) as $EndArrow){
			if($EndArrow!=="      "){
				$ArrayD1Score[] = ValutaArrowString($EndArrow);
			} else {
        $ArrayD1Score[] = "";
      }
		}
		$ArrayD2Score = [];
		foreach(str_split($Data['QuD2ArrowString'], 6) as $EndArrow){
			if($EndArrow!=="      "){
				$ArrayD2Score[] = ValutaArrowString($EndArrow);
			} else {
        $ArrayD2Score[] = "";
      }
		}
    
    $D1Score = "";
    $D2Score = "";
    for($i=0;$i<6;$i++){
      $D1Score .= "<td class='s'>".($ArrayD1Score[$i] ?? '')."</td>";
      $D2Score .= "<td class='s'>".($ArrayD2Score[$i] ?? '')."</td>";
    }
		
		echo <<<EOM
<tr>
	<th class="boldleft">{$Data['Target']}</th>
	<td>{$Data['Class']}</td>
EOM;
	
  $_Name = "{$Data['EnFirstName']}  {$Data['EnName']}";
  $_cnt = mb_strwidth($_Name);
  if($_cnt<18){
    $_size = 1;
  } else {
    $_size = 18/$_cnt;
  }
	echo "   <td class='boldright' data-size='{$_cnt}' style='text-align:left;width:10rem;'><div style='transform-origin: 0 0;transform:scale({$_size},1);max-width:10rem;'>{$_Name}</div></td>";;
  
  $_Name = $Data['CoName'];
  $_cnt = mb_strwidth($_Name);
  if($_cnt<20){
    $_size = 1;
  } else {
    $_size = 20/$_cnt;
  }
	echo "   <td class='boldright' data-size='{$_cnt}' style='text-align:left;width:12rem;'><div style='transform-origin: 0 0;transform:scale({$_size},1);max-width:12rem;'>{$_Name}</div></td>";
		echo <<<EOM
  <td class='score sticky'>{$Data['QuScore']}</td>
	<td class='goldx9'>{$Data['QuGold']}</td>
	<td class='goldx9 boldright'>{$Data['QuXnine']}</td>
  {$D1Score}
	<td class='score doubleleft boldright'>{$Data['QuD1Score']}</td>
  {$D2Score}
	<td class='score doubleleft boldright'>{$Data['QuD2Score']}</td>
</tr>
EOM;

	}
	echo "</table></div>";

	include('Common/Templates/tail-min.php');


