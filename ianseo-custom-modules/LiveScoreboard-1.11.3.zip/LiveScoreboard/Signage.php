<?php
/*
ライブ得点集計（LiveScoreboard.php）をサイネージ向けに表示する画面。

・大会名などの見出し部分は出さず、表だけを横幅いっぱいに並べる。
・止まらずに下へスクロールし続け、下まで来たら最初のブロックから下へ継ぎ足して、終わりなく流す。
・表は LiveScoreboard.php から読み込み直す（ページはリロードしない）。間隔は、ふだん 30 秒。
  内容が書き換わったら 5 秒ごとに縮め、5 秒ごとの読み込みを 3 回続けてどこも変わらなければ 30 秒に戻す
  （行射中はほとんど更新されず、採点中は随時更新されるため）。
  変わったマスは黄色く点滅させ、しばらく薄い黄色のまま残す。新しく出てきた行は行ごと点滅させる。
・種別名（h2）と表の見出し行は、その種別の表が流れ切るまで画面の上端に残す。
  次の種別が下から来ると、前の見出しは徐々に薄くなって消え（フェードアウト）、次の見出しに入れ替わる。
・所属の列は表の横幅の 15% の固定幅にし、文字は横幅に合わせて縮める。空いた分は選手名の列に回し、選手名を大きく出す。
・クラス（RM30 など、部門＋クラス）は表の中には出さず、表題の後ろに（RW30n）のように付ける。
・所属は正式名のまま出す。
  クラスは、この画面の ?meta=1 から JSON で取る。

パラメータ（LiveScoreboard.php と同じもの＋サイネージ用）:
  Tour      大会コード（省略時はログイン中の大会）
  Order     Ranking（既定）/ Target / Round（ランキングラウンド）
  s[]       セッション絞り込み（複数可）
  speed     スクロールの速さ（px/秒、既定 40、0 で止める）
  zoom      文字の大きさの倍率（既定 1）
  hide      隠す距離の番号（カンマ区切り、例 hide=1）
  interval  ふだんの読み込み間隔（秒、既定 30）
  fast      内容が書き換わったあとの読み込み間隔（秒、既定 5）
  calm      fast の間隔で何回続けて変わらなければふだんの間隔に戻すか（既定 3）
  top       10 なら個人の表を上位 10 人に絞る（どこかの表に 10 名以上いるときだけ効く）
  t         1 なら「団体」ボタンを押した状態（セッションと同じトグル。何も押さなければ個人の全セッションのあとに団体予選を続けて流す）

例: Signage.php?Tour=261R0707&speed=60

右下の半透明のパネルのボタンで、セッションの絞り込み、距離ごとの表示・非表示、
文字の大きさ、スクロールの速さを変えられる。
セッションは URL（s[]）に書き戻す。距離・文字・速さはこのブラウザに覚えておき、URL にも書き戻す
（URL に hide / zoom / speed があればそちらを優先）。
「一時停止」ボタン（またはスペースキー）でスクロールを止め、「再開」で動かす。
画面（パネル以外）をタップ（クリック）しても、一時停止・再開を切り替える。一時停止中は右下のパネルを濃く出す。
どこかの部門の表に 10 名以上いるときは、個人のボタンを「個人全て」「個人TOP10」にする（どちらか一方だけ ON）。
TOP10 は各表の上位 10 人（10 位と同順位の人は含める）だけを流す（URL の top=10）。
右下の数字（次の読み込みまでの秒数）をクリックすると、その場で表を読み込み直す。
画面をダブルクリックすると全画面表示を切り替える。

変更履歴:
2026/10/12 決勝のスケジュールがあれば、パネルに決勝のサイネージ（SignageFinal.php）へのボタンを出す
2026/10/12 TOP10 で絞り込んだ表は、部門名の後ろに TOP10 と出す
2026/10/12 画面のタップで一時停止・再開を切り替え、一時停止中は右下のパネルを濃く出す
2026/10/12 部門の表に 10 名以上いるとき、個人の表を上位 10 人に絞る「個人TOP10」ボタンを追加（「個人全て」とどちらか一方だけ ON）
2026/10/01 右下の表示を、最終更新の時刻ではなく、次の読み込みまでの秒数（数字だけ）にする
2026/10/01 個人の表のあとに団体予選の表（SignageTeam.php の内容）を続けて流す。パネルに団体予選のオン・オフボタンを追加
2026/09/30 クラスの列を表から外して表題に出し、所属は正式名にする
2026/09/26 上端の見出しの入れ替わりを、押し出しからフェードアウトに変える
2026/09/26 Web フォント（さくらの UD新ゴ）の読み込みをやめ、ブラウザの標準の sans-serif にする
2026/09/26 所属の列を最大で表の横幅の 15% にする
2026/09/26 種別名と表の見出し行を画面の上端に残すようにする
2026/09/26 選手名の前にクラスの列を足し、所属を所属先コード（略称）で出すようにする
2026/09/26 スクロールの一時停止・再開ボタンを追加、更新時刻のクリックで読み込み直すようにする
2026/09/26 セッションの絞り込み・距離の表示／非表示のボタンをパネルに追加
2026/09/26 文字の大きさ・スクロールの速さを変えるボタンを追加
2026/09/26 初版
*/
	require_once(dirname(dirname(__FILE__)) . '/config.php');

	// ---- ?meta=1：選手ごとのクラス（部門＋クラス）と所属先コードを JSON で返す ----
	if (!empty($_GET['meta'])) {
		header('Content-Type: application/json; charset=UTF-8');
		header('Cache-Control: no-store');

		// 大会の決め方は LiveScoreboard.php と同じ（Tour がなければログイン中の大会）
		$TourId = 0;
		if (!empty($_REQUEST['Tour'])) {
			$TourId = getIdFromCode(stripslashes($_REQUEST['Tour']));
		}
		if (!($TourId > 0) && !empty($_SESSION['TourId'])) {
			$TourId = intval($_SESSION['TourId']);
		}

		$Ret = new stdClass();
		if ($TourId > 0) {
			$Rs = safe_r_sql("SELECT EnId, CONCAT(EnDivision, EnClass) AS Class, CoCode
				FROM Entries
				LEFT JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament
				WHERE EnTournament={$TourId} AND EnAthlete=1");
			while ($r = safe_fetch($Rs)) {
				$Ret->{$r->EnId} = ['cls' => (string)$r->Class, 'code' => (string)$r->CoCode];
			}
		}
		echo json_encode($Ret, JSON_UNESCAPED_UNICODE);
		exit;
	}
?><!DOCTYPE html>
<html lang="ja" class="notranslate" translate="no">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google" content="notranslate">
<title>ライブ得点集計</title>
<style>
html{
  font-size:clamp(6pt, 1.0vw, 40pt);
  font-family:sans-serif;
  background:#fff;
  color:#000;
  overflow:hidden;
  height:100%;
}
body{
  margin:0;
  height:100%;
  overflow:hidden;
  background:#fff;
}
/* マウスを 3 秒動かさないとカーソルを消す */
body.idle, body.idle * {
  cursor:none !important;
}

#viewport{
  position:fixed;
  inset:0;
  overflow:hidden;
}
#track{
  position:relative;
  padding:0 1vmin;
  will-change:transform;
}

/* 画面の上端に残す見出し。上端にかかっているブロックを複製して、見出しの高さで切り取る。
   表の列の幅がもとの表とそろうよう、#track と同じ横の余白にする */
#sticky{
  position:fixed;
  top:0;
  left:0;
  right:0;
  z-index:5;
  overflow:hidden;
  padding:0 1vmin;
  background:#fff;
  box-shadow:0 2px 6px rgba(0,0,0,0.25);
  will-change:opacity;
  pointer-events:none;
}
#sticky[hidden]{ display:none; }

/* ブロック＝見出し（h2）＋表。display:flow-root で h2 の余白も高さに含める */
.block{
  display:flow-root;
  padding-bottom:1.5rem;
}
.block h2{
  margin:0.8rem 0 0.3rem;
}

/* ---- ここから LiveScoreboard.php の表のスタイル ---- */
table {
  border-collapse:collapse;
  border-spacing: 0;
  width:100%;
}

table th,table td{
  text-align: center;
  white-space:nowrap;
  white-space-collapse: preserve;
}

table th{
  background-color: #007db3 ;
  color: white;
  border:solid 1px black;
  height:1.3em;
}

th.dilabel {
  min-width:5rem;
}

.dibutton {
  display: flex;
  justify-content: center;
  align-items: center;
  min-width:5rem;
  margin:0 auto;
  padding: 0;
  border: 1px solid #000;
  border-radius: 5px;
  font-size: 0.8em;
  background-color: #005a80 ;
  color: white;
  pointer-events: none;
}

table th.boldleft:first-child {
  width:3rem;
}

table td{
  border:solid 1px black;
  padding: 0.3em 0.5em;
}

td.score {
  background:#eee;
  font-weight:bold;
  width:3rem;
  min-width:3rem;
}
td.goldx9 {
  width:2rem;
  min-width:2rem;
}
td.s{
  width:1.5em;
  margin:1px;
}

.r_class{
  min-width:3rem;
  border-right: 2px solid black !important;
  border-left: 2px solid black !important;
}
.r_name{
  min-width:8rem;
  border-right: 2px solid black !important;
  border-left: 2px solid black !important;
  font-weight:bold;
}
.r_country{
  min-width:8rem;
  border-right: 2px solid black !important;
  border-left: 2px solid black !important;
}

/* 所属の列は表の横幅の 15% の固定幅。文字は JS（fitCountry）で横幅に合わせて縮める。
   空いた分は選手名の列に回し、選手名は大きく太く出す（団体予選の表には効かせない） */
.block:not(.teamblock) th.r_country,
.block:not(.teamblock) td.r_country + td.r_country{
  width:15%;
  min-width:15%;
  max-width:15%;
  overflow:hidden;
}
.block:not(.teamblock) td.r_country:not(td.r_country + td.r_country){
  font-size:1.3em;
  font-weight:bold;
}
/* 総合計の数字は、選手名と同じ大きさにする */
.block:not(.teamblock) td.score.sticky{
  font-size:1.3em;
  width:auto;
}
/* 選手名は縮めずに全部出す（所属だけ JS で縮める） */
.block:not(.teamblock) td.r_country:not(td.r_country + td.r_country) > div{
  transform:none !important;
}

.boldleft {
  border-left: 2px solid black !important;
}
.boldright {
  border-right: 2px solid black;
}
.doubleleft {
  border-left: 2px double black !important;
}

.highlight > th{
  background: #005a80 !important;
}
.highlight > td{
  background: #007db340 !important;
}

/* スコアカードの列など、印刷しない部分はサイネージでも出さない */
.noprint, .hidden {
  display:none !important;
}
/* ---- ここまで ---- */

/* ---- 団体予選の表（LiveScoreboardTeam.php）。個人の表と列の名前が同じなので .teamblock の中だけに効かせる ---- */
.teamblock table th.boldleft:first-child{ width:6%; }
.teamblock table th.r_country{ width:30%; }
.teamblock table th.r_name{ width:22%; }
.teamblock table th.ttotal{ width:14%; }
.teamblock table th.goldx9{ width:7%; }
.teamblock td.r_country{ text-align:left; font-weight:bold; }
.teamblock td.r_name{ text-align:left; font-weight:normal; }
.teamblock td.member{ font-size:0.95em; }
.teamblock tr.teamtop > th, .teamblock tr.teamtop > td{ border-top:2px solid black; }
.teamblock tr.teamend > th, .teamblock tr.teamend > td{ border-bottom:2px solid black; }
.teamblock td.teamtotal{ background:#eee; font-weight:bold; font-size:1.2em; }

/* ---- 更新があったところの目印 ---- */
@keyframes chgFlash {
  0%, 16%, 33%   { background-color:#ffe600; }
  8%, 25%, 42%   { background-color:#fff9c4; }
  100%           { background-color:#fff59d; }
}
@keyframes chgRowFlash {
  0%, 16%, 33%   { background-color:#ffe600; }
  8%, 25%, 42%   { background-color:#fff9c4; }
  100%           { background-color:#fffde7; }
}
/* 今回の更新で変わったマス：点滅したあと薄い黄色のまま残す */
table td.chg, table th.chg {
  animation:chgFlash 3s ease-out forwards;
  color:#000;
}
/* 前回までに変わって、まだ画面から流れ切っていないマス：点滅なしで薄い黄色 */
table td.chg-keep, table th.chg-keep {
  background-color:#fff59d !important;
  color:#000;
}
/* 新しく出てきた行 */
tr.chg-row > td, tr.chg-row > th {
  animation:chgRowFlash 3s ease-out forwards;
  color:#000;
}
tr.chg-row-keep > td, tr.chg-row-keep > th {
  background-color:#fffde7 !important;
  color:#000;
}

/* ---- 右下の半透明パネル（文字の大きさ・速さのボタンと状態表示） ---- */
/* 文字の大きさを変えてもパネルは変わらないよう、rem ではなく自前の大きさで決める */
#panel{
  position:fixed;
  right:0.8em;
  bottom:0.8em;
  z-index:10;
  display:flex;
  align-items:center;
  gap:0.8em;
  padding:0.35em 0.6em;
  border-radius:2em;
  background:rgba(0,0,0,0.55);
  color:#fff;
  flex-wrap:wrap;
  justify-content:flex-end;
  row-gap:0.4em;
  max-width:calc(100vw - 1.6em);
  box-sizing:border-box;
  font-size:clamp(12px, 0.9vw, 28px);
  font-family:sans-serif;
  opacity:0.1;
  transition:opacity 0.3s;
  user-select:none;
  -webkit-backdrop-filter:blur(3px);
  backdrop-filter:blur(3px);
}
#panel:hover{
  opacity:1;
}
/* TOP10 で絞り込んだ表の、部門名の後ろの印 */
.top10{
  display:inline-block;
  margin-left:0.4em;
  padding:0 0.4em;
  border:1px solid #007db3;
  border-radius:4px;
  color:#007db3;
  font-size:0.8em;
  vertical-align:middle;
}
/* 一時停止中は、パネルを濃く出す */
#panel.paused{
  opacity:1;
}
#panel [hidden]{
  display:none !important;
}
#panel .ctrl{
  display:flex;
  flex-wrap:wrap;
  align-items:center;
  gap:0.3em;
}
/* 見えているグループの間に区切り線を入れる */
#panel > .ctrl:not([hidden]) ~ .ctrl:not([hidden]){
  border-left:1px solid rgba(255,255,255,0.35);
  padding-left:0.8em;
}
#panel .label{
  margin-right:0.1em;
}
#panel .sep{
  opacity:0.6;
}
#panel .sep[hidden]{ display:none !important; }
#panel .value{
  display:inline-block;
  min-width:3.2em;
  text-align:center;
  font-variant-numeric:tabular-nums;
}
#panel button{
  width:1.8em;
  height:1.8em;
  padding:0;
  border:1px solid rgba(255,255,255,0.6);
  border-radius:50%;
  background:rgba(255,255,255,0.15);
  color:#fff;
  font-size:1em;
  line-height:1;
  cursor:pointer;
}
#panel button:hover{
  background:rgba(255,255,255,0.35);
}
#panel button:active{
  background:rgba(255,255,255,0.6);
}
#panel button:disabled{
  opacity:0.3;
  cursor:default;
}
/* 決勝（SignageFinal.php）へのリンク。ボタンと同じ見た目 */
#panel a.tgl{
  display:inline-flex;
  align-items:center;
  box-sizing:border-box;
  height:1.8em;
  padding:0 0.7em;
  border:1px solid rgba(255,255,255,0.6);
  border-radius:1em;
  background:rgba(255,255,255,0.15);
  color:#fff;
  text-decoration:none;
  white-space:nowrap;
}
#panel a.tgl:hover{
  background:rgba(255,255,255,0.35);
}
/* セッション・距離の切り替えボタン（押されている＝白く塗る） */
#panel button.tgl{
  width:auto;
  min-width:1.8em;
  padding:0 0.7em;
  border-radius:1em;
  white-space:nowrap;
}
#panel button.tgl.on{
  background:rgba(255,255,255,0.85);
  border-color:#fff;
  color:#000;
  font-weight:bold;
}
#panel button.tgl.off{
  text-decoration:line-through;
  opacity:0.7;
}

#status{
  display:inline-block !important;
  padding:0.1em 0.5em;
  border-radius:1em;
  white-space:nowrap;
  cursor:pointer;
}
#status:hover{
  background:rgba(255,255,255,0.25);
}
#statusText{
  display:inline-block;
  min-width:1.6em;
  text-align:right;
  font-variant-numeric:tabular-nums;
}
#status .dot{
  display:inline-block;
  width:0.6em;
  height:0.6em;
  margin-right:0.4em;
  border-radius:50%;
  background:#4caf50;
  vertical-align:middle;
}
#status.error .dot{ background:#f44336; }
#status.changed{ animation:statusPulse 1.5s ease-out; }
@keyframes statusPulse {
  0%   { background:rgba(255,200,0,0.95); color:#000; transform:scale(1.2); }
  100% { background:transparent; color:#fff; transform:scale(1); }
}

#message{
  position:fixed;
  inset:0;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:2rem;
  color:#666;
}
#message[hidden]{ display:none; }
</style>
</head>
<body>
<div id="viewport"><div id="track"></div></div>
<div id="sticky" hidden></div>
<div id="message">読み込み中…</div>
<div id="panel">
  <div class="ctrl" id="finCtrl" title="決勝（マッチ戦）のサイネージへ" hidden><a class="tgl" id="finLink" href="#">決勝</a></div>
  <div class="ctrl" id="sesCtrl" title="個人のセッションと団体予選の表示・非表示">
    <span class="label">セッション</span>
    <span class="ctrl" id="sesButtons"></span>
    <span class="sep" id="teamSep">｜</span>
    <span class="ctrl" id="teamButtons"></span>
  </div>
  <div class="ctrl" id="diCtrl" title="距離ごとの表示・非表示" hidden>
    <span class="label">距離</span>
    <span class="ctrl" id="diButtons"></span>
  </div>
  <div class="ctrl" title="文字の大きさ">
    <span class="label">文字</span>
    <button type="button" id="zoomDown" aria-label="文字を小さく">－</button>
    <span class="value" id="zoomValue">100%</span>
    <button type="button" id="zoomUp" aria-label="文字を大きく">＋</button>
  </div>
  <div class="ctrl" title="スクロールの速さ（0 で止まる）">
    <span class="label">速さ</span>
    <button type="button" id="speedDown" aria-label="遅く">－</button>
    <span class="value" id="speedValue">40</span>
    <button type="button" id="speedUp" aria-label="速く">＋</button>
    <button type="button" class="tgl" id="pauseBtn">⏸ 一時停止</button>
  </div>
  <div class="ctrl" id="status" title="クリックで今すぐ読み込み直す"><span class="dot"></span><span id="statusText">…</span></div>
</div>
<script>
(() => {
  'use strict';

  // ---------------- パラメータ ----------------
  const params = new URLSearchParams(location.search);
  const num = (key, def, min, max) => {
    const v = parseFloat(params.get(key));
    return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : def;
  };
  // ボタンで変えた値はこのブラウザに覚えておく（URL に書いてあればそちらを優先）
  const STORE_KEY = 'LiveScoreboardSignage';
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(STORE_KEY)) || {}; } catch (e) { saved = {}; }
  const pick = (key, def, min, max) => {
    const v = params.has(key) ? parseFloat(params.get(key)) : parseFloat(saved[key]);
    return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : def;
  };
  const SPEED_MIN = 0, SPEED_MAX = 500, SPEED_STEP = 10;
  const ZOOM_MIN = 0.3, ZOOM_MAX = 5, ZOOM_STEP = 1.1;
  let speed = pick('speed', 40, SPEED_MIN, SPEED_MAX);  // px/秒
  let zoom  = pick('zoom', 1, ZOOM_MIN, ZOOM_MAX);      // 文字の大きさの倍率
  const INTERVAL = num('interval', 30, 3, 3600) * 1000; // ふだんの間隔（ミリ秒）
  const FAST = Math.min(INTERVAL, num('fast', 5, 1, 3600) * 1000); // 書き換えがあったあとの間隔
  const CALM = Math.round(num('calm', 3, 1, 100)); // 変わらないまま続いたら、ふだんの間隔に戻す回数
  let fastMode = false;   // 書き換えがあって、短い間隔で読み込んでいる最中
  let calmCount = 0;      // 短い間隔で、続けて変わらなかった回数
  const MARK_TTL = 10 * 60 * 1000;                      // 流れ切らなくても、この時間で目印を消す

  // 個人と団体予選は、それぞれボタンで表示・非表示を切り替える（URL の ind=0 で個人なし、team=0 で団体なし）。
  // 個人はさらにセッションで絞り込める（sessions が空なら全セッション）
  let indOn = params.get('ind') !== '0';
  let teamOn = params.get('team') !== '0';
  let teamAvail = null;           // 団体戦の設定があるか（団体の画面から分かる。分かるまでは null）
  // 個人の表を上位 10 人に絞るか（URL の top=10）。どこかの表に 10 名以上いるとき（bigTable）だけ効く
  const TOP_N = 10;
  let top10 = params.get('top') === String(TOP_N);
  let bigTable = false;
  let cachedSessionList = null;   // 個人の表を取らないときのために、セッション・距離の一覧は覚えておく
  let cachedDistList = null;

  // 隠す距離の番号
  const hiddenDi = new Set(
    (params.has('hide') ? params.get('hide').split(',') : (Array.isArray(saved.hide) ? saved.hide : []))
      .map(v => parseInt(v, 10)).filter(v => v > 0)
  );

  // 表示するセッション（空なら全て）
  let sessions = [...params.getAll('s[]'), ...params.getAll('s')]
    .map(v => parseInt(v, 10)).filter(v => v > 0);
  sessions = [...new Set(sessions)].sort((a, b) => a - b);

  // LiveScoreboard.php に渡すのは表の中身に関わるものだけ（r=1 などは渡さない）
  function srcUrl() {
    const q = new URLSearchParams();
    for (const [k, v] of params) {
      if (k === 'Tour' || k === 'Order') q.append(k, v);
    }
    sessions.forEach(v => q.append('s[]', String(v)));
    return 'LiveScoreboard.php' + (q.toString() ? '?' + q.toString() : '');
  }

  // 団体予選の表の取得先（Tour だけ渡す）
  function teamUrl() {
    const q = new URLSearchParams();
    if (params.has('Tour')) q.append('Tour', params.get('Tour'));
    return 'LiveScoreboardTeam.php' + (q.toString() ? '?' + q.toString() : '');
  }

  const root      = document.documentElement;
  const viewport  = document.getElementById('viewport');
  const track     = document.getElementById('track');
  const message   = document.getElementById('message');
  const statusBox = document.getElementById('status');
  const statusTxt = document.getElementById('statusText');

  // ---------------- 表の読み取り ----------------
  const text = el => (el ? el.textContent : '').replace(/\s+/g, ' ').trim();

  // 行の選手の EnId。スコアカードのボタン（showscore(...) の JSON）から取る
  function enIdOf(tr) {
    const btn = tr.querySelector('[onclick*="showscore"]');
    const m = btn && /"EnId":"?(\d+)/.exec(btn.getAttribute('onclick'));
    return m ? m[1] : null;
  }

  // 行を見分けるキー：EnId（取れないときは選手名＋所属）
  function rowKeys(container) {
    const seen = new Map();
    const rows = [];
    container.querySelectorAll('tr[class*="target-"]').forEach(tr => {
      const id = enIdOf(tr);
      const tds = tr.querySelectorAll('td.r_country');
      let key = id ? 'id:' + id : text(tds[0]) + '|' + text(tds[1]);
      const n = (seen.get(key) || 0) + 1;
      seen.set(key, n);
      if (n > 1) key += '#' + n;
      rows.push({ key, tr });
    });
    return rows;
  }

  // 選手ごとのクラスと所属先コード（?meta=1 から取る。取れなかったときは前回のものを使う）
  let meta = {};

  // 表題（h2）の後ろにクラスのコードを足す（例：新人戦女子（RW30n））。順位表示のときだけ
  function titleWithClass(box, h2) {
    const order = params.get('Order');
    if (order && order !== 'Ranking') return h2.innerHTML;
    const codes = new Set();
    box.querySelectorAll('tr[class*="target-"]').forEach(tr => {
      const id = enIdOf(tr);
      if (id && meta[id] && meta[id].cls) codes.add(meta[id].cls);
    });
    return h2.innerHTML + (codes.size && codes.size <= 3 ? '（' + [...codes].join('・') + '）' : '');
  }

  function metaUrl() {
    const q = new URLSearchParams({ meta: '1' });
    if (params.has('Tour')) q.set('Tour', params.get('Tour'));
    return location.pathname + '?' + q.toString();
  }

  async function loadMeta() {
    try {
      const res = await fetch(metaUrl(), { cache: 'no-store', credentials: 'same-origin' });
      if (!res.ok) return;
      const j = await res.json();
      if (j && typeof j === 'object' && !Array.isArray(j)) meta = j;
    } catch (e) {}
  }

  // 取ってきた HTML から「h2＋表」のブロックを取り出す
  function parseBlocks(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const blocks = [];
    const seen = new Map();
    let bigFound = false;
    doc.querySelectorAll('div.table_box').forEach(box => {
      const h2 = box.previousElementSibling && box.previousElementSibling.tagName === 'H2'
        ? box.previousElementSibling : null;
      let key = h2 ? text(h2) : '(無題)';
      const n = (seen.get(key) || 0) + 1;
      seen.set(key, n);
      if (n > 1) key += '#' + n;

      if (h2) h2.innerHTML = titleWithClass(box, h2);

      // 10 名以上の表があるか調べ、TOP10 のときは上位 10 人（10 位と同順位の人は含める）だけを残す
      const trs = [...box.querySelectorAll('tr[class*="target-"]')];
      if (trs.length >= TOP_N) bigFound = true;
      if (top10 && trs.length > TOP_N) {
        const rankOf = tr => { const t = tr.firstElementChild ? text(tr.firstElementChild) : ''; return /^\d+$/.test(t) ? t : null; };
        const last = rankOf(trs[TOP_N - 1]);
        trs.slice(TOP_N).forEach(tr => {
          if (last === null || rankOf(tr) !== last) tr.remove();
        });
        // 絞り込んだ表は、部門名の後ろに TOP10 と出す
        if (h2) h2.insertAdjacentHTML('beforeend', ' <span class="top10">TOP' + TOP_N + '</span>');
      }

      const rows = new Map();
      rowKeys(box).forEach(({ key: rk, tr }) => {
        rows.set(rk, Array.from(tr.children, text));
      });
      blocks.push({
        key,
        html: (h2 ? h2.outerHTML : '') + box.outerHTML,
        rows,
        marks: new Map(), // "行キー\t列番号"（列番号 -1 は行ごと）→ 変わった時刻
        fresh: new Set(), // 今回の更新で変わった目印
      });
    });
    return { blocks, title: doc.title, sessionList: parseSessions(doc), distList: parseDistances(doc), big: bigFound };
  }

  // セッションのトグルボタン（LiveScoreboard.php の表の下にあるもの）からセッションの一覧を取り出す。
  // リンク先は「そのセッションを切り替えたときの s[]」なので、今の選択との差がそのセッションの番号になる
  function parseSessions(doc) {
    const cur = new Set(sessions);
    const list = [];
    doc.querySelectorAll('a.session-toggle-btn:not(.all-btn)').forEach(a => {
      let next;
      try {
        next = new Set(new URL(a.getAttribute('href'), location.href).searchParams.getAll('s[]').map(v => parseInt(v, 10)));
      } catch (e) { return; }
      let id = null;
      next.forEach(v => { if (!cur.has(v)) id = v; });
      if (id === null) cur.forEach(v => { if (!next.has(v)) id = v; });
      if (id !== null) list.push({ id, label: text(a) });
    });
    return list;
  }

  // 距離の見出し（th[data-di]）から距離の一覧を取り出す。セッションで名前が違うときは「距離1」などにする
  function parseDistances(doc) {
    const names = new Map();
    doc.querySelectorAll('th[data-di]').forEach(th => {
      const di = parseInt(th.dataset.di, 10);
      if (!(di > 0)) return;
      if (!names.has(di)) names.set(di, new Set());
      names.get(di).add(text(th));
    });
    return [...names.keys()].sort((a, b) => a - b).map(di => {
      const n = names.get(di);
      return { di, label: n.size === 1 && [...n][0] ? [...n][0] : '距離' + di };
    });
  }

  // ---- 団体予選：チームごとの行（rowspan で複数の行にまたがる）を data-team ごとにまとめる ----
  function teamGroups(container) {
    const groups = new Map();
    container.querySelectorAll('tr[data-team]').forEach(tr => {
      const key = tr.dataset.team;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(tr);
    });
    return [...groups].map(([key, trs]) => ({ key, trs }));
  }
  // チームの全マスを上から順に並べたもの（目印のマス番号はこの並びの番号）
  const groupCells = trs => trs.flatMap(tr => Array.from(tr.children));

  // 団体予選の HTML から「h2＋表」のブロックを取り出す
  function parseTeamBlocks(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const blocks = [];
    const seen = new Map();
    doc.querySelectorAll('div.table_box').forEach(box => {
      const h2 = box.previousElementSibling && box.previousElementSibling.tagName === 'H2'
        ? box.previousElementSibling : null;
      let key = 'team:' + (h2 ? text(h2) : '(無題)');
      const n = (seen.get(key) || 0) + 1;
      seen.set(key, n);
      if (n > 1) key += '#' + n;

      const rows = new Map();
      teamGroups(box).forEach(({ key: rk, trs }) => {
        rows.set(rk, groupCells(trs).map(text));
      });
      blocks.push({
        key,
        team: true,
        html: (h2 ? h2.outerHTML : '') + box.outerHTML,
        rows,
        marks: new Map(),
        fresh: new Set(),
      });
    });
    // 団体戦の設定があれば、団体の画面に種目のリンクが「全て」のほかに 1 つ以上ある
    const avail = doc.querySelectorAll('a.event-link').length > 1;
    return { blocks, avail };
  }

  // 前回の表と比べて、変わったマスに目印をつける
  function diffBlocks(oldBlocks, newBlocks, firstLoad) {
    const oldMap = new Map(oldBlocks.map(b => [b.key, b]));
    const now = Date.now();
    let count = 0;
    newBlocks.forEach(nb => {
      const ob = oldMap.get(nb.key);
      if (ob) {
        // 前からある目印は、行がまだあれば引き継ぐ
        ob.marks.forEach((t, id) => {
          if (now - t < MARK_TTL && nb.rows.has(id.split('\t')[0])) nb.marks.set(id, t);
        });
      }
      if (firstLoad) return;
      nb.rows.forEach((cells, rk) => {
        const oldCells = ob ? ob.rows.get(rk) : undefined;
        if (!oldCells || oldCells.length !== cells.length) {
          const id = rk + '\t-1';
          nb.marks.set(id, now);
          nb.fresh.add(id);
          count++;
          return;
        }
        cells.forEach((c, i) => {
          if (c !== oldCells[i]) {
            const id = rk + '\t' + i;
            nb.marks.set(id, now);
            nb.fresh.add(id);
            count++;
          }
        });
      });
    });
    return count;
  }

  // ---------------- 描画 ----------------
  let model = [];          // 今の表のブロック一覧
  let lastAppendedKey = null;
  let pos = 0;             // スクロール量（px）

  // ブロックの要素を作る。onlyFresh=true のときは今回の更新分だけ点滅させ、前からの目印は点滅なしで残す
  function renderBlock(block, onlyFresh) {
    const el = document.createElement('div');
    el.className = 'block' + (block.team ? ' teamblock' : '');
    el.dataset.key = block.key;
    el.innerHTML = block.html;
    el._renderedAt = Date.now();
    applyDistances(el);

    if (block.marks.size && block.team) {
      const byTeam = new Map(teamGroups(el).map(r => [r.key, r.trs]));
      block.marks.forEach((t, id) => {
        const [rk, idxStr] = id.split('\t');
        const trs = byTeam.get(rk);
        if (!trs) return;
        const flash = !onlyFresh || block.fresh.has(id);
        const idx = parseInt(idxStr, 10);
        if (idx < 0) {
          trs.forEach(tr => tr.classList.add(flash ? 'chg-row' : 'chg-row-keep'));
        } else {
          const cell = groupCells(trs)[idx];
          if (cell) cell.classList.add(flash ? 'chg' : 'chg-keep');
        }
      });
    } else if (block.marks.size) {
      const byRow = new Map(rowKeys(el).map(r => [r.key, r.tr]));
      block.marks.forEach((t, id) => {
        const [rk, idxStr] = id.split('\t');
        const tr = byRow.get(rk);
        if (!tr) return;
        const flash = !onlyFresh || block.fresh.has(id);
        const idx = parseInt(idxStr, 10);
        if (idx < 0) {
          tr.classList.add(flash ? 'chg-row' : 'chg-row-keep');
        } else if (tr.children[idx]) {
          tr.children[idx].classList.add(flash ? 'chg' : 'chg-keep');
        }
      });
    }
    return el;
  }

  // 隠す距離は、各エンドの列を消して、見出しを合計の 1 列分にする（LiveScoreboard.php の hideScore と同じ）
  function applyDistances(el) {
    el.querySelectorAll('th[data-di]').forEach(th => {
      const di = parseInt(th.dataset.di, 10);
      const hide = hiddenDi.has(di);
      th.colSpan = hide ? 1 : (parseInt(th.dataset.ends, 10) || 0) + 1;
      el.querySelectorAll('.d' + di).forEach(c => c.classList.toggle('hidden', hide));
    });
  }

  function nextBlock() {
    if (!model.length) return null;
    const i = model.findIndex(b => b.key === lastAppendedKey);
    return model[(i + 1) % model.length];
  }

  // 所属は固定幅の列に収まるよう、文字の横幅を縮める（選手名は縮めない）
  function fitCountry(root) {
    root.querySelectorAll('.block:not(.teamblock) td.r_country + td.r_country > div').forEach(d => {
      const cell = d.parentElement;
      const cs = getComputedStyle(cell);
      const avail = cell.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
      d.style.transform = '';
      d.style.transformOrigin = '0 0';
      const w = d.scrollWidth;
      if (avail > 0 && w > avail) d.style.transform = 'scale(' + (avail / w) + ',1)';
    });
  }

  // 画面の下に足りない分だけ、次のブロックを継ぎ足す
  function fill() {
    const need = viewport.clientHeight * 2;
    let guard = 0;
    while (track.offsetHeight - pos < need && guard++ < 200) {
      const b = nextBlock();
      if (!b) return;
      const added = renderBlock(b, false);
      track.appendChild(added);
      fitCountry(added);
      lastAppendedKey = b.key;
    }
  }

  // 上に流れ切ったブロックを外す（外した分だけ pos を戻す）
  function trim() {
    let first = track.firstElementChild;
    while (first && first.offsetHeight > 0 && first.offsetHeight <= pos && first.nextElementSibling) {
      pos -= first.offsetHeight;
      consumeMarks(first);
      first.remove();
      first = track.firstElementChild;
    }
  }

  // 流れ切ったブロックに出していた目印は、見せ終わったので消す
  function consumeMarks(el) {
    const b = model.find(m => m.key === el.dataset.key);
    if (!b) return;
    b.marks.forEach((t, id) => {
      if (t <= el._renderedAt) b.marks.delete(id);
    });
  }

  // 表が横にはみ出すときは文字を小さくする
  const baseFont = `clamp(6pt, 1.0vw, 40pt)`;
  let fontScale = zoom;
  function setFont(scale) {
    fontScale = scale;
    root.style.fontSize = `calc(${scale} * ${baseFont})`;
  }
  // ---------------- 上端に残す見出し ----------------
  const sticky = document.getElementById('sticky');
  let stickySrc = null;      // 今複製しているブロック
  let stickyDirty = true;    // 列の幅などが変わったので複製し直す
  let stickyH = 0;           // 見出しの高さ（ブロックの上端から最初の選手の行まで）

  function hideSticky() {
    if (!sticky.hidden) sticky.hidden = true;
  }

  function updateSticky() {
    // 画面の上端にかかっているブロック
    let el = track.firstElementChild;
    while (el && el.offsetTop + el.offsetHeight <= pos) el = el.nextElementSibling;
    if (!el || pos <= el.offsetTop) { hideSticky(); return; }

    if (el !== stickySrc || stickyDirty) {
      const firstRow = el.querySelector('tr[class*="target-"], tr[data-team]');
      if (!firstRow) { hideSticky(); stickySrc = null; return; }
      stickyH = firstRow.getBoundingClientRect().top - el.getBoundingClientRect().top + 1;
      const clone = el.cloneNode(true);
      clone.removeAttribute('data-key');
      clone.querySelectorAll('.chg, .chg-keep, .chg-row, .chg-row-keep').forEach(c => {
        c.classList.remove('chg', 'chg-keep', 'chg-row', 'chg-row-keep');
      });
      sticky.replaceChildren(clone);
      sticky.style.height = stickyH + 'px';
      stickySrc = el;
      stickyDirty = false;
    }

    // 次のブロックが近づいたら見出しを徐々に消す。次の見出しと重なって文字がだぶらないよう、
    // 次のブロックが見出しの下端に届くまで（見出しの高さ 1 つ分手前から）に消し終える
    const next = el.nextElementSibling;
    const rest = next ? next.offsetTop - pos - stickyH : Infinity; // 次のブロックが見出しの下端に届くまでの距離
    const opacity = Math.max(0, Math.min(1, rest / stickyH));
    sticky.style.opacity = opacity.toFixed(3);
    sticky.hidden = false;
  }

  function fit(reset) {
    stickyDirty = true;
    if (reset) setFont(zoom);
    for (let i = 0; i < 4; i++) {
      const cs = getComputedStyle(track);
      const inner = track.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
      let widest = 0;
      track.querySelectorAll('table').forEach(t => { widest = Math.max(widest, t.offsetWidth); });
      if (!widest || widest <= inner + 1) break;
      setFont(fontScale * inner / widest * 0.98);
    }
    fitCountry(track);
  }

  // ---------------- 読み込み ----------------
  let firstLoad = true;

  // 右下の表示は、次に読み込み直すまでの秒数（数字だけ）。最後の更新の結果などは、マウスを乗せたときの説明に出す
  let nextAt = null;   // 次に読み込み直す時刻（ミリ秒）。読み込み中は null
  function renderCountdown() {
    statusTxt.textContent = nextAt === null ? '…' : String(Math.max(0, Math.ceil((nextAt - Date.now()) / 1000)));
  }
  setInterval(renderCountdown, 250);

  function setStatus(msg, isError, changed) {
    statusBox.title = msg + '（クリックで今すぐ読み込み直す）';
    statusBox.classList.toggle('error', !!isError);
    if (changed) {
      statusBox.classList.remove('changed');
      void statusBox.offsetWidth; // アニメーションをやり直す
      statusBox.classList.add('changed');
    }
  }

  const hhmmss = d => d.toTimeString().slice(0, 8);

  let paused = false;
  let loadGen = 0;       // セッションを切り替えたら増やし、古い読み込みの結果は捨てる
  let loadTimer = null;

  async function load() {
    const gen = loadGen;
    nextAt = null;
    renderCountdown();
    try {
      // 団体戦の設定があるかは、最初の 1 回は団体の画面を取って調べる。団体だけのときも、
      // 最初の 1 回は個人の表を取って、セッションと距離の一覧を覚える
      const needInd = indOn || cachedSessionList === null;
      const needTeam = teamOn || teamAvail === null;
      const [res, tres] = await Promise.all([
        needInd ? fetch(srcUrl(), { cache: 'no-store', credentials: 'same-origin' }) : Promise.resolve(null),
        needTeam
          ? fetch(teamUrl(), { cache: 'no-store', credentials: 'same-origin' }).catch(() => null)
          : Promise.resolve(null),
        indOn ? loadMeta() : Promise.resolve(),
      ]);
      let indBlocks = [], title = '', sessionList = cachedSessionList || [], distList = cachedDistList || [];
      if (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const html = await res.text();
        if (gen !== loadGen) return;
        const parsed = parseBlocks(html);
        title = parsed.title;
        sessionList = cachedSessionList = parsed.sessionList;
        distList = cachedDistList = parsed.distList;
        bigTable = parsed.big;
        if (indOn) indBlocks = parsed.blocks;
      }
      if (gen !== loadGen) return;
      // 団体予選は、個人の表のあとに続ける（取れなかったときは個人だけ出す）
      let teamBlocks = [];
      if (tres && tres.ok) {
        try {
          const pt = parseTeamBlocks(await tres.text());
          teamAvail = pt.avail;
          if (teamOn && teamAvail) teamBlocks = pt.blocks;
        } catch (e) { teamBlocks = []; }
      }
      // 団体戦の設定がないのに個人が消えている状態は戻す
      if (teamAvail === false && !indOn) { indOn = true; saveSettings(); reloadNow(); return; }
      const blocks = [...indBlocks, ...teamBlocks];

      buildSessionButtons(sessionList);
      buildDistanceButtons(distList);

      if (title) document.title = title;

      const count = diffBlocks(model, blocks, firstLoad);
      model = blocks;

      // 書き換えがあれば短い間隔にし、短い間隔で CALM 回続けて変わらなければふだんの間隔に戻す
      if (count > 0) {
        fastMode = true;
        calmCount = 0;
      } else if (fastMode && ++calmCount >= CALM) {
        fastMode = false;
        calmCount = 0;
      }

      if (!model.length) {
        message.textContent = '表示するデータがありません';
        message.hidden = false;
        track.replaceChildren();
        lastAppendedKey = null;
        pos = 0;
        setStatus(hhmmss(new Date()) + ' データなし', true, false);
        return;
      }
      message.hidden = true;

      // 画面にあるブロックは、変わったものだけその場で差し替える
      const byKey = new Map(model.map(b => [b.key, b]));
      Array.from(track.children).forEach(el => {
        const b = byKey.get(el.dataset.key);
        if (b && b.fresh.size) {
          const nel = renderBlock(b, true);
          el.replaceWith(nel);
          fitCountry(nel);
        }
      });

      fill();
      if (firstLoad) fit(true);
      else fit(false);
      firstLoad = false;
      updatePanel();

      setStatus(hhmmss(new Date()) + (count ? ` 更新 ${count}か所` : ' 更新') + (fastMode ? ` ・${FAST / 1000}秒ごと` : ''), false, count > 0);
    } catch (e) {
      if (gen !== loadGen) return;
      setStatus(hhmmss(new Date()) + ' 読み込みに失敗しました', true, false);
      if (!model.length) message.textContent = '読み込みに失敗しました（再試行します）';
    } finally {
      if (gen === loadGen) {
        const delay = fastMode ? FAST : INTERVAL;
        loadTimer = setTimeout(load, delay);
        nextAt = Date.now() + delay;
        renderCountdown();
      }
    }
  }

  // 表示はそのままで、今すぐ読み込み直す（変わったところの点滅もいつもどおり）
  function refreshNow() {
    loadGen++;
    clearTimeout(loadTimer);
    nextAt = null;
    renderCountdown();
    setStatus('更新中…', false, false);
    load();
  }

  // 表示を空にして、今の条件ですぐに読み込み直す
  function reloadNow() {
    loadGen++;
    clearTimeout(loadTimer);
    model = [];
    track.replaceChildren();
    track.style.transform = '';
    lastAppendedKey = null;
    pos = 0;
    firstLoad = true;
    fastMode = false;
    calmCount = 0;
    message.textContent = '読み込み中…';
    message.hidden = false;
    load();
  }

  // ---------------- スクロール ----------------
  let last = performance.now();
  const dpr = window.devicePixelRatio || 1;
  function frame(now) {
    const dt = Math.min(100, now - last); // タブが裏に回っていたときに飛ばないように
    last = now;
    if (model.length && track.firstElementChild) {
      if (!paused) pos += speed * dt / 1000;
      trim();
      fill();
      track.style.transform = `translate3d(0, ${-Math.round(pos * dpr) / dpr}px, 0)`;
      updateSticky();
    } else {
      hideSticky();
    }
    requestAnimationFrame(frame);
  }

  window.addEventListener('resize', () => { fit(true); fill(); updatePanel(); });

  // ---------------- 文字の大きさ・速さのボタン ----------------
  const panel = document.getElementById('panel');
  const zoomUp = document.getElementById('zoomUp');
  const zoomDown = document.getElementById('zoomDown');
  const speedUp = document.getElementById('speedUp');
  const speedDown = document.getElementById('speedDown');

  function updatePanel() {
    // 横幅に収まるよう小さくしていることがあるので、実際の大きさを出す
    document.getElementById('zoomValue').textContent = Math.round(fontScale * 100) + '%';
    document.getElementById('speedValue').textContent = speed === 0 ? '停止' : String(speed);
    zoomDown.disabled = zoom <= ZOOM_MIN + 1e-9;
    zoomUp.disabled = zoom >= ZOOM_MAX - 1e-9;
    speedDown.disabled = speed <= SPEED_MIN;
    speedUp.disabled = speed >= SPEED_MAX;
  }

  function saveSettings() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify({ speed, zoom, hide: [...hiddenDi] })); } catch (e) {}
    // URL にも書き戻して、リロードしても同じ値になるようにする
    try {
      const url = new URL(location.href);
      url.searchParams.set('speed', String(speed));
      url.searchParams.set('zoom', String(Math.round(zoom * 1000) / 1000));
      url.searchParams.delete('team');
      url.searchParams.delete('t');
      if (indOn) url.searchParams.delete('ind'); else url.searchParams.set('ind', '0');
      if (teamOn) url.searchParams.delete('team'); else url.searchParams.set('team', '0');
      if (top10) url.searchParams.set('top', String(TOP_N)); else url.searchParams.delete('top');
      url.searchParams.set('hide', [...hiddenDi].sort((a, b) => a - b).join(','));
      url.searchParams.delete('s');
      url.searchParams.delete('s[]');
      sessions.forEach(v => url.searchParams.append('s[]', String(v)));
      history.replaceState(null, '', url);
    } catch (e) {}
  }

  function changeZoom(factor) {
    // 表が横幅いっぱいになっていて大きくできないときは、今の実際の大きさから変える
    zoom = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, fontScale * factor));
    fit(true);
    zoom = fontScale;
    fill();
    saveSettings();
    updatePanel();
  }

  function changeSpeed(delta) {
    speed = Math.min(SPEED_MAX, Math.max(SPEED_MIN, speed + delta));
    saveSettings();
    updatePanel();
  }

  // ---------------- セッション・距離のボタン ----------------
  const sesCtrl = document.getElementById('sesCtrl');
  const sesButtons = document.getElementById('sesButtons');
  const diCtrl = document.getElementById('diCtrl');
  const diButtons = document.getElementById('diButtons');
  let sesSig = null, diSig = null;

  function tglButton(label, on, onClick, offStyle) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'tgl' + (on ? ' on' : (offStyle ? ' off' : ''));
    b.textContent = label;
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
    b.addEventListener('click', onClick);
    return b;
  }

  // 「全て」「セッション…」「団体」のトグル。セッションが 1 つだけのときは「全て」「団体」だけになる
  // 「セッション [すべて][セッション…]…｜[団体]」。個人も団体も、ボタンのオン・オフで切り替える
  //   ・セッションが 1 つだけのときは「すべて」の代わりに「個人」だけを出す
  //   ・団体戦の設定がないときは「団体」を出さない
  //   ・個人も団体も消えた状態にはならない（最後の 1 つを消そうとしたら何もしない）
  function buildSessionButtons(list) {
    const sig = JSON.stringify([list, sessions, indOn, teamOn, teamAvail, top10, bigTable]);
    if (sig === sesSig) return;
    sesSig = sig;
    sesButtons.replaceChildren();
    document.getElementById('teamButtons').replaceChildren();
    const hasTeam = teamAvail === true;
    document.getElementById('teamSep').hidden = !hasTeam;
    sesCtrl.hidden = false;

    // 個人の「全て」「TOP10」：どちらか一方だけ ON。ON のボタンをもう一度押すと個人を消す（団体が ON のときだけ）
    const indModeButton = (label, wantTop) => tglButton(label, indOn && top10 === wantTop, () => {
      if (indOn && top10 === wantTop) {
        if (!(hasTeam && teamOn)) return;
        indOn = false;
      } else {
        indOn = true;
        top10 = wantTop;
      }
      changed();
    });
    if (list.length < 2) {
      if (bigTable) {
        sesButtons.appendChild(indModeButton('個人全て', false));
        sesButtons.appendChild(indModeButton('個人TOP10', true));
      } else {
        sesButtons.appendChild(tglButton('個人', indOn, () => {
          if (indOn && !(hasTeam && teamOn)) return;
          indOn = !indOn;
          changed();
        }));
      }
    } else {
      const allOn = indOn && sessions.length === 0;
      sesButtons.appendChild(tglButton('すべて', allOn, () => {
        if (allOn) {
          if (!(hasTeam && teamOn)) return;
          indOn = false;
        } else {
          indOn = true;
          sessions = [];
        }
        changed();
      }));
      list.forEach(({ id, label }) => {
        const on = indOn && sessions.includes(id);
        sesButtons.appendChild(tglButton(label, on, () => {
          if (on) {
            sessions = sessions.filter(v => v !== id);
          } else {
            indOn = true;
            sessions = [...new Set([...sessions, id])].sort((a, b) => a - b);
          }
          changed();
        }));
      });
      // セッションが複数あるときは、セッションの後ろに TOP10 の切り替えを付ける
      if (bigTable) {
        sesButtons.appendChild(tglButton('TOP10', indOn && top10, () => {
          top10 = !top10;
          indOn = true;
          changed();
        }));
      }
    }
    if (hasTeam) {
      document.getElementById('teamButtons').appendChild(tglButton('団体', teamOn, () => {
        if (teamOn && !indOn) return;
        teamOn = !teamOn;
        changed();
      }));
    }
  }

  function changed() {
    sesSig = null;
    saveSettings();
    reloadNow();
  }

  function setSessions(next) {
    sessions = [...new Set(next)].sort((a, b) => a - b);
    changed();
  }

  function buildDistanceButtons(list) {
    const sig = JSON.stringify([list, [...hiddenDi], indOn]);
    if (sig === diSig) return;
    diSig = sig;
    diButtons.replaceChildren();
    diCtrl.hidden = list.length === 0 || !indOn;
    list.forEach(({ di, label }) => {
      diButtons.appendChild(tglButton(label, !hiddenDi.has(di), () => {
        if (hiddenDi.has(di)) hiddenDi.delete(di); else hiddenDi.add(di);
        track.querySelectorAll('.block').forEach(applyDistances);
        fit(true);
        fill();
        saveSettings();
        updatePanel();
        buildDistanceButtons(list);
      }, true));
    });
  }

  // ---------------- 一時停止・今すぐ更新 ----------------
  const pauseBtn = document.getElementById('pauseBtn');
  function setPaused(p) {
    paused = p;
    pauseBtn.textContent = paused ? '▶ 再開' : '⏸ 一時停止';
    pauseBtn.classList.toggle('on', paused);
    pauseBtn.setAttribute('aria-pressed', paused ? 'true' : 'false');
    panel.classList.toggle('paused', paused);   // 一時停止中はパネルを濃く出す
  }
  pauseBtn.addEventListener('click', () => setPaused(!paused));
  document.addEventListener('keydown', e => {
    if (e.code === 'Space' && !e.repeat) {
      e.preventDefault();
      setPaused(!paused);
    }
  });
  statusBox.addEventListener('click', refreshNow);
  // 画面（パネル以外）をタップ・クリックしたら、一時停止・再開を切り替える
  document.addEventListener('click', e => {
    if (panel.contains(e.target)) return;
    setPaused(!paused);
  });

  zoomUp.addEventListener('click', () => changeZoom(ZOOM_STEP));
  zoomDown.addEventListener('click', () => changeZoom(1 / ZOOM_STEP));
  speedUp.addEventListener('click', () => changeSpeed(SPEED_STEP));
  speedDown.addEventListener('click', () => changeSpeed(-SPEED_STEP));

  // マウスを動かしたときだけカーソルを出す
  let idleTimer = null;
  const wake = () => {
    document.body.classList.remove('idle');
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => document.body.classList.add('idle'), 3000);
  };
  document.addEventListener('mousemove', wake);
  document.addEventListener('touchstart', wake, { passive: true });
  wake();

  // ダブルクリックで全画面表示を切り替える（パネルのボタンを続けて押したときは切り替えない）
  document.addEventListener('dblclick', e => {
    if (panel.contains(e.target)) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => {});
  });

  // 決勝のスケジュールがあれば、パネルに「決勝」（SignageFinal.php）を出す
  (async () => {
    try {
      const q = new URLSearchParams({ json: '1', list: '1' });
      if (params.has('Tour')) q.set('Tour', params.get('Tour'));
      const res = await fetch('SignageFinal.php?' + q.toString(), { cache: 'no-store', credentials: 'same-origin' });
      const j = await res.json();
      if (j && Array.isArray(j.schedules) && j.schedules.length) {
        document.getElementById('finLink').href = 'SignageFinal.php' + (params.has('Tour') ? '?Tour=' + encodeURIComponent(params.get('Tour')) : '');
        document.getElementById('finCtrl').hidden = false;
      }
    } catch (e) {}
  })();

  setFont(zoom);
  updatePanel();
  load();
  requestAnimationFrame(frame);
})();
</script>
</body>
</html>
