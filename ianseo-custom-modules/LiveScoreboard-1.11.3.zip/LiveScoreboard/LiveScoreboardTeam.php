<?php
/*
団体戦の予選順位（ライブ得点集計）。画面の体裁は個人戦（LiveScoreboard.php）に合わせる。

・ianseo 標準の団体予選順位（Obj_RankFactory の AbsTeam）を読み、種目ごとに表にする。
・得点の入力前でも、団体の設定（種目・団体に出る選手）があれば、チームの組み方を出す。ianseo のチーム編成は
  得点のある選手しかチームに入れないので、ランキングにまだ載っていない国は、個人予選と同じ選手のデータ（Entries /
  Qualifications）と団体の設定（EventClass）から読み取り専用で組み（Lib.php の lsb_team_candidates）、
  ランキングの後ろに順位・得点なしで続ける。
・チームごとに、順位・所属・メンバー（縦に並べる）・メンバーの合計・
  チームの総合計・ゴールド／Xナイン の数を出す。距離ごとの得点は出さない。

パラメータ:
  Tour     大会コード（省略時はログイン中の大会）
  Event    種目コード（カンマ区切りで複数可。省略時は全種目）
  r        1 なら 30 秒ごとに自動で読み込み直す

例: LiveScoreboardTeam.php?Tour=26HR0871&Event=RW

変更履歴:
2026/10/06 得点の入力前でも、団体の設定があればチームの組み方を出す（ランキングに載っていない国を、順位なしで続ける）
2026/10/01 種目の選択は「すべて」か 1 種目だけにする（複数選択をやめる）
2026/10/01 画面の切り替えを共通のパネル（Lib.php）にし、見出しの大会コードを外す
2026/10/01 チーム内のメンバーを個人の点数の高い順に並べる
2026/10/01 距離別（前半・後半）の得点を表示しない
2026/10/01 初版
*/
	define('debug',false);
	define('IN_PHP', true);
	ini_set('display_errors', 1);

	require_once(dirname(dirname(__FILE__)) . '/config.php');

	require_once('Common/Fun_FormatText.inc.php');
	require_once('Common/Lib/CommonLib.php');
	require_once('Common/Lib/ArrTargets.inc.php');
	require_once(dirname(__FILE__) . '/Lib.php');

	function esc($s) {
		return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
	}

	// ---- 大会の決め方は LiveScoreboard.php と同じ（Tour がなければログイン中の大会） ----
	$TourCode = !empty($_REQUEST['Tour']) ? stripslashes($_REQUEST['Tour']) : '';
	$TourId = $TourCode !== '' ? intval(getIdFromCode($TourCode)) : 0;
	if (!($TourId > 0) && !empty($_SESSION['TourId'])) {
		$TourId = intval($_SESSION['TourId']);
	}
	if (!($TourId > 0)) {
		include('Common/Templates/head-min.php');
		echo "error!";
		include('Common/Templates/tail-min-min.php');
		die();
	}

	$Reload = (!empty($_REQUEST['r']) && stripslashes($_REQUEST['r']) == '1');

	// 種目の絞り込み
	$EventFilter = [];
	if (!empty($_REQUEST['Event'])) {
		$raw = is_array($_REQUEST['Event']) ? $_REQUEST['Event'] : explode(',', stripslashes($_REQUEST['Event']));
		foreach ($raw as $e) {
			$e = trim($e);
			if ($e !== '' && preg_match('/^[0-9A-Za-z-]+$/', $e)) $EventFilter[] = $e;
		}
	}

	// ---- 大会の情報 ----
	$Rs = safe_r_sql("SELECT ToName, ToWhere, ToWhenFrom, ToWhenTo, ToCode, ToOnlineId,
			ToGolds AS GoldLabel, ToXNine AS XNineLabel
		FROM Tournament WHERE ToId={$TourId}");
	$Tour = safe_fetch($Rs);
	if (!$Tour) {
		include('Common/Templates/head-min.php');
		echo "error!";
		include('Common/Templates/tail-min-min.php');
		die();
	}
	$TourCode = $Tour->ToCode;

	// 団体の種目の一覧（切り替えリンク用）
	// （団体のチームができている種目だけ。種目があるだけでは出さない）
	$EventList = lsb_events($TourId, 1, false);

	// 団体の設定にない種目のコードは、絞り込みから外す（団体決勝から引き継いだときなど）
	$EventFilter = array_values(array_intersect($EventFilter, array_keys($EventList)));

	// ---- 団体予選順位を読む（Obj_Rank 系はセッションの大会を見るので、読む間だけ差し替える） ----
	$OrigTourId = $_SESSION['TourId'] ?? null;
	$_SESSION['TourId'] = $TourId;
	require_once('Common/Lib/Obj_RankFactory.php');

	$Sections = [];
	$Cand = [];
	// 表示する種目は、切り替えリンクと同じ順（種目の並び順）
	$want = $EventFilter ? array_values(array_intersect(array_keys($EventList), $EventFilter)) : array_keys($EventList);
	if ($want) {
		$opts = ['tournament' => $TourId, 'events' => $want];
		$rank = Obj_RankFactory::create('AbsTeam', $opts);
		$rank->read();
		$Data = $rank->getData();
		$Sections = $Data['sections'] ?? [];
		// チームの候補（ランキングに載っていない国を出すため）
		$Cand = lsb_team_candidates($TourId, $want);
	}

	if ($OrigTourId === null) unset($_SESSION['TourId']); else $_SESSION['TourId'] = $OrigTourId;

	function selfUrl($over) {
		$q = [];
		foreach (['Tour', 'Event', 'r'] as $k) {
			if (isset($_REQUEST[$k]) && $_REQUEST[$k] !== '') $q[$k] = is_array($_REQUEST[$k]) ? implode(',', $_REQUEST[$k]) : stripslashes($_REQUEST[$k]);
		}
		foreach ($over as $k => $v) {
			if ($v === null) unset($q[$k]); else $q[$k] = $v;
		}
		return 'LiveScoreboardTeam.php' . ($q ? '?' . http_build_query($q) : '');
	}

	// ---- 切り替えパネル：1 列目は共通、2 列目は種目（設定のある団体の種目だけ） ----
	// 種目のボタンのクラス event-link は、Signage.php が団体戦の設定の有無を調べるのに使う
	$LsbInfo = lsb_info($TourId);
	$LsbHdr = lsb_ianseo_header($TourId);
	$lsbSelf = ['Tour' => $TourCode, 'Event' => $EventFilter ? implode(',', $EventFilter) : null];
	$evBase = ['Tour' => $TourCode, 'r' => $Reload ? 1 : null];
	$evBtns = [];
	if (count($EventList) >= 1) {
		$evBtns[] = lsb_btn('すべて', lsb_url('LiveScoreboardTeam.php', $evBase), !$EventFilter, 'event-link');
		foreach ($EventList as $code => $name) {
			// 「すべて」は全部、種目は 1 つだけ選ぶ（押した種目だけにする）
			$on = in_array($code, $EventFilter);
			$evBtns[] = lsb_btn($name ?: $code, lsb_url('LiveScoreboardTeam.php', $evBase + ['Event' => $code]), $on, 'event-link');
		}
	}
	$LsbCtx = [
		'code' => $TourCode, 'reload' => $Reload, 'event' => $EventFilter ? implode(',', $EventFilter) : null, 'selfFile' => 'LiveScoreboardTeam.php', 'self' => $lsbSelf,
	];
	$PanelHtml = lsb_panel('team', $LsbInfo, $LsbCtx, [lsb_group('', $evBtns)]);

	$When = $Tour->ToWhenFrom . (($Tour->ToWhenTo && $Tour->ToWhenTo != $Tour->ToWhenFrom) ? '～' . $Tour->ToWhenTo : '');
?><!DOCTYPE html>
<html lang="ja" class="notranslate" translate="no">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, user-scalable=yes">
<meta name="google" content="notranslate">
<title><?php echo esc($Tour->ToName . ' - ' . $Tour->ToWhere . ' (' . $Tour->ToWhenFrom . ') 団体予選'); ?></title>
<style>
html{
   font-size:clamp(10pt, 1.3vw, 18pt);
   font-family:"UD新ゴ R";
   margin:1vmin;
}
h1,h2{ margin-bottom:0; }
table{ border-collapse:collapse; border-spacing:0; }
table th,table td{
  text-align:center;
  white-space:nowrap;
  white-space-collapse:preserve;
}
table th{
  background-color:#007db3;
  color:white;
  border:solid 1px black;
  height:1.3em;
}
table td{
  border:solid 1px black;
  padding:0.3em 0.5em;
}
td.score{ background:#eee; font-weight:bold; width:3rem; min-width:3rem; }
td.goldx9{ width:2rem; min-width:2rem; }
.r_country{
  width:12rem; min-width:12rem; text-align:left;
  border-right:2px solid black !important;
  border-left:2px solid black !important;
  font-weight:bold;
}
.r_name{
  width:8rem; min-width:8rem; text-align:left;
  border-right:2px solid black !important;
}
.boldleft{ border-left:2px solid black !important; }
.boldright{ border-right:2px solid black !important; }
tr.teamtop > th, tr.teamtop > td{ border-top:2px solid black; }
tr.teamend > th, tr.teamend > td{ border-bottom:2px solid black; }
td.teamtotal{ background:#eee; font-weight:bold; font-size:1.2em; }
td.member{ font-size:0.95em; }

<?php echo lsb_css() . $LsbHdr['css']; ?>
.nodata{ color:#888; padding:1em 0; }
@media print{ .noprint{ display:none !important; } }
</style>
<script type="text/javascript" src="//webfonts.sakura.ne.jp/js/sakurav3.js"></script>
</head>
<body>
<?php echo $LsbHdr['html']; ?>
<?php echo lsb_title($LsbInfo, '（団体予選）', $LsbCtx); ?>
<?php echo $PanelHtml; ?>
<?php
	if (!$want) {
		echo '<div class="nodata">表示する団体の予選順位がありません</div>';
	}

	foreach ($want as $evCode) {
		$section = $Sections[$evCode] ?? [];
		$items = $section['items'] ?? [];
		// ランキングにまだ載っていない国（得点の入力前、またはチームがまだ組めない国）の候補を、続けて出す
		$ranked = [];
		foreach ($items as $team) $ranked[$team['id']] = true;
		foreach ($Cand[$evCode] ?? [] as $team) {
			if (empty($ranked[$team['id']])) $items[] = $team;
		}
		echo '<h2>' . esc(($section['meta']['descr'] ?? '') ?: ($EventList[$evCode] ?? $evCode)) . '</h2>';
		if (!$items) {
			echo '<div class="nodata">まだチームがありません</div>';
			continue;
		}

		echo '<div class="table_box"><table>';
		echo '<tr><th rowspan=2 class="boldleft">順位</th><th rowspan=2 class="r_country">所属</th>';
		echo '<th rowspan=2 class="r_name">選手名</th>';
		echo '<th class="boldright">個人成績</th>';
		echo '<th colspan=3 class="boldright">団体成績</th></tr>';
		echo '<tr><th class="boldright">合計</th>';
		echo '<th class="ttotal">総合計</th><th class="goldx9">' . esc($Tour->GoldLabel) . '</th><th class="boldright goldx9">' . esc($Tour->XNineLabel) . '</th></tr>';

		foreach ($items as $team) {
			$members = $team['athletes'] ?? [];
			// チーム内は、個人の点数の高い順（同点なら 10+X、X の数の順）に並べる
			usort($members, function ($a, $b) {
				return intval($b['quscore'] ?? 0) <=> intval($a['quscore'] ?? 0)
					?: intval($b['qugolds'] ?? 0) <=> intval($a['qugolds'] ?? 0)
					?: intval($b['quxnine'] ?? 0) <=> intval($a['quxnine'] ?? 0);
			});
			$n = max(1, count($members));

			$irm = (!empty($team['irm']) && !empty($team['irmText'])) ? $team['irmText'] : '';
			$rankText = $irm !== '' ? $irm : ($team['rank'] !== '' ? $team['rank'] : '－');
			$hasScore = ($team['score'] != 0 || $team['hits'] != 0);

			for ($i = 0; $i < $n; $i++) {
				$m = $members[$i] ?? null;
				$cls = ($i == 0 ? 'teamtop ' : '') . ($i == $n - 1 ? 'teamend' : '');
				echo '<tr class="' . $cls . '" data-team="' . esc($evCode . '-' . $team['id'] . '-' . $team['subteam']) . '">';
				if ($i == 0) {
					echo '<th rowspan=' . $n . ' class="boldleft">' . esc($rankText) . '</th>';
					echo '<td rowspan=' . $n . ' class="r_country">' . esc($team['countryName']) . '</td>';
				}
				if ($m) {
					echo '<td class="r_name member">' . esc(trim(($m['familyname'] ?? '') . '  ' . ($m['givenname'] ?? ''))) . '</td>';
					echo '<td class="score boldright">' . esc($m['quscore'] ?? '') . '</td>';
				} else {
					echo '<td class="r_name member"></td>';
					echo '<td class="score boldright"></td>';
				}
				if ($i == 0) {
					echo '<td rowspan=' . $n . ' class="teamtotal">' . ($hasScore ? esc($team['score']) : '') . '</td>';
					echo '<td rowspan=' . $n . ' class="goldx9">' . ($hasScore ? esc($team['gold']) : '') . '</td>';
					echo '<td rowspan=' . $n . ' class="goldx9 boldright">' . ($hasScore ? esc($team['xnine']) : '') . '</td>';
				}
				echo '</tr>';
			}
		}
		echo '</table></div>';
		if (!empty($section['meta']['lastUpdate']) && $section['meta']['lastUpdate'] != '0000-00-00 00:00:00') {
			echo '<div style="color:#888;font-size:0.85em">最終更新 ' . esc($section['meta']['lastUpdate']) . '</div>';
		}
	}
?>
</body>
</html>
