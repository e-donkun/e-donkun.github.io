<?php
/*

変更履歴:251026

*/
	define('debug',false);
	define('IN_PHP', true);

	require_once(dirname(dirname(__FILE__)) . '/config.php');

	require_once('Common/Fun_FormatText.inc.php');
	require_once('TV/Fun_HTML.local.inc.php');
    require_once('Common/Lib/CommonLib.php');
	require_once('Common/Lib/ArrTargets.inc.php');


	if (empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		
		//printCrackError();
		$Select	= "SELECT ToId,ToCode,ToName,ToWhere 
		FROM Tournament 
		ORDER BY ToWhenTo DESC, ToWhenFrom DESC, ToCode ASC";
		$Rs=safe_r_sql($Select);
		include('Common/Templates/head-min.php');
		echo "<table>";
		if (safe_num_rows($Rs)>0) {
			echo '<tr>
				<th class="Title w-5">&nbsp;</th>
				<th class="Title w-10">'.get_text('TourCode','Tournament').'</th>
				<th class="Title w-30">'.get_text('TourName','Tournament').'</th>
				<th class="Title w-20">'.get_text('TourWhere','Tournament').'</th>
				</tr>';
			while ($MyRow=safe_fetch($Rs)) {
				print '<tr>';
				print '<td><a class="Link" href="?Tour=' . $MyRow->ToCode . '">' . get_text('Open') . '</a></td>';
				print '<td>' . $MyRow->ToCode . '</td>';
				print '<td>' . ManageHTML($MyRow->ToName) . '</td>';
				print '<td>' . ManageHTML($MyRow->ToWhere) . '</td>';
				print '</tr>';
			}
		}
		echo '</table>';
		include('Common/Templates/tail-min-min.php');
		die();
	}


	$TourCode=stripslashes($_REQUEST['Tour']);
	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
	$Order=stripslashes($_REQUEST['Order']);
	if($Order==""){
		$Order="Ranking";
	}
	
  //checkFullACL(AclOutput,'outTv', AclReadOnly,true, $TourId);
	
  if(! ($TourId > 0) ){
    include('Common/Templates/head-min.php');
    echo "error!";
    include('Common/Templates/tail-min-min.php');
    die();
  }
    
	$tmpSel='';
	for ($i=1; $i<=2; $i++) {
		$tmpSel .= "QuD{$i}Score, QuD{$i}Hits, QuD{$i}Gold, QuD{$i}Xnine, QuD{$i}ArrowString, Td{$i}, DiEnds{$i}, DiArrows{$i}, ";
	}
		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,
			IF(CoName != '', CoName, CoCode) AS CountryName,
			QuTargetNo, QuTarget,QuLetter,
			$tmpSel
			QuScore, QuGold, QuXnine,
			ToId,ToGolds AS GoldLabel, ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
			DivDescription,ClDescription,DivViewOrder,ClViewOrder,
			ToName,ToWhere,ToWhenFrom,ToWhenTo,ToCode,QuSession,
			IF(QuClRank = 0,10000,QuClRank) as ClRank,
			ToOnlineId
		FROM 
       Tournament 
        LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType
        LEFT JOIN Entries ON EnTournament=ToId AND EnAthlete=1 AND CONCAT(EnDivision,EnClass) LIKE TdClasses
        LEFT JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament 
        LEFT JOIN Qualifications ON QuId=EnId
        LEFT JOIN (
            SELECT
                a.DiTournament
                , a.DiSession
                , a.DiEnds AS DiEnds1
                , a.DiArrows AS DiArrows1
                , b.DiEnds AS DiEnds2
                , b.DiArrows AS DiArrows2 
            FROM
                DistanceInformation a 
                JOIN DistanceInformation b 
                    ON a.DiTournament = b.DiTournament 
                    AND a.DiSession = b.DiSession
                    AND a.DiType = b.DiType 
            WHERE
                a.DiDistance = 1 AND b.DiDistance = 2
                AND a.DiType='Q' ) DistInfo
            ON DiTournament=ToId and DiSession=QuSession
        LEFT JOIN Divisions ON DivTournament=EnTournament AND DivId=EnDivision    
        LEFT JOIN Classes ON ClTournament=EnTournament AND ClId=EnClass
		
		WHERE ToId = {$TourId}	
		";
	//var_dump($Select);
	$Rs=safe_r_sql($Select);
	

	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}
  
  
	if($Order === "Target"){
		//セッションー的番号順
		usort($ArrayData, function($a, $b) {
			return $a['QuSession'] <=> $b['QuSession'] // QuSession は昇順
				?: $a['QuTargetNo'] <=> $b['QuTargetNo'];   			// QuTargetNo は昇順
		});
	
	} else {
		//ランキング順
		usort($ArrayData, function($a, $b) {
			return $a['DivViewOrder'] <=> $b['DivViewOrder'] // DivViewOrder は昇順
				?: $a['ClViewOrder'] <=> $b['ClViewOrder']   			// ClViewOrder は昇順
				?: $a['Class'] <=> $b['Class']   			// Class は昇順
				?: $a['ClRank'] <=> $b['ClRank'];      	// QuClRank は昇順
		});
	}

  $Tour = $ArrayData[0];

	//include('Common/Templates/head-min.php');
	
	//echo "<pre>";var_dump($ArrayData[0]);echo "</pre>";
	
	echo <<<EOM
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, user-scalable=yes">
<title>{$Tour['ToName']} - {$Tour['ToWhere']} ({$Tour['ToWhenFrom']}) </title>
<script type="text/javascript" src="//webfonts.sakura.ne.jp/js/sakurav3.js"></script>
<style>
html{
   font-size:clamp(6pt, 1.0vw, 14pt);
   font-family:"UD新ゴ R";
   margin:1vmin;
}

thead {
  top: 0;
  left: 0;	
}

h1,h2{
  margin-bottom:0;
}

/*
.table_box {
  overflow-x: auto;
  max-width: 100%;
}
*/

table {
  /* width: max-content;  */
  border-collapse:collapse;
  border-spacing: 0;
}

table th,table td{
  text-align: center;
  white-space:nowrap;
  white-space-collapse: preserve;
}

table th{
  background-color: #c79852 !important;
  color: white;
  border:solid 1px black;
  height:1.3em;
}

table td{
  border:solid 1px black;
  padding: 0.3em 0.5em;
}

td.score {
  background:#eee;
  font-weight:bold;
	width:3rem;
	max-width:3rem;
	min-width:3rem;
}
td.goldx9 {
	width:2rem;
	max-width:2rem;
	min-width:2rem;
}
td.s{
  /* display:inline-block; */
  width:1.5em;
  background:#eee;
  margin:1px;
 
}

.r_class{
	width:3rem;
	max-width:3rem;
	min-width:3rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}
.r_name{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
	font-weight:bold;
	/* position: sticky;
	left: 0;
	background-color: white;
	z-index: 2;  */
}
.r_country{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}

.boldleft {
  border-left: 2px solid black !important;
}
.boldright {
  border-right: 2px solid black;
}
.doubleleft {
  border-left: 2px double black !important;
}

.highlight > th{
	background: #863 !important;
}
.highlight > td{
	background: #88663340 !important;
}

@media print {
  .noprint {
    display: none !important;
  }
}


</style>
</head>
<body>
<h1>{$Tour['ToName']}</h1>
<div>会場:{$Tour['ToWhere']} (日程:{$Tour['ToWhenFrom']}
EOM;


  if($Tour['ToWhenFrom'] != $Tour['ToWhenTo']){
      echo "～{$Tour['ToWhenTo']}";
  }
  echo ")</div>";

  echo "<div class='noprint'>";
  if($Order === "Target" ){
     echo "[<a href='?Order=Ranking'>ランキング</a>][ターゲット順]";	  
  } else {
     echo "[ランキング][<a href='?Order=Target'>ターゲット順</a>]";
  }
  
  if($Tour['ToOnlineId']>0){
	echo "[<a href='https://www.ianseo.net/Details.php?toId={$Tour['ToOnlineId']}'>I@nseoへ</a>]";
  }
  echo "</div>";
  
  $preClass = "";
  $preSession = "";
  $preTarget = "";
  $flgHighlight = false;
	
	foreach($ArrayData as $Data){
		
		if(is_null($Data["EnId"])){
			continue;
		}
		
		if($preTarget != $Data['QuTarget']){
			$flgHighlight = !$flgHighlight;
		}
    
		if( ( $Order==="Target" && $preSession != $Data['QuSession'] ) || ( $Order!=="Target" && $preClass != $Data['Class'])){
		  if( $preSession != ""  || $preClass != "" ){
			echo "</table>\n";
			echo "</div>";
		  }
		  
		  if( $Order==="Target" ) {
				echo "<h2>セッション{$Data['QuSession']}</h2>";  
		  } else {
				echo "<h2>{$Data['DivDescription']}{$Data['ClDescription']}</h2>";   
		  }
		  
		  echo <<<EOM
<div class='table_box'>
<table>
<tr>
EOM;
		  echo "<th rowspan=2 class='boldleft'>".($Order==="Target" ? "的番号" : "順位")."</th>";
		  echo <<<EOM
	<th rowspan=2 class="r_class">クラス</th>
	<th rowspan=2 class="r_name">選手名</th>
	<th rowspan=2 class="boldright r_country">所属</th>
  <th colspan=3 class="boldright">総合成績</th>
EOM;
		  echo "<th colspan=".(intval($Data['DiEnds1'])+1)." class='boldright'>{$Data['Td1']}</th>\n";    
		  echo "<th colspan=".(intval($Data['DiEnds2'])+1)." class='boldright'>{$Data['Td2']}</th>\n";   
		  echo <<<EOM
</tr>
<tr>
	<th class="boldleft">総合計</th>
	<th class="s">{$Data['GoldLabel']}</th>
	<th class="boldright s">{$Data['XNineLabel']}</th>
EOM;

		  foreach(range(1,$Data['DiEnds1']) as $i){
			echo "<th class='s'>{$i}</th>\n";
		  }
		  echo "<th class='doubleleft boldright'>合計</th>\n";
		  foreach(range(1,$Data['DiEnds2']) as $i){
			echo "<th class='sticky'>{$i}</th>\n";
		  }
		  echo "<th class='doubleleft boldright'>合計</th>\n";
		  echo "</tr>\n";
		  

		}
		$preClass = $Data['Class'];
		$preSession = $Data["QuSession"];
		$preTarget = $Data["QuTarget"];
		
		
		$_RankText = $Order==="Target" ? str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT) : $Data['ClRank']; 
		if( intval($Data['ClRank'])>10000 ) {
			$_RankText = $Order==="Target" ? $_RankText : "欠";
			$Data['QuD1ArrowString'] = "";
			$Data['QuD2ArrowString'] = "";
			$Data['QuScore'] = "欠";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
			$Data['QuD1Score'] = "";
			$Data['QuD2Score'] = "";			
		} else if( intval($Data['ClRank'])==10000 ) {
			$_RankText = $Data['QuSession']."-".str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT);
			$Data['QuD1ArrowString'] = "";
			$Data['QuD2ArrowString'] = "";
			$Data['QuScore'] = "";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
			$Data['QuD1Score'] = "";
			$Data['QuD2Score'] = "";	
		}
		
    
		$ArrayD1Score = [];
		foreach(str_split(substr($Data['QuD1ArrowString'],0,$Data['QuD1Hits']), $Data['DiArrows1']) as $EndArrow){
			if($EndArrow!=="      "){
				$ArrayD1Score[] = ValutaArrowString($EndArrow);
			} else {
				$ArrayD1Score[] = "";
			}
		}
		$ArrayD2Score = [];
		foreach(str_split(substr($Data['QuD2ArrowString'],0,$Data['QuD2Hits']), $Data['DiArrows2']) as $EndArrow){
			if($EndArrow!=="      "){
				$ArrayD2Score[] = ValutaArrowString($EndArrow);
			} else {
				$ArrayD2Score[] = "";
			}
		}
    
		$D1Score = "";
		for($i=0;$i<$Data['DiEnds1'];$i++){
		  $D1Score .= "<td class='s'>".($ArrayD1Score[$i] ?? '')."</td>";
		}
		
		$D2Score = "";
		for($i=0;$i<$Data['DiEnds2'];$i++){
		  $D2Score .= "<td class='s'>".($ArrayD2Score[$i] ?? '')."</td>";
		}
		
		$_trclass = ($Order === "Target" && $flgHighlight) ? 'highlight' : '';
		
		echo <<<EOM
<tr class='target-{$Data['QuTarget']} {$_trclass}'>
	<th class="boldleft">{$_RankText}</th>
	<td class="r_class">{$Data['Class']}</td>
EOM;
	
		$_Name = "{$Data['EnFirstName']}  {$Data['EnName']}";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($_Name,16)."</td>";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($Data['CountryName'],16)."</td>";
		echo <<<EOM
  <td class='score sticky'>{$Data['QuScore']}</td>
	<td class='goldx9'>{$Data['QuGold']}</td>
	<td class='goldx9 boldright'>{$Data['QuXnine']}</td>
  {$D1Score}
	<td class='score doubleleft boldright'>{$Data['QuD1Score']}</td>
  {$D2Score}
	<td class='score doubleleft boldright'>{$Data['QuD2Score']}</td>
</tr>
EOM;

	}
	echo "</table></div>";

	include('Common/Templates/tail-min.php');



function shrinktext($_Text,$maxsize){
  $_cnt = mb_strwidth($_Text);
  if($_cnt==0) $_cnt = 1;
  
  if($_cnt<$maxsize){
    $_size = 1;
  } else {
    $_size = $maxsize/$_cnt;
  }
  
  return "<div style='transform-origin: 0 0;transform:scale({$_size},1);'>{$_Text}</div>";
}
