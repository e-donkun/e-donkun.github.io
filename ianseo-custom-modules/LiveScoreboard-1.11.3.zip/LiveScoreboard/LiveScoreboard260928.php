<?php
/*
【検証用】LiveScoreboard.php を変えずに、距離別（Order=Distance）の直しを試すための写し。
  ・メニューに［距離別］を出し、ランキング・ターゲット順と切り替えられるようにする
  ・距離別はいつも全セッションで集計し、セッションの切り替えボタンは出さない
  ・距離の名前の全角・半角の違い（30ｍ と 30m）を同じ距離とみなす
  ・X と 10 点の数を、大会の見出し（X / 10 / 10+X）で見分けて並べる
検証が済んだら LiveScoreboard.php に反映して、このファイルは消す。

表示順（Order）:
  Ranking   クラスごとの順位（既定）
  Target    的番号順
  Distance  距離別。部門ごとに、同じ距離（距離の名前の組み合わせ）ならクラスが違ってもまとめ、
            男女別に 総合得点 → X の数 → 10 点の数 の順で並べる。
            順位は総合得点だけでつける（同点なら、X や 10 点の数が違っても同順位）。

変更履歴:
2026/09/28 距離別はいつも全セッションで集計し、セッションの切り替えボタンを出さない
2026/09/28 距離別を画面のメニュー（［距離別］）から切り替えられるようにする
2026/09/28 距離別：距離の名前の全角・半角の違い（30ｍ と 30m など）を同じ距離とみなす。
           X と 10 点の数を、大会の「ゴールド」「Xナイン」の見出し（X / 10 / 10+X）から見分けて並べる
2026/09/27 距離別を部門ごとに分ける（クラスが違ってもまとめるのはそのまま）
2026/09/27 距離別の順位を総合得点だけでつける（同点は同順位）
2026/09/27 距離別（Order=Distance）を追加
2026/08/23 スコアカード不具合調整
2026/06/14 スコアカード機能を追加
2026/05/31 セッション絞り込みをトグル複数選択に変更
2026/05/31 セッション絞り込みメニューを追加
2026/03/15 セッション名が表示されるように変更
2025/11/17 セッションを持っていない場合は表示させないように変更
2025/10/26 初版
*/
	define('debug',false);
	define('IN_PHP', true);
	ini_set('display_errors', 1);

	require_once(dirname(dirname(__FILE__)) . '/config.php');

	require_once('Common/Fun_FormatText.inc.php');
	require_once('TV/Fun_HTML.local.inc.php');
	require_once('Common/Lib/CommonLib.php');
	require_once('Common/Lib/ArrTargets.inc.php');

	$TourCode=stripslashes($_REQUEST['Tour']);
  

	// セッション複数選択：s[] で受け取り、整数配列に正規化
	$GameSessions = [];
	if (!empty($_REQUEST['s'])) {
		$raw = $_REQUEST['s'];
		if (is_array($raw)) {
			foreach ($raw as $v) {
				$v = intval($v);
				if ($v > 0) $GameSessions[] = $v;
			}
		} else {
			$v = intval($raw);
			if ($v > 0) $GameSessions[] = $v;
		}
		$GameSessions = array_unique($GameSessions);
		sort($GameSessions);
	}

	if (empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		include('Common/Templates/head-min.php');
		echo "<a href='https://ianseo.net'>i@nseo.net</a>";
		include('Common/Templates/tail-min-min.php');
		die();
	}
	else if (!empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		$Select	= "SELECT ToId,ToCode,ToName,ToWhere,ToNumDist
			FROM Tournament WHERE ToId='".$_SESSION['TourId']."'";	
		$Rs=safe_r_sql($Select);
		$MyRow=safe_fetch($Rs);
		$TourCode = $MyRow->ToCode;
	}

	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
	$Order=stripslashes($_REQUEST['Order']);
	if($Order==""){
		$Order="Ranking";
	}

	// 距離別はいつも全セッションで集計する（s[] は使わない）
	if($Order==="Distance"){
		$GameSessions = [];
	}
	
  if(! ($TourId > 0) ){
    include('Common/Templates/head-min.php');
    echo "error!";
    include('Common/Templates/tail-min-min.php');
    die();
  }
 

    

	// ----------------------------------------
	// セッション一覧を取得
	// ----------------------------------------
	$SelectSessions = "
		SELECT DISTINCT QuSession, SesName
		FROM Qualifications
		LEFT JOIN Entries ON EnId = QuId AND EnTournament = {$TourId} AND EnAthlete = 1
		LEFT JOIN Session ON SesTournament = {$TourId} AND SesOrder = QuSession AND SesType = 'Q'
		WHERE EnTournament = {$TourId}
		ORDER BY QuSession ASC
	";
	$RsSessions = safe_r_sql($SelectSessions);
	$SessionList = [];
	while ($SesRow = safe_fetch($RsSessions)) {
		$SessionList[] = [
			'QuSession' => intval($SesRow->QuSession),
			'SesName'   => $SesRow->SesName,
		];
	}

	// ----------------------------------------
	// セッションパラメータをURLクエリ文字列に変換するヘルパー
	// ----------------------------------------
	function buildSesParam($sessions) {
		if (empty($sessions)) return "";
		$parts = [];
		foreach ($sessions as $s) {
			$parts[] = "s[]=" . intval($s);
		}
		return "&" . implode("&", $parts);
	}

	// あるセッションをトグルした場合の選択リストを返す
	function toggleSession($current, $toggleId) {
		if (in_array($toggleId, $current)) {
			$next = array_values(array_filter($current, fn($v) => $v !== $toggleId));
		} else {
			$next = array_merge($current, [$toggleId]);
			sort($next);
		}
		return $next;
	}

  // 距離の種類を取得
  $Select	= "SELECT ToNumDist FROM Tournament WHERE ToId= {$TourId}";
  $Rs=safe_r_sql($Select);
  $MyRow=safe_fetch($Rs);
  $ToNumDist = $MyRow->ToNumDist;
  
  // 距離の情報を取得
  $Select	= "SELECT DiSession,DiDistance,DiEnds,DiArrows FROM DistanceInformation WHERE DiTournament= {$TourId}";
  $Rs=safe_r_sql($Select);
 	$DistanceInfo = [];
	while( $MyRow=safe_fetch($Rs) ){
		$tmpArray = json_decode(json_encode($MyRow), true);
    
    $DistanceInfo[$tmpArray['DiSession']][$tmpArray['DiDistance']]=$tmpArray;
	}
  //$ToNumDist = 3;
  
	$tmpSel='';
	for($di=1; $di<=$ToNumDist; $di++) {
		$tmpSel .= "QuD{$di}Score, QuD{$di}Hits, QuD{$di}Gold, QuD{$di}Xnine, QuD{$di}ArrowString, Td{$di},"; // DiEnds{$di}, DiArrows{$di}, ";
	}

	// WHERE句：複数セッション対応
	$tmpSession = "";	
	if (!empty($GameSessions)) {
		$inList = implode(",", $GameSessions);
		$tmpSession = "AND QuSession IN ({$inList}) ";
	}
		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,EnSex,
			IF(CoName != '', CoName, CoCode) AS CountryName,
			QuTargetNo, QuTarget,QuLetter,
			$tmpSel
			QuScore, QuGold, QuXnine,
			ToId,ToGoldsChars,ToGolds AS GoldLabel,ToXNineChars,ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
			DivDescription,ClDescription,DivViewOrder,ClViewOrder,
			ToName,ToWhere,ToWhenFrom,ToWhenTo,ToCode,QuSession,SesName,
			IF(QuClRank = 0,10000,QuClRank) as ClRank,
			ToOnlineId
		FROM 
       Tournament 
        LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType
        LEFT JOIN Entries ON EnTournament=ToId AND EnAthlete=1 AND CONCAT(EnDivision,EnClass) LIKE TdClasses
        LEFT JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament 
        LEFT JOIN Qualifications ON QuId=EnId
        LEFT JOIN Divisions ON DivTournament=EnTournament AND DivId=EnDivision    
        LEFT JOIN Classes ON ClTournament=EnTournament AND ClId=EnClass
        LEFT JOIN Session ON SesTournament=EnTournament AND SesOrder=QuSession AND SesType='Q'
		WHERE ToId = {$TourId} $tmpSession
		";
	$Rs=safe_r_sql($Select);



	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}

	
	
/* 	echo "<pre>";
	var_dump($ArrayData);
	echo "</pre>"; */
	
	$isTarget = ($Order === "Target");
	$isDistance = ($Order === "Distance");

	if($isTarget){
 		usort($ArrayData, function($a, $b) {
			return $a['QuSession'] <=> $b['QuSession']
            ?: $a['QuTarget'] <=> $b['QuTarget']
            ?: $a['QuLetter'] <=> $b['QuLetter'];
		}); 
	} else {
		usort($ArrayData, function($a, $b) {
			return $a['DivViewOrder'] <=> $b['DivViewOrder']
				?: $a['QuSession'] <=> $b['QuSession']
				?: $a['ClViewOrder'] <=> $b['ClViewOrder']
				?: $a['Class'] <=> $b['Class']
				?: $a['ClRank'] <=> $b['ClRank']
        ?: $a['QuTarget'] <=> $b['QuTarget']
        ?: $a['QuLetter'] <=> $b['QuLetter'];        
		});
	}

	// ---- 距離別：同じ距離なら男女別にまとめ、総合得点 → X → 10 点の数 の順に並べる ----
	// （10 点の数は、X の数が同じなら「10+X」の数で比べるのと同じ）
	$GroupEnds = [];
	if($isDistance){
		// 距離の名前は、全角・半角の違いや空白を無視して比べる（「30ｍ」と「30m」を同じ距離にする）
		$distDisp = function($s) {
			return trim(mb_convert_kana((string)$s, 'as', 'UTF-8'));
		};
		$distKey = function($s) use ($distDisp) {
			return strtolower(preg_replace('/\s+/u', '', $distDisp($s)));
		};

		// X の数と 10 点（または 10+X）の数が、QuGold / QuXnine のどちらに入っているかを見出しで見分ける。
		// 世界基準の設定はゴールド＝10+X・Xナイン＝X、京都の大会ではゴールド＝X・Xナイン＝10 のことがある
		$firstRow = null;
		foreach($ArrayData as $d){
			if(!is_null($d['EnId'])){ $firstRow = $d; break; }
		}
		$isX = function($label) use ($distKey) {
			return $distKey($label) === 'x';
		};
		if($firstRow && $isX($firstRow['GoldLabel']) && !$isX($firstRow['XNineLabel'])){
			$tie1 = 'QuGold';  $tie2 = 'QuXnine';
		} else if($firstRow && $isX($firstRow['XNineLabel'])){
			$tie1 = 'QuXnine'; $tie2 = 'QuGold';
		} else {
			$tie1 = 'QuGold';  $tie2 = 'QuXnine'; // どちらも X でなければ ianseo の並び（ゴールド → Xナイン）
		}

		// 部門・距離の出てくる順は、ランキングの並び（上の usort の結果）で最初に出てきた順にする
		$DistOrder = [];
		foreach($ArrayData as &$d){
			if(is_null($d['EnId'])) continue;
			$names = [];
			$keys = [];
			for($di=1; $di<=$ToNumDist; $di++) {
				$names[] = $distDisp($d["Td{$di}"]);
				$keys[] = $distKey($d["Td{$di}"]);
			}
			// 部門は分け、クラスは分けない
			$dk = $d['EnDivision'] . '|' . implode('/', $keys);
			if(!isset($DistOrder[$dk])) $DistOrder[$dk] = count($DistOrder);
			$sex = intval($d['EnSex']);
			$d['DistIdx'] = $DistOrder[$dk];
			$d['DistGroup'] = $dk . '|' . $sex;
			$d['DistTitle'] = trim(trim((string)$d['DivDescription']) . ' ' . implode('・', array_unique(array_filter($names, 'strlen')))) . ' ' . ($sex == 1 ? '女子' : '男子');

			// セッションでエンド数が違うこともあるので、まとめた表ではいちばん多いエンド数で列を作る
			for($di=1; $di<=$ToNumDist; $di++) {
				$ends = intval($DistanceInfo[$d['QuSession']][$di]['DiEnds'] ?? 0);
				$GroupEnds[$d['DistGroup']][$di] = max($GroupEnds[$d['DistGroup']][$di] ?? 0, $ends);
			}
		}
		unset($d);

		usort($ArrayData, function($a, $b) use ($tie1, $tie2) {
			$aOut = intval($a['ClRank']) >= 10000; // 欠・未集計は最後
			$bOut = intval($b['ClRank']) >= 10000;
			return ($a['DistIdx'] ?? PHP_INT_MAX) <=> ($b['DistIdx'] ?? PHP_INT_MAX)
				?: intval($a['EnSex']) <=> intval($b['EnSex'])
				?: $aOut <=> $bOut
				?: intval($b['QuScore']) <=> intval($a['QuScore'])
				?: intval($b[$tie1]) <=> intval($a[$tie1])
				?: intval($b[$tie2]) <=> intval($a[$tie2])
				?: intval($a['ClRank']) <=> intval($b['ClRank'])
				?: $a['QuSession'] <=> $b['QuSession']
				?: $a['QuTarget'] <=> $b['QuTarget']
				?: $a['QuLetter'] <=> $b['QuLetter'];
		});

		// まとめた中での順位。並びは X・10 点の数も使うが、順位は総合得点だけでつける（同点なら同順位）
		$preGroup = null;
		$cnt = 0;
		$rank = 0;
		$preKey = null;
		foreach($ArrayData as &$d){
			if(is_null($d['EnId'])) continue;
			if($d['DistGroup'] !== $preGroup){
				$preGroup = $d['DistGroup'];
				$cnt = 0;
				$preKey = null;
			}
			if(intval($d['ClRank']) >= 10000){
				$d['DistRank'] = '';
				continue;
			}
			$cnt++;
			$key = intval($d['QuScore']);
			if($key !== $preKey){
				$rank = $cnt;
				$preKey = $key;
			}
			$d['DistRank'] = $rank;
		}
		unset($d);
	}

	$Tour = $ArrayData[0];
	$labelGold = $Tour["GoldLabel"];
	$labelXNine = $Tour["XNineLabel"];
	$pointGold  = ValutaArrowString(substr($Tour["ToGoldsChars"], 0, 1));
	$pointXNine = ValutaArrowString(substr($Tour["ToXNineChars"], 0, 1));

	// 自動更新フラグ
	$mode_reload = "";
	if(stripslashes($_REQUEST['r'])=="1"){
		$mode_reload = "&r=1";
	}

	// 現在のセッションパラメータ文字列（リンク引き継ぎ用）
	$sesParam = buildSesParam($GameSessions);

	echo <<<EOM
<!DOCTYPE html>
<html lang="ja" class="notranslate" translate="no">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, user-scalable=yes">
<meta name="google" content="notranslate">
<title>{$Tour['ToName']} - {$Tour['ToWhere']} ({$Tour['ToWhenFrom']}) </title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
<style>
html{
   font-size:clamp(6pt, 1.0vw, 14pt);
   font-family:"UD新ゴ R";
   margin:1vmin;
}

thead {
  top: 0;
  left: 0;	
}

h1,h2{
  margin-bottom:0;
}

table {
  border-collapse:collapse;
  border-spacing: 0;
}

table th,table td{
  text-align: center;
  white-space:nowrap;
  white-space-collapse: preserve;
}

table th{
  background-color: #c79852 ;
  color: white;
  border:solid 1px black;
  height:1.3em;
}

th.dilabel {
	min-width:5rem;
}

.dibutton {
    display: flex;
    justify-content: center;
    align-items: center;
    min-width:5rem;
    margin:0 auto;
    padding: 0;
    border: 1px solid #000;
    border-radius: 5px;
    font-size: 0.8em;
    background-color: #634C29 ;
    color: white;    
    pointer-events: none;
}

table th.boldleft:first-child {
	width:3rem;
}


table td{
  border:solid 1px black;
  padding: 0.3em 0.5em;
}

td.score {
  background:#eee;
  font-weight:bold;
	width:3rem;
	max-width:3rem;
	min-width:3rem;
}
td.goldx9 {
	width:2rem;
	max-width:2rem;
	min-width:2rem;
}
td.s{
  width:1.5em;
  /* background:#eee; */
  margin:1px;
}

td.blank {
  background-image: 
    linear-gradient(20deg, transparent 49%, black 49%, black 51%, transparent 51%), /* 右下がり */
    linear-gradient(-20deg, transparent 49%, black 49%, black 51%, transparent 51%); /* 右上がり */
}

/* スコアカード */
#sc td {
	min-width:2rem;
	height:1.8rem;
}

#sc th {
	min-width:1.5rem;
}


#sc td.point {
  width:2rem;
	min-width:2rem;
  max-width:2rem;
  font-weight:bold;
  font-size:1.2rem;
  border:2px solid black;
}

#sc td.total {
  width:3rem;
	min-width:3rem;
  max-width:3rem;
  font-weight:bold;
  font-size:1.2rem;
  border:2px solid black;
}

table.sctable > tbody > tr {
  vertical-align:top;	
}
table.sctable > tbody > tr > td {
   border:0;	
   padding:1rem;
}

.btn_card > .material-icons {
  cursor: pointer;
  font-size:1.3rem;
}

.r_class{
	/*width:3rem;*/
	max-width:6rem;
	min-width:3rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}
.r_name{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
	font-weight:bold;
}
.r_country{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}

.boldleft {
  border-left: 2px solid black !important;
}
.boldright {
  border-right: 2px solid black;
}
.doubleleft {
  border-left: 2px double black !important;
}

.highlight > th{
	background: #863 !important;
}
.highlight > td{
	background: #88663340 !important;
}

/* セッショントグルボタン */
.session-toggle-btn {
  display: inline-block;
  margin: 0 2px;
  padding: 1px 7px;
  border: 1px solid #999;
  border-radius: 4px;
  text-decoration: none;
  color: #333;
  background: #f5f5f5;
  font-size: inherit;
  cursor: pointer;
  user-select: none;
}
.session-toggle-btn:hover {
  background: #e8e8e8;
}
.session-toggle-btn.active {
  background: #c79852;
  border-color: #a07030;
  color: white;
  font-weight: bold;
}
.session-toggle-btn.all-btn.active {
  background: #555;
  border-color: #333;
}

.hidden {
  display:none;	
}
@media print {
  .noprint {
    display: none !important;
  }
}
</style>
<script type="text/javascript" src="//webfonts.sakura.ne.jp/js/sakurav3.js"></script>
</head>
<body>
EOM;

	if(!empty($_SESSION['TourId'])){
		echo "<div class='noprint' style='text-align:right;'><a href='../../../Main.php'>大会情報参照</a></div>";
	}

	echo <<<EOM
<h1>{$Tour['ToName']}</h1>
<div>{$TourCode}</div>
<div>会場:{$Tour['ToWhere']} (日程:{$Tour['ToWhenFrom']}
EOM;

  if($Tour['ToWhenFrom'] != $Tour['ToWhenTo']){
      echo "～{$Tour['ToWhenTo']}";
  }
  echo ")</div>"; 

  echo "<div class='noprint'>";

//  if($Tour['ToOnlineId']>0){
//    echo <<<EOM
//<div style="margin:1em;padding:2em;background:yellow;font-size:2rem;">
//個人・団体の決勝トーナメントは ianseo.net をご覧ください<br>
//[<a href='https://www.ianseo.net/Details.php?toId={$Tour['ToOnlineId']}'>i@nseoへ</a>]<br>
//</div>
//EOM;

  
//  }
  
  

  // ---- 表示順メニュー ----
  $curOrder = $isTarget ? "Target" : ($isDistance ? "Distance" : "Ranking");
  foreach(["Ranking" => "ランキング", "Target" => "ターゲット順", "Distance" => "距離別"] as $ordKey => $ordLabel){
     if($ordKey === $curOrder){
        echo "[{$ordLabel}]";
     } else {
        echo "[<a href='?Tour={$TourCode}&Order={$ordKey}{$sesParam}{$mode_reload}'>{$ordLabel}</a>]";
     }
  }
  
  if($Tour['ToOnlineId']>0){
	echo "[<a href='https://www.ianseo.net/Details.php?toId={$Tour['ToOnlineId']}'>i@nseoへ</a>]";
  }

  echo "　　";

  // ---- 自動更新メニュー ----
  if(stripslashes($_REQUEST['r'])=="1"){
		echo <<<EOM
<span style='border:1px solid black' id='count'>30</span>
<script>
  cnt = -1;
  interval_flg = true;
  setInterval(() => {
    cnt = parseInt(document.getElementById('count').innerHTML);
    if(interval_flg)cnt--;
    document.getElementById('count').innerHTML = cnt;
    if(cnt==0){
      cnt=30;
      location.reload();
    }
  }, 1000);
</script>
EOM;
		echo "[<a href='?Tour={$TourCode}&Order={$Order}{$sesParam}'>更新停止</a>]";
	} else {
		echo "[<a href='?Tour={$TourCode}&Order={$Order}&r=1{$sesParam}'>自動更新</a>]";
	}

  echo "</div>"; // .noprint

  $preClass = "";
  $preSession = "";
  $preTarget = "";
  $preDistance = "";
  $preGroup = "";
  $flgHighlight = false;
  $flg_First = true;
	
	foreach($ArrayData as $Data){
		
		if(is_null($Data["EnId"])){
			continue;
		}
		
		if($preTarget != $Data['QuTarget']){
			$flgHighlight = !$flgHighlight;
		}
    
		if( $isTarget ){
			$newBlock = ( $preSession != $Data['QuSession'] || $preDistance != $Data['Td1'] );
		} else if( $isDistance ){
			$newBlock = ( $preGroup !== $Data['DistGroup'] );
		} else {
			$newBlock = ( $preClass != $Data['Class'] );
		}

		if( $newBlock ){
		  if( $flg_First ){
			  $flg_First = false;
		  } else {
			if( !$isTarget || $preSession != $Data['QuSession'] ){
				echo "</table><!-aa->\n</div>";
			} else {
				
			}
		  }
		  
		  if( $isTarget ) {
			    if( $preSession != $Data['QuSession'] ){
					echo "<h2>".($Data['SesName'] ?: "セッション".$Data['QuSession'])."</h2>"; 
					echo "<div class='table_box'><table>";	
				}				
		  } else if( $isDistance ) {
				echo "<h2>{$Data['DistTitle']}</h2>";
                echo "<div class='table_box'><table>";	
		  } else {
				echo "<h2>{$Data['DivDescription']}{$Data['ClDescription']}</h2>";   
                echo "<div class='table_box'><table>";	
		  }
		  
		  echo <<<EOM
<tr>
EOM;
		  echo "<th rowspan=2 class='boldleft'>".($Order==="Target" ? "的番号" : "順位")."</th>";
		  echo (($isTarget || $isDistance) ? "<th rowspan=2 class='r_class'>クラス</th>" : ""); 
		  echo <<<EOM
	<th rowspan=2 class="r_name">選手名</th>
	<th rowspan=2 class="boldright r_country">所属</th>
  <th colspan=3 class="boldright">総合成績</th>
EOM;
      for($di=1; $di<=$ToNumDist; $di++) {
          $hdrEnds = $isDistance ? $GroupEnds[$Data['DistGroup']][$di] : $DistanceInfo[$Data['QuSession']][$di]['DiEnds'];
  		  echo "<th colspan=".(intval($hdrEnds)+1)." class='dilabel boldright di{$di}' data-di='{$di}' data-ends='".$hdrEnds."'><span class='dibutton'>".($isDistance ? $distDisp($Data["Td{$di}"]) : $Data["Td{$di}"])."</span></th>\n";  
      }
		  echo <<<EOM
	<th rowspan='2' class='noprint' style='font-size:0.8em'>スコア<br>カード</th>
</tr>
<tr>
	<th class="boldleft">総合計</th>
	<th class="goldx9">{$Data['GoldLabel']}</th>
	<th class="boldright goldx9">{$Data['XNineLabel']}</th>
EOM;

      for($di=1; $di<=$ToNumDist; $di++) {
        $hdrEnds = $isDistance ? $GroupEnds[$Data['DistGroup']][$di] : $DistanceInfo[$Data['QuSession']][$di]['DiEnds'];
        foreach(range(1,$hdrEnds) as $i){
          echo "<th class='s d{$di}'>{$i}</th>\n";
        }
        echo "<th class='doubleleft boldright'>合計</th>\n";
      }
		echo <<<EOM
</tr>	
EOM;
		}

		$preClass = $Data['Class'];
		$preSession = $Data["QuSession"];
		$preTarget = $Data["QuTarget"];
		$preDistance = $Data["Td1"];
		$preGroup = $Data['DistGroup'] ?? "";
		
		$_RankText = $isTarget ? str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT) : ($isDistance ? $Data['DistRank'] : $Data['ClRank']); 
		if( intval($Data['ClRank'])>10000 ) {
			$_RankText = $isTarget ? $_RankText : "欠";
      for($di=1; $di<=$ToNumDist; $di++) {
        $Data["QuD{$di}ArrowString"] = "";
        $Data["QuD{$di}Score"] = "";        
      }
			$Data['QuScore'] = "欠";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
		} else if( intval($Data['ClRank'])==10000 ) {
			$_RankText = $Data['QuSession']."-".str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT);
      for($di=1; $di<=$ToNumDist; $di++) {
        $Data["QuD{$di}ArrowString"] = "";
        $Data["QuD{$di}Score"] = "";        
      }
			$Data['QuScore'] = "";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
		}
    
		$_trclass = ($Order === "Target" && $flgHighlight) ? 'highlight' : '';
		echo <<<EOM
<tr class='target-{$Data['QuTarget']} {$_trclass}'>
	<th class="boldleft">{$_RankText}</th>
EOM;
		echo (($isTarget || $isDistance) ? "<td class='r_class'>{$Data['Class']}</td>" : "");
	
		$_Name = "{$Data['EnFirstName']}  {$Data['EnName']}";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($_Name,14)."</td>";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($Data['CountryName'],14)."</td>";
		echo <<<EOM
  <td class='score sticky'>{$Data['QuScore']}</td>
	<td class='goldx9'>{$Data['QuGold']}</td>
	<td class='goldx9 boldright'>{$Data['QuXnine']}</td>
EOM;
    for($di=1; $di<=$ToNumDist; $di++) {      
      $Data["ArrayD{$di}Point"] = DecodeFromString($Data["QuD{$di}ArrowString"]);
      $Data["DiArrows{$di}"] = $DistanceInfo[$Data['QuSession']][$di]['DiArrows'];
      $Data["DiEnds{$di}"] = $DistanceInfo[$Data['QuSession']][$di]['DiEnds'];
      
      $ArrayScore = [];
      foreach(str_split(substr($Data["QuD{$di}ArrowString"],0,$Data["QuD{$di}Hits"]), $Data["DiArrows{$di}"]) as $EndArrow){
        if($EndArrow!==str_repeat(" ",$Data["DiArrows{$di}"])){
          $ArrayScore[] = ValutaArrowString($EndArrow);
        } else {
          $ArrayScore[] = "";
        }
      }
      $rowEnds = $isDistance ? $GroupEnds[$Data['DistGroup']][$di] : $Data["DiEnds{$di}"];
      for($i=0;$i<$rowEnds;$i++){
        echo "<td class='s d{$di}'>".($ArrayScore[$i] ?? '')."</td>";
      }
      echo "<td class='score doubleleft boldright'>".$Data["QuD{$di}Score"]."</td>";
    }
		echo "<td class='noprint' style='padding:0;'><div class='btn_card' onclick='showscore(".json_encode($Data).");'><span class='material-icons'>article</span></div></td>";
		//echo "<script>console.log(JSON.parse('".json_encode($Data)."'));</script>";
    echo "</tr>";

	}
	echo "</table></div>";
  
  //var_dump($Data);

	// ---- セッション絞り込みトグルメニュー（テーブル下） ----
	if(count($SessionList) > 1 && !$isDistance){
		echo "<br>";
		echo "<div class='noprint'>";
		echo "セッション：";
		$allActive = empty($GameSessions) ? " active" : "";
		echo "<a class='session-toggle-btn all-btn{$allActive}' href='?Tour={$TourCode}&Order={$Order}{$mode_reload}'>全て</a>";
		foreach($SessionList as $Ses){
			$sesId    = $Ses['QuSession'];
			$sesLabel = (!empty($Ses['SesName'])) ? $Ses['SesName'] : "Session {$sesId}";
			$isActive = in_array($sesId, $GameSessions);
			$btnClass = $isActive ? " active" : "";
			$toggled      = toggleSession($GameSessions, $sesId);
			$toggledParam = buildSesParam($toggled);
			echo "<a class='session-toggle-btn{$btnClass}' href='?Tour={$TourCode}&Order={$Order}{$toggledParam}{$mode_reload}'>{$sesLabel}</a>";
		}
		echo "</div>";
	}
	
	echo <<<EOM
<dialog>
  <div style='padding:0 2rem;margin:0;'>
  <div style="text-align:right"><button id="closeDialog">×閉じる</button></div>
  <div>{$Tour['ToName']}<br>{$TourCode}  会場:{$Tour['ToWhere']} ({$Tour['ToWhenFrom']})</div>
  <div id="sc_name" style=''></div>
  <!--<div id="sc_score" style='text-align:right;'></div>-->
  </div>
  <div id="sc"></div>
</dialog>
<script>
const LABEL_GOLD = '{$labelGold}';
const LABEL_XNINE = '{$labelXNine}';
const POINT_GOLD = parseInt('{$pointGold}');
const POINT_XNINE = parseInt('{$pointXNine}');

const dialog = document.querySelector("dialog");
const closeButton = document.querySelector("#closeDialog");
closeButton.addEventListener("click", () => {
  dialog.close(); // モーダルダイアログを閉じる
  interval_flg = true;  
});

const showscore = (Data) => {
  //console.log(Data);
  const sc = document.querySelector("#sc");
  const sc_name = document.querySelector("#sc_name");
  //const sc_score = document.querySelector("#sc_score");
  
  let tname = "";
  tname += "<span style='font-size:1.5em;'>";
  tname += "<span style='border:solid 1px black;font-weight:bold;font-family: sans-serif;'>"+Data.QuTarget+Data.QuLetter+"</span>";
  tname += Data.EnFirstName+"　"+Data.EnName+"("+Data.CountryName+")";
  tname += "</span>   ";
  tname += Data.SesName+" "+Data.ClDescription+"["+Data.Class+"]";
  
  sc_name.innerHTML = tname;
  
  /*
  let tscore = "";
  tscore += "<span style='font-size:1.5em;'>";
  tscore += "合計<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuScore+"</span>";
  tscore += "  "+Data.GoldLabel+"<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuGold+"</span>";
  tscore += "  "+Data.XNineLabel+"<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuXnine+"</span>";
  tscore += "</span>";
  sc_score.innerHTML = tscore;
  */

  
  let tbody = "";
  tbody += "<table class='sctable'>";
  tbody += "<tr>";
EOM;

    for($di=1; $di<$ToNumDist; $di++) {	
  echo <<<EOM
  tbody += "<td><div>"+Data.Td{$di}+"</div>";
  tbody += createCard(Data.ArrayD{$di}Point,Data.DiArrows{$di},Data.DiEnds{$di},Data.QuD{$di}Hits);
  tbody += "</td>";
EOM;
      if($di%2==0){
        echo "  tbody += '</tr><tr>';";
      }
    }
  $di = $ToNumDist;
  echo <<<EOM
  tbody += "<td><div>"+Data.Td{$di}+"</div>";
  tbody += createCard(Data.ArrayD{$di}Point,Data.DiArrows{$di},Data.DiEnds{$di},Data.QuD{$di}Hits,Data.QuScore,Data.QuGold,Data.QuXnine,Data.ClRank);
  tbody += "</td>";
  tbody += "</tr>";  
  tbody += "</table>";
  
  sc.innerHTML = tbody;
  
	dialog.showModal();
  interval_flg = false;  
}

function createCard(score,DiArrows=6,DiEnds=6,Hits=36,QuScore=null,QuGold=null,QuXnine=null,ClRank=null){
  	
	
  let tbody = "<table>";
  tbody += "<tr><th></th><th>1</th><th>2</th><th>3</th>";
  tbody += "<th>小計</th><th colspan=2>累計</th><th>"+LABEL_GOLD+"</th><th>"+LABEL_XNINE+"</th></tr>";
  
  let ends = 1;
  let sum3 = 0;
  let sum_ends = 0;
  let cnt_GOLD = 0;
  let cnt_XNINE = 0;
  let cnt3_GOLD = 0;
  let cnt3_XNINE = 0;

  let total = 0;
  let totalcnt_GOLD = 0;
  let totalcnt_XNINE = 0;
  
  tbody += "<tr>";
  for(let i=0;i<(DiArrows*DiEnds);i++){
     if(i%DiArrows==0){
       tbody += "<th "+( DiArrows>3 ? 'rowspan=2' : '' )+">"+ends+"</th>";
       ends++;
       
		sum_ends=0;
		cnt_GOLD = 0;
		cnt_XNINE = 0; 
		cnt3_GOLD = 0;
		cnt3_XNINE = 0;
     }
	 if(i%3==0){
		sum3 = 0;
		cnt3_GOLD = 0;
		cnt3_XNINE = 0;
	 }
	 
	 
     if(i<score.length){
       tbody += "<td class='point'>"+score[i]+"</td>"; 
       point=0;
       if(Number.isInteger(parseInt(score[i]))){
         point = parseInt(score[i]);
       }
       if(score[i]==LABEL_GOLD){
         point=POINT_GOLD;
         cnt_GOLD++;
         cnt3_GOLD++;
         totalcnt_GOLD++;
       }
       if(score[i]==LABEL_XNINE){
         point=POINT_XNINE;
         cnt_XNINE++;
		 cnt3_XNINE++;
         totalcnt_XNINE++;
       }
       total+=point;
       sum3+=point;
       sum_ends+=point;
       
     } else {
       tbody += "<td></td>"; 
     } 
	 
     if(i%3==2){
       tbody += "<td>"+(i<=Hits? sum3 : "")+"</td>";
	   if( DiArrows>3 ){
		   if(i%DiArrows==(DiArrows-1)){
			 tbody += "<td>"+(i<=Hits? sum_ends : "")+"</td>";         
			 tbody += "<td class='total'>"+total+"</td>";
		   } else {
			 tbody += "<td colspan=2 class='blank'></td>";
		   }
	   } else {
			 tbody += "<td colspan=2 class='total'>"+total+"</td>";
	   }
       tbody += "<td class='pointx'>"+(cnt3_GOLD || "") +"</td>";
       tbody += "<td class='point9'>"+(cnt3_XNINE || "") +"</td>";
       tbody += "</tr>";
       
       tbody += "<tr>"; 
     }
  }
  tbody += "</tr>";
  
  tbody += "<tr>";
  tbody += "<td colspan=6 style='border:none;text-align:right'>総計</td>";
  tbody += "<td class='total'>"+total+"</td>";
  tbody += "<td>"+totalcnt_GOLD+"</td>";
  tbody += "<td>"+totalcnt_XNINE+"</td>";
  tbody += "</tr>";
  
  if(QuScore!==null){
	tbody += "<tr style='background:#ffd;'>";
	tbody += "<td colspan=3>順位:"+ClRank+"</td>";
	tbody += "<td colspan=3 style='border:none;text-align:right'>総合計</td>";
	tbody += "<td class='total'>"+QuScore+"</td>";
	tbody += "<td>"+QuGold+"</td>";
	tbody += "<td>"+QuXnine+"</td>";
	tbody += "</tr>";
  }
  
  tbody += "</table>";  
  return tbody;
}

document.querySelectorAll('th[data-di]').forEach(th => {
  th.style.cursor = 'pointer';
  th.addEventListener('click', () => {
    hideScore(th);
  });
});

let setting = JSON.parse(sessionStorage.getItem('{$TourCode}'));
if(!setting) setting=[];

window.onload = function(){
  for(let i=0;i<setting.length;i++){
    const th=document.querySelector('th.di'+setting[i]);
    hideScore(th);
  }
}

function hideScore(th){
  const di = th.dataset.di;
  const ends = parseInt(th.dataset.ends);
  
  let isHidden = false;
  document.querySelectorAll('.d'+di).forEach(el => {
    if(el.classList.contains('hidden')) isHidden = true;
  });
  
  isHidden = !isHidden;
  document.querySelectorAll('.d'+di).forEach(el => {
    el.classList.toggle('hidden', isHidden);
  });
  document.querySelectorAll('th.di'+di).forEach(el => {
    el.colSpan = isHidden ? 1 : (ends+1);
  });
  
  if(isHidden){
    setting.push(di);
    setting = [...new Set(setting)];
  } else {
    let result = setting.filter(function( item ) {
      return item !== di;
    });
    setting = result;
  }
  sessionStorage.setItem('{$TourCode}',JSON.stringify(setting));
}


</script>
EOM;
	include('Common/Templates/tail-min.php');



function shrinktext($_Text,$maxsize){
  $_cnt = mb_strwidth($_Text);
  if($_cnt==0) $_cnt = 1;
  
  if($_cnt<$maxsize){
    $_size = 1;
  } else {
    $_size = $maxsize/$_cnt;
  }
  
  return "<div style='transform-origin: 0 0;transform:scale({$_size},1);'>{$_Text}</div>";
}