<?php
/*

変更履歴:
2026/06/14 スコアカード機能を追加
2026/05/31 セッション絞り込みをトグル複数選択に変更
2026/05/31 セッション絞り込みメニューを追加
2026/03/15 セッション名が表示されるように変更
2025/11/17 セッションを持っていない場合は表示させないように変更
2025/10/26

*/
	define('debug',false);
	define('IN_PHP', true);
	ini_set('display_errors', 1);

	require_once(dirname(dirname(__FILE__)) . '/config.php');

	require_once('Common/Fun_FormatText.inc.php');
	require_once('TV/Fun_HTML.local.inc.php');
	require_once('Common/Lib/CommonLib.php');
	require_once('Common/Lib/ArrTargets.inc.php');

	$TourCode=stripslashes($_REQUEST['Tour']);
  

	// セッション複数選択：s[] で受け取り、整数配列に正規化
	$GameSessions = [];
	if (!empty($_REQUEST['s'])) {
		$raw = $_REQUEST['s'];
		if (is_array($raw)) {
			foreach ($raw as $v) {
				$v = intval($v);
				if ($v > 0) $GameSessions[] = $v;
			}
		} else {
			$v = intval($raw);
			if ($v > 0) $GameSessions[] = $v;
		}
		$GameSessions = array_unique($GameSessions);
		sort($GameSessions);
	}

	if (empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		include('Common/Templates/head-min.php');
		echo "<a href='https://ianseo.net'>i@nseo.net</a>";
		include('Common/Templates/tail-min-min.php');
		die();
	}
	else if (!empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		$Select	= "SELECT ToId,ToCode,ToName,ToWhere,ToNumDist
			FROM Tournament WHERE ToId='".$_SESSION['TourId']."'";	
		$Rs=safe_r_sql($Select);
		$MyRow=safe_fetch($Rs);
		$TourCode = $MyRow->ToCode;
	}

	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
	$Order=stripslashes($_REQUEST['Order']);
	if($Order==""){
		$Order="Ranking";
	}
	
  if(! ($TourId > 0) ){
    include('Common/Templates/head-min.php');
    echo "error!";
    include('Common/Templates/tail-min-min.php');
    die();
  }
 

    

	// ----------------------------------------
	// セッション一覧を取得
	// ----------------------------------------
	$SelectSessions = "
		SELECT DISTINCT QuSession, SesName
		FROM Qualifications
		LEFT JOIN Entries ON EnId = QuId AND EnTournament = {$TourId} AND EnAthlete = 1
		LEFT JOIN Session ON SesTournament = {$TourId} AND SesOrder = QuSession AND SesType = 'Q'
		WHERE EnTournament = {$TourId}
		ORDER BY QuSession ASC
	";
	$RsSessions = safe_r_sql($SelectSessions);
	$SessionList = [];
	while ($SesRow = safe_fetch($RsSessions)) {
		$SessionList[] = [
			'QuSession' => intval($SesRow->QuSession),
			'SesName'   => $SesRow->SesName,
		];
	}

	// ----------------------------------------
	// セッションパラメータをURLクエリ文字列に変換するヘルパー
	// ----------------------------------------
	function buildSesParam($sessions) {
		if (empty($sessions)) return "";
		$parts = [];
		foreach ($sessions as $s) {
			$parts[] = "s[]=" . intval($s);
		}
		return "&" . implode("&", $parts);
	}

	// あるセッションをトグルした場合の選択リストを返す
	function toggleSession($current, $toggleId) {
		if (in_array($toggleId, $current)) {
			$next = array_values(array_filter($current, fn($v) => $v !== $toggleId));
		} else {
			$next = array_merge($current, [$toggleId]);
			sort($next);
		}
		return $next;
	}

  // 距離の種類を取得
  $Select	= "SELECT ToNumDist FROM Tournament WHERE ToId= {$TourId}";
  $Rs=safe_r_sql($Select);
  $MyRow=safe_fetch($Rs);
  $ToNumDist = $MyRow->ToNumDist;
  
  // 距離の情報を取得
  $Select	= "SELECT DiSession,DiDistance,DiEnds,DiArrows FROM DistanceInformation WHERE DiTournament= {$TourId}";
  $Rs=safe_r_sql($Select);
 	$DistanceInfo = [];
	while( $MyRow=safe_fetch($Rs) ){
		$tmpArray = json_decode(json_encode($MyRow), true);
    
    $DistanceInfo[$tmpArray['DiSession']][$tmpArray['DiDistance']]=$tmpArray;
	}
  //$ToNumDist = 3;
  
	$tmpSel='';
	for($di=1; $di<=$ToNumDist; $di++) {
		$tmpSel .= "QuD{$di}Score, QuD{$di}Hits, QuD{$di}Gold, QuD{$di}Xnine, QuD{$di}ArrowString, Td{$di},"; // DiEnds{$di}, DiArrows{$di}, ";
	}

	// WHERE句：複数セッション対応
	$tmpSession = "";	
	if (!empty($GameSessions)) {
		$inList = implode(",", $GameSessions);
		$tmpSession = "AND QuSession IN ({$inList}) ";
	}
		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,
			IF(CoName != '', CoName, CoCode) AS CountryName,
			QuTargetNo, QuTarget,QuLetter,
			$tmpSel
			QuScore, QuGold, QuXnine,
			ToId,ToGoldsChars,ToGolds AS GoldLabel,ToXNineChars,ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
			DivDescription,ClDescription,DivViewOrder,ClViewOrder,
			ToName,ToWhere,ToWhenFrom,ToWhenTo,ToCode,QuSession,SesName,
			IF(QuClRank = 0,10000,QuClRank) as ClRank,
			ToOnlineId
		FROM 
       Tournament 
        LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType
        LEFT JOIN Entries ON EnTournament=ToId AND EnAthlete=1 AND CONCAT(EnDivision,EnClass) LIKE TdClasses
        LEFT JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament 
        LEFT JOIN Qualifications ON QuId=EnId
        LEFT JOIN Divisions ON DivTournament=EnTournament AND DivId=EnDivision    
        LEFT JOIN Classes ON ClTournament=EnTournament AND ClId=EnClass
        LEFT JOIN Session ON SesTournament=EnTournament AND SesOrder=QuSession AND SesType='Q'
		WHERE ToId = {$TourId} $tmpSession
		";
	$Rs=safe_r_sql($Select);



	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}

	
	
/* 	echo "<pre>";
	var_dump($ArrayData);
	echo "</pre>"; */
	
	if($Order === "Target"){
 		usort($ArrayData, function($a, $b) {
			return $a['QuSession'] <=> $b['QuSession']
            ?: $a['QuTarget'] <=> $b['QuTarget']
            ?: $a['QuLetter'] <=> $b['QuLetter'];
		}); 
	} else {
		usort($ArrayData, function($a, $b) {
			return $a['DivViewOrder'] <=> $b['DivViewOrder']
				?: $a['QuSession'] <=> $b['QuSession']
				?: $a['ClViewOrder'] <=> $b['ClViewOrder']
				?: $a['Class'] <=> $b['Class']
				?: $a['ClRank'] <=> $b['ClRank']
        ?: $a['QuTarget'] <=> $b['QuTarget']
        ?: $a['QuLetter'] <=> $b['QuLetter'];        
		});
	}

	$Tour = $ArrayData[0];
	$labelGold = $Tour["GoldLabel"];
	$labelXNine = $Tour["XNineLabel"];
	$pointGold = ValutaArrowString($Tour["ToGoldsChars"]);
	$pointXNine = ValutaArrowString($Tour["ToXNineChars"]);

	// 自動更新フラグ
	$mode_reload = "";
	if(stripslashes($_REQUEST['r'])=="1"){
		$mode_reload = "&r=1";
	}

	// 現在のセッションパラメータ文字列（リンク引き継ぎ用）
	$sesParam = buildSesParam($GameSessions);

	echo <<<EOM
<!DOCTYPE html>
<html lang="ja" class="notranslate" translate="no">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, user-scalable=yes">
<meta name="google" content="notranslate">
<title>{$Tour['ToName']} - {$Tour['ToWhere']} ({$Tour['ToWhenFrom']}) </title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
<style>
html{
   font-size:clamp(6pt, 1.0vw, 14pt);
   font-family:"UD新ゴ R";
   margin:1vmin;
}

thead {
  top: 0;
  left: 0;	
}

h1,h2{
  margin-bottom:0;
}

table {
  border-collapse:collapse;
  border-spacing: 0;
}

table th,table td{
  text-align: center;
  white-space:nowrap;
  white-space-collapse: preserve;
}

table th{
  background-color: #c79852 ;
  color: white;
  border:solid 1px black;
  height:1.3em;
}

th.dilabel {
	min-width:5rem;
}

.dibutton {
    display: flex;
    justify-content: center;
    align-items: center;
    min-width:5rem;
    margin:0 auto;
    padding: 0;
    border: 1px solid #000;
    border-radius: 5px;
    font-size: 0.8em;
    background-color: #634C29 ;
    color: white;    
    pointer-events: none;
}

table th.boldleft:first-child {
	width:3rem;
}


table td{
  border:solid 1px black;
  padding: 0.3em 0.5em;
}

td.score {
  background:#eee;
  font-weight:bold;
	width:3rem;
	max-width:3rem;
	min-width:3rem;
}
td.goldx9 {
	width:2rem;
	max-width:2rem;
	min-width:2rem;
}
td.s{
  width:1.5em;
  /* background:#eee; */
  margin:1px;
}

td.blank {
  background-image: 
    linear-gradient(20deg, transparent 49%, black 49%, black 51%, transparent 51%), /* 右下がり */
    linear-gradient(-20deg, transparent 49%, black 49%, black 51%, transparent 51%); /* 右上がり */
}

/* スコアカード */
#sc td {
	min-width:2rem;
	height:1.8rem;
}

#sc th {
	min-width:1.5rem;
}


#sc td.point {
  width:2rem;
	min-width:2rem;
  max-width:2rem;
  font-weight:bold;
  font-size:1.2rem;
  border:2px solid black;
}

#sc td.total {
  width:3rem;
	min-width:3rem;
  max-width:3rem;
  font-weight:bold;
  font-size:1.2rem;
  border:2px solid black;
}

table.sctable > tbody > tr {
  vertical-align:top;	
}
table.sctable > tbody > tr > td {
   border:0;	
   padding:1rem;
}

.btn_card > .material-icons {
  cursor: pointer;
  font-size:1.3rem;
}

.r_class{
	/*width:3rem;*/
	max-width:6rem;
	min-width:3rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}
.r_name{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
	font-weight:bold;
}
.r_country{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}

.boldleft {
  border-left: 2px solid black !important;
}
.boldright {
  border-right: 2px solid black;
}
.doubleleft {
  border-left: 2px double black !important;
}

.highlight > th{
	background: #863 !important;
}
.highlight > td{
	background: #88663340 !important;
}

/* セッショントグルボタン */
.session-toggle-btn {
  display: inline-block;
  margin: 0 2px;
  padding: 1px 7px;
  border: 1px solid #999;
  border-radius: 4px;
  text-decoration: none;
  color: #333;
  background: #f5f5f5;
  font-size: inherit;
  cursor: pointer;
  user-select: none;
}
.session-toggle-btn:hover {
  background: #e8e8e8;
}
.session-toggle-btn.active {
  background: #c79852;
  border-color: #a07030;
  color: white;
  font-weight: bold;
}
.session-toggle-btn.all-btn.active {
  background: #555;
  border-color: #333;
}

.hidden {
  display:none;	
}
@media print {
  .noprint {
    display: none !important;
  }
}
</style>
<script type="text/javascript" src="//webfonts.sakura.ne.jp/js/sakurav3.js"></script>
</head>
<body>
EOM;

	if(!empty($_SESSION['TourId'])){
		echo "<div class='noprint' style='text-align:right;'><a href='../../../Main.php'>大会情報参照</a></div>";
	}

	echo <<<EOM
<h1>{$Tour['ToName']}</h1>
<div>{$TourCode}</div>
<div>会場:{$Tour['ToWhere']} (日程:{$Tour['ToWhenFrom']}
EOM;

  if($Tour['ToWhenFrom'] != $Tour['ToWhenTo']){
      echo "～{$Tour['ToWhenTo']}";
  }
  echo ")</div>"; 

  echo "<div class='noprint'>";

  if($Tour['ToOnlineId']>0){
    echo <<<EOM
<div style="margin:1em;padding:2em;background:yellow;font-size:2rem;">
個人・団体の決勝トーナメントは ianseo.net をご覧ください<br>
[<a href='https://www.ianseo.net/Details.php?toId={$Tour['ToOnlineId']}'>i@nseoへ</a>]<br>
</div>
EOM;

  
  }
  
  

  // ---- 表示順メニュー ----
  if($Order === "Target" ){
     echo "[<a href='?Tour={$TourCode}&Order=Ranking{$sesParam}{$mode_reload}'>ランキング</a>][ターゲット順]";	  
  } else {
     echo "[ランキング][<a href='?Tour={$TourCode}&Order=Target{$sesParam}{$mode_reload}'>ターゲット順</a>]";
  }
  
  if($Tour['ToOnlineId']>0){
	echo "[<a href='https://www.ianseo.net/Details.php?toId={$Tour['ToOnlineId']}'>i@nseoへ</a>]";
  }

  echo "　　";

  // ---- 自動更新メニュー ----
  if(stripslashes($_REQUEST['r'])=="1"){
		echo <<<EOM
<span style='border:1px solid black' id='count'>30</span>
<script>
  cnt = -1;
  interval_flg = true;
  setInterval(() => {
    cnt = parseInt(document.getElementById('count').innerHTML);
    if(interval_flg)cnt--;
    document.getElementById('count').innerHTML = cnt;
    if(cnt==0){
      cnt=30;
      location.reload();
    }
  }, 1000);
</script>
EOM;
		echo "[<a href='?Tour={$TourCode}&Order={$Order}{$sesParam}'>更新停止</a>]";
	} else {
		echo "[<a href='?Tour={$TourCode}&Order={$Order}&r=1{$sesParam}'>自動更新</a>]";
	}

  echo "</div>"; // .noprint

  $preClass = "";
  $preSession = "";
  $preTarget = "";
  $preDistance = "";
  $flgHighlight = false;
  $flg_First = true;
	
	foreach($ArrayData as $Data){
		
		if(is_null($Data["EnId"])){
			continue;
		}
		
		if($preTarget != $Data['QuTarget']){
			$flgHighlight = !$flgHighlight;
		}
    
		if( ( $Order==="Target" && ( $preSession != $Data['QuSession'] || $preDistance != $Data['Td1'] ) ) || ( $Order!=="Target" && $preClass != $Data['Class'])){
		  if( $flg_First ){
			  $flg_First = false;
		  } else {
			if( $preSession != $Data['QuSession'] || ($Order!=="Target" && $preClass != $Data['Class']) ){
				echo "</table><!-aa->\n</div>";
			} else {
				
			}
		  }
		  
		  if( $Order==="Target") {
			    if( $preSession != $Data['QuSession'] ){
					echo "<h2>".($Data['SesName'] ?: "セッション".$Data['QuSession'])."</h2>"; 
					echo "<div class='table_box'><table>";	
				}				
		  } else {
				echo "<h2>{$Data['DivDescription']}{$Data['ClDescription']}</h2>";   
                echo "<div class='table_box'><table>";	
		  }
		  
		  echo <<<EOM
<tr>
EOM;
		  echo "<th rowspan=2 class='boldleft'>".($Order==="Target" ? "的番号" : "順位")."</th>";
		  echo ($Order==="Target" ? "<th rowspan=2 class='r_class'>クラス</th>" : ""); 
		  echo <<<EOM
	<th rowspan=2 class="r_name">選手名</th>
	<th rowspan=2 class="boldright r_country">所属</th>
  <th colspan=3 class="boldright">総合成績</th>
EOM;
      for($di=1; $di<=$ToNumDist; $di++) {
  		  echo "<th colspan=".(intval($DistanceInfo[$Data['QuSession']][$di]['DiEnds'])+1)." class='dilabel boldright di{$di}' data-di='{$di}' data-ends='".$DistanceInfo[$Data['QuSession']][$di]['DiEnds']."'><span class='dibutton'>".$Data["Td{$di}"]."</span></th>\n";  
      }
		  echo <<<EOM
	<th rowspan='2' class='noprint' style='font-size:0.8em'>スコア<br>カード</th>
</tr>
<tr>
	<th class="boldleft">総合計</th>
	<th class="goldx9">{$Data['GoldLabel']}</th>
	<th class="boldright goldx9">{$Data['XNineLabel']}</th>
EOM;

      for($di=1; $di<=$ToNumDist; $di++) {
        foreach(range(1,$DistanceInfo[$Data['QuSession']][$di]['DiEnds']) as $i){
          echo "<th class='s d{$di}'>{$i}</th>\n";
        }
        echo "<th class='doubleleft boldright'>合計</th>\n";
      }
		echo <<<EOM
</tr>	
EOM;
		}

		$preClass = $Data['Class'];
		$preSession = $Data["QuSession"];
		$preTarget = $Data["QuTarget"];
		$preDistance = $Data["Td1"];
		
		$_RankText = $Order==="Target" ? str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT) : $Data['ClRank']; 
		if( intval($Data['ClRank'])>10000 ) {
			$_RankText = $Order==="Target" ? $_RankText : "欠";
      for($di=1; $di<=$ToNumDist; $di++) {
        $Data["QuD{$di}ArrowString"] = "";
        $Data["QuD{$di}Score"] = "";        
      }
			$Data['QuScore'] = "欠";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
		} else if( intval($Data['ClRank'])==10000 ) {
			$_RankText = $Data['QuSession']."-".str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT);
      for($di=1; $di<=$ToNumDist; $di++) {
        $Data["QuD{$di}ArrowString"] = "";
        $Data["QuD{$di}Score"] = "";        
      }
			$Data['QuScore'] = "";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
		}
    
		$_trclass = ($Order === "Target" && $flgHighlight) ? 'highlight' : '';
		echo <<<EOM
<tr class='target-{$Data['QuTarget']} {$_trclass}'>
	<th class="boldleft">{$_RankText}</th>
EOM;
		echo ($Order==="Target" ? "<td class='r_class'>{$Data['Class']}</td>" : "");
	
		$_Name = "{$Data['EnFirstName']}  {$Data['EnName']}";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($_Name,14)."</td>";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($Data['CountryName'],14)."</td>";
		echo <<<EOM
  <td class='score sticky'>{$Data['QuScore']}</td>
	<td class='goldx9'>{$Data['QuGold']}</td>
	<td class='goldx9 boldright'>{$Data['QuXnine']}</td>
EOM;
    for($di=1; $di<=$ToNumDist; $di++) {      
      $Data["ArrayD{$di}Point"] = DecodeFromString($Data["QuD{$di}ArrowString"]);
      $Data["DiArrows{$di}"] = $DistanceInfo[$Data['QuSession']][$di]['DiArrows'];
      $Data["DiEnds{$di}"] = $DistanceInfo[$Data['QuSession']][$di]['DiEnds'];
      
      $ArrayScore = [];
      foreach(str_split(substr($Data["QuD{$di}ArrowString"],0,$Data["QuD{$di}Hits"]), $Data["DiArrows{$di}"]) as $EndArrow){
        if($EndArrow!==str_repeat(" ",$Data["DiArrows{$di}"])){
          $ArrayScore[] = ValutaArrowString($EndArrow);
        } else {
          $ArrayScore[] = "";
        }
      }
      for($i=0;$i<$Data["DiEnds{$di}"];$i++){
        echo "<td class='s d{$di}'>".($ArrayScore[$i] ?? '')."</td>";
      }
      echo "<td class='score doubleleft boldright'>".$Data["QuD{$di}Score"]."</td>";
    }
		echo "<td class='noprint' style='padding:0;'><div class='btn_card' onclick='showscore(".json_encode($Data).");'><span class='material-icons'>article</span></div></td>";
		//echo "<script>console.log(JSON.parse('".json_encode($Data)."'));</script>";
    echo "</tr>";

	}
	echo "</table></div>";
  
  //var_dump($Data);

	// ---- セッション絞り込みトグルメニュー（テーブル下） ----
	if(count($SessionList) > 1){
		echo "<br>";
		echo "<div class='noprint'>";
		echo "セッション：";
		$allActive = empty($GameSessions) ? " active" : "";
		echo "<a class='session-toggle-btn all-btn{$allActive}' href='?Tour={$TourCode}&Order={$Order}{$mode_reload}'>全て</a>";
		foreach($SessionList as $Ses){
			$sesId    = $Ses['QuSession'];
			$sesLabel = (!empty($Ses['SesName'])) ? $Ses['SesName'] : "Session {$sesId}";
			$isActive = in_array($sesId, $GameSessions);
			$btnClass = $isActive ? " active" : "";
			$toggled      = toggleSession($GameSessions, $sesId);
			$toggledParam = buildSesParam($toggled);
			echo "<a class='session-toggle-btn{$btnClass}' href='?Tour={$TourCode}&Order={$Order}{$toggledParam}{$mode_reload}'>{$sesLabel}</a>";
		}
		echo "</div>";
	}
	
	echo <<<EOM
<dialog>
  <div style='padding:0 2rem;margin:0;'>
  <div style="text-align:right"><button id="closeDialog">×閉じる</button></div>
  <div>{$Tour['ToName']}<br>{$TourCode}  会場:{$Tour['ToWhere']} ({$Tour['ToWhenFrom']})</div>
  <div id="sc_name" style=''></div>
  <!--<div id="sc_score" style='text-align:right;'></div>-->
  </div>
  <div id="sc"></div>
</dialog>
<script>
const LABEL_GOLD = '{$labelGold}';
const LABEL_XNINE = '{$labelXNine}';
const POINT_GOLD = parseInt('{$pointGold}');
const POINT_XNINE = parseInt('{$pointXNine}');

const dialog = document.querySelector("dialog");
const closeButton = document.querySelector("#closeDialog");
closeButton.addEventListener("click", () => {
  dialog.close(); // モーダルダイアログを閉じる
  interval_flg = true;  
});

const showscore = (Data) => {
  //console.log(Data);
  const sc = document.querySelector("#sc");
  const sc_name = document.querySelector("#sc_name");
  //const sc_score = document.querySelector("#sc_score");
  
  let tname = "";
  tname += "<span style='font-size:1.5em;'>";
  tname += "<span style='border:solid 1px black;font-weight:bold;font-family: sans-serif;'>"+Data.QuTarget+Data.QuLetter+"</span>";
  tname += Data.EnFirstName+"　"+Data.EnName+"("+Data.CountryName+")";
  tname += "</span>   ";
  tname += Data.SesName+" "+Data.ClDescription+"["+Data.Class+"]";
  
  sc_name.innerHTML = tname;
  
  /*
  let tscore = "";
  tscore += "<span style='font-size:1.5em;'>";
  tscore += "合計<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuScore+"</span>";
  tscore += "  "+Data.GoldLabel+"<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuGold+"</span>";
  tscore += "  "+Data.XNineLabel+"<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuXnine+"</span>";
  tscore += "</span>";
  sc_score.innerHTML = tscore;
  */

  
  let tbody = "";
  tbody += "<table class='sctable'>";
  tbody += "<tr>";
EOM;

    for($di=1; $di<$ToNumDist; $di++) {	
  echo <<<EOM
  tbody += "<td><div>"+Data.Td{$di}+"</div>";
  tbody += createCard(Data.ArrayD{$di}Point,Data.DiArrows{$di},Data.DiEnds{$di},Data.QuD{$di}Hits);
  tbody += "</td>";
EOM;
      if($di%2==0){
        echo "  tbody += '</tr><tr>';";
      }
    }
  $di = $ToNumDist;
  echo <<<EOM
  tbody += "<td><div>"+Data.Td{$di}+"</div>";
  tbody += createCard(Data.ArrayD{$di}Point,Data.DiArrows{$di},Data.DiEnds{$di},Data.QuD{$di}Hits,Data.QuScore,Data.QuGold,Data.QuXnine,Data.ClRank);
  tbody += "</td>";
  tbody += "</tr>";  
  tbody += "</table>";
  
  sc.innerHTML = tbody;
  
	dialog.showModal();
  interval_flg = false;  
}

function createCard(score,DiArrows=6,DiEnds=6,Hits=36,QuScore=null,QuGold=null,QuXnine=null,ClRank=null){
  	
	
  let tbody = "<table>";
  tbody += "<tr><th></th><th>1</th><th>2</th><th>3</th>";
  tbody += "<th>小計</th><th colspan=2>累計</th><th>"+LABEL_GOLD+"</th><th>"+LABEL_XNINE+"</th></tr>";
  
  let ends = 1;
  let sum3 = 0;
  let sum_ends = 0;
  let cnt_GOLD = 0;
  let cnt_XNINE = 0;
  let total = 0;
  let totalcnt_GOLD = 0;
  let totalcnt_XNINE = 0;
  
  tbody += "<tr>";
  for(let i=0;i<(DiArrows*DiEnds);i++){
     if(i%DiArrows==0){
       tbody += "<th "+( DiArrows>3 ? 'rowspan=2' : '' )+">"+ends+"</th>";
       ends++;
       
		sum_ends=0;
		cnt_GOLD = 0;
		cnt_XNINE = 0; 
     }
	 if(i%3==0) sum3 = 0;
	 
	 
     if(i<score.length){
       tbody += "<td class='point'>"+score[i]+"</td>"; 
       point=0;
       if(Number.isInteger(parseInt(score[i]))){
         point = parseInt(score[i]);
       }
       if(score[i]==LABEL_GOLD){
         point=POINT_GOLD;
         cnt_GOLD++;
         totalcnt_GOLD++;
       }
       if(score[i]==LABEL_XNINE){
         point=POINT_XNINE;
         cnt_XNINE++;
         totalcnt_XNINE++;
       }
       total+=point;
       sum3+=point;
       sum_ends+=point;
       
     } else {
       tbody += "<td></td>"; 
     } 
	 
     if(i%3==2){
       tbody += "<td>"+(i<=Hits? sum3 : "")+"</td>";
	   if( DiArrows>3 ){
		   if(i%DiArrows==(DiArrows-1)){
			 tbody += "<td>"+(i<=Hits? sum_ends : "")+"</td>";         
			 tbody += "<td class='total'>"+total+"</td>";
		   } else {
			 tbody += "<td colspan=2 class='blank'></td>";
		   }
	   } else {
			 tbody += "<td colspan=2 class='total'>"+total+"</td>";
	   }
       tbody += "<td>"+(cnt_GOLD || "") +"</td>";
       tbody += "<td>"+(cnt_XNINE || "") +"</td>";
       tbody += "</tr>";
       
       tbody += "<tr>"; 
     }
  }
  tbody += "</tr>";
  
  tbody += "<tr>";
  tbody += "<td colspan=6 style='border:none;text-align:right'>総計</td>";
  tbody += "<td class='total'>"+total+"</td>";
  tbody += "<td>"+totalcnt_GOLD+"</td>";
  tbody += "<td>"+totalcnt_XNINE+"</td>";
  tbody += "</tr>";
  
  if(QuScore!==null){
	tbody += "<tr style='background:#ffd;'>";
	tbody += "<td colspan=3>順位:"+ClRank+"</td>";
	tbody += "<td colspan=3 style='border:none;text-align:right'>総合計</td>";
	tbody += "<td class='total'>"+QuScore+"</td>";
	tbody += "<td>"+QuGold+"</td>";
	tbody += "<td>"+QuXnine+"</td>";
	tbody += "</tr>";
  }
  
  tbody += "</table>";  
  return tbody;
}

document.querySelectorAll('th[data-di]').forEach(th => {
  th.style.cursor = 'pointer';
  th.addEventListener('click', () => {
    hideScore(th);
  });
});

let setting = JSON.parse(sessionStorage.getItem('{$TourCode}'));
if(!setting) setting=[];

window.onload = function(){
  for(let i=0;i<setting.length;i++){
    const th=document.querySelector('th.di'+setting[i]);
    hideScore(th);
  }
}

function hideScore(th){
  const di = th.dataset.di;
  const ends = parseInt(th.dataset.ends);
  
  let isHidden = false;
  document.querySelectorAll('.d'+di).forEach(el => {
    if(el.classList.contains('hidden')) isHidden = true;
  });
  
  isHidden = !isHidden;
  document.querySelectorAll('.d'+di).forEach(el => {
    el.classList.toggle('hidden', isHidden);
  });
  document.querySelectorAll('th.di'+di).forEach(el => {
    el.colSpan = isHidden ? 1 : (ends+1);
  });
  
  if(isHidden){
    setting.push(di);
    setting = [...new Set(setting)];
  } else {
    let result = setting.filter(function( item ) {
      return item !== di;
    });
    setting = result;
  }
  sessionStorage.setItem('{$TourCode}',JSON.stringify(setting));
}


</script>
EOM;
	include('Common/Templates/tail-min.php');



function shrinktext($_Text,$maxsize){
  $_cnt = mb_strwidth($_Text);
  if($_cnt==0) $_cnt = 1;
  
  if($_cnt<$maxsize){
    $_size = 1;
  } else {
    $_size = $maxsize/$_cnt;
  }
  
  return "<div style='transform-origin: 0 0;transform:scale({$_size},1);'>{$_Text}</div>";
}