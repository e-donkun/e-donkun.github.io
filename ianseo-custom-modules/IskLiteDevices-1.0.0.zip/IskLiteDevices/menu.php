<?php
/*
ISK-NG Lite の大会で、スコアキーパーメニューに「ISK端末一覧（Lite）」と
「ISK端末一覧（サーバー全体）」を追加する。

変更履歴:
2026/09/25 「ISK端末一覧（サーバー全体）」を追加
2026/09/24 初版
*/
// 11 = ISK_NG_LITE_CODE（Api/ISK-NG/config_defines.php）
if(!empty($on) and ($_SESSION['UseApi']??'')==11 and isset($acl) and subFeatureAcl($acl, AclISKServer, 'iskUser') >= AclReadOnly) {
	$ret['API'][] = MENU_DIVIDER;
	$ret['API'][] = 'ISK端末一覧（Lite）' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/IskLiteDevices/Devices.php';
	if(subFeatureAcl($acl, AclISKServer, 'iskManagement') >= AclReadOnly) {
		$ret['API'][] = 'ISK端末一覧（サーバー全体）' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/IskLiteDevices/AllDevices.php';
	}
}
