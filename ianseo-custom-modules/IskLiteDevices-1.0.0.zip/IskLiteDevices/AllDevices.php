<?php
/*
ISK端末一覧（サーバー全体）。
IskDevices テーブルに登録されているすべての端末を、どの大会に接続しているかに関係なく表示する。
端末コードは大会ごとではなくサーバー全体で通しの番号なので、コードの変更と端末の削除はこの画面で行う。
- 表示には ISK の管理権限（iskManagement）の閲覧、コード変更・削除には書き込みが必要
- コード変更: 英数字4文字（36進数、小文字にそろえる）。他の端末と重複するコードは拒否する
- 削除: チェックボックスで選んだ端末をまとめて削除する。その端末がもう一度 QR を読み込むと、新しいコードで登録し直される
各列の意味は Devices.php（大会ごとの一覧）と同じ。ただし UUID も表示し、バージョンの注記（要更新など）は出さない（古いものは赤字）。

変更履歴:
2026/09/25 チェックボックスで選んだ端末の削除、UUID の列を追加。バージョンの注記を表示しないように変更
2026/09/25 初版
*/
require_once(dirname(dirname(__FILE__)) . '/config.php');
require_once('Common/Lib/CommonLib.php');
require_once($CFG->DOCUMENT_PATH . 'Api/ISK-NG/config.php');
require_once(__DIR__ . '/Lib.php');

CheckTourSession(true);
checkFullACL(AclISKServer, 'iskManagement', AclReadOnly);
$CanEdit = hasFullACL(AclISKServer, 'iskManagement', AclReadWrite);

// コード変更・削除。処理後は同じページへ戻し、結果はセッションに入れて1回だけ表示する
if($CanEdit and $_SERVER['REQUEST_METHOD'] == 'POST' and !empty($_POST['LiteDevAction'])) {
	$_SESSION['LiteDevMessage'] = liteDevAction($_POST);
	CD_redirect($_SERVER['PHP_SELF']);
}
$Message = $_SESSION['LiteDevMessage'] ?? null;
unset($_SESSION['LiteDevMessage']);

$ToId = intval($_SESSION['TourId']);
$LocalTz = liteDevLocalTz($ToId);
$TzLabel = 'UTC' . (new DateTime('now', $LocalTz))->format('P');

$Devices = [];
$Versions = [];
$TourIds = [];
$q = safe_r_sql("select IskDvDevice, IskDvCode, IskDvAppVersion, IskDvVersion, IskDvSchedKey, IskDvTarget, IskDvBattery, IskDvLastSeen,
		IskDvTournament, ToId, ToCode, IF(ToNameShort!='', ToNameShort, ToName) as TournamentName, ToNumDist
	from IskDevices
	left join Tournament on ToId=IskDvTournament
	order by IskDvCode");
while($r = safe_fetch($q)) {
	$Devices[] = $r;
	// 最新バージョンはアプリの種類ごとに比べる
	if($r->IskDvVersion) {
		$Versions[$r->IskDvAppVersion][] = $r->IskDvVersion;
	}
	if($r->ToId) {
		$TourIds[$r->ToId] = $r->ToId;
	}
}
$LatestVersions = [];
foreach($Versions as $App => $List) {
	usort($List, 'version_compare');
	$LatestVersions[$App] = end($List);
}

// 予選のセッション名: $SessionNames[大会][セッション] = 名前
$SessionNames = [];
if($TourIds) {
	$q = safe_r_sql("select SesTournament, SesOrder, SesName from Session where SesTournament in (" . implode(',', $TourIds) . ") and SesType='Q'");
	while($r = safe_fetch($q)) {
		$SessionNames[$r->SesTournament][$r->SesOrder] = $r->SesName;
	}
}

$Now = time();
$Counts = ['active' => 0, 'recent' => 0, 'lost' => 0];
$CountThisTour = 0;
$Cols = ($CanEdit ? 12 : 10);
// 選択用のチェックボックスの列がある分、並び替えの列番号をずらす
$C = ($CanEdit ? 1 : 0);

$IncludeFA = true;
$PAGE_TITLE = 'ISK端末一覧（サーバー全体）';
$JS_SCRIPT = liteDevHeadAssets('LiteDevAllV2');

require_once('Common/Templates/head.php');

$Rows = '';
$RowNum = 0;
foreach($Devices as $r) {
	$St = liteDevStatus($r->IskDvLastSeen, $Now);
	$Counts[$St['state']]++;
	// 必要バージョンの確認は ISK のアプリだけ（ゲートのアプリは対象外）
	$IsIsk = in_array(intval($r->IskDvAppVersion), [ISK_NG_LITE_CODE, ISK_NG_PRO_CODE, ISK_NG_LIVE_CODE]);
	list($Version) = liteDevVersion($r->IskDvVersion, $LatestVersions[$r->IskDvAppVersion] ?? '', $IsIsk);
	list($BatteryText, $BatteryKey) = liteDevBattery($r->IskDvBattery);
	$AppName = strval(AppNames[$r->IskDvAppVersion] ?? $r->IskDvAppVersion);

	if($r->ToId) {
		$IsThisTour = ($r->ToId == $ToId);
		if($IsThisTour) {
			$CountThisTour++;
		}
		$TourHtml = '<span' . ($IsThisTour ? ' class="LiteDevCurrent"' : '') . '>'
			. htmlspecialchars($r->ToCode) . ' ' . htmlspecialchars($r->TournamentName)
			. ($IsThisTour ? '（この大会）' : '')
			. '</span>';
		$TourKey = ($IsThisTour ? '0' : '1') . $r->ToCode;
		list($AssignHtml, $AssignKey) = liteDevAssignment($r, strval($r->ToNumDist), $SessionNames[$r->ToId] ?? []);
	} else {
		$TourHtml = '<span class="LiteDevMuted">なし</span>';
		$TourKey = '2';
		list($AssignHtml, $AssignKey) = ['<span class="LiteDevMuted">—</span>', '9'];
	}

	$Rows .= '<tr data-row="' . ($RowNum++) . '">'
		. ($CanEdit ? '<td class="Center">' . liteDevSelectBox($r) . '</td>' : '')
		. '<td class="Center" data-sort="' . $St['key'] . '">' . liteDevStateHtml($St['state'], $St['text']) . '</td>'
		. '<td class="Center Bold" data-sort="' . htmlspecialchars($r->IskDvCode) . '" title="' . htmlspecialchars($r->IskDvDevice) . '">' . htmlspecialchars($r->IskDvCode) . '</td>'
		. '<td class="NoWrap LiteDevUuid" data-sort="' . htmlspecialchars($r->IskDvDevice) . '">' . htmlspecialchars($r->IskDvDevice) . '</td>'
		. '<td class="NoWrap" data-sort="' . htmlspecialchars($TourKey) . '">' . $TourHtml . '</td>'
		. '<td class="NoWrap" data-sort="' . htmlspecialchars($AssignKey) . '">' . $AssignHtml . '</td>'
		. '<td class="NoWrap" data-sort="' . htmlspecialchars($AppName) . '">' . htmlspecialchars($AppName) . '</td>'
		. '<td class="Center" data-sort="' . htmlspecialchars(liteDevVersionKey($r->IskDvVersion)) . '">' . $Version . '</td>'
		. '<td class="Right NoWrap" data-sort="' . $BatteryKey . '">' . $BatteryText . '</td>'
		. '<td class="NoWrap" data-sort="' . intval($St['lastSeen']) . '">' . liteDevLastSeenText($St['lastSeen'], $LocalTz) . '</td>'
		. '<td class="Right NoWrap" data-sort="' . ($St['elapsed'] ?? PHP_INT_MAX) . '">' . $St['elapsedText'] . '</td>'
		. ($CanEdit ? '<td class="NoWrap">' . liteDevCodeButton($r) . '</td>' : '')
		. '</tr>';
}

echo '<table class="Tabella freeWidth LiteDevTable">';
echo '<thead>';
echo '<tr><th colspan="' . $Cols . '" class="Main">ISK端末一覧（サーバー全体）</th></tr>';
echo '<tr><td colspan="' . $Cols . '" class="Left">'
	. '登録端末 ' . count($Devices) . '台（うちこの大会 ' . $CountThisTour . '台）'
	. '（' . liteDevStateHtml('active', '通信中') . ' ' . $Counts['active']
	. '　' . liteDevStateHtml('recent', '応答待ち') . ' ' . $Counts['recent']
	. '　' . liteDevStateHtml('lost', '切断') . ' ' . $Counts['lost'] . '）'
	. '　' . liteDevRefreshControls()
	. ($CanEdit ? '　' . liteDevDeleteForm() : '')
	. '</td></tr>';
if($Message) {
	echo '<tr><td colspan="' . $Cols . '" class="Left LiteDevMsg ' . ($Message[0] ? 'ok' : 'ng') . '">' . htmlspecialchars($Message[1]) . '</td></tr>';
}
echo '<tr>'
	. ($CanEdit ? '<th class="Title"><input type="checkbox" id="LiteDevSelAll" title="すべて選択"></th>' : '')
	. '<th class="Title" data-sort-col="' . ($C + 0) . '" data-sort-type="num">状態</th>'
	. '<th class="Title" data-sort-col="' . ($C + 1) . '">端末コード</th>'
	. '<th class="Title" data-sort-col="' . ($C + 2) . '">UUID</th>'
	. '<th class="Title" data-sort-col="' . ($C + 3) . '">大会</th>'
	. '<th class="Title" data-sort-col="' . ($C + 4) . '">選択中の的</th>'
	. '<th class="Title" data-sort-col="' . ($C + 5) . '">アプリ</th>'
	. '<th class="Title" data-sort-col="' . ($C + 6) . '">バージョン</th>'
	. '<th class="Title" data-sort-col="' . ($C + 7) . '" data-sort-type="num">電池</th>'
	. '<th class="Title" data-sort-col="' . ($C + 8) . '" data-sort-type="num">最終通信（' . $TzLabel . '）</th>'
	. '<th class="Title" data-sort-col="' . ($C + 9) . '" data-sort-type="num">経過</th>'
	. ($CanEdit ? '<th class="Title">操作</th>' : '')
	. '</tr>';
echo '</thead>';
echo '<tbody id="LiteDevBody">';
if($Rows) {
	echo $Rows;
} else {
	echo '<tr><td colspan="' . $Cols . '" class="Center LiteDevMuted">このサーバーに登録されている端末はありません</td></tr>';
}
echo '</tbody>';
echo '<tfoot><tr><td colspan="' . $Cols . '" class="Left LiteDevMuted">'
	. '端末コードはこのサーバー全体で通しの番号です（大会ごとではありません）。新しく接続した端末には、登録済みの最大のコードの次の番号が振られます。'
	. '<br>「大会」は、その端末が最後に QR を読み込んだ大会です。別の大会の QR を読み込むと切り替わり、端末コードはそのまま引き継がれます。'
	. '<br>バージョンが赤字の端末は、必要なバージョン（' . reqAppVersion . '）より古いか、同じ種類のアプリの他の端末より古いものです。'
	. '<br>状態は最終通信からの経過時間で判定しています（' . intval(LITE_DEV_ACTIVE_SEC / 60) . '分以内: 通信中、' . intval(LITE_DEV_RECENT_SEC / 60) . '分以内: 応答待ち、それ以上: 切断）。'
	. '</td></tr></tfoot>';
echo '</table>';

require_once('Common/Templates/tail.php');
