<?php
/*
印刷メニューに「賞状PDF発行」を追加する。
最初にテンプレート選択（index.php）を開く。テンプレートの名前を押すと編集の画面へ、そこから上のタブで発行の画面へ移る。発行履歴は、テンプレート選択の上のタブから移る。
（Modules/Custom/menu.php から移した）

変更履歴:
2026/09/30 説明をテンプレート選択（名前を押して編集、上のタブで発行）にあわせた
2026/09/27 メニューから開く画面をテンプレートの一覧（index.php）にした
2026/09/26 メニューを「賞状PDF発行」の 1 つにまとめた（発行の画面を開く）
2026/09/26 テンプレートと発行履歴の画面を追加
2026/09/26 Modules/Custom/menu.php から移す
*/
if(!empty($on)) {
<<<<<<< Updated upstream
	$ret['PRNT'][] = MENU_DIVIDER;
	$ret['PRNT'][] = '賞状PDF発行' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/Award/index.php';
=======
  $ret['PRNT'][] = MENU_DIVIDER;
	$ret['PRNT'][] = '賞状PDF出力' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Award/index.php';
	$ret['PRNT'][] = '賞状PDF出力(つつじ賞)' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Award/tsutsuji.php';
	$ret['PRNT'][] = '賞状PDF出力(市ア協)' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Award/OutputCityAssociation.php';
	$ret['PRNT'][] = '賞状PDF出力(近畿大会)' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/' . 'Award/kinki2026.php';  
>>>>>>> Stashed changes
}
