<<<<<<< Updated upstream
<?php
/*
賞状のテンプレートの一覧。
テンプレートの新規作成・編集・複製・削除、別の ianseo に持っていくための書き出し・読み込みをする。
テンプレートは試合ごとではなく、この ianseo 全体で共通（data/templates に保存）。
- 一覧を見る・発行するのは、予選の印刷ができる人（awCanView）
- 作る・変える・消すのは、大会のデータを変えられる人（awCanEdit）

変更履歴:
2026/09/30 名前を押すと編集の画面へ。表のボタンは複製・削除・書き出しの 3 つだけにした（発行は、編集の画面の上のタブ「賞状発行」から）
2026/09/30 テンプレート選択の画面にした。見本から追加する機能をやめた（見本は data/templates に置いてある）
2026/09/26 テンプレートの一覧にした（賞状の出力は Issue.php へ移した）
2026/09/23 初版（予選の順位から賞状の PDF を出力）
*/
require_once(dirname(dirname(__FILE__)) . '/config.php');
require_once('Common/Lib/CommonLib.php');
require_once(__DIR__ . '/Lib.php');

CheckTourSession(true);
if(!awCanView()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}
$CanEdit = awCanEdit();
$Writable = awEnsureDirs();
$Errors = [];
$Msg = $_GET['msg'] ?? '';

// 書き出し（画像も中に入れた JSON）
if(isset($_GET['export']) and ($t = awLoadTemplate($_GET['export']))) {
	$out = awExportTemplate($t);
	header('Content-Type: application/json; charset=utf-8');
	header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode('賞状テンプレート_' . $t['name'] . '.json'));
	echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	$Act = $_POST['act'] ?? '';
	if(!$CanEdit) {
		$Errors[] = 'テンプレートを変更する権限がありません。';
	} elseif(!awCheckToken()) {
		$Errors[] = '画面の有効期限が切れました。もう一度操作してください。';
	} elseif(!$Writable) {
		$Errors[] = 'data フォルダに書き込めません。';
	} elseif($Act == 'new') {
		if($t = awSaveTemplate(awNewTemplate())) {
			CD_redirect('Edit.php?id=' . $t['id']);
		}
		$Errors[] = 'テンプレートを作れませんでした。';
	} elseif($Act == 'copy' and ($t = awLoadTemplate($_POST['id'] ?? ''))) {
		$t['id'] = '';
		$t['name'] .= ' のコピー';
		$t['createdAt'] = '';
		if($t = awSaveTemplate($t)) {
			CD_redirect('Edit.php?id=' . $t['id']);
		}
		$Errors[] = 'テンプレートを複製できませんでした。';
	} elseif($Act == 'delete' and ($t = awLoadTemplate($_POST['id'] ?? ''))) {
		awDeleteTemplate($t['id']);
		CD_redirect('index.php?msg=' . rawurlencode('「' . $t['name'] . '」を削除しました。発行履歴は残っています。'));
	} elseif($Act == 'import') {
		$f = $_FILES['file'] ?? null;
		if(!is_array($f) or ($f['error'] ?? UPLOAD_ERR_NO_FILE) != UPLOAD_ERR_OK or !is_uploaded_file($f['tmp_name'])) {
			$r = 'ファイルを受け取れませんでした。';
		} else {
			$r = awImportTemplate(file_get_contents($f['tmp_name']));
		}
		if(is_array($r)) {
			CD_redirect('Edit.php?id=' . $r['id']);
		}
		$Errors[] = $r;
	}
}

$Templates = awListTemplates();

$PAGE_TITLE = '賞状 - テンプレート';
$JS_SCRIPT = ['<link href="./award.css" rel="stylesheet" type="text/css">'];
$IncludeFA = true;
require_once('Common/Templates/head.php');

echo awTabs('index');
if(!$Writable) {
	echo '<div class="AwErr">' . awH(AW_DATA_DIR) . ' に書き込めません。フォルダを作って、Web サーバーが書き込めるようにしてください。</div>';
}
if($Msg !== '') {
	echo '<div class="AwMsg">' . awH($Msg) . '</div>';
}
foreach($Errors as $e) {
	echo '<div class="AwErr">' . awH($e) . '</div>';
}


if(!$Templates) {
	echo '<p>テンプレートがまだありません。' . ($CanEdit ? '「新しいテンプレート」から作ってください。' : '') . '</p>';
} else {
	echo '<table class="Tabella freeWidth AwTable">';
	echo '<tr><th>名前</th><th>書き方</th><th>用紙</th><th>項目</th><th>更新</th>' . ($CanEdit ? '<th></th>' : '') . '</tr>';
	foreach($Templates as $t) {
		$texts = count(array_filter($t['items'], function($i) { return $i['type'] == 'text'; }));
		$images = count($t['items']) - $texts;
		echo '<tr>';
		// 名前を押すと、編集の画面へ（編集できない人は発行の画面へ）
		$Link = $CanEdit ? 'Edit.php?id=' . rawurlencode($t['id']) : 'Issue.php?tpl=' . rawurlencode($t['id']);
		echo '<td><a href="' . awH($Link) . '"><b>' . awH($t['name']) . '</b></a>' . ($t['note'] !== '' ? '<br><span class="AwNote">' . nl2br(awH($t['note'])) . '</span>' : '') . '</td>';
		echo '<td>' . ($t['direction'] == 'vertical' ? '縦書き' : '横書き') . '</td>';
		echo '<td>' . awH($t['paper']['size'] == 'custom' ? $t['paper']['width'] . '×' . $t['paper']['height'] . 'mm' : $t['paper']['size'] . ($t['paper']['orientation'] == 'L' ? ' 横' : ' 縦'))
			. ($t['paper']['image'] ? '<br><img class="AwThumb" src="' . awH(awImageUrl($t['paper']['image'])) . '" alt="">' : '') . '</td>';
		echo '<td>テキスト ' . $texts . ($images ? '<br>画像 ' . $images : '') . '</td>';
		echo '<td>' . awH($t['updatedAt']) . '</td>';
		if($CanEdit) {
			// 複製・削除・書き出しの 3 つのボタン
			echo '<td class="AwBtns">';
			echo '<form method="post">' . awTokenField() . '<input type="hidden" name="act" value="copy"><input type="hidden" name="id" value="' . awH($t['id']) . '"><button type="submit">複製</button></form>';
			echo '<form method="post" onsubmit="return confirm(\'「' . awH(addslashes($t['name'])) . '」を削除しますか？（発行履歴は残ります）\')">' . awTokenField() . '<input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="' . awH($t['id']) . '"><button type="submit" class="AwDanger">削除</button></form>';
			echo '<form method="get"><input type="hidden" name="export" value="' . awH($t['id']) . '"><button type="submit">書き出し</button></form>';
			echo '</td>';
		}
		echo '</tr>';
	}
	echo '</table>';
}

if($CanEdit and $Writable) {
	echo '<p><form method="post">' . awTokenField() . '<input type="hidden" name="act" value="new"><button type="submit">新しいテンプレート</button></form></p>';
	echo '<form method="post" enctype="multipart/form-data">' . awTokenField() . '<input type="hidden" name="act" value="import">';
	echo 'テンプレートの読み込み（「書き出し」で保存した .json）: <input type="file" name="file" accept=".json,application/json" required> <button type="submit">読み込む</button>';
	echo '</form>';
}

include('Common/Templates/tail.php');
=======
<?php

	ini_set('display_errors', "On");

	require_once(dirname(dirname(__FILE__)) . '/config.php');
	require_once('Common/Lib/Fun_Modules.php');
	require_once('Common/tcpdf/tcpdf.php');
	require_once('./fpdi/autoload.php');

	CheckTourSession(true);
	
	$TourCode=stripslashes($_REQUEST['Tour']);
	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
	if(!($TourId > 0)) {
		die("error!");
	}
	

		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,
			CoCode,CoName,
			QuTargetNo, QuTarget, SUBSTRING(QuTargetNo,2) AS Target,
			QuScore, QuGold, QuXnine,
			ToId,ToGolds AS GoldLabel, ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
		  DivDescription,ClDescription,
		  ToName,ToWhere,ToWhenFrom,ToWhenTo,ToCode,ToComDescr,ToWhenTo,
		  
    RANK() OVER (
        PARTITION BY CONCAT(EnDivision, EnClass)
        ORDER BY QuScore DESC, QuGold DESC, QuXnine DESC
    ) AS Ranking

		FROM Entries 
		INNER JOIN Qualifications ON EnId=QuId 
		LEFT JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament 
		LEFT JOIN Tournament ON EnTournament=ToId
		LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType

    INNER JOIN Divisions ON DivTournament=ToId AND DivId=EnDivision    
    INNER JOIN Classes ON ClTournament=ToId AND ClId=EnClass
  	WHERE EnAthlete=1 AND ToId = {$TourId} AND CONCAT(EnDivision,EnClass) LIKE TdClasses";
	//var_dump($Select);
	$Rs=safe_r_sql($Select);

	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}
  
  
	usort($ArrayData, function($a, $b) {
    return $a['Class'] <=> $b['Class']             // Class は昇順
        ?: $b['QuScore'] <=> $a['QuScore']         // QuScore は降順
        ?: $b['QuGold'] <=> $a['QuGold']           // QuGold は降順
        ?: $b['QuXnine'] <=> $a['QuXnine'];        // QuXnine は降順

	});
	
	




	if(empty($_REQUEST["Data"])){
		
		include('Common/Templates/head.php');
    
    
    $classCounts = [];

    foreach ($ArrayData as $Data) {
        $class = $Data['Class'];
        if (!isset($classCounts[$class])) {
            $classCounts[$class] = 0;
        }
        $classCounts[$class]++;
    }
		
    echo <<<EOT
<style>
  .select-row {
    display: block;
    padding: 5px;
    cursor: pointer;
    font-size:1.5em;
  }
  .select-row.checked {
    background-color: yellow;
  }

@media print {
  .no-print {
    display: none !important;
  }
  .select-row.checked {
    background-color: #eee;
  }
  .select-row:not(.checked) {
    color:gray;
    font-size:0.9em;
  }
}
</style>

<script>
  function toggleRow(checkbox) {
    const label = checkbox.closest('label');
    if (checkbox.checked) {
      label.classList.add('checked');
    } else {
      label.classList.remove('checked');
    }
  }
</script>
EOT;
echo "<h1 class='no-print'>賞状発行</h1>";
    
$awardlimit = null;
$preClass = null;
$linecnt = 0;
echo "<form method='post' target='_blank'>";
echo "<input type='submit' value='PDF出力' class='no-print'>";
foreach($ArrayData as $no => $Data){
    if( $preClass != $Data['Class'] ) { 
        $awardLimit = getAwardLimit($classCounts[$Data['Class']]);
        echo "<hr>"; 
        echo "<h2>{$Data['Class']} {$Data['DivDescription']}部門 {$Data['ClDescription']}";
        echo "(参加者数{$classCounts[$Data['Class']]}→表彰数{$awardLimit})</h2>";
        $rank=1;
        $linecnt = 0;
    }
    $linecnt++;
    $preClass = $Data['Class'] ;
    if(intval($Data['Ranking'])>($awardLimit+2) || ( $Data['QuScore'] == 0 && $linecnt > 1)){
      echo "○";
      continue;
    }

    $checked = ($Data['Ranking']<=$awardLimit && $Data['QuScore']>0) ? "checked" : "" ;
    echo "<label class='select-row {$checked}'>";
    echo (($Data['QuScore']>0) ? "{$Data['Ranking']}位 " : "出力テスト" );
    echo "<input type='checkbox' name='Data[]' value='{$no}' class='no-print' onchange='toggleRow(this)' {$checked}> ";
    echo "{$Data['EnFirstName']} {$Data['EnName']} ";
    echo "{$Data['QuScore']} ";
    echo "{$Data['CoName']} ";
    echo "</label>";
}
echo "<hr>";
echo "</form>";
/*   
		$preClass = null;
		echo "<form method='post'>";
		foreach($ArrayData as $no => $Data){
			if( $preClass != $Data['Class'] ) { 
				echo "<hr>"; 
				echo "{$Data['Class']} {$Data['DivDescription']}部門 {$Data['ClDescription']}<br>";
				$rank=1;
			}
			$preClass = $Data['Class'] ;
			if(intval($Data['Ranking'])>8) continue;
			echo "{$Data['Ranking']}位";
			echo "<input type='checkbox' name='Data[]' value='{$no}'>";
			echo "{$Data['EnFirstName']} {$Data['EnName']} ";
			echo "{$Data['QuScore']}";
			echo "{$Data['CoName']} ";
			echo "<br>";
		} 
		echo "<hr><input type='submit' value='PDF出力'>";
		echo "</form>";
*/

		include('Common/Templates/tail.php');
	
	} else {
		
		
		$filteredArrayData = array_map(function($index) use ($ArrayData) {
			return $ArrayData[$index];
		}, $_REQUEST["Data"]);

	
		
		$pdf = new setasign\Fpdi\Tcpdf\Fpdi('L','mm');
		$pdf->setAutoPageBreak(false, 0);
		$pdf->setPrintHeader(false);
		$pdf->setPrintFooter(false);

		$pdf->setSourceFile('./PDF/26DR0798.pdf');

		
		$pdf->setFontSize(12);
		$pdf->setMargins(0, 0, 0);
		$pdf->setCellPadding(0);

	  
		$paper_h = 210;
		$paper_w = 297;
		$pageoffset_y = 40;
    $pageoffset_x = 0;
    


		
		// IPAフォント埋め込み
		$font = new TCPDF_FONTS();   
		$fontfile = 'fonts/YujiSyuku-Regular.ttf';
		$myFont = $font->addTTFfont($fontfile);
		
		foreach($filteredArrayData as $Data){
			
			$pdf->AddPage();
			//$page = $pdf->importPage(1); 
			//$pdf->useTemplate($page); 
      
      
      tateText($pageoffset_x+238,$pageoffset_y+25,"賞　　状",45);
			
		
			tateText($pageoffset_x+225,$pageoffset_y+5,"{$Data['DivDescription']}部門{$Data['ClDescription']}",14);
			tateText($pageoffset_x+212,$pageoffset_y+10,"第".numberToKanji($Data['Ranking'])."位",30);
			tateText($pageoffset_x+214.1,$pageoffset_y+pt2mm(30*4)+10,"{$Data['QuScore']}点",20);
			
			
			$l = mb_strlen(mb_convert_kana($Data['CoName'],"ASK", 'UTF-8'), 'UTF-8');
			$size = 20;
			if($l>11) {
			  $size = $size * 11 / $l ;	
			}
			tateText($pageoffset_x+200,$pageoffset_y+40,$Data['CoName'],$size);
			
			$name = "{$Data['EnFirstName']} {$Data['EnName']}";
			$l = mb_strlen(mb_convert_kana($name,"ASK", 'UTF-8'), 'UTF-8');
			tateText($pageoffset_x+188,$paper_h-$pageoffset_y-pt2mm(30*($l+2)),"{$name}",30);
			tateText($pageoffset_x+188,$paper_h-$pageoffset_y-pt2mm(30*1),"殿",30);
			//tateText(130,$pageoffset_y,"{$Data['QuScore']}",12);
      
      $sText = "あなたは{$Data['ToName']}に於いてよく健闘され頭書の成績を収められましたのでこれを賞します";
      
      //preg_match_all('/(\d{1,2})/', $sText, $match, PREG_SET_ORDER);
      preg_match_all('/\b(?!\d{1,2}m\b)(\d{1,2})\b/', $sText, $match, PREG_SET_ORDER);
      $search = [];
      $replace = [];
      foreach($match as $d){
        $search[] = $d[1];
        $replace[] = numberToKanji($d[1]);
      }
      $sText = str_replace($search, $replace, $sText);
      $sText_cnt = mb_strlen($sText);
      
      
      if($sText_cnt<=64){
         $sText_line = 4;
      } else {
         $sText_line = 5;
      }

      $sText_splitlen = ceil( $sText_cnt / $sText_line );
      $sText_arr = mb_str_split($sText, $sText_splitlen, 'UTF-8');
			
      for($i=0;$i<count($sText_arr);$i++){
        tateText($pageoffset_x+160-((55/($sText_line-1))*$i),$pageoffset_y,$sText_arr[$i],24,(2.95-0.125* $sText_splitlen));
      }

      tateText($pageoffset_x+80,$pageoffset_y,convertToKanjiDate($Data['ToWhenTo']),22,1);     
      tateText($pageoffset_x+66,$pageoffset_y+10,$Data['ToComDescr'],24,1);
      tateText($pageoffset_x+52,$pageoffset_y+30,"会長",24,1);  
      tateText($pageoffset_x+50.5,$pageoffset_y+52,"石橋　常男",32,1.1);  
      $pdf->Image("stamp.png", $pageoffset_x+45, $pageoffset_y+112, 24, 24, '','',null,false,300);
      
		}
		
		$pdf->Output();
	
	}
	
	
	
function tateText($x, $y, $str, $size, $width=1.1) {
	global $pdf, $myFont;
	//フォントサイズ設定
	$pdf->SetFont($myFont, '', $size);
	//字間
	$fh = pt2mm($size*$width);
	//文字数
	
	$str = mb_convert_kana($str,"ASK", 'UTF-8');
	$l = mb_strlen($str, 'UTF-8');
	for ($i=0; $i<$l; $i++) {
		$s1 = mb_substr($str, $i, 1, 'UTF-8');
		$adj_x = 0; $adj_y = 0;
		// 文字ごとの位置や回転調整
		switch($s1){
			case '「':
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.5);
				$adj_rotate_posi_x = pt2mm($size*0.4);
				$adj_rotate_posi_y = 0;
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
        break;
			case '」':
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.5);
				$adj_rotate_posi_x = pt2mm($size*0.4);
				$adj_rotate_posi_y = pt2mm($size*0.3);
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
        break;
			case '（':
			case '）':
			case '《':
			case '》':
			case '～':
			case 'ー':
			case '〔':
			case '〕':
			case '【':
			case '】':      
				//$adj_rotate_x = pt2mm($size);
				//$adj_rotate_y = pt2mm($size*0.3);
				//$adj_rotate_posi_x = pt2mm($size*0.7);
				$adj_rotate_x = pt2mm($size);
				$adj_rotate_y = pt2mm($size*0.4);
				$adj_rotate_posi_x = pt2mm($size*0.75);
				if($size<=12){
					$adj_rotate_posi_y = pt2mm($size*0.15);
				}else{
					$adj_rotate_posi_y = pt2mm($size*0.2);
				}
				$pdf->Rotate(270,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
				$pdf->Text($x+$adj_x+$adj_rotate_posi_x, $y+$fh*$i+$adj_y+$adj_rotate_posi_y, $s1,0);
				$pdf->Rotate(90,$x+$adj_x+$adj_rotate_x,$y+$fh*$i+$adj_y+$adj_rotate_y);
        break;
			case '。':
			case '、':
				$adj_x = $fh * 0.7; $adj_y = -$fh * 0.7;
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
        break;
			case 'っ':
			case 'ッ':
				$adj_x = pt2mm($size*0.1);
				$adj_y = -1*pt2mm($size*0.1);
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
        break;
			default:
				$pdf->Text($x+$adj_x, $y+$fh*$i+$adj_y, $s1,0);
        break;
		}
	}
}

function convertToKanjiDate($raw_date) {
    // 日付を年、月、日に分割
    
    $date = new DateTime($raw_date);

    $year  = $date->format('Y');
    $month = $date->format('n');
    $day   = $date->format('j');

    // 変換用配列
    $numMap = ['0'=>'〇', '1'=>'一', '2'=>'二', '3'=>'三', '4'=>'四', '5'=>'五', '6'=>'六', '7'=>'七', '8'=>'八', '9'=>'九'];

    // 1. 年の変換（一文字ずつ置換）
    $kanjiYear = strtr($year, $numMap);

    // 2. 月・日の変換ロジック
    $convertMD = function($num) use ($numMap) {
        $n = (int)$num;
        if ($n === 10) return '十';
        if ($n < 10) return $numMap[$n];
        if ($n < 20) return '十' . $numMap[$n % 10];
        if ($n % 10 === 0) return $numMap[$n / 10] . '十';
        return $numMap[(int)($n / 10)] . '十' . $numMap[$n % 10];
    };

    $kanjiMonth = $convertMD($month);
    $kanjiDay = $convertMD($day);

    return "{$kanjiYear}年{$kanjiMonth}月{$kanjiDay}日";
}

// 1 インチ = 25.4 ミリメートル
// 1 ポイント = 1/72 インチ
// 1mm　は、 25.4分の1インチ
function mm2pt($mm) {
	$pt = $mm / 25.4 * 72;
	return $pt;
}
function pt2mm($pt) {
	$mm = $pt / 72  * 25.4;
	return $mm;
}



function numberToKanji($number) {
    $kanjiNumbers = ['〇', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
    $kanjiUnits = ['', '十', '百', '千'];
    $kanjiBigUnits = ['', '万', '億', '兆'];

    if ($number == 0) return $kanjiNumbers[0];

    $result = '';
    $strNumber = strval($number);
    $length = strlen($strNumber);
    $groupCount = ceil($length / 4);

    for ($i = 0; $i < $groupCount; $i++) {
        $group = substr($strNumber, -4 * ($i + 1), 4);
        $group = str_pad($group, 4, '0', STR_PAD_LEFT);
        $groupKanji = '';

        for ($j = 0; $j < 4; $j++) {
            $digit = intval($group[$j]);
            if ($digit !== 0) {
                $groupKanji .= ($digit === 1 && $j !== 3) ? $kanjiUnits[3 - $j] : $kanjiNumbers[$digit] . $kanjiUnits[3 - $j];
            }
        }

        if ($groupKanji !== '') {
            $result = $groupKanji . $kanjiBigUnits[$i] . $result;
        }
    }

    return $result;
}


function getAwardLimit($participantCount) {
    if ($participantCount <= 1) {
        return 0; // 表彰なし
    } elseif ($participantCount <= 6) {
        return 1;
    } elseif ($participantCount <= 12) {
        return 2;
    } elseif ($participantCount <= 18) {
        return 3;
    } else {
        return 6;
    }
}
>>>>>>> Stashed changes
