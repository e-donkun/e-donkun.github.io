<?php
/*
予選スコアカード印刷のカスタマイズ

Common/Lib/ScorecardsLib.php の CreateSessionScorecard() のうち「通常スコアカード（ターゲット）」の
描画部分をもとに、次の点を変えて1つのPDFに描画する。
本体には手を入れないので、ianseo を更新しても消えない。

  1. 1的5人・6人立ち（ABC / DEF の2ページ構成）では、両方のページにQRコード（ISK-NG など）を印字する。
     標準では2ページ目を描いたあとに1回しかQRを描かないため、DEF側にしか出ない。
  2. 1的5人・6人立ちで、ABC側・DEF側それぞれ選手が1人もいないページは出力しない。
  3. セッション「---」（すべて）のとき、各セッションのデータを先に取得してから、1つのPDFに続けて描画する。
     標準では全セッションを的番号だけで並べるため、別セッションの同じ的番号が重なりセッション1しか出ない。
  4. 各ページの右上にセッション名を印字する。
  5. 予備のブランクスコアカード（CustomCreateBlankScorecard()）。ヘッダー（大会名）だけを印字し、
     セッション名・選手名・所属・的番号・クラス・距離・的ごとのQRコードは印字しない。
     指定すれば、ISK-NG の設定用QRコード（Api/ISK-NG/QRcodesPDF.php と同じ内容）を各ページに印字する。

個人スコアカード（全距離を1枚に）、フィールド/3D、Draw、HorScoreAllDist は標準の処理をそのまま使う。

変更履歴:
2026/09/25 設定用QRコードの下の「ISK-NG Liteセットアップ」などの文字を削除
2026/09/25 予備のブランクスコアカードに ISK-NG 設定用QRコードの印字を追加
2026/09/25 予備のブランクスコアカードの出力を追加
2026/09/23 セッション名の「セッション:」を削除し、セッション名だけを印字
2026/09/23 PDFを後から結合する方式をやめ、全セッションのデータを取得してから1つのPDFに描画する方式に変更
2026/09/23 セッション名を印字
2026/09/23 すべてのセッションの印刷に対応
2026/09/23 ABC側に選手がいない場合もページを削除
2026/09/23 初版
*/

require_once('Common/Lib/ScorecardsLib.php');
require_once('Common/Fun_Sessions.inc.php');

/**
 * @param int $Session 印刷するセッション。0以下ならすべての予選セッション
 * @param array $Options CreateSessionScorecard() と同じ
 * @return ScorePDF
 */
function CustomCreateSessionScorecard($Session, $FromTgt=1, $ToTgt=999, $Options=array()) {
	$ScoreDraw=(empty($Options["ScoreDraw"]) ? '' : $Options["ScoreDraw"]);

	// 対象外の印刷は標準の処理のまま
	if(!empty($Options["TourField3D"])
			or !empty($Options['PersonalScore'])
			or !empty($Options['SessionType'])
			or $ScoreDraw=='Draw'
			or $ScoreDraw=='HorScoreAllDist'
			or $ScoreDraw=='FourScoresNFAA') {
		return CreateSessionScorecard($Session, $FromTgt, $ToTgt, $Options);
	}

	// 印刷するセッション
	$Sessions=array();
	foreach(GetSessions('Q') as $Ses) {
		if($Session<=0 or $Ses->SesOrder==$Session) {
			$Sessions[]=$Ses;
		}
	}
	if($Session<=0) {
		// すべてのセッションのときは、各セッションの全的
		$FromTgt='';
		$ToTgt='';
	}

	$DistArray=array();
	if(!empty($Options["ScoreDist"]) and is_array($Options["ScoreDist"])) {
		foreach($Options["ScoreDist"] as $Dist) {
			if(is_numeric($Dist)) {
				$DistArray[]=$Dist;
			}
		}
	}
	if(!$DistArray) {
		$DistArray[]=0;
	}

	$FillWithArrows=!empty($Options["ScoreFilled"]);
	$pdf=CustomNewScorePDF($Options, $ScoreDraw, $FillWithArrows);

	// 先にすべてのセッションのデータを取得する
	// （1的の人数や的の範囲がセッションごとに違ってもよいように、取得はセッション単位）
	$AllData=array();
	foreach($Sessions as $Ses) {
		$Data=QualificationScorecards($Ses->SesOrder, $FromTgt, $ToTgt, empty($Options["noEmpty"]), $ScoreDraw, $FillWithArrows, false, false, $Options);
		$pdf->LastUpdate=max($pdf->LastUpdate, $Data->QuTimestamp);
		$AllData[]=array('Session'=>$Ses, 'Data'=>$Data);
	}

	// 1つのPDFに続けて描画する
	foreach($AllData as $Item) {
		CustomDrawSessionScorecards($pdf, $Item['Data'], $Item['Session'], $DistArray, $ScoreDraw);
	}

	if(!$pdf->getNumPages()) {
		// 印刷するページがない場合は標準の出力
		return CreateSessionScorecard($Session, $FromTgt, $ToTgt, $Options);
	}
	return $pdf;
}

/**
 * 予備のブランクスコアカード
 * ヘッダー（大会名）は印刷オプションのとおりに印字し、それ以外（セッション名、選手名、所属、的番号、
 * クラス、距離、的ごとのQRコード）は印字しない。
 * BlankSetupQr を指定すると、的ごとのQRコードと同じ位置に ISK-NG の設定用QRコードを印字する。
 * 1ページのカード枚数（レイアウト）とエンド数・射数は、選んだセッション（すべてのときは最初のセッション）と
 * 選んだ距離（距離なしのときは第1距離）に合わせる。
 *
 * @param int $Session 印刷画面で選んだセッション。0以下ならすべて
 * @param array $Options 印刷画面の設定。BlankPages にページ数、BlankSetupQr に設定用QRコードの印字
 * @return ScorePDF
 */
function CustomCreateBlankScorecard($Session, $Options=array()) {
	// 標準・合計列付きの書式だけ。QRコード・バーコード・生年月日などは印字しない
	$ScoreDraw=((!empty($Options["ScoreDraw"]) and $Options["ScoreDraw"]=='CompleteTotals') ? 'CompleteTotals' : '');
	unset($Options["QRCode"], $Options["ScoreQrPersonal"], $Options["ScoreBarcode"], $Options["GetArcInfo"], $Options["ScoreFlags"]);
	$SetupQr=(empty($Options["BlankSetupQr"]) ? '' : CustomSetupQrCode());
	if($SetupQr) {
		// スコアカードの大きさとQRコードの位置を、的ごとのQRコードを1つ印字するときと同じにする
		// （$pdf->QRCode はレイアウトの計算だけに使い、的ごとのQRコードは描かない）
		$Options["QRCode"]=array('ISK-NG');
	}
	$pdf=CustomNewScorePDF($Options, $ScoreDraw, false);
	// 的番号がないので ScorecardsAI のマーカーも印字しない
	$pdf->Aruco=0;
	$pdf->ArucoSize=0;
	$pdf->ArucoType=0;
	$pdf->ArucoMarker=null;

	$Pages=max(1, min(100, intval($Options["BlankPages"] ?? 1)));

	// レイアウトとエンド数・射数のもとにするセッションと距離
	$Ses=null;
	foreach(GetSessions('Q') as $tmp) {
		if(!$Ses or $tmp->SesOrder==$Session) {
			$Ses=$tmp;
		}
		if($tmp->SesOrder==$Session) {
			break;
		}
	}
	$SesOrder=($Ses ? $Ses->SesOrder : 1);
	$Ath4Target=($Ses ? $Ses->SesAth4Target : 4);

	$Dist=1;
	if(!empty($Options["ScoreDist"]) and is_array($Options["ScoreDist"])) {
		foreach($Options["ScoreDist"] as $tmp) {
			if(is_numeric($tmp) and $tmp>0) {
				$Dist=intval($tmp);
				break;
			}
		}
	}

	$q=safe_r_sql("select ToGolds, ToGoldsChars, ToXNine, ToXNineChars from Tournament where ToId={$_SESSION['TourId']}");
	$r=safe_fetch($q);
	// 距離（D0）・カテゴリー（Cat）・的番号（tNo）・選手名などは入れない
	$Card=array('Session'=>$SesOrder, 'Arr0'=>'', 'Golds'=>$r->ToGolds, 'XNine'=>$r->ToXNine,
		'GoldsChars'=>$r->ToGoldsChars, 'XNineChars'=>$r->ToXNineChars);
	$ArrowEnds=getArrowEnds($SesOrder, $Dist);
	if(!$ArrowEnds) {
		$ArrowEnds=getArrowEnds($SesOrder);
	}
	if($ArrowEnds) {
		$tmp=reset($ArrowEnds);
		$Card['NumEnds0']=$tmp['ends'];
		$Card['NumArrows0']=$tmp['arrows'];
	}

	$L=CustomScorecardLayout($pdf, $Ath4Target, $ScoreDraw);
	for($p=0; $p<$Pages; $p++) {
		if($Ath4Target<=2) {
			// 横向きに2枚
			$pdf->AddPage('L');
			$pdf->DrawScoreNew($L->X, $L->Y, $L->W, $L->H, 0, $Card);
			$pdf->DrawScoreNew(2*$L->X+$L->W, $L->Y, $L->W, $L->H, 0, $Card);
		} elseif($Ath4Target==3 or $Ath4Target==5 or $Ath4Target==6) {
			// 横向きに3枚
			$pdf->AddPage('L');
			for($i=0; $i<3; $i++) {
				$pdf->DrawScoreNew($L->X+$i*($L->W+$L->ScoreGutter), $L->Y, $L->W, $L->H, 0, $Card);
			}
		} else {
			// 縦向きに4枚
			$pdf->AddPage('P');
			$pdf->DrawScoreNew($L->X, $L->Y, $L->W, $L->H, 0, $Card);
			$pdf->DrawScoreNew($L->X2, $L->Y, $L->W, $L->H, 0, $Card);
			$pdf->DrawScoreNew($L->X, $L->Y2, $L->W, $L->H, 0, $Card);
			$pdf->DrawScoreNew($L->X2, $L->Y2, $L->W, $L->H, 0, $Card);
		}
		if($SetupQr) {
			CustomDrawSetupQrCode($pdf, $L, $SetupQr);
		}
	}
	return $pdf;
}

/**
 * ISK-NG の設定用QRコードの内容（Api/ISK-NG/QRcodesPDF.php と同じ）
 * Lite/Pro はサーバーURLと大会コード（PIN）、Live は QRcodes.php で保存した設定。
 * ISK-NG を使っていない、または設定がない場合は空文字
 */
function CustomSetupQrCode() {
	global $CFG;
	require_once('Api/ISK-NG/config_defines.php');
	require_once('Api/ISK-NG/Lib.php');
	switch($_SESSION['UseApi']??'') {
		case ISK_NG_LITE_CODE:
		case ISK_NG_PRO_CODE:
			// QRcodes.php が保存する内容と同じ
			if(!($Url=getModuleParameter('ISK-NG', 'ServerUrl'))) {
				return '';
			}
			$QrCode=array('u'=>$Url.$CFG->ROOT_DIR, 'c'=>$_SESSION['TourCode']);
			if($Pin=getModuleParameter('ISK-NG', 'ServerUrlPin')) {
				$QrCode['c'].='|'.$Pin;
			}
			break;
		case ISK_NG_LIVE_CODE:
			if(!($QrCode=getSetupGlobalQrCode($_SESSION['TourId']))) {
				return '';
			}
			unset($QrCode['regexSignature']);
			break;
		default:
			return '';
	}
	return json_encode($QrCode);
}

/**
 * 現在のページに ISK-NG の設定用QRコードを印字する
 * 位置と大きさは的ごとのQRコード（DrawQRCode_ISK_NG()）と同じ
 */
function CustomDrawSetupQrCode($pdf, $L, $Code) {
	$Size=25;
	$X=($L->QRCodeX ?: ($pdf->getPageWidth()-$Size)/2);
	$Y=($L->QRCodeY ?: ($pdf->getPageHeight()-$Size-3)/2);
	$pdf->Rect($X, $Y, $Size, $Size, 'FD', array('all'=>array('color'=>100)), array(255));
	$pdf->write2DBarcode($Code, 'QRCODE,L', $X+2.5, $Y+2.5, $Size-5, $Size-5);
}

/**
 * ScorePDF を作って印刷オプションを設定する（CreateSessionScorecard() の設定部分と同じ）
 */
function CustomNewScorePDF($Options, $ScoreDraw, $FillWithArrows) {
	global $CFG;
	$pdf = new ScorePDF(true);
	if(!$FillWithArrows and getModuleParameter('ScorecardsAI', 'Active', '') and module_exists('ScorecardsAI')) {
		$pdf->Aruco=1;
		$pdf->ArucoSize=getModuleParameter('ScorecardsAI', 'Size', 10);
		$pdf->ArucoType=970;
		require_once($CFG->DOCUMENT_PATH.'Modules/ScorecardsAI/Lib.php');
		$pdf->ArucoMarker=new ArucoMarkers();
	} else {
		$pdf->Aruco=0;
		$pdf->ArucoSize=0;
		$pdf->ArucoType=0;
		$pdf->ArucoMarker=null;
	}
	if(!empty($Options["QRCode"])) {
		$pdf->QRCode=$Options["QRCode"];
		$pdf->BottomImage=false;
	}
	if(!empty($Options["ScoreQrPersonal"])) {
		$pdf->ScoreQrPersonal=true;
		$pdf->BottomImage=false;
	}
	$pdf->FillWithArrows=$FillWithArrows;
	if(empty($Options["ScoreHeader"])) {
		$pdf->HideHeader();
	}
	if(empty($Options["ScoreLogos"])) {
		$pdf->HideLogo();
	}
	if(empty($Options["ScoreFlags"])) {
		$pdf->HideFlags();
	}
	$pdf->FullHeaderShow(!empty($Options["ScorePageHeaderFooter"]));
	if(!empty($Options["ScoreBarcode"])) {
		$pdf->PrintBarcode=true;
	}
	if(!empty($Options["GetArcInfo"])) {
		$pdf->GetArcInfo=true;
	}
	switch($ScoreDraw) {
		case 'Data': $pdf->NoDrawing(); break;
		case 'CompleteTotals': $pdf->PrintTotalColumns(); break;
	}
	return $pdf;
}

/**
 * 1的の人数に応じたスコアカードとQRコードの位置（CreateSessionScorecard() の計算と同じ）
 * 縦向き（A4縦）を基準に計算するので、途中で横向きのページがあっても結果は変わらない。
 */
function CustomScorecardLayout($pdf, $Ath4Target, $ScoreDraw) {
	$PW=min($pdf->getPageWidth(), $pdf->getPageHeight());
	$PH=max($pdf->getPageWidth(), $pdf->getPageHeight());
	$M=$pdf->getSideMargin();
	$A=$pdf->ArucoSize;

	$L=new stdClass();
	$L->ScoreGutter=0;
	$L->W = ($PW-$M*3-($A ? $A-8 : 0))/2;
	$L->H = ($PH-$M*3-($pdf->NoTensOnlyX ? 7 : 0)-($A ? $A-8 : 0))/2;
	$L->X = $M+($A ? $A-3 : 0);
	$L->X2 = $L->X + ($A ? 5 : $M) + $L->W;
	$L->Y = $M;
	$L->Y2 = $L->Y + ($A ? 5 : $M) + $L->H - ($pdf->PrintFullHeader ? 10 + (empty($pdf->QRCode) ? 5 : 0) : 0);

	if($Ath4Target<=2) {
		$L->X = $M*3;
		$L->H = ($PW-$M*2-($pdf->NoTensOnlyX ? 7 : 0)-$A-($pdf->PrintFullHeader ? 10 : 0));
		$L->W = ($PH-$L->X*3)/2;
	} elseif($Ath4Target==3 or $Ath4Target==5 or $Ath4Target==6) {
		$L->ScoreGutter = ($A ? $M/2 : $M);
		$L->H = ($PW-$M*2-$A)-($pdf->PrintFullHeader ? 10 : 0);
		$L->W = ($PH-$M*4-($A ? $A-13 : 0))/3;
	} elseif($ScoreDraw=='HorScore') {
		$L->ScoreGutter=$M/2;
		$L->H = ($PW-$M-34-($A ? $A-8 : 0));
		$L->W = ($PH-$M*2-$L->ScoreGutter*3-($A ? $A-3 : 0))/4;
		$L->Y+=3;
	}

	$L->QRCodeX=0;
	$L->QRCodeY=0;
	if($pdf->QRCode or $pdf->ScoreQrPersonal) {
		$quanti=count($pdf->QRCode)+($pdf->ScoreQrPersonal ? 1 : 0);
		switch($Ath4Target) {
			case 1:
			case 2:
			case 3:
			case 5:
			case 6:
				// 横向きのページ
				$L->H-=25;
				$L->QRCodeY=$PW - $M - 25 - ($pdf->PrintFullHeader ? 8 : 0) - $A;
				$L->QRCodeX=($PH + 5 - (25*$quanti))/2;
				break;
			default:
				if($ScoreDraw=='HorScore') {
					$L->H-=25;
					$L->QRCodeY=$PW - $M - 25;
					$L->QRCodeX=($PH + 5 - (25*$quanti))/2;
				} else {
					$L->H-=8;
					$L->Y2+=8;
					$L->QRCodeY=(($PH - 25)/2)-0.5;
					if(count($pdf->QRCode)>1 or $pdf->ScoreQrPersonal) {
						$L->QRCodeX=($PW + 5 - (30*$quanti))/2;
					}
				}
				break;
		}
	}
	return $L;
}

/**
 * 1セッション分のスコアカードを描画する（CreateSessionScorecard() の通常スコアカード部分をもとにしている）
 */
function CustomDrawSessionScorecards($pdf, $Data, $Ses, $DistArray, $ScoreDraw) {
	$L=CustomScorecardLayout($pdf, $Data->Ath4Target, $ScoreDraw);
	$SesName=($Ses->SesName!=='' ? $Ses->SesName : $Ses->SesOrder);

	foreach($Data->Scores as $Cards) {
		foreach($DistArray as $CurDist) {
			if($CurDist and $Cards[0]["D".$CurDist]=='-') {
				continue 2;
			}
			if($Data->Ath4Target==1 and empty($Cards[0]['Ath'])) {
				continue;
			}

			$Aru=[];
			$ArucoLeft=6;
			switch($Data->Ath4Target) {
				case 2:
					CustomAddPage($pdf, 'L', $SesName);
					$ArucoBottom=$pdf->getPageHeight()-16;
					$ArucoRight=$pdf->getPageWidth()-$pdf->getSideMargin()-$pdf->ArucoSize;
					$pdf->ArucoType = $pdf->ArucoMarker ? $pdf->ArucoMarker::Q2H : 0;
					$tmp=$pdf->DrawScoreNew($L->X, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 0));
					$Aru['T']=['X'=>$ArucoLeft,'Y'=>$tmp['Y'], 'N'=>$pdf->ArucoType];
					$Aru['E']=['X'=>$tmp['X'],'Y'=>$ArucoBottom, 'N'=>$tmp['E']];
					$tmp=$pdf->DrawScoreNew(2*$L->X+$L->W, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 1));
					$Aru['O']=['X'=>$tmp['X'],'Y'=>$ArucoBottom,'N'=>$tmp['O']];
					$Aru['W']=['X'=>$ArucoRight-5*$pdf->ArucoSize,'Y'=>$ArucoBottom,'N'=>$tmp['W']];
					$Aru['H']=['X'=>$tmp['X']-3*$pdf->ArucoSize,'Y'=>$ArucoBottom,'N'=>$tmp['H']];
					$Aru['A']=['X'=>$ArucoRight,'Y'=>$ArucoBottom,'N'=>$tmp['A']];
					break;
				case 3:
					CustomAddPage($pdf, 'L', $SesName);
					$ArucoBottom=$pdf->getPageHeight()-16;
					$ArucoRight=$pdf->getPageWidth()-$pdf->getSideMargin()-$pdf->ArucoSize;
					$tmp=$pdf->DrawScoreNew($L->X, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 0));
					$Aru['T']=['X'=>$ArucoLeft,'Y'=>$tmp['Y'], 'N'=>$pdf->ArucoType];
					$Aru['E']=['X'=>$tmp['X'],'Y'=>$ArucoBottom, 'N'=>$tmp['E']];
					$tmp=$pdf->DrawScoreNew($L->X+$L->W+$L->ScoreGutter, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 1));
					$Aru['O']=['X'=>$tmp['X'],'Y'=>$ArucoBottom,'N'=>$tmp['O']];
					$tmp=$pdf->DrawScoreNew($L->X+2*($L->W+$L->ScoreGutter), $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 2));
					$Aru['W']=['X'=>$tmp['X'],'Y'=>$ArucoBottom,'N'=>$tmp['W']];
					$Aru['H']=['X'=>$ArucoRight-3*$pdf->ArucoSize,'Y'=>$ArucoBottom,'N'=>$tmp['H']];
					$Aru['A']=['X'=>$ArucoRight,'Y'=>$ArucoBottom,'N'=>$tmp['A']];
					break;
				case 4:
					CustomAddPage($pdf, ($ScoreDraw=='HorScore' ? 'L' : 'P'), $SesName);
					$ArucoBottom=$pdf->getPageHeight()-16;
					$ArucoRight=$pdf->getPageWidth()-$pdf->getSideMargin()-$pdf->ArucoSize;
					if($ScoreDraw=='HorScore') {
						$pdf->ArucoType = $pdf->ArucoMarker ? $pdf->ArucoMarker::Q4H : 0;
						$tmp=$pdf->DrawScoreNew($L->X, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 0));
						$Aru['T']=['X'=>$ArucoLeft,'Y'=>$tmp['Y'], 'N'=>$pdf->ArucoType];
						$Aru['E']=['X'=>$tmp['X'],'Y'=>$ArucoBottom, 'N'=>$tmp['E']];
						$tmp=$pdf->DrawScoreNew($L->X+$L->ScoreGutter+$L->W, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 1));
						$Aru['O']=['X'=>$tmp['X'],'Y'=>$ArucoBottom,'N'=>$tmp['O']];
						$tmp=$pdf->DrawScoreNew($L->X+2*($L->W+$L->ScoreGutter), $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 2));
						$Aru['W']=['X'=>$tmp['X'],'Y'=>$ArucoBottom,'N'=>$tmp['W']];
						$tmp=$pdf->DrawScoreNew($L->X+3*($L->W+$L->ScoreGutter), $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 3));
						$Aru['H']=['X'=>$tmp['X'],'Y'=>$ArucoBottom,'N'=>$tmp['H']];
						$Aru['A']=['X'=>$ArucoRight,'Y'=>$ArucoBottom,'N'=>$tmp['A']];
					} else {
						$pdf->ArucoType = $pdf->ArucoMarker ? $pdf->ArucoMarker::Q4X : 0;
						$tmp=$pdf->DrawScoreNew($L->X, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 0));
						$Aru['T']=['X'=>$ArucoLeft,'Y'=>$tmp['Y'], 'N'=>$pdf->ArucoType];
						$tmp=$pdf->DrawScoreNew($L->X2, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 1));
						$Aru['O']=['X'=>$tmp['X'],'Y'=>$ArucoBottom, 'N'=>$tmp['O']];
						$tmp=$pdf->DrawScoreNew($L->X, $L->Y2, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 2));
						$Aru['E']=['X'=>$tmp['X'],'Y'=>$ArucoBottom,'N'=>$tmp['E']];
						$tmp=$pdf->DrawScoreNew($L->X2, $L->Y2, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 3));
						$Aru['W']=['X'=>$ArucoLeft,'Y'=>$tmp['Y'],'N'=>$tmp['W']];
						$Aru['H']=['X'=>$ArucoRight-2*$pdf->ArucoSize,'Y'=>$ArucoBottom,'N'=>$tmp['H']];
						$Aru['A']=['X'=>$ArucoRight,'Y'=>$ArucoBottom,'N'=>$tmp['A']];
					}
					break;
				case 5:
				case 6:
					// ABC と DEF の2ページ。選手が1人もいないページは出さない。どちらのページにもQRコードを印字する
					$Pages=array(array(0,1,2), range(3, $Data->Ath4Target-1));
					foreach($Pages as $Idx) {
						if($ScoreDraw!='TargetNo' and CustomIsEmpty($Cards, $Idx)) {
							continue;
						}
						CustomAddPage($pdf, 'L', $SesName);
						foreach($Idx as $i => $n) {
							$pdf->DrawScoreNew(($i+1)*$L->X+$i*$L->W, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, $n));
						}
						CustomDrawQRCode($pdf, $L, $Cards, $CurDist);
					}
					continue 2;
				default:
					if($Data->Ath4Target==1) {
						CustomAddPage($pdf, 'L', $SesName);
						$pdf->DrawScoreNew($L->X, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, 0));
						break;
					}
					// 7人以上: 縦向きに4枚ずつ。どのページにもQRコードを印字する
					for($n=0; $n<count($Cards); $n++) {
						switch($n%4) {
							case 0:
								if($n) {
									CustomDrawQRCode($pdf, $L, $Cards, $CurDist);
								}
								CustomAddPage($pdf, ($ScoreDraw=='HorScore' ? 'L' : 'P'), $SesName);
								$pdf->DrawScoreNew($L->X, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, $n));
								break;
							case 1:
								$pdf->DrawScoreNew($L->X2, $L->Y, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, $n));
								break;
							case 2:
								$pdf->DrawScoreNew($L->X, $L->Y2, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, $n));
								break;
							case 3:
								$pdf->DrawScoreNew($L->X2, $L->Y2, $L->W, $L->H, $CurDist, CustomCard($Data, $Cards, $n));
								break;
						}
					}
					break;
			}
			$pdf->PrintAruco($Aru);
			CustomDrawQRCode($pdf, $L, $Cards, $CurDist);
		}
	}
}

/**
 * ページを追加して、右上にセッション名を印字する
 */
function CustomAddPage($pdf, $Orientation, $SesName) {
	$pdf->AddPage($Orientation);

	$Right=$pdf->getSideMargin();
	$Y=2.5;
	if($pdf->PrintFullHeader) {
		// ページヘッダー（大会名など）の右側。右のロゴがあれば、その左に置く
		$Y=5;
		if(!empty($pdf->ToPaths['ToRight']) and $im=@getimagesize($pdf->ToPaths['ToRight'])) {
			$Right+=($im[0]*15/$im[1])+2;
		}
	}
	$pdf->SetFont($pdf->FontStd, 'B', 13);
	$pdf->SetTextColor(0);
	$pdf->SetXY($pdf->getPageWidth()-$Right-100, $Y);
	$pdf->Cell(100, 6, $SesName, 0, 0, 'R', 0);
}

/**
 * 的の n 番目のカード（ない場合は空のカード）
 */
function CustomCard($Data, $Cards, $n) {
	return $Cards[$n] ?? $Data->DefaultScore+array('tNo'=>chr(65+$n));
}

/**
 * 指定したカードすべてに選手がいなければ true
 */
function CustomIsEmpty($Cards, $Idx) {
	foreach($Idx as $n) {
		if(!empty($Cards[$n]['EnCode'])) {
			return false;
		}
	}
	return true;
}

/**
 * 現在のページにQRコードを印字する（CreateSessionScorecard() と同じ内容・位置）
 */
function CustomDrawQRCode($pdf, $L, $Cards, $CurDist) {
	if(!$pdf->QRCode and !$pdf->ScoreQrPersonal) {
		return;
	}
	$TmpTarget = substr($Cards[0]['tNo'],0,-1);
	$k=-1;
	foreach($pdf->QRCode as $k => $Api) {
		require_once('Api/'.$Api.'/DrawQRCode.php');
		$Function='DrawQRCode_'.preg_replace('/[^a-z0-9]/sim', '_', $Api);
		$Function($pdf, $L->QRCodeX + 30*$k, $L->QRCodeY, $Cards[0]['Session'], $CurDist, $TmpTarget, '', 'Q', false);
	}
	if($pdf->ScoreQrPersonal) {
		$k++;
		DrawScoreQrPersonal($pdf, $Cards[0]['AtTarget'], $L->QRCodeX + 30*$k, $L->QRCodeY);
	}
}
