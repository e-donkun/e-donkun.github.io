<?php
/*
個人・団体決勝の予備のブランクスコアカード

Final/Individual/PDFScoreMatch.php・Final/Team/PDFScoreMatch.php の「1試合1枚」のスコアカード（DrawScore()）を
もとに、何も入っていないカードだけを描く。本体には手を入れないので、ianseo を更新しても消えない。

  - ページのヘッダー（大会名）とフッターは標準と同じに印字する。
  - フェーズ、選手名・チーム名、所属、部門・クラス、的番号、予選順位は空欄にする。
  - エンド数・射数・シュートオフの射数、セット制か累計か、10・X の欄は、選んだ書式（その書式を使う種目の設定）に合わせる。
  - 標準の白紙（Blank=1）と違い、選んだ書式だけを指定したページ数だけ出す。
  - 指定すれば、ISK-NG の設定用QRコード（Api/ISK-NG/QRcodesPDF.php と同じ内容）を、試合ごとのQRコードと同じ位置（右上）に印字する。
  - バーコード・試合ごとのQRコード・ScorecardsAI のマーカーは印字しない。

変更履歴:
2026/10/13 初版
*/

require_once('Common/pdf/ScorePDF.inc.php');
require_once('Common/Lib/ArrTargets.inc.php');
require_once('Common/Lib/Fun_Phases.inc.php');
require_once(__DIR__ . '/CustomScorecardsLib.php');

/**
 * 決勝の種目で使うスコアカードの書式の一覧
 * 書式が同じ種目は1つにまとめる。ラウンドによってエリミネーション用とファイナル用の設定を使い分ける種目は、両方を入れる。
 *
 * @param int $Team 0: 個人、1: 団体
 * @return array キーは書式のキー。値は Key, MatchMode, ElimType, Ends, Arrows, SO, CheckGolds, CheckXNines, Golds, XNine, Events
 */
function CustomFinalBlankFormats($Team) {
	$Team=($Team ? 1 : 0);
	$q=safe_r_sql("select ToGolds, ToXNine from Tournament where ToId={$_SESSION['TourId']}");
	$Tour=safe_fetch($q);

	$Formats=array();
	$q=safe_r_sql("SELECT EvCode, EvMatchMode, EvElimType, EvFinalFirstPhase, EvMatchArrowsNo,
			EvElimEnds, EvElimArrows, EvElimSO, EvFinEnds, EvFinArrows, EvFinSO,
			EvCheckGolds, EvCheckXNines, EvGolds, EvXNine
		FROM Events
		WHERE EvTournament={$_SESSION['TourId']} AND EvTeamEvent=$Team AND EvFinalFirstPhase!=0
		ORDER BY EvProgr, EvCode");
	while($r=safe_fetch($q)) {
		$Sets=array();
		list($HasElim, $HasFin)=elimFinFromMatchArrowsNo($r->EvFinalFirstPhase, $r->EvMatchArrowsNo);
		if($HasElim) {
			$Sets[]=array($r->EvElimEnds, $r->EvElimArrows, $r->EvElimSO);
		}
		if($HasFin) {
			$Sets[]=array($r->EvFinEnds, $r->EvFinArrows, $r->EvFinSO);
		}
		foreach($Sets as $Set) {
			$F=array(
				'MatchMode'=>intval($r->EvMatchMode),
				'ElimType'=>($Team ? 0 : intval($r->EvElimType)),
				'Ends'=>max(1, intval($Set[0])),
				'Arrows'=>max(1, intval($Set[1])),
				'SO'=>max(1, intval($Set[2])),
				'CheckGolds'=>intval($r->EvCheckGolds),
				'CheckXNines'=>intval($r->EvCheckXNines),
				'Golds'=>($r->EvGolds!=='' ? $r->EvGolds : $Tour->ToGolds),
				'XNine'=>($r->EvXNine!=='' ? $r->EvXNine : $Tour->ToXNine),
			);
			$Key=implode('_', array($F['MatchMode'], $F['ElimType'], $F['Ends'], $F['Arrows'], $F['SO'], $F['CheckGolds'], $F['CheckXNines'], bin2hex($F['Golds'].'|'.$F['XNine'])));
			if(empty($Formats[$Key])) {
				$Formats[$Key]=$F+array('Key'=>$Key, 'Events'=>array());
			}
			if(!in_array($r->EvCode, $Formats[$Key]['Events'])) {
				$Formats[$Key]['Events'][]=$r->EvCode;
			}
		}
	}
	return $Formats;
}

/**
 * 書式の説明（画面に出す）
 */
function CustomFinalBlankFormatText($F) {
	$Txt=($F['MatchMode'] ? 'セット制' : '累計') . '　' . $F['Ends'] . 'エンド × ' . $F['Arrows'] . '射' . '　シュートオフ ' . $F['SO'] . '射';
	$Cols=array();
	if($F['CheckGolds']) {
		$Cols[]=$F['Golds'];
	}
	if($F['CheckXNines']) {
		$Cols[]=$F['XNine'];
	}
	if($Cols) {
		$Txt.='　（' . implode('・', $Cols) . ' の欄あり）';
	}
	return $Txt;
}

/**
 * 決勝の予備のブランクスコアカード（1ページに1試合分＝左右2枚）
 *
 * @param int $Team 0: 個人、1: 団体
 * @param array $F CustomFinalBlankFormats() の書式
 * @param int $Pages ページ数
 * @param bool $SetupQr ISK-NG の設定用QRコードを印字する
 * @return ScorePDF
 */
function CustomCreateFinalBlankScorecard($Team, $F, $Pages=1, $SetupQr=false) {
	$Pages=max(1, min(100, intval($Pages)));
	$QrCode=($SetupQr ? CustomSetupQrCode() : '');

	// 標準の PDFScoreMatch.php と同じ設定（横向き、ヘッダー・フッターあり）
	$pdf = new ScorePDF(false);
	$pdf->setBarcodeHeader(10);
	$pdf->setPrintHeader(true);
	$pdf->setPrintFooter(true);
	$pdf->PrintFooterSerialNumber=true;
	$pdf->Aruco=0;
	$pdf->ArucoSize=0;
	$pdf->ArucoType=0;
	$pdf->ArucoMarker=null;
	$pdf->PrintFlags=false;

	// 大きさ（標準と同じ計算）
	$L=new stdClass();
	$L->ScoreWidth=(($pdf->GetPageWidth()-$pdf->getSideMargin()*3)/2);
	$L->StartX=array($pdf->getSideMargin(), ($pdf->GetPageWidth()-$pdf->getSideMargin()-$L->ScoreWidth));
	$NumUnits=($Team ? 18 : 15) + ($F['CheckGolds'] ? 1 : 0) + ($F['CheckXNines'] ? 1 : 0);
	if($Team) {
		$L->StartY=array(55, 55);
		$L->GoldW=$L->ScoreWidth*(1/$NumUnits);
		$L->TotalW=$L->ScoreWidth*(2.5/$NumUnits);
		$L->ArrowTotW=$L->ScoreWidth*(10/$NumUnits);
	} else {
		$L->StartY=array(60, 60);
		$L->GoldW=$L->ScoreWidth*(1/$NumUnits);
		$L->TotalW=$L->ScoreWidth*(3/$NumUnits);
		$L->ArrowTotW=$L->ScoreWidth*(6/$NumUnits);
	}
	$pdf->ScoreCellHeight=min(9, intval(($pdf->getPageHeight() - 120 - 4.5) / (4 + $F['Ends'])));

	for($p=0; $p<$Pages; $p++) {
		$pdf->AddPage();
		foreach(array(0, 1) as $Side) {
			if($Team) {
				CustomFinalDrawBlankTeam($pdf, $F, $L, $Side);
			} else {
				CustomFinalDrawBlankInd($pdf, $F, $L, $Side);
			}
		}

		// 審判のサイン、時刻、メモ
		$pdf->SetLeftMargin($L->StartX[0]);
		$pdf->Ln(5);
		$pdf->Cell(($pdf->GetPageWidth()-$pdf->getSideMargin()*2)-90, 8, (get_text('TargetJudgeSignature', 'Tournament')), 'B', 0, 'L', 0);
		$pdf->Cell(90, 8, (get_text('TimeStampSignature', 'Tournament')), 1, 1, 'L', 0);
		$pdf->Ln(6);
		$pdf->Cell(($pdf->GetPageWidth()-$pdf->getSideMargin()*2), 4, (get_text('JudgeNotes')), 'B', 1, 'L', 0);

		// 試合ごとのQRコードと同じ位置（右上）に設定用QRコード
		if($QrCode) {
			$X=$pdf->BarcodeHeaderX-25;
			$Y=5;
			$pdf->Rect($X, $Y, 25, 25, 'FD', array('all'=>array('color'=>100)), array(255));
			$pdf->write2DBarcode($QrCode, 'QRCODE,L', $X+2.5, $Y+2.5, 20, 20);
			$pdf->SetDefaultColor();
		}
	}
	return $pdf;
}

/**
 * 個人戦のブランクのカード1枚（Final/Individual/PDFScoreMatch.php の DrawScore() を何も入れずに描く）
 */
function CustomFinalDrawBlankInd($pdf, $F, $L, $Side) {
	$ScoreWidth=$L->ScoreWidth;
	$NumRow=$F['Ends'];
	$NumCol=$F['Arrows'];
	$SO=$F['SO'];
	$ArrowW=round($L->ArrowTotW/$NumCol, 1);
	$TotalW=$L->TotalW;
	$GoldW=round($L->GoldW, 1);
	$H=$pdf->ScoreCellHeight;
	$X=$L->StartX[$Side];
	$Y=$L->StartY[$Side];

	// 選手・所属・部門・的番号（空欄）
	$pdf->SetDefaultColor();
	$pdf->SetLeftMargin($X);
	$pdf->SetY(35);
	$pdf->SetFont($pdf->FontStd, '', 10);
	$pdf->Cell(20, 6, (get_text('Athlete')) . ': ', 'TL', 0, 'L', 0);
	$pdf->Cell($ScoreWidth-20-$TotalW, 6, '', 'T', 1, 'L', 0);
	$pdf->Cell(20, 6, (get_text('Country')) . ': ', 'L', 0, 'L', 0);
	$pdf->Cell($ScoreWidth-20-$TotalW, 6, '', 0, 1, 'L', 0);
	$pdf->Cell(20, 6, (get_text('DivisionClass')) . ': ', 'LB', 0, 'L', 0);
	$pdf->Cell($ScoreWidth-20-2*$TotalW, 6, '', 'B', 0, 'L', 0);
	$pdf->SetFont($pdf->FontStd, 'B', 10);
	$pdf->Cell($TotalW, 6, (get_text('Target')) . ' ', '1', 1, 'C', 1);

	// 予選順位（空欄）
	$pdf->SetXY($ScoreWidth-$TotalW+$X, 35);
	$pdf->SetFont($pdf->FontStd, 'B', 10);
	$pdf->Cell($TotalW, 6, (get_text('Rank')), 'TLR', 1, 'C', 1);
	$pdf->SetXY($ScoreWidth-$TotalW+$X, $pdf->GetY());
	$pdf->Cell($TotalW, 12, '', 'BLR', 1, 'C', 1);

	// フェーズ（空欄）と勝者のチェック欄
	$pdf->SetFont($pdf->FontStd, 'B', 10);
	$pdf->SetXY($X, $Y);
	$pdf->Cell($GoldW, $H, '', 0, 0, 'C', 0);
	$pdf->Cell($ScoreWidth-$GoldW, $H, '', 1, 0, 'C', 1);
	$pdf->SetXY($X, $Y);
	$pdf->Cell($TotalW, $H, '', 0, 0, 'C', 0);
	$pdf->Rect($X+$GoldW+2, $Y+2, $H-4, $H-4, 'DF', array(), array(255, 255, 255));
	$pdf->SetDefaultColor();
	$pdf->Cell($GoldW+2*$TotalW+$NumCol*$ArrowW, $H, get_text('Winner'), 0, 1, 'L', 0);
	$Y=$pdf->GetY();

	// 射の番号、合計などの見出し
	CustomFinalDrawBlankHeadRow($pdf, $F, $X, $Y, $H, $GoldW, $ArrowW, $TotalW);
	$Y=$pdf->GetY();

	// エンドの行
	for($i=1; $i<=$NumRow; $i++) {
		CustomFinalDrawBlankEndRow($pdf, $F, $X, $Y, $H, $GoldW, $ArrowW, $TotalW, $i);
		$Y=$pdf->GetY();
	}

	// シュートオフ
	$SORows=($F['ElimType'] ? 1 : 3);
	$pdf->SetXY($X, $Y+($H/4));
	$pdf->SetFont($pdf->FontStd, 'B', 8);
	$pdf->Cell($GoldW, $H*($F['ElimType'] ? 11 : 23)/8, (get_text('TB')), 1, 0, 'C', 1);
	$ShootOffW=($SO<=$NumCol ? $ArrowW : ($ArrowW*$NumCol)/$SO);
	$StartX=$pdf->getX();
	for($i=0; $i<$SORows; $i++) {
		$pdf->SetX($StartX);
		for($j=0; $j<$SO; $j++) {
			$pdf->SetFont($pdf->FontStd, ($SO==1 ? 'B' : ''), 10);
			$pdf->Cell($ShootOffW, $H*3/4, '', 1, 0, 'C', 0);
		}
		if($SO>1) {
			$pdf->SetX($pdf->GetX()+2);
			$pdf->SetFont($pdf->FontStd, 'B', 10);
			$pdf->Cell($TotalW-2, $H*3/4, '', 1, 0, 'C', 0);
		}
		$pdf->ln();
	}

	// 合計
	CustomFinalDrawBlankTotalRow($pdf, $F, $StartX+$ArrowW*$NumCol, $Y, $H, $GoldW, $TotalW, false);
	$Y=$pdf->GetY();

	// 中心に近い矢
	$pdf->SetFont($pdf->FontStd, '', 9);
	$pdf->SetXY($X+$GoldW+$ShootOffW/2, $Y+$H*($F['ElimType'] ? 1 : 13)/8);
	$pdf->Cell($ShootOffW/2, $H/2, '', 1, 0, 'R', 0);
	$pdf->Cell($ArrowW*($NumCol-1), $H*2/4, get_text('Close2Center', 'Tournament'), 0, 0, 'L', 0);
	$Y=$pdf->GetY()+10;

	// 選手のサイン
	$pdf->SetXY($X, $Y);
	$pdf->SetFont($pdf->FontStd, 'i', 8);
	$pdf->Cell($ScoreWidth, 4, (get_text('ArcherSignature', 'Tournament')), 'B', 1, 'L', 0);
}

/**
 * 団体戦のブランクのカード1枚（Final/Team/PDFScoreMatch.php の DrawScore() を何も入れずに描く）
 */
function CustomFinalDrawBlankTeam($pdf, $F, $L, $Side) {
	$ScoreWidth=$L->ScoreWidth;
	$NumRow=$F['Ends'];
	$NumCol=$F['Arrows'];
	$SO=$F['SO'];
	$ArrowW=$L->ArrowTotW/$NumCol;
	$GoldW=$L->GoldW;
	$TotalW=$L->TotalW;
	$margins=$pdf->getMargins();
	$H=min(($pdf->GetPageHeight()-$margins['bottom']-100)/($NumRow+6), $pdf->ScoreCellHeight);
	$X=$L->StartX[$Side];
	$Y=$L->StartY[$Side];

	// チーム・部門・的番号（空欄）
	$pdf->SetDefaultColor();
	$pdf->SetLeftMargin($X);
	$pdf->SetY(35);
	$pdf->SetFont($pdf->FontStd, '', 10);
	$pdf->Cell(20, 6, (get_text('Team')) . ': ', 'LT', 0, 'L', 0);
	$pdf->Cell($ScoreWidth-20-2*$GoldW, 6, '', 'T', 1, 'L', 0);
	$pdf->Cell($ScoreWidth-$TotalW, 6, '', 'L', 1, 'L', 0);
	$pdf->Cell(20, 6, (get_text('DivisionClass')) . ': ', 'LB', 0, 'L', 0);
	$pdf->Cell($ScoreWidth-20-$TotalW-2*$GoldW, 6, '', 'B', 0, 'L', 0);
	$pdf->SetFont($pdf->FontStd, 'B', 10);
	$pdf->Cell($TotalW, 6, (get_text('Target')) . ' ', '1', 1, 'C', 1);

	// 予選順位（空欄）
	$pdf->SetXY($ScoreWidth-2*$GoldW+$X, 35);
	$pdf->SetFont($pdf->FontStd, 'B', 10);
	$pdf->Cell(2*$GoldW, 6, (get_text('Rank')), 'TLR', 1, 'C', 1);
	$pdf->SetXY($ScoreWidth-2*$GoldW+$X, $pdf->GetY());
	$pdf->Cell(2*$GoldW, 12, '', 'BLR', 1, 'C', 1);
	if($Y <= $pdf->getY()+5) {
		$Y=$pdf->getY()+5;
	}

	// フェーズ（空欄）と勝者のチェック欄
	$pdf->SetFont($pdf->FontStd, 'B', 10);
	$pdf->SetXY($X, $Y);
	$pdf->Cell($GoldW, $H, '', 0, 0, 'C', 0);
	$pdf->Cell($ScoreWidth-$GoldW, $H, '', 1, 0, 'C', 1);
	$pdf->SetXY($X, $Y);
	$pdf->Cell(2*$GoldW, $H, '', 0, 0, 'C', 0);
	$pdf->Rect($X+$GoldW+2, $Y+2, $H-4, $H-4, 'DF', array(), array(255, 255, 255));
	$pdf->SetDefaultColor();
	$pdf->Cell($GoldW+2*$TotalW+$NumCol*$ArrowW, $H, get_text('Winner'), 0, 1, 'L', 0);
	$Y=$pdf->GetY();

	// 射の番号、合計などの見出し
	CustomFinalDrawBlankHeadRow($pdf, $F, $X, $Y, $H, $GoldW, $ArrowW, $TotalW);
	$Y=$pdf->GetY();

	// エンドの行
	for($i=1; $i<=$NumRow; $i++) {
		CustomFinalDrawBlankEndRow($pdf, $F, $X, $Y, $H, $GoldW, $ArrowW, $TotalW, $i);
		$Y=$pdf->GetY();
	}

	// シュートオフ
	$pdf->SetXY($X, $Y+($H/4));
	$pdf->SetFont($pdf->FontStd, 'B', 8);
	$pdf->Cell($GoldW, $H*3.5+1, (get_text('TB')), 1, 0, 'C', 1);
	$ShootOffW=($SO<=$NumCol ? $ArrowW : ($ArrowW*$NumCol)/$SO);
	$ShootTotalW=min(20, ($SO<$NumCol ? min(20, $NumCol-$SO)*$ArrowW : $TotalW));
	$StartX=$pdf->getx();
	for($i=0; $i<3; $i++) {
		$pdf->SetX($StartX);
		for($j=0; $j<$SO; $j++) {
			$pdf->SetFont($pdf->FontStd, ($SO==1 ? 'B' : ''), 10);
			$pdf->Cell($ShootOffW, $H, '', 1, 0, 'C', 0);
		}
		if($SO>1) {
			$pdf->SetX($pdf->GetX()+2);
			$pdf->SetFont($pdf->FontStd, 'B', 10);
			$pdf->Cell($ShootTotalW, $H, '', 1, 0, 'C', 0);
		}
		$pdf->ln();
	}
	$SOY=$pdf->GetY();

	// 合計
	CustomFinalDrawBlankTotalRow($pdf, $F, $StartX+$ArrowW*$NumCol, $Y, $H, $GoldW, $TotalW, true);

	// 中心に近い矢
	$pdf->SetFont($pdf->FontStd, '', 9);
	$pdf->SetXY($X+$GoldW+($ShootOffW/2), $SOY + 1);
	$pdf->Cell($ShootOffW/2, $H/2, '', 1, 0, 'R', 0);
	$pdf->Cell($ArrowW*($NumCol-1), $H*2/4, get_text('Close2Center', 'Tournament'), 0, 0, 'L', 0);
	$Y=$pdf->GetY()+10;

	// 選手のサイン
	$pdf->SetXY($X, $Y);
	$pdf->SetFont($pdf->FontStd, 'I', 7);
	$pdf->Cell($ScoreWidth, 4, (get_text('ArcherSignature', 'Tournament')), 'B', 1, 'L', 0);
}

/**
 * 射の番号、エンドの合計、累計またはセットポイント、10・X の見出し（個人・団体で同じ）
 */
function CustomFinalDrawBlankHeadRow($pdf, $F, $X, $Y, $H, $GoldW, $ArrowW, $TotalW) {
	$pdf->SetXY($X, $Y);
	$pdf->Cell($GoldW, $H, '', 0, 0, 'C', 0);
	for($j=0; $j<$F['Arrows']; $j++) {
		$pdf->Cell($ArrowW, $H, ($j+1), 1, 0, 'C', 1);
	}
	$pdf->Cell($TotalW, $H, get_text(($F['MatchMode']==0 ? 'EndTotal' : 'SetTotal'), 'Tournament'), 1, 0, 'C', 1);
	if($F['MatchMode']==0) {
		$pdf->Cell($TotalW+2*$GoldW, $H, get_text('RunningTotal', 'Tournament'), 1, 0, 'C', 1);
	} else {
		$pdf->Cell(2*$GoldW, $H, get_text('SetPoints', 'Tournament'), 1, 0, 'C', 1);
		$pdf->Cell($TotalW, $H, get_text('TotalPoints', 'Tournament'), 1, 0, 'C', 1);
	}
	if($F['CheckGolds']) {
		$pdf->Cell($GoldW, $H, $F['Golds'], 1, 0, 'C', 1);
	}
	if($F['CheckXNines']) {
		$pdf->Cell($GoldW, $H, $F['XNine'], 1, 0, 'C', 1);
	}
	$pdf->ln();
}

/**
 * エンドの行（個人・団体で同じ）
 */
function CustomFinalDrawBlankEndRow($pdf, $F, $X, $Y, $H, $GoldW, $ArrowW, $TotalW, $End) {
	$pdf->SetFont($pdf->FontStd, 'B', 10);
	$pdf->SetXY($X, $Y);
	$pdf->Cell($GoldW, $H, $End, 1, 0, 'C', 1);
	$pdf->SetFont($pdf->FontStd, '', 10);
	for($j=0; $j<$F['Arrows']; $j++) {
		$pdf->Cell($ArrowW, $H, '', 1, 0, 'C', 0);
	}
	$pdf->Cell($TotalW, $H, '', 1, 0, 'C', 0);
	if($F['MatchMode']==0) {
		$pdf->Cell($TotalW+2*$GoldW, $H, '', 1, 0, 'C', 0);
	} else {
		$pdf->SetFont($pdf->FontStd, 'B', 11);
		$pdf->Cell($GoldW*2/3, $H, '2', 1, 0, 'C', 0);
		$pdf->Cell($GoldW*2/3, $H, '1', 1, 0, 'C', 0);
		$pdf->Cell($GoldW*2/3, $H, '0', 1, 0, 'C', 0);
		$pdf->Cell($TotalW, $H, '', 1, 0, 'C', 0);
	}
	if($F['CheckGolds']) {
		$pdf->Cell($GoldW, $H, '', 1, 0, 'C', 0);
	}
	if($F['CheckXNines']) {
		$pdf->Cell($GoldW, $H, '', 1, 0, 'C', 0);
	}
	$pdf->ln();
}

/**
 * 合計の行（個人と団体で、セット制のときの空きの幅だけが違う）
 */
function CustomFinalDrawBlankTotalRow($pdf, $F, $X, $Y, $H, $GoldW, $TotalW, $Team) {
	$pdf->SetXY($X, $Y);
	$pdf->SetFont($pdf->FontStd, 'B', 10);
	if($F['MatchMode']==0) {
		$pdf->Cell($TotalW, $H, get_text('Total'), 0, 0, 'R', 0);
		$pdf->Cell($TotalW+2*$GoldW, $H, '', 1, 0, 'C', 0);
	} elseif($Team) {
		$pdf->Cell($TotalW, $H, '', 0, 0, 'R', 0);
		$pdf->Cell(2*$GoldW, $H, get_text('Total'), 0, 0, 'R', 0);
		$pdf->Cell($TotalW, $H, '', 1, 0, 'C', 0);
	} else {
		$pdf->Cell(2*$GoldW, $H, '', 0, 0, 'R', 0);
		$pdf->Cell($TotalW, $H, get_text('Total'), 0, 0, 'R', 0);
		$pdf->Cell($TotalW, $H, '', 1, 0, 'C', 0);
	}
	if($F['CheckGolds']) {
		$pdf->Cell($GoldW, $H, '', 1, 0, 'C', 0);
	}
	if($F['CheckXNines']) {
		$pdf->Cell($GoldW, $H, '', 1, 0, 'C', 0);
	}
	$pdf->ln();
}
