<?php
/*
予選メニューに「スコアカード印刷（カスタム）」を追加する。
個人決勝・団体決勝のメニューには、標準の「スコアカードを印刷」のすぐ下に「スコアカードを印刷（カスタム）」を追加する。

変更履歴:
2026/10/13 個人決勝・団体決勝のメニューを追加
2026/09/23 初版
*/
if(!empty($on)) {
	$ret['QUAL'][] = MENU_DIVIDER;
	$ret['QUAL'][] = get_text('MenuLM_Scorecard Printout') . '（カスタム）' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/CustomPrintScore/PrintScore.php';

	// 標準の決勝のスコアカード印刷の項目を探して、そのすぐ下に入れる（標準の項目がないとき＝見られないときは入れない）
	foreach(array('FINI'=>array('Final/Individual/PrintScore.php', 0), 'FINT'=>array('Final/Team/PrintScore.php', 1)) as $Menu=>$Item) {
		if(empty($ret[$Menu]) or !is_array($ret[$Menu])) {
			continue;
		}
		foreach($ret[$Menu] as $k=>$v) {
			if(is_string($v) and strpos($v, '|' . $CFG->ROOT_DIR . $Item[0])!==false) {
				$Pos=array_search($k, array_keys($ret[$Menu]), true);
				array_splice($ret[$Menu], $Pos+1, 0, array(get_text('MenuLM_Scorecard Printout') . '（カスタム）' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/CustomPrintScore/FinalPrintScore.php?Team=' . $Item[1]));
				break;
			}
		}
	}
}
