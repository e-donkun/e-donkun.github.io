<?php
/*
Qualification/PrintScore.php のカスタム版（スコアカード印刷画面）。
「スコアカード印刷」ボタンの出力先を同じフォルダの PDFScore.php（カスタム版）に変更している。
それ以外の印刷（スコア集計用、ラベル、名前、スコア回収票）は標準の Qualification/ 以下を使う。

変更履歴:
2026/09/25 予備のブランクスコアカードに ISK-NG 設定用QRコードの印字を追加
2026/09/25 予備のブランクスコアカードの印刷を追加
2026/09/23 セッション「---」をすべてのセッションの印刷に変更、Intermediate results collecting paper を非表示
2026/09/23 標準スコアカード以外の書式、国旗・生年月日・バーコード、ラベル・名前印刷を非表示（初期Off）
2026/09/23 初版（Qualification/PrintScore.php をもとに作成）
*/
require_once(dirname(dirname(__FILE__)) . '/config.php');
require_once('Common/Lib/CommonLib.php');
require_once('Common/Fun_Sessions.inc.php');
require_once('Common/Fun_FormatText.inc.php');
require_once('Common/Fun_Modules.php');
CheckTourSession(true);
checkFullACL(AclQualification, '', AclReadOnly);

$RowTour=NULL;

$Select
	= "SELECT ToCategory, ToId,ToNumDist AS TtNumDist, ToCategory&12 as IsTeam3D "
	. "FROM Tournament  "
	. "WHERE ToId=" . StrSafe_DB($_SESSION['TourId']) . " ";

$RsTour=safe_r_sql($Select);
if (safe_num_rows($RsTour)==1){
	$RowTour=safe_fetch($RsTour);
	safe_free_result($RsTour);
}

$IncludeJquery = true;
$JS_SCRIPT=array(
	phpVars2js(array('MsgAreYouSure' => get_text('MsgAreYouSure'), "nDist"=> $RowTour->TtNumDist)),
	'<script type="text/javascript" src="'.$CFG->ROOT_DIR.'Common/ajax/ObjXMLHttpRequest.js"></script>',
	'<script type="text/javascript" src="'.$CFG->ROOT_DIR.'Common/js/Fun_JS.inc.js"></script>',
	'<script type="text/javascript" src="'.$CFG->ROOT_DIR.'Qualification/Fun_AJAX_index.js"></script>',
	'<script type="text/javascript" src="'.$CFG->ROOT_DIR.'Qualification/Fun_JS.js"></script>',
	'<script type="text/javascript">
        // 標準の SelectSession_JSON は相対パスのため、Qualification/ を明示して上書きする
        // 「---」（すべてのセッション）のときは、開始・終了を空にする（各セッションの全的を印刷）
        function SelectSession_JSON(obj) {
            if($(obj).val()==\'-1\') {
                $(\'#x_From\').val(\'\');
                $(\'#x_To\').val(\'\');
                $(\'#x_Coalesce_div\').html(\'\');
                return;
            }
            $.getJSON(\''.$CFG->ROOT_DIR.'Qualification/SelectSession.php?Ses=\'+$(obj).val(), function(data) {
                if (data.error==0) {
                    $(\'#x_From\').val(data.min);
                    $(\'#x_To\').val(data.max);
                    $(\'#x_Coalesce_div\').html(data.coalesce);
                }
            });
        }

        function optionField3d() {
            $(\'#ScoreCollectorDiv\').toggleClass(\'d-none\', $(\'#TourField3D\').is(\':checked\'));
            if($(\'#TourField3D\').is(\':checked\')) {
                $("#ScoreHeader").prop("checked", true);
                $("#ScoreLogos").prop("checked", true);
                $("#ScorePageHeaderFooter").prop("checked", false).prop("disabled", true);
            } else {
                $("#ScorePageHeaderFooter").prop("disabled", false)        
            }
        }
		function DisableChkOther(NoDist, NumDist) {
			if(NoDist) {
				if(document.getElementById(\'ChkDist0\').checked) {
					for(i=1; i<=NumDist; i++)
						document.getElementById(\'ChkDist\'+i).checked=false;
					document.getElementById(\'ScoreFilled\').checked=false;
					document.getElementById(\'ScoreFilled\').disabled=true;
				}
			} else {
				for(i=1; i<=NumDist; i++) {
					if(document.getElementById(\'ChkDist\'+i).checked)
						document.getElementById(\'ChkDist0\').checked=false;
					document.getElementById(\'ScoreFilled\').disabled=false;
				}
			}
		}
	
		function CheckAction() {
			var action="'.$CFG->ROOT_DIR.'Modules/Custom/CustomPrintScore/PDFScore.php";
			if(document.getElementById("BlankScore").value=="1") {
				// 予備のブランクスコアカードは他の印刷の設定にかかわらずカスタム版で出力する
				document.getElementById("PrnParameters").action=action;
				return true;
			}
			if(document.getElementById("ScoreCollector") && document.getElementById("ScoreCollector").checked) {
				action="'.$CFG->ROOT_DIR.'Qualification/PDFScoreCollect.php";
				if(document.getElementById("ScoreCollector6").checked) action="'.$CFG->ROOT_DIR.'Qualification/PDFScoreCollect.php?arr=6";
			}
			if(document.getElementById("ScoreLabels").checked) action="'.$CFG->ROOT_DIR.'Qualification/PrnLabels.php";
			if(document.getElementById("BigNames").checked) action="'.$CFG->ROOT_DIR.'Qualification/PDFBigNames.php";
			document.getElementById("PrnParameters").action=action;
			return true;
		}
		
		function manageDistances(doEnable) {
			for(i=1; i<=nDist; i++) {
				document.getElementById("ChkDist"+i).disabled = (!doEnable);
				if(!doEnable && document.getElementById("ChkDist"+i).checked) {
					document.getElementById("ChkDist"+i).checked = false;
				}
			}
			if(!doEnable) {
				document.getElementById("ChkDist0").checked = true;
			}
		}
        
        function fullScoreHeader(level) {
            switch(level) {
                case 0:
                    if($("#ScorePageHeaderFooter").is(":checked")) {
                        $("#ScoreHeader").prop("checked", false);
                        $("#ScoreLogos").prop("checked", false);
                    }
                    break;
                case 1:
                case 2:
                    if($("#ScoreHeader").is(":checked") || $("#ScoreLogos").is(":checked")) {
                        $("#ScorePageHeaderFooter").prop("checked", false);
                    }
                    break;
            }
        }
	</script>',
	'<style>#x_Coalesce_div {display:inline-block;margin-left:2em;vertical-align:middle;text-align: left;}#x_Coalesce_div div {font-size:0.8em}</style>'
	);

$PAGE_TITLE=get_text('PrintScore', 'Tournament').'（カスタム）';

include('Common/Templates/head.php');

echo '<form id="PrnParameters" onsubmit="return CheckAction();" action="" method="post" target="PrintOut">';
echo '<table class="Tabella">';
echo '<tr><th class="Title" colspan="2">' . get_text('PrintScore','Tournament')  . '（カスタム）</th></tr>';
echo '<tr><td colspan="2">1的5人・6人立ちのとき、ABC側のページにもQRコードを印字し、選手が1人もいないページ（ABC側・DEF側とも）は出力しません。<br>セッションで「---（すべてのセッション）」を選ぶと、全セッションの全的を印刷します。</td></tr>';
echo '<tr><th class="SubTitle" colspan="2">' . get_text('ScorePrintMode','Tournament')  . '</th></tr>';
//Parametri
echo '<tr>';
//Tipo di Score
echo '<td width="50%"><br>';
echo '<input name="ScoreDraw" type="radio" value="Complete" checked onClick="manageDistances(true);">&nbsp;' . get_text('ScoreComplete','Tournament') . '<br>';
// カスタム: 標準スコアカード以外の選択肢は初期状態Offで非表示
echo '<div style="display:none">';
echo '<input name="ScoreDraw" type="radio" value="CompleteTotals" onClick="manageDistances(true);">&nbsp;' . get_text('ScoreCompleteTotals','Tournament') . '<br>';
echo '<input name="ScoreDraw" type="radio" value="Data" onClick="manageDistances(true);">&nbsp;' . get_text('ScoreData','Tournament') . '<br>';
echo '<input name="ScoreDraw" type="radio" value="TargetNo" onClick="manageDistances(true);">&nbsp;' . get_text('ScoreTargetNo','Tournament') . '<br>';
echo '<input name="ScoreDraw" type="radio" value="Draw" onClick="manageDistances(true);">&nbsp;' . get_text('ScoreDrawing') . '<br>';
if($_SESSION['TourLocRule']=='NFAA') {
    echo '<input name="ScoreDraw" type="radio" value="FourScoresNFAA" onClick="manageDistances(true);">&nbsp;' . get_text('FourScoresNFAA', 'Tournament') . '<br>';
}
echo '<input name="ScoreDraw" type="radio" value="HorScore" onClick="manageDistances(true);">&nbsp;' . get_text('HorScore','Tournament') . '<br>';
if($_SESSION['TourLocRule']=='LANC') {
    echo '<input name="ScoreDraw" type="radio" value="HorScoreAllDist" onClick="manageDistances(true);">&nbsp;' . get_text('HorScoreAllDist', 'Tournament') . '<br>';
}
//echo '<input name="ScoreDraw" type="radio" value="VertScoreAllDist" onClick="manageDistances(true);">&nbsp;' . get_text('VertScoreAllDist','Tournament') . '<br>';
echo '<input name="TourField3D" id="TourField3D" type="checkbox" value="'.($RowTour->IsTeam3D==0 ? 'FIELD': ($RowTour->IsTeam3D==4 ? 'FIELD'  : '3D')).'" onclick="optionField3d()">&nbsp;'.get_text('FieldScorecard', 'Tournament').'<br/>';
echo '<div id="ScoreCollectorDiv">';
echo '<input name="ScoreCollector" id="ScoreCollector" type="checkbox" value="Collector">&nbsp;' . get_text('ScoreCollector', 'Tournament') ;
echo '<input name="ScoreCollectorArrows" id="ScoreCollector6" type="radio" value="6" checked="checked">6 - ';
echo '<input name="ScoreCollectorArrows" id="ScoreCollector3" type="radio" value="3">3<br>';
echo '</div>';
echo '</div>';
echo '</td>';
//Header e Immagini
echo '<td class="w-50"><br>';
echo '<input id="ScorePageHeaderFooter" name="ScorePageHeaderFooter" type="checkbox" value="1" checked onclick="fullScoreHeader(0)">&nbsp;' . get_text('ScorePageHeaderFooter','Tournament') . '<br>';
echo '<input id="ScoreHeader" name="ScoreHeader" type="checkbox" value="1" onclick="fullScoreHeader(1)">&nbsp;' . get_text('ScoreTournament','Tournament') . '<br>';
echo '<input id="ScoreLogos" name="ScoreLogos" type="checkbox" value="1" onclick="fullScoreHeader(2)">&nbsp;' . get_text('ScoreLogos','Tournament') . '<br>';
echo '<br>';
// カスタム: 国旗・生年月日/e-mail・バーコードは初期状態Offで非表示
echo '<div style="display:none">';
echo '<input name="ScoreFlags" type="checkbox" value="1">&nbsp;' . get_text('ScoreFlags','Tournament') . '<br>';
echo '<input name="GetArcInfo" type="checkbox" value="1" >&nbsp;' . get_text('GetArcInfo','Tournament') . '<br>';
if(module_exists("Barcodes")) {
	echo '<input name="ScoreBarcode" type="checkbox" value="1" >&nbsp;' . get_text('ScoreBarcode','Tournament') . '<br>';
}
echo '</div>';
if(getModuleParameter('ISK-NG', 'UsePersonalDevices', '')) {
	echo '<input name="ScoreQrPersonal" type="checkbox" checked value="1" >&nbsp;' . get_text('UsePersonalDevices-Print','Api') . '<br>';
}

foreach(AvailableApis() as $Api) {
	if(!($tmp=getModuleParameter($Api, 'Mode')) || strpos($tmp,'live') !== false) {
		continue;
	}
	echo '<input name="QRCode[]" type="checkbox" '.(strpos($tmp,'pro')!== false ? '' : 'checked="checked"').' value="'.$Api.'" >&nbsp;' . get_text($Api.'-QRCode','Api') . '<br>';
}
echo '&nbsp;<br>';
echo '<input name="PersonalScore" type="checkbox" value="1" >&nbsp;' . get_text('Score1PageAllDist','Tournament') . '<br>';
echo '</td>';
echo '</tr>';


$ComboSes='';
$TxtFrom='';
$TxtTo='';
$ComboDist='';
$ChkG='';
$ChkX='';
if($RowTour != NULL)
{
//Sessioni
	$sessions=GetSessions('Q');
	echo '<tr><th class="SubTitle" colspan="2">' . get_text('Session')  . '</th></tr>';
	echo '<tr>';
	echo '<td colspan="2" align="Center"><br>';
	echo '<input type="hidden" name="chk_BlockAutoSave" id="chk_BlockAutoSave" value="1">';
	echo get_text('Session') . '&nbsp;<select name="x_Session" id="x_Session" onChange="SelectSession_JSON(this)">';
	echo '<option value="-1">---（すべてのセッション）</option>';
	foreach ($sessions as $s)
	{
		echo '<option value="' . $s->SesOrder . '"' . (isset($_REQUEST['x_Session']) && $_REQUEST['x_Session']==$s->SesOrder ? ' selected' : '') . '>' . $s->Descr . '</option>';
	}
	echo '</select>';

	echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo  get_text('From','Tournament') . '&nbsp;<input type="text" name="x_From" id="x_From" size="5" maxlength="' . (TargetNoPadding +1) . '" value="' . (isset($_REQUEST['x_From']) ? $_REQUEST['x_From'] : '') . '">';
	echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo  get_text('To','Tournament') . '&nbsp;<input type="text" name="x_To" id="x_To" size="5" maxlength="' . (TargetNoPadding +1) . '" value="' . (isset($_REQUEST['x_To']) ? $_REQUEST['x_To'] : '') . '">';
	echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input id="x_noEmpty" name="noEmpty" type="checkbox" value="1">' . get_text('StartlistSessionNoEmpty', 'Tournament');
	echo '<div id="x_Coalesce_div"></div>';
// 		if($RowTour->ToCategory==8) {
// 			// 3D => 2 Arrows score!;
// 			echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
// 			echo '<input id="TwoArrows" name="TwoArrows" type="checkbox">2 ' . get_text('Arrows', 'Tournament');
// 		}
	echo '</td>';
	echo '</tr>';
//Distanze
	echo '<tr><th class="SubTitle" colspan="2">' . get_text('Distance','Tournament')  . '</th></tr>';
	echo '<tr>';
	echo '<td colspan="2" align="Center"><br>';
	echo '<input name="ScoreDist[]" type="checkbox" value="0" checked id="ChkDist0" onClick="javascript: DisableChkOther(true, ' . $RowTour->TtNumDist . ')">&nbsp;' . get_text('NoDistance','Tournament') . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	for($i=1; $i<=$RowTour->TtNumDist; $i++)
		echo '<input name="ScoreDist[]" type="checkbox" value="' . $i . '" id="ChkDist' . $i . '"  onClick="javascript: DisableChkOther(false, ' . $RowTour->TtNumDist . ')">&nbsp;' . $i . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '</td>';
	echo '</tr>';
	echo '<tr>';
	echo '<td colspan="2" align="Center">';
	echo '<input id="ScoreFilled" name="ScoreFilled" type="checkbox" value="1" disabled>' . get_text('ScoreFilled');
	echo '</td>';
	echo '</tr>';
}
// カスタム: Print Stickers / Print Names は初期状態Offで非表示
echo '<tr style="display:none">';
echo '<td colspan="2" align="Center">';
echo '<input type="checkbox" id="ScoreLabels" name="ScoreLabels">' . get_text('PrintLabels','Tournament') . '';
echo '&nbsp;&nbsp;<input type="checkbox" id="BigNames">' . get_text('PrintNames','Tournament') . '';
echo '</td>';
echo '</tr>';

echo '<tr>';
echo '<td colspan="2" align="Center"><br>';
echo '<input type="hidden" name="BlankScore" id="BlankScore" value="0">';
echo '<input type="submit" value="' . get_text('PrintScore','Tournament') . '" onclick="document.getElementById(\'BlankScore\').value=\'0\'"><br>&nbsp;';
echo '</td>';
echo '</tr>';
// カスタム: 予備のブランクスコアカード
echo '<tr><th class="SubTitle" colspan="2">予備のスコアカード（ブランク）</th></tr>';
echo '<tr><td colspan="2">ヘッダー（大会名）だけを印字し、セッション名・選手名・所属・的番号・クラス・距離・的ごとのQRコードは印字しません。<br>ISK-NG の設定用QRコード（QRcodesPDF.php と同じもの）は、チェックすると各ページに印字します。<br>1ページの枚数とエンド数・射数は、上で選んだセッション（「---」のときは最初のセッション）と距離（「距離なし」のときは第1距離）に合わせます。</td></tr>';
echo '<tr>';
echo '<td colspan="2" align="Center"><br>';
echo 'ページ数&nbsp;<input type="number" name="BlankPages" id="BlankPages" min="1" max="100" value="1" style="width:5em">';
echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
echo '<input name="BlankSetupQr" id="BlankSetupQr" type="checkbox" value="1" checked>&nbsp;ISK-NG 設定用QRコード';
echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
echo '<input type="submit" value="ブランクのスコアカードを印刷" onclick="document.getElementById(\'BlankScore\').value=\'1\'"><br>&nbsp;';
echo '</td>';
echo '</tr>';
echo '</table>';
echo '</form>';
print '<br/>';

//Bigliettini
print '<form name="frmTick" method="post" action="'.$CFG->ROOT_DIR.'Qualification/PrnGetScore.php" target="PrintOut">';
	print '<input type="hidden" name ="x_Session" id="xx_Session" value="">';
	print '<input type="hidden" name="x_From" id="xx_From" value="">';
	print '<input type="hidden" name="x_To" id="xx_To" value="">';
	print '<input type="hidden" name="noEmpty" id="xx_noEmpty" value="">';
	// カスタム: Intermediate results collecting paper は使わないので非表示
	print '<table class="Tabella" style="display:none">';
		echo '<tr><th class="SubTitle" colspan="2">' . get_text('TicketGetScore', 'Tournament')  . '</th></tr>';
		echo '<tr>';
			echo '<td colspan="2" align="Center"><br>';
				//echo '<a href="PrnGetScore.php" target="PrintOut" class="Link">' .  get_text('Print', 'Tournament') . '</a>&nbsp;';
				print '<input type="button" onclick="submitTicket();" value="' . get_text('Print', 'Tournament') .'">';
			echo '</td>';
		echo '</tr>';
	print '</table>';
print '</form>';


include('Common/Templates/tail.php');
