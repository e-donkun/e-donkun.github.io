<?php
/*
個人・団体決勝のスコアカード印刷（カスタム）の画面
予備のブランクスコアカード（1試合1枚の書式）を、書式とページ数を選んで印刷する。
ふつうのスコアカードは標準の Final/Individual/PrintScore.php・Final/Team/PrintScore.php で印刷する。

パラメーター:
  Team  0: 個人（個人決勝のメニュー）、1: 団体（団体決勝のメニュー）

変更履歴:
2026/10/13 初版
*/
require_once(dirname(dirname(__FILE__)) . '/config.php');
require_once(dirname(__FILE__) . '/CustomFinalScorecardsLib.php');
CheckTourSession(true);

$Team=(empty($_REQUEST['Team']) ? 0 : 1);
checkFullACL(($Team ? AclTeams : AclIndividuals), '', AclReadOnly);

$Formats=CustomFinalBlankFormats($Team);

$PAGE_TITLE=get_text(($Team ? 'MenuLM_Team Finals' : 'MenuLM_Individual Finals')).' '.get_text('MenuLM_Scorecard Printout').'（カスタム）';
include('Common/Templates/head.php');

echo '<form action="'.$CFG->ROOT_DIR.'Modules/Custom/CustomPrintScore/FinalPDFScore.php" method="get" target="PrintOut">';
echo '<input type="hidden" name="Team" value="'.$Team.'">';
echo '<table class="Tabella">';
echo '<tr><th class="Title">' . $PAGE_TITLE . '</th></tr>';
echo '<tr><th class="SubTitle">予備のスコアカード（ブランク）</th></tr>';
echo '<tr><td>1試合1枚のスコアカード（1ページに左右2枚）を、何も記入せずに印刷します。<br>'
	. 'ページのヘッダー（大会名）だけを印字し、フェーズ、' . ($Team ? 'チーム名' : '選手名・所属') . '、部門・クラス、的番号、予選順位は空欄です。<br>'
	. 'エンド数・射数・シュートオフ、セット制か累計か、10・X の欄は、選んだ書式（その書式を使う種目の設定）に合わせます。<br>'
	. 'ISK-NG の設定用QRコード（QRcodesPDF.php と同じもの）は、チェックすると各ページの右上に印字します。</td></tr>';

if(!$Formats) {
	echo '<tr><td class="Center"><br>決勝の種目がありません。<br>&nbsp;</td></tr>';
} else {
	echo '<tr><td><br>';
	$First=true;
	foreach($Formats as $F) {
		echo '<div class="mb-2"><label><input type="radio" name="Format" value="' . htmlspecialchars($F['Key']) . '"' . ($First ? ' checked' : '') . '>&nbsp;'
			. '<b>' . htmlspecialchars(implode(', ', $F['Events'])) . '</b>&nbsp;&nbsp;' . htmlspecialchars(CustomFinalBlankFormatText($F)) . '</label></div>';
		$First=false;
	}
	echo '<br></td></tr>';
	echo '<tr><td class="Center"><br>';
	echo 'ページ数&nbsp;<input type="number" name="Pages" min="1" max="100" value="1" style="width:5em">';
	echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<label><input name="SetupQr" type="checkbox" value="1" checked>&nbsp;ISK-NG 設定用QRコード</label>';
	echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
	echo '<input type="submit" value="ブランクのスコアカードを印刷"><br>&nbsp;';
	echo '</td></tr>';
}
echo '</table>';
echo '</form>';

include('Common/Templates/tail.php');
