<?php
/*
大会メニューに「既存の試合から新規作成」を追加する。試合を開いていてもいなくても表示する。
試合を新規作成できる権限（Common/Menu.php の「新規作成」と同じ条件）があるときだけ表示する。

変更履歴:
2026/09/25 初版
*/
if(isset($acl) and (subFeatureAcl($acl, AclRoot) == AclReadWrite or possibleFeature(AclRoot, AclReadWrite))) {
	$ret['COMP'][] = MENU_DIVIDER;
	$ret['COMP'][] = '既存の試合から新規作成' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/Duplicate/index.php';
}
