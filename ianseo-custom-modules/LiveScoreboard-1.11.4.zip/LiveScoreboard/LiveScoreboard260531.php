<?php
/*

変更履歴:
2026/05/31 セッション絞り込みをトグル複数選択に変更
2026/05/31 セッション絞り込みメニューを追加
2026/03/15 セッション名が表示されるように変更
2025/11/17 セッションを持っていない場合は表示させないように変更
2025/10/26

*/
	define('debug',false);
	define('IN_PHP', true);

	require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php

	require_once('Common/Fun_FormatText.inc.php');
	require_once('TV/Fun_HTML.local.inc.php');
    require_once('Common/Lib/CommonLib.php');
	require_once('Common/Lib/ArrTargets.inc.php');

	$TourCode=stripslashes($_REQUEST['Tour']);

	// セッション複数選択：s[] で受け取り、整数配列に正規化
	$GameSessions = [];
	if (!empty($_REQUEST['s'])) {
		$raw = $_REQUEST['s'];
		if (is_array($raw)) {
			foreach ($raw as $v) {
				$v = intval($v);
				if ($v > 0) $GameSessions[] = $v;
			}
		} else {
			$v = intval($raw);
			if ($v > 0) $GameSessions[] = $v;
		}
		$GameSessions = array_unique($GameSessions);
		sort($GameSessions);
	}

	if (empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		include('Common/Templates/head-min.php');
		echo "<a href='https://ianseo.net'>i@nseo.net</a>";
		include('Common/Templates/tail-min-min.php');
		die();
	}
	else if (!empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		$Select	= "SELECT ToId,ToCode,ToName,ToWhere 
			FROM Tournament WHERE ToId='".$_SESSION['TourId']."'";	
		$Rs=safe_r_sql($Select);
		$MyRow=safe_fetch($Rs);
		$TourCode = $MyRow->ToCode;
	}

	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
	$Order=stripslashes($_REQUEST['Order']);
	if($Order==""){
		$Order="Ranking";
	}
	
  if(! ($TourId > 0) ){
    include('Common/Templates/head-min.php');
    echo "error!";
    include('Common/Templates/tail-min-min.php');
    die();
  }

	// ----------------------------------------
	// セッション一覧を取得
	// ----------------------------------------
	$SelectSessions = "
		SELECT DISTINCT QuSession, SesName
		FROM Qualifications
		LEFT JOIN Entries ON EnId = QuId AND EnTournament = {$TourId} AND EnAthlete = 1
		LEFT JOIN Session ON SesTournament = {$TourId} AND SesOrder = QuSession AND SesType = 'Q'
		WHERE EnTournament = {$TourId}
		ORDER BY QuSession ASC
	";
	$RsSessions = safe_r_sql($SelectSessions);
	$SessionList = [];
	while ($SesRow = safe_fetch($RsSessions)) {
		$SessionList[] = [
			'QuSession' => intval($SesRow->QuSession),
			'SesName'   => $SesRow->SesName,
		];
	}

	// ----------------------------------------
	// セッションパラメータをURLクエリ文字列に変換するヘルパー
	// ----------------------------------------
	function buildSesParam($sessions) {
		if (empty($sessions)) return "";
		$parts = [];
		foreach ($sessions as $s) {
			$parts[] = "s[]=" . intval($s);
		}
		return "&" . implode("&", $parts);
	}

	// あるセッションをトグルした場合の選択リストを返す
	function toggleSession($current, $toggleId) {
		if (in_array($toggleId, $current)) {
			$next = array_values(array_filter($current, fn($v) => $v !== $toggleId));
		} else {
			$next = array_merge($current, [$toggleId]);
			sort($next);
		}
		return $next;
	}

	$tmpSel='';
	for ($i=1; $i<=2; $i++) {
		$tmpSel .= "QuD{$i}Score, QuD{$i}Hits, QuD{$i}Gold, QuD{$i}Xnine, QuD{$i}ArrowString, Td{$i}, DiEnds{$i}, DiArrows{$i}, ";
	}

	// WHERE句：複数セッション対応
	$tmpSession = "";	
	if (!empty($GameSessions)) {
		$inList = implode(",", $GameSessions);
		$tmpSession = "AND QuSession IN ({$inList}) ";
	}
		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,
			IF(CoName != '', CoName, CoCode) AS CountryName,
			QuTargetNo, QuTarget,QuLetter,
			$tmpSel
			QuScore, QuGold, QuXnine,
			ToId,ToGolds AS GoldLabel, ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
			DivDescription,ClDescription,DivViewOrder,ClViewOrder,
			ToName,ToWhere,ToWhenFrom,ToWhenTo,ToCode,QuSession,SesName,
			IF(QuClRank = 0,10000,QuClRank) as ClRank,
			ToOnlineId
		FROM 
       Tournament 
        LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType
        LEFT JOIN Entries ON EnTournament=ToId AND EnAthlete=1 AND CONCAT(EnDivision,EnClass) LIKE TdClasses
        LEFT JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament 
        LEFT JOIN Qualifications ON QuId=EnId
        LEFT JOIN (
            SELECT
                a.DiTournament
                , a.DiSession
                , a.DiEnds AS DiEnds1
                , a.DiArrows AS DiArrows1
                , b.DiEnds AS DiEnds2
                , b.DiArrows AS DiArrows2 
            FROM
                DistanceInformation a 
                JOIN DistanceInformation b 
                    ON a.DiTournament = b.DiTournament 
                    AND a.DiSession = b.DiSession
                    AND a.DiType = b.DiType 
            WHERE
                a.DiDistance = 1 AND b.DiDistance = 2
                AND a.DiType='Q' ) DistInfo
            ON DiTournament=ToId and DiSession=QuSession
        LEFT JOIN Divisions ON DivTournament=EnTournament AND DivId=EnDivision    
        LEFT JOIN Classes ON ClTournament=EnTournament AND ClId=EnClass
        LEFT JOIN Session ON SesTournament=EnTournament AND SesOrder=QuSession AND SesType='Q'
		WHERE ToId = {$TourId} $tmpSession
		";
	$Rs=safe_r_sql($Select);
	

	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}
  
	if($Order === "Target"){
		usort($ArrayData, function($a, $b) {
			return $a['QuSession'] <=> $b['QuSession']
				?: $a['QuTargetNo'] <=> $b['QuTargetNo'];
		});
	} else {
		usort($ArrayData, function($a, $b) {
			return $a['DivViewOrder'] <=> $b['DivViewOrder']
				?: $a['QuSession'] <=> $b['QuSession']
				?: $a['ClViewOrder'] <=> $b['ClViewOrder']
				?: $a['Class'] <=> $b['Class']
				?: $a['ClRank'] <=> $b['ClRank'];
		});
	}

  $Tour = $ArrayData[0];

	// 自動更新フラグ
	$mode_reload = "";
	if(stripslashes($_REQUEST['r'])=="1"){
		$mode_reload = "&r=1";
	}

	// 現在のセッションパラメータ文字列（リンク引き継ぎ用）
	$sesParam = buildSesParam($GameSessions);

	echo <<<EOM
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, user-scalable=yes">
<title>{$Tour['ToName']} - {$Tour['ToWhere']} ({$Tour['ToWhenFrom']}) </title>
<script type="text/javascript" src="//webfonts.sakura.ne.jp/js/sakurav3.js"></script>
<style>
html{
   font-size:clamp(6pt, 1.0vw, 14pt);
   font-family:"UD新ゴ R";
   margin:1vmin;
}

thead {
  top: 0;
  left: 0;	
}

h1,h2{
  margin-bottom:0;
}

table {
  border-collapse:collapse;
  border-spacing: 0;
}

table th,table td{
  text-align: center;
  white-space:nowrap;
  white-space-collapse: preserve;
}

table th{
  background-color: #c79852 !important;
  color: white;
  border:solid 1px black;
  height:1.3em;
}

table td{
  border:solid 1px black;
  padding: 0.3em 0.5em;
}

td.score {
  background:#eee;
  font-weight:bold;
	width:3rem;
	max-width:3rem;
	min-width:3rem;
}
td.goldx9 {
	width:2rem;
	max-width:2rem;
	min-width:2rem;
}
td.s{
  width:1.5em;
  background:#eee;
  margin:1px;
}

.r_class{
	width:3rem;
	max-width:3rem;
	min-width:3rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}
.r_name{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
	font-weight:bold;
}
.r_country{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}

.boldleft {
  border-left: 2px solid black !important;
}
.boldright {
  border-right: 2px solid black;
}
.doubleleft {
  border-left: 2px double black !important;
}

.highlight > th{
	background: #863 !important;
}
.highlight > td{
	background: #88663340 !important;
}

/* セッショントグルボタン */
.session-toggle-btn {
  display: inline-block;
  margin: 0 2px;
  padding: 1px 7px;
  border: 1px solid #999;
  border-radius: 4px;
  text-decoration: none;
  color: #333;
  background: #f5f5f5;
  font-size: inherit;
  cursor: pointer;
  user-select: none;
}
.session-toggle-btn:hover {
  background: #e8e8e8;
}
.session-toggle-btn.active {
  background: #c79852;
  border-color: #a07030;
  color: white;
  font-weight: bold;
}
.session-toggle-btn.all-btn.active {
  background: #555;
  border-color: #333;
}

@media print {
  .noprint {
    display: none !important;
  }
}
</style>
</head>
<body>
<h1>{$Tour['ToName']}</h1>
<div>{$TourCode}</div>
<div>会場:{$Tour['ToWhere']} (日程:{$Tour['ToWhenFrom']}
EOM;

  if($Tour['ToWhenFrom'] != $Tour['ToWhenTo']){
      echo "～{$Tour['ToWhenTo']}";
  }
  echo ")</div>"; 

  echo "<div class='noprint'>";

  // ---- 表示順メニュー ----
  if($Order === "Target" ){
     echo "[<a href='?Tour={$TourCode}&Order=Ranking{$sesParam}{$mode_reload}'>ランキング</a>][ターゲット順]";	  
  } else {
     echo "[ランキング][<a href='?Tour={$TourCode}&Order=Target{$sesParam}{$mode_reload}'>ターゲット順</a>]";
  }
  
  if($Tour['ToOnlineId']>0){
	echo "[<a href='https://www.ianseo.net/Details.php?toId={$Tour['ToOnlineId']}'>i@nseoへ</a>]";
  }

  echo "　　";

  // ---- 自動更新メニュー ----
  if(stripslashes($_REQUEST['r'])=="1"){
		echo <<<EOM
<span style='border:1px solid black' id='count'>30</span>
<script>
  cnt = -1;
  setInterval(() => {
	cnt = parseInt(document.getElementById('count').innerHTML);
	cnt--;
	document.getElementById('count').innerHTML = cnt;
	if(cnt==0){
		cnt=30;
		location.reload();
	}
  }, 1000);
</script>
EOM;
		echo "[<a href='?Tour={$TourCode}&Order={$Order}{$sesParam}'>更新停止</a>]";
	} else {
		echo "[<a href='?Tour={$TourCode}&Order={$Order}&r=1{$sesParam}'>自動更新</a>]";
	}

  echo "</div>"; // .noprint

  $preClass = "";
  $preSession = "";
  $preTarget = "";
  $flgHighlight = false;
	
	foreach($ArrayData as $Data){
		
		if(is_null($Data["EnId"])){
			continue;
		}
		
		if($preTarget != $Data['QuTarget']){
			$flgHighlight = !$flgHighlight;
		}
    
		if( ( $Order==="Target" && $preSession != $Data['QuSession'] ) || ( $Order!=="Target" && $preClass != $Data['Class'])){
		  if( $preSession != ""  || $preClass != "" ){
			echo "</table>\n";
			echo "</div>";
		  }
		  
		  if( $Order==="Target" ) {
				echo "<h2>".($Data['SesName'] ?: "セッション".$Data['QuSession'])."</h2>";  
		  } else {
				echo "<h2>{$Data['DivDescription']}{$Data['ClDescription']}</h2>";   
		  }
		  
		  echo <<<EOM
<div class='table_box'>
<table>
<tr>
EOM;
		  echo "<th rowspan=2 class='boldleft'>".($Order==="Target" ? "的番号" : "順位")."</th>";
		  echo <<<EOM
	<th rowspan=2 class="r_class">クラス</th>
	<th rowspan=2 class="r_name">選手名</th>
	<th rowspan=2 class="boldright r_country">所属</th>
  <th colspan=3 class="boldright">総合成績</th>
EOM;
		  echo "<th colspan=".(intval($Data['DiEnds1'])+1)." class='boldright'>{$Data['Td1']}</th>\n";    
		  echo "<th colspan=".(intval($Data['DiEnds2'])+1)." class='boldright'>{$Data['Td2']}</th>\n";   
		  echo <<<EOM
</tr>
<tr>
	<th class="boldleft">総合計</th>
	<th class="s">{$Data['GoldLabel']}</th>
	<th class="boldright s">{$Data['XNineLabel']}</th>
EOM;

		  foreach(range(1,$Data['DiEnds1']) as $i){
			echo "<th class='s'>{$i}</th>\n";
		  }
		  echo "<th class='doubleleft boldright'>合計</th>\n";
		  foreach(range(1,$Data['DiEnds2']) as $i){
			echo "<th class='sticky'>{$i}</th>\n";
		  }
		  echo "<th class='doubleleft boldright'>合計</th>\n";
		  echo "</tr>\n";
		}

		$preClass = $Data['Class'];
		$preSession = $Data["QuSession"];
		$preTarget = $Data["QuTarget"];
		
		$_RankText = $Order==="Target" ? str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT) : $Data['ClRank']; 
		if( intval($Data['ClRank'])>10000 ) {
			$_RankText = $Order==="Target" ? $_RankText : "欠";
			$Data['QuD1ArrowString'] = "";
			$Data['QuD2ArrowString'] = "";
			$Data['QuScore'] = "欠";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
			$Data['QuD1Score'] = "";
			$Data['QuD2Score'] = "";			
		} else if( intval($Data['ClRank'])==10000 ) {
			$_RankText = $Data['QuSession']."-".str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT);
			$Data['QuD1ArrowString'] = "";
			$Data['QuD2ArrowString'] = "";
			$Data['QuScore'] = "";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
			$Data['QuD1Score'] = "";
			$Data['QuD2Score'] = "";	
		}
    
		$ArrayD1Score = [];
		foreach(str_split(substr($Data['QuD1ArrowString'],0,$Data['QuD1Hits']), $Data['DiArrows1']) as $EndArrow){
			if($EndArrow!=="      "){
				$ArrayD1Score[] = ValutaArrowString($EndArrow);
			} else {
				$ArrayD1Score[] = "";
			}
		}
		$ArrayD2Score = [];
		foreach(str_split(substr($Data['QuD2ArrowString'],0,$Data['QuD2Hits']), $Data['DiArrows2']) as $EndArrow){
			if($EndArrow!=="      "){
				$ArrayD2Score[] = ValutaArrowString($EndArrow);
			} else {
				$ArrayD2Score[] = "";
			}
		}
    
		$D1Score = "";
		for($i=0;$i<$Data['DiEnds1'];$i++){
		  $D1Score .= "<td class='s'>".($ArrayD1Score[$i] ?? '')."</td>";
		}
		
		$D2Score = "";
		for($i=0;$i<$Data['DiEnds2'];$i++){
		  $D2Score .= "<td class='s'>".($ArrayD2Score[$i] ?? '')."</td>";
		}
		
		$_trclass = ($Order === "Target" && $flgHighlight) ? 'highlight' : '';
		
		echo <<<EOM
<tr class='target-{$Data['QuTarget']} {$_trclass}'>
	<th class="boldleft">{$_RankText}</th>
	<td class="r_class">{$Data['Class']}</td>
EOM;
	
		$_Name = "{$Data['EnFirstName']}  {$Data['EnName']}";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($_Name,14)."</td>";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($Data['CountryName'],14)."</td>";
		echo <<<EOM
  <td class='score sticky'>{$Data['QuScore']}</td>
	<td class='goldx9'>{$Data['QuGold']}</td>
	<td class='goldx9 boldright'>{$Data['QuXnine']}</td>
  {$D1Score}
	<td class='score doubleleft boldright'>{$Data['QuD1Score']}</td>
  {$D2Score}
	<td class='score doubleleft boldright'>{$Data['QuD2Score']}</td>
</tr>
EOM;

	}
	echo "</table></div>";

	// ---- セッション絞り込みトグルメニュー（テーブル下） ----
	if(count($SessionList) > 1){
		echo "<br>";
		echo "<div class='noprint'>";
		echo "セッション：";
		$allActive = empty($GameSessions) ? " active" : "";
		echo "<a class='session-toggle-btn all-btn{$allActive}' href='?Tour={$TourCode}&Order={$Order}{$mode_reload}'>全て</a>";
		foreach($SessionList as $Ses){
			$sesId    = $Ses['QuSession'];
			$sesLabel = (!empty($Ses['SesName'])) ? $Ses['SesName'] : "Session {$sesId}";
			$isActive = in_array($sesId, $GameSessions);
			$btnClass = $isActive ? " active" : "";
			$toggled      = toggleSession($GameSessions, $sesId);
			$toggledParam = buildSesParam($toggled);
			echo "<a class='session-toggle-btn{$btnClass}' href='?Tour={$TourCode}&Order={$Order}{$toggledParam}{$mode_reload}'>{$sesLabel}</a>";
		}
		echo "</div>";
	}
	
	include('Common/Templates/tail-min.php');



function shrinktext($_Text,$maxsize){
  $_cnt = mb_strwidth($_Text);
  if($_cnt==0) $_cnt = 1;
  
  if($_cnt<$maxsize){
    $_size = 1;
  } else {
    $_size = $maxsize/$_cnt;
  }
  
  return "<div style='transform-origin: 0 0;transform:scale({$_size},1);'>{$_Text}</div>";
}