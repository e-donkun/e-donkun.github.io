<?php
/*
決勝（個人・団体のマッチ戦）を、サイネージ向けに表示する画面。ianseo の「実況ビュー」（Modules/Speaker）と同じ内容を出す。

・1 つのスケジュール（同じ時刻に行う試合）の試合を、的番号の順に 1 行ずつ並べる。
  イベント | 的番号 | 選手・チーム（予選順位・所属またはメンバー） | ポイント | セットポイント（上下 2 段） | ポイント | 選手・チーム | 的番号
・勝った側は黄色にする。
・前回の読み込みから変わったマス（ポイント・セットポイントの各段・選手／チーム）は、3 秒点滅させたあと
  薄い黄色で MARK_TTL（2 分）残す。スケジュールを切り替えた直後と最初の読み込みでは目印をつけない。
・画面の縦に収まらないときは、Signage.php と同じく止まらずに下へスクロールし、終わりなく流す。収まるときはスクロールしない。
  表の見出し行は、画面の上端に残す。
・表は ?json=1 から読み込み直す（ページはリロードしない）。間隔は 10 秒。

右下の半透明のパネル:
  [予選]（Signage.php へ） ｜ ＜ スケジュール ＞ ｜ 文字 －＋ ｜ 速さ －＋ 一時停止 ｜ 次の読み込みまでの秒数
・スケジュールは ＜ ＞ で切り替える。選んだスケジュールは URL（sch）に書き戻す。
  何も選んでいなければ、ISK で進行中のスケジュール、なければ今の時刻までに始まった最後のスケジュール、なければ最初のスケジュール。
・画面（パネル以外）をタップ（クリック）すると、一時停止・再開を切り替える。一時停止中はパネルを濃く出す。
・文字・速さはこのブラウザに覚えておき、URL にも書き戻す。

パラメータ:
  Tour   大会コード（省略時はログイン中の大会）
  sch    スケジュール（個人は 0、団体は 1 のあとに「YYYY-MM-DD HH:MM」。例 sch=12026-10-11 13:25）
  speed  スクロールの速さ（px/秒、既定 40、0 で止める）
  zoom   文字の大きさの倍率（既定 1）

変更履歴:
2026/10/12 表の見出しを 1 行に収め、はみ出す分は … で省略する
2026/10/12 上の見出しを大会名にし、スケジュール（団体 2026-10-11 14:37 - …）はその下に標準の文字の大きさで出す
2026/10/12 更新があったマスを黄色で点滅させ、しばらく薄い黄色で残す（Signage.php と同じ）
2026/10/12 文字を大きくしても、セットポイントは省略せずに出す（列を中身に合わせて広げ、チームの列を狭めて省略する）
2026/10/12 選手名を、名前の並び設定によらず「姓 名」の順で出す
2026/10/12 セットポイントを左寄せにし、左右で同じ的なら的番号を 2A / 2B にする
2026/10/12 初版
*/
	require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php
	require_once('Common/Lib/Fun_Final.local.inc.php');
	require_once('Common/Lib/Fun_Phases.inc.php');
	require_once('Common/Lib/Fun_Modules.php');

	// 大会の決め方は LiveScoreboard.php と同じ（Tour がなければログイン中の大会）
	$TourId = 0;
	if (!empty($_REQUEST['Tour'])) {
		$TourId = intval(getIdFromCode(stripslashes($_REQUEST['Tour'])));
	}
	if (!($TourId > 0) && !empty($_SESSION['TourId'])) {
		$TourId = intval($_SESSION['TourId']);
	}

	// ---- 決勝のスケジュールの一覧（個人・団体）。[値 => 表示名]。値は 個人 0 / 団体 1 ＋「YYYY-MM-DD HH:MM」 ----
	function sf_schedules($TourId) {
		$list = [];
		$rs = safe_r_sql("SELECT DISTINCT FsTeamEvent,
				CONCAT(FsScheduledDate, ' ', DATE_FORMAT(FsScheduledTime, '%H:%i')) AS MyDate,
				EvFinalFirstPhase, GrPhase,
				GROUP_CONCAT(DISTINCT FsEvent ORDER BY FsEvent SEPARATOR ', ') AS Events
			FROM FinSchedule
			INNER JOIN Events ON FsEvent=EvCode AND FsTeamEvent=EvTeamEvent AND FsTournament=EvTournament
			INNER JOIN Grids ON FsMatchNo=GrMatchNo
			WHERE FsTournament=" . intval($TourId) . " AND FsScheduledDate>0 AND FsScheduledTime>0
			GROUP BY MyDate, FsTeamEvent, GrPhase
			ORDER BY MyDate, FsTeamEvent, GrPhase DESC");
		$tmp = [];
		while ($r = safe_fetch($rs)) {
			$k = $r->FsTeamEvent . $r->MyDate;
			if (!isset($tmp[$k])) $tmp[$k] = ['team' => $r->FsTeamEvent ? '団体' : '個人', 'date' => $r->MyDate, 'txt' => []];
			$tmp[$k]['txt'][] = get_text(namePhase($r->EvFinalFirstPhase, $r->GrPhase) . '_Phase') . ' ' . $r->Events;
		}
		foreach ($tmp as $k => $v) {
			$list[] = ['val' => $k, 'txt' => $v['team'] . ' ' . $v['date'] . ' - ' . implode(' + ', $v['txt'])];
		}
		return $list;
	}

	// 何も選んでいないときのスケジュール（ISK で進行中 → 今の時刻までに始まった最後 → 最初）
	function sf_default_schedule($list) {
		if (!$list) return '';
		if ($seq = getModuleParameter('ISK-NG', 'Sequence')) {
			if (!isset($seq['session'])) $seq = current($seq);
			if (!empty($seq['session'])) {
				foreach ($list as $s) {
					if (str_replace(' ', '', substr($s['val'], 1)) === substr(str_replace(' ', '', $seq['session']), 0, 15)) return $s['val'];
				}
			}
		}
		$now = date('Y-m-d H:i');
		$pick = '';
		foreach ($list as $s) {
			if (substr($s['val'], 1) <= $now) $pick = $s['val'];
		}
		return $pick !== '' ? $pick : $list[0]['val'];
	}

	// 試合（イベント・マッチ番号）の選手名を「姓 名」の配列で返す。個人は 1 人、団体はメンバー（TfcOrder 順）。
	// GetFinMatches_sql の名前は EnNameOrder（名前の並び）で 名 姓 になることがあるため、ここで組み直す。
	function sf_names($TourId, $team, $event, $matchNo) {
		$ev = StrSafe_DB($event);
		$mn = intval($matchNo);
		if ($team) {
			$rs = safe_r_sql("SELECT EnFirstName, EnName FROM TeamFinals
				INNER JOIN TeamFinComponent ON TfcTournament=TfTournament AND TfcEvent=TfEvent AND TfcCoId=TfTeam AND TfcSubTeam=TfSubTeam
				INNER JOIN Entries ON EnId=TfcId
				WHERE TfTournament={$TourId} AND TfEvent={$ev} AND TfMatchNo={$mn}
				ORDER BY TfcOrder, EnFirstName");
		} else {
			$rs = safe_r_sql("SELECT EnFirstName, EnName FROM Finals
				INNER JOIN Entries ON EnId=FinAthlete
				WHERE FinTournament={$TourId} AND FinEvent={$ev} AND FinMatchNo={$mn}");
		}
		$out = [];
		while ($rs && ($r = safe_fetch($rs))) $out[] = trim($r->EnFirstName . ' ' . $r->EnName);
		return $out;
	}

	// セットポイント（1|2|0|0 の形）を、後ろの 0 同士を落として空白区切りにする
	function sf_set_points($p1, $p2) {
		$a = explode('|', (string)$p1);
		$b = explode('|', (string)$p2);
		while (count($a) && count($a) == count($b) && intval(end($a)) == 0 && intval(end($b)) == 0) {
			array_pop($a);
			array_pop($b);
		}
		return [trim(implode(' ', $a)), trim(implode(' ', $b))];
	}

	// ---- ?json=1：スケジュールの一覧と、選んだスケジュールの試合を返す ----
	if (!empty($_GET['json'])) {
		header('Content-Type: application/json; charset=UTF-8');
		header('Cache-Control: no-store');
		$J = ['schedules' => [], 'current' => '', 'rows' => []];
		if ($TourId > 0) {
			$J['schedules'] = sf_schedules($TourId);
			$sch = isset($_GET['sch']) ? (string)$_GET['sch'] : '';
			$vals = array_column($J['schedules'], 'val');
			if (!in_array($sch, $vals, true)) $sch = sf_default_schedule($J['schedules']);
			$J['current'] = $sch;

			if ($sch !== '' && empty($_GET['list'])) {
				$team = intval(substr($sch, 0, 1));
				$when = substr($sch, 1) . ':00';
				$where = " AND fs1.FSTeamEvent=" . $team .
					" AND (CONCAT(fs1.FSScheduledDate,' ',fs1.FSScheduledTime)=" . StrSafe_DB($when) .
					" OR CONCAT(fs2.FSScheduledDate,' ',fs2.FSScheduledTime)=" . StrSafe_DB($when) . ")";
				$order = " CAST(fs1.FSTarget AS SIGNED) ASC, CAST(fs2.FSTarget AS SIGNED) ASC";

				// GetFinMatches_sql はセッションの大会を見るので、読む間だけ差し替える
				$OrigTourId = $_SESSION['TourId'] ?? null;
				$_SESSION['TourId'] = $TourId;
				$rs = GetFinMatches_sql($where, $team, $order, false);
				if ($OrigTourId === null) unset($_SESSION['TourId']); else $_SESSION['TourId'] = $OrigTourId;

				while ($rs && ($r = safe_fetch($rs))) {
					$t1 = ltrim((string)$r->target1, '0');
					$t2 = ltrim((string)$r->target2, '0');
					if ($t1 === '' && $t2 === '') continue;
					// 上下で同じ的なら、左を A、右を B にする（2A / 2B）
					if ($t1 !== '' && $t1 === $t2) {
						$t1 .= 'A';
						$t2 .= 'B';
					}
					$mm = intval($r->matchMode) == 1;
					$s1 = $mm ? $r->setScore1 : $r->score1;
					$s2 = $mm ? $r->setScore2 : $r->score2;
					$bye1 = intval($r->tie1) == 2;
					$bye2 = intval($r->tie2) == 2;
					if ($bye1 || $bye2) {
						$sp1 = $bye1 ? 'Bye' : '';
						$sp2 = $bye2 ? 'Bye' : '';
					} elseif ($mm) {
						list($sp1, $sp2) = sf_set_points($r->setPoints1, $r->setPoints2);
					} else {
						// 合計点制：エンドごとの合計を並べる
						$obj = getEventArrowsParams($r->event, $r->phase, $team, $TourId);
						$sp1 = $sp2 = '';
						foreach ([1, 2] as $i) {
							$as = (string)$r->{'arrowString' . $i};
							$tmp = [];
							for ($c = 0; $c < strlen($as); $c += max(1, $obj->arrows)) $tmp[] = ValutaArrowString(substr($as, $c, $obj->arrows));
							${'sp' . $i} = implode(' ', $tmp);
						}
					}
					// シュートオフの矢
					foreach ([1, 2] as $i) {
						$tb = trim((string)$r->{'tiebreak' . $i});
						if ($tb !== '') {
							$tmp = [];
							for ($c = 0; $c < strlen($tb); $c++) $tmp[] = DecodeFromLetter($tb[$c]);
							if (!empty($r->{'tieclosest' . $i})) $tmp[] = '+';
							${'sp' . $i} .= ' (SO ' . implode(' ', $tmp) . ')';
						}
					}
					$started = ($s1 != 0 || $s2 != 0 || trim((string)$r->arrowString1) !== '' || trim((string)$r->arrowString2) !== '');
					// 名前は「姓 名」の順にする（個人は選手名、団体はメンバー）
					$n1 = (string)$r->name1; $m1 = (string)$r->countryName1;
					$n2 = (string)$r->name2; $m2 = (string)$r->countryName2;
					foreach ([1, 2] as $i) {
						$nm = sf_names($TourId, $team, $r->event, $r->{'match' . $i});
						if ($team) {
							if ($nm) ${'m' . $i} = implode(', ', $nm);
						} elseif ($nm) {
							${'n' . $i} = $nm[0];
						}
					}
					$J['rows'][] = [
						'k' => $r->event . '-' . $r->match1,
						'ev' => $r->eventName,
						'ph' => get_text(namePhase($r->firstPhase, $r->phase) . '_Phase'),
						't1' => $t1, 't2' => $t2,
						'n1' => $n1, 'rk1' => intval($r->rank1), 'm1' => $m1,
						'n2' => $n2, 'rk2' => intval($r->rank2), 'm2' => $m2,
						's1' => $started ? (string)$s1 : '', 's2' => $started ? (string)$s2 : '',
						'sp1' => $sp1, 'sp2' => $sp2,
						'w1' => intval($r->win1) == 1 && !$bye2, 'w2' => intval($r->win2) == 1 && !$bye1,
					];
				}
			}
		}
		echo json_encode($J, JSON_UNESCAPED_UNICODE);
		exit;
	}

	$TourCode = '';
	$TourName = '';
	if ($TourId > 0) {
		$rs = safe_r_sql("SELECT ToCode, ToName FROM Tournament WHERE ToId={$TourId}");
		if ($r = safe_fetch($rs)) {
			$TourCode = $r->ToCode;
			$TourName = $r->ToName;
		}
	}
?><!DOCTYPE html>
<html lang="ja" class="notranslate" translate="no">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google" content="notranslate">
<title><?php echo htmlspecialchars(($TourName !== '' ? $TourName . ' ' : '') . '決勝', ENT_QUOTES); ?></title>
<style>
html{
  --zoom:1;
  font-size:calc(clamp(10px, 1.1vw, 40px) * var(--zoom));
  font-family:sans-serif;
}
html, body{ margin:0; padding:0; height:100%; overflow:hidden; background:#fff; }
body.idle{ cursor:none; }
table{ width:100%; border-collapse:collapse; table-layout:fixed; }
th, td{ border:1px solid #000; padding:0.25em 0.4em; vertical-align:middle; }
th{ background:#007db3; color:#fff; font-weight:bold; text-align:center; }
/* 見出しはセットポイントの点数と同じ大きさで 1 行に収め、はみ出す分は … で省略する */
#headTable th{ font-size:1em; padding:0.15em 0.3em; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
#head{ position:fixed; top:0; left:0; right:0; z-index:5; background:#fff; padding:0 0.5vw; }
#head .title{ font-size:1.2rem; font-weight:bold; padding:0.2em 0 0; }
#head .sch{ padding:0.1em 0 0.2em; }
#viewport{ position:absolute; left:0; right:0; bottom:0; overflow:hidden; padding:0 0.5vw; }
#track{ will-change:transform; }
td.ev, td.tg, td.pt{ text-align:center; }
td.ev{ font-size:0.9em; }
td.ev .ph{ display:block; color:#555; font-size:0.85em; }
td.tg{ font-weight:bold; }
/* チームの列は 1 行に収め、はみ出す分は … で省略する（セットポイントの列を優先する） */
td.tm{ overflow:hidden; }
td.tm .l1, td.tm .mem{ white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
td.tm .nm{ font-weight:bold; font-size:1.15em; }
td.tm .rk{ color:#555; font-weight:normal; font-size:0.85em; margin-left:0.3em; }
td.tm .mem{ display:block; font-size:0.85em; color:#333; }
td.pt{ font-weight:bold; font-size:1.6em; background:#eee; }
td.sp{ text-align:left; padding:0; }
td.sp div{ padding:0.15em 0.3em; white-space:nowrap; overflow:hidden; }
td.sp div + div{ border-top:1px solid #999; }
.win, td.pt.win{ background:#fff59d; }

/* ---- 更新があったところの目印（Signage.php と同じ点滅） ---- */
@keyframes chgFlash {
  0%, 16%, 33%   { background-color:#ffe600; }
  8%, 25%, 42%   { background-color:#fff9c4; }
  100%           { background-color:#fff9c4; }
}
@keyframes chgFlashWin {
  0%, 16%, 33%   { background-color:#ffe600; }
  8%, 25%, 42%   { background-color:#fff9c4; }
  100%           { background-color:#fff59d; }
}
/* 今回の更新で変わったマス：点滅したあと薄い黄色のまま残す（勝った側は勝ちの黄色に戻す） */
td.chg, td.sp div.chg{ animation:chgFlash 3s ease-out forwards; }
td.win.chg{ animation-name:chgFlashWin; }
/* 前回までに変わって、まだ MARK_TTL がたっていないマス */
td.chg-keep:not(.win), td.sp div.chg-keep{ background-color:#fff9c4; }
#message{ position:fixed; inset:0; display:flex; align-items:center; justify-content:center; font-size:1.5rem; color:#555; }
#message[hidden]{ display:none; }

/* ---- 右下の半透明パネル（Signage.php と同じ見た目） ---- */
#panel{
  position:fixed; right:0.8em; bottom:0.8em; z-index:10;
  display:flex; align-items:center; gap:0.8em; padding:0.35em 0.6em; border-radius:2em;
  background:rgba(0,0,0,0.55); color:#fff; flex-wrap:wrap; justify-content:flex-end; row-gap:0.4em;
  max-width:calc(100vw - 1.6em); box-sizing:border-box;
  font-size:clamp(12px, 0.9vw, 28px); font-family:sans-serif;
  opacity:0.1; transition:opacity 0.3s; user-select:none;
  -webkit-backdrop-filter:blur(3px); backdrop-filter:blur(3px);
}
#panel:hover, #panel.paused{ opacity:1; }
#panel [hidden]{ display:none !important; }
#panel .ctrl{ display:flex; flex-wrap:wrap; align-items:center; gap:0.3em; }
#panel > .ctrl:not([hidden]) ~ .ctrl:not([hidden]){ border-left:1px solid rgba(255,255,255,0.35); padding-left:0.8em; }
#panel .label{ margin-right:0.1em; }
#panel .value{ display:inline-block; min-width:3.2em; text-align:center; font-variant-numeric:tabular-nums; }
#panel #schLabel{ min-width:6em; max-width:40vw; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
#panel button, #panel a.tgl{
  width:1.8em; height:1.8em; padding:0; border:1px solid rgba(255,255,255,0.6); border-radius:50%;
  background:rgba(255,255,255,0.15); color:#fff; font-size:1em; line-height:1; cursor:pointer;
}
#panel button:hover, #panel a.tgl:hover{ background:rgba(255,255,255,0.35); }
#panel button:disabled{ opacity:0.3; cursor:default; }
#panel button.tgl, #panel a.tgl{
  width:auto; min-width:1.8em; padding:0 0.7em; border-radius:1em; white-space:nowrap;
  display:inline-flex; align-items:center; text-decoration:none; box-sizing:border-box;
}
#status{ display:inline-block !important; padding:0.1em 0.5em; border-radius:1em; white-space:nowrap; cursor:pointer; }
#status:hover{ background:rgba(255,255,255,0.25); }
#statusText{ display:inline-block; min-width:1.6em; text-align:right; font-variant-numeric:tabular-nums; }
#status .dot{ display:inline-block; width:0.6em; height:0.6em; margin-right:0.4em; border-radius:50%; background:#4caf50; vertical-align:middle; }
#status.error .dot{ background:#f44336; }
</style>
</head>
<body>
<div id="head"><div class="title"><?php echo htmlspecialchars($TourName, ENT_QUOTES); ?></div><div class="sch" id="title"></div><table id="headTable"></table></div>
<div id="viewport"><div id="track"></div></div>
<div id="message">読み込み中…</div>
<div id="panel">
  <div class="ctrl"><a class="tgl" id="qualLink" href="#">予選</a></div>
  <div class="ctrl" title="スケジュールの切り替え">
    <button type="button" id="schPrev" aria-label="前のスケジュール">＜</button>
    <span class="value" id="schLabel">…</span>
    <button type="button" id="schNext" aria-label="次のスケジュール">＞</button>
  </div>
  <div class="ctrl" title="文字の大きさ">
    <span class="label">文字</span>
    <button type="button" id="zoomDown" aria-label="文字を小さく">－</button>
    <span class="value" id="zoomValue">100%</span>
    <button type="button" id="zoomUp" aria-label="文字を大きく">＋</button>
  </div>
  <div class="ctrl" title="スクロールの速さ（0 で止まる）">
    <span class="label">速さ</span>
    <button type="button" id="speedDown" aria-label="遅く">－</button>
    <span class="value" id="speedValue">40</span>
    <button type="button" id="speedUp" aria-label="速く">＋</button>
    <button type="button" class="tgl" id="pauseBtn">⏸ 一時停止</button>
  </div>
  <div class="ctrl" id="status" title="クリックで今すぐ読み込み直す"><span class="dot"></span><span id="statusText">…</span></div>
</div>
<script>
(() => {
  'use strict';
  const TOUR = <?php echo json_encode($TourCode, JSON_UNESCAPED_UNICODE); ?>;
  const params = new URLSearchParams(location.search);
  const STORE_KEY = 'LiveScoreboardSignageFinal';
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(STORE_KEY)) || {}; } catch (e) { saved = {}; }
  const pick = (key, def, min, max) => {
    const v = params.has(key) ? parseFloat(params.get(key)) : parseFloat(saved[key]);
    return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : def;
  };
  const SPEED_MIN = 0, SPEED_MAX = 600, SPEED_STEP = 20, ZOOM_MIN = 0.3, ZOOM_MAX = 5, ZOOM_STEP = 1.1;
  let speed = pick('speed', 40, SPEED_MIN, SPEED_MAX);
  let zoom = pick('zoom', 1, ZOOM_MIN, ZOOM_MAX);
  const INTERVAL = 10 * 1000;
  let sch = params.get('sch') || '';
  let schedules = [];
  let paused = false;
  let lastJson = '';
  // 更新の目印。marks: 試合のキー → (項目 → 変わった時刻)。fresh: 今回の読み込みで変わったもの
  const MARK_TTL = 2 * 60 * 1000;
  const MARK_FIELDS = ['n1', 'm1', 's1', 'sp1', 'sp2', 's2', 'n2', 'm2'];
  let marks = new Map(), fresh = new Set(), prevRows = null, prevSch = null, curRows = [];

  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const panel = $('panel'), track = $('track'), viewport = $('viewport'), head = $('head');

  $('qualLink').href = 'Signage.php' + (TOUR ? '?Tour=' + encodeURIComponent(TOUR) : '');

  // 列の幅（見出しの表と本体の表で同じにする）
  // チームの列は幅を決めず、残りを左右で分ける。セットポイントの列は fitCols() で中身に合わせる
  const SP_MIN = 0.12; // セットポイントの列の最小幅（表の幅に対する割合）
  const COLS = '<colgroup><col style="width:9%"><col style="width:5%"><col><col style="width:6%"><col class="c-sp" style="width:12%"><col style="width:6%"><col><col style="width:5%"></colgroup>';
  // 見出し：団体のスケジュールは「チーム」、個人は「選手」
  function setHead(team) {
    const who = team ? 'チーム' : '選手';
    $('headTable').innerHTML = COLS + '<tr><th>イベント</th><th>的番号</th><th>' + who + '</th><th>ポイント</th><th>セットポイント</th><th>ポイント</th><th>' + who + '</th><th>的番号</th></tr>';
    fitCols();
  }
  setHead(true);

  // 目印のクラス（項目のどれかが今回変わっていれば点滅、前に変わっていれば薄い黄色）
  function mk(k, ...fields) {
    const m = marks.get(k);
    if (!m) return '';
    if (fields.some(f => fresh.has(k + '\t' + f))) return ' chg';
    return fields.some(f => m.has(f)) ? ' chg-keep' : '';
  }

  function teamCell(n, rk, m, win, cls) {
    return '<td class="tm' + (win ? ' win' : '') + (cls || '') + '">' +
      '<div class="l1"><span class="nm">' + esc(n) + '</span>' + (n && rk ? '<span class="rk">(#' + rk + ')</span>' : '') + '</div>' +
      (m ? '<span class="mem">' + esc(m) + '</span>' : '') + '</td>';
  }

  function rowHtml(r) {
    return '<tr>' +
      '<td class="ev">' + esc(r.ev) + '<span class="ph">' + esc(r.ph) + '</span></td>' +
      '<td class="tg">' + esc(r.t1) + '</td>' +
      teamCell(r.n1, r.rk1, r.m1, r.w1, mk(r.k, 'n1', 'm1')) +
      '<td class="pt' + (r.w1 ? ' win' : '') + mk(r.k, 's1') + '">' + esc(r.s1) + '</td>' +
      '<td class="sp"><div class="' + mk(r.k, 'sp1') + '">' + (esc(r.sp1) || '&nbsp;') + '</div><div class="' + mk(r.k, 'sp2') + '">' + (esc(r.sp2) || '&nbsp;') + '</div></td>' +
      '<td class="pt' + (r.w2 ? ' win' : '') + mk(r.k, 's2') + '">' + esc(r.s2) + '</td>' +
      teamCell(r.n2, r.rk2, r.m2, r.w2, mk(r.k, 'n2', 'm2')) +
      '<td class="tg">' + esc(r.t2) + '</td>' +
      '</tr>';
  }

  // ---------------- 描画とスクロール ----------------
  // セットポイントの列を、いちばん長いセットポイントが省略されない幅にする（最小は表の幅の SP_MIN、最大は半分）
  function fitCols() {
    const tableW = $('headTable').clientWidth;
    if (!tableW) return;
    let need = 0;
    const body = track.firstElementChild;
    if (body) body.querySelectorAll('td.sp div').forEach(d => { need = Math.max(need, d.scrollWidth); });
    const w = Math.min(tableW * 0.5, Math.max(tableW * SP_MIN, need + 2));
    document.querySelectorAll('col.c-sp').forEach(c => { c.style.width = w + 'px'; });
  }

  let pos = 0, loopH = 0, scrolling = false;
  function layout() {
    fitCols();
    viewport.style.top = head.offsetHeight + 'px';
    const body = track.firstElementChild;
    const h = body ? body.offsetHeight : 0;
    // 収まらないときだけ、同じ表をもう 1 つ続けて、終わりなく流す
    const need = h > viewport.clientHeight;
    if (need && track.children.length < 2 && body) track.appendChild(body.cloneNode(true));
    if (!need) while (track.children.length > 1) track.lastElementChild.remove();
    scrolling = need;
    loopH = need ? h + parseFloat(getComputedStyle(body).marginBottom || 0) : 0;
    if (!need) { pos = 0; track.style.transform = ''; }
  }

  // 前回の表と比べて目印をつける。最初の読み込みとスケジュールを切り替えた直後はつけない
  function diffRows(rows) {
    const now = Date.now();
    fresh = new Set();
    if (prevRows && prevSch === sch) {
      const old = new Map(prevRows.map(r => [r.k, r]));
      rows.forEach(r => {
        const o = old.get(r.k);
        MARK_FIELDS.forEach(f => {
          if (o && String(o[f] ?? '') === String(r[f] ?? '')) return;
          if (!o && !String(r[f] ?? '')) return;
          if (!marks.has(r.k)) marks.set(r.k, new Map());
          marks.get(r.k).set(f, now);
          fresh.add(r.k + '\t' + f);
        });
      });
    } else {
      marks = new Map();
    }
    prevRows = rows; prevSch = sch;
  }
  // MARK_TTL をすぎた目印を消す。消えたものがあれば true
  function pruneMarks() {
    const now = Date.now();
    let removed = false;
    marks.forEach((m, k) => {
      m.forEach((t, f) => { if (now - t >= MARK_TTL) { m.delete(f); removed = true; } });
      if (!m.size) marks.delete(k);
    });
    return removed;
  }

  function render(rows) {
    curRows = rows;
    const html = '<table style="margin-bottom:2em">' + COLS + rows.map(rowHtml).join('') + '</table>';
    track.innerHTML = html;
    $('message').hidden = rows.length > 0;
    if (!rows.length) $('message').textContent = schedules.length ? 'この時間の試合はありません' : '決勝のスケジュールがありません';
    layout();
  }

  let lastT = null;
  function frame(t) {
    if (lastT !== null && scrolling && !paused) {
      pos += speed * (t - lastT) / 1000;
      if (loopH > 0) pos %= loopH;
      track.style.transform = 'translateY(' + (-pos) + 'px)';
    }
    lastT = t;
    requestAnimationFrame(frame);
  }

  // ---------------- 読み込み ----------------
  let nextAt = 0;
  async function load() {
    nextAt = Date.now() + INTERVAL;
    try {
      const q = new URLSearchParams({ json: '1' });
      if (TOUR) q.set('Tour', TOUR);
      if (sch) q.set('sch', sch);
      const res = await fetch(location.pathname + '?' + q.toString(), { cache: 'no-store', credentials: 'same-origin' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const j = await res.json();
      schedules = j.schedules || [];
      sch = j.current || '';
      updateSchedule();
      const sig = JSON.stringify(j.rows || []);
      const pruned = pruneMarks();
      if (sig !== lastJson) {
        lastJson = sig;
        diffRows(j.rows || []);
        render(j.rows || []);
      } else if (pruned) {
        // 目印が消えただけのときは、点滅させずに描き直す
        fresh = new Set();
        render(curRows);
      }
      $('status').classList.remove('error');
    } catch (e) {
      $('status').classList.add('error');
    }
  }
  function refreshNow() { lastJson = ''; load(); }
  setInterval(() => {
    const s = Math.max(0, Math.ceil((nextAt - Date.now()) / 1000));
    $('statusText').textContent = s;
    if (Date.now() >= nextAt) load();
  }, 250);

  // ---------------- パネル ----------------
  function updateSchedule() {
    const i = schedules.findIndex(s => s.val === sch);
    const cur = schedules[i];
    $('schLabel').textContent = cur ? cur.txt : 'スケジュールなし';
    $('schLabel').title = cur ? cur.txt : '';
    $('title').textContent = cur ? cur.txt : '決勝';
    setHead(!cur || cur.val.charAt(0) === '1');
    $('schPrev').disabled = i <= 0;
    $('schNext').disabled = i < 0 || i >= schedules.length - 1;
    saveSettings();
  }
  function moveSchedule(d) {
    const i = schedules.findIndex(s => s.val === sch);
    const n = schedules[i + d];
    if (!n) return;
    sch = n.val; pos = 0; refreshNow();
  }
  function saveSettings() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify({ speed, zoom })); } catch (e) {}
    try {
      const url = new URL(location.href);
      url.searchParams.set('speed', String(speed));
      url.searchParams.set('zoom', String(Math.round(zoom * 1000) / 1000));
      if (sch) url.searchParams.set('sch', sch); else url.searchParams.delete('sch');
      history.replaceState(null, '', url);
    } catch (e) {}
  }
  function updatePanel() {
    $('zoomValue').textContent = Math.round(zoom * 100) + '%';
    $('speedValue').textContent = speed;
    $('zoomDown').disabled = zoom <= ZOOM_MIN; $('zoomUp').disabled = zoom >= ZOOM_MAX;
    $('speedDown').disabled = speed <= SPEED_MIN; $('speedUp').disabled = speed >= SPEED_MAX;
  }
  function setZoom(z) {
    zoom = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, z));
    document.documentElement.style.setProperty('--zoom', zoom);
    layout(); updatePanel(); saveSettings();
  }
  function setPaused(p) {
    paused = p;
    $('pauseBtn').textContent = paused ? '▶ 再開' : '⏸ 一時停止';
    panel.classList.toggle('paused', paused);
  }
  $('schPrev').addEventListener('click', () => moveSchedule(-1));
  $('schNext').addEventListener('click', () => moveSchedule(1));
  $('zoomUp').addEventListener('click', () => setZoom(zoom * ZOOM_STEP));
  $('zoomDown').addEventListener('click', () => setZoom(zoom / ZOOM_STEP));
  $('speedUp').addEventListener('click', () => { speed = Math.min(SPEED_MAX, speed + SPEED_STEP); updatePanel(); saveSettings(); });
  $('speedDown').addEventListener('click', () => { speed = Math.max(SPEED_MIN, speed - SPEED_STEP); updatePanel(); saveSettings(); });
  $('pauseBtn').addEventListener('click', () => setPaused(!paused));
  $('status').addEventListener('click', refreshNow);
  // 画面（パネル以外）をタップ・クリックしたら、一時停止・再開を切り替える
  document.addEventListener('click', e => { if (!panel.contains(e.target)) setPaused(!paused); });
  document.addEventListener('keydown', e => { if (e.code === 'Space' && !e.repeat) { e.preventDefault(); setPaused(!paused); } });
  window.addEventListener('resize', layout);
  // マウスを動かしたときだけカーソルを出す
  let idleTimer = null;
  const wake = () => { document.body.classList.remove('idle'); clearTimeout(idleTimer); idleTimer = setTimeout(() => document.body.classList.add('idle'), 3000); };
  document.addEventListener('mousemove', wake);
  wake();

  setZoom(zoom);
  load();
  requestAnimationFrame(frame);
})();
</script>
</body>
</html>
