<?php
/*
メディアメニューに「ライブ得点集計」を追加する。
（Modules/Custom/menu.php から移した）

変更履歴:
2026/10/01 団体予選・個人決勝・団体決勝は、ライブ得点集計の画面のパネルから行き来できるので、メニューから外す
2026/10/01 団体予選のサイネージ（SignageTeam.php）は Signage.php に統合したので、メニューから外す
2026/10/01 団体予選（LiveScoreboardTeam.php）を追加
2026/10/01 個人決勝・団体決勝（LiveScoreboardFinal.php）を追加
2026/09/26 Modules/Custom/menu.php から移す
2026/09/26 サイネージ表示（Signage.php）を追加
*/

if(!empty($on)) {
  $ret['MEDI'][] = MENU_DIVIDER;
  $ret['MEDI'][] = 'ライブ得点集計' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/LiveScoreboard/LiveScoreboard.php';
  $ret['MEDI'][] = 'ライブ得点集計（サイネージ）' . '|' . $CFG->ROOT_DIR . 'Modules/Custom/LiveScoreboard/Signage.php';
}
