<?php
/*

変更履歴:
2026/06/14 スコアカード機能を追加
2026/05/31 セッション絞り込みをトグル複数選択に変更
2026/05/31 セッション絞り込みメニューを追加
2026/03/15 セッション名が表示されるように変更
2025/11/17 セッションを持っていない場合は表示させないように変更
2025/10/26

*/
	define('debug',false);
	define('IN_PHP', true);
	ini_set('display_errors', 1);

	require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php

	require_once('Common/Fun_FormatText.inc.php');
	require_once('TV/Fun_HTML.local.inc.php');
    require_once('Common/Lib/CommonLib.php');
	require_once('Common/Lib/ArrTargets.inc.php');

	$TourCode=stripslashes($_REQUEST['Tour']);

	// セッション複数選択：s[] で受け取り、整数配列に正規化
	$GameSessions = [];
	if (!empty($_REQUEST['s'])) {
		$raw = $_REQUEST['s'];
		if (is_array($raw)) {
			foreach ($raw as $v) {
				$v = intval($v);
				if ($v > 0) $GameSessions[] = $v;
			}
		} else {
			$v = intval($raw);
			if ($v > 0) $GameSessions[] = $v;
		}
		$GameSessions = array_unique($GameSessions);
		sort($GameSessions);
	}

	if (empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		include('Common/Templates/head-min.php');
		echo "<a href='https://ianseo.net'>i@nseo.net</a>";
		include('Common/Templates/tail-min-min.php');
		die();
	}
	else if (!empty($_SESSION['TourId']) && empty($_REQUEST['Tour'])) {
		$Select	= "SELECT ToId,ToCode,ToName,ToWhere 
			FROM Tournament WHERE ToId='".$_SESSION['TourId']."'";	
		$Rs=safe_r_sql($Select);
		$MyRow=safe_fetch($Rs);
		$TourCode = $MyRow->ToCode;
	}

	$TourId=getIdFromCode($TourCode);
	if(!($TourId > 0) && !empty($_SESSION['TourId'])){
		$TourId = $_SESSION['TourId'];
	}
	
	$Order=stripslashes($_REQUEST['Order']);
	if($Order==""){
		$Order="Ranking";
	}
	
  if(! ($TourId > 0) ){
    include('Common/Templates/head-min.php');
    echo "error!";
    include('Common/Templates/tail-min-min.php');
    die();
  }

	// ----------------------------------------
	// セッション一覧を取得
	// ----------------------------------------
	$SelectSessions = "
		SELECT DISTINCT QuSession, SesName
		FROM Qualifications
		LEFT JOIN Entries ON EnId = QuId AND EnTournament = {$TourId} AND EnAthlete = 1
		LEFT JOIN Session ON SesTournament = {$TourId} AND SesOrder = QuSession AND SesType = 'Q'
		WHERE EnTournament = {$TourId}
		ORDER BY QuSession ASC
	";
	$RsSessions = safe_r_sql($SelectSessions);
	$SessionList = [];
	while ($SesRow = safe_fetch($RsSessions)) {
		$SessionList[] = [
			'QuSession' => intval($SesRow->QuSession),
			'SesName'   => $SesRow->SesName,
		];
	}

	// ----------------------------------------
	// セッションパラメータをURLクエリ文字列に変換するヘルパー
	// ----------------------------------------
	function buildSesParam($sessions) {
		if (empty($sessions)) return "";
		$parts = [];
		foreach ($sessions as $s) {
			$parts[] = "s[]=" . intval($s);
		}
		return "&" . implode("&", $parts);
	}

	// あるセッションをトグルした場合の選択リストを返す
	function toggleSession($current, $toggleId) {
		if (in_array($toggleId, $current)) {
			$next = array_values(array_filter($current, fn($v) => $v !== $toggleId));
		} else {
			$next = array_merge($current, [$toggleId]);
			sort($next);
		}
		return $next;
	}

	$tmpSel='';
	for ($i=1; $i<=2; $i++) {
		$tmpSel .= "QuD{$i}Score, QuD{$i}Hits, QuD{$i}Gold, QuD{$i}Xnine, QuD{$i}ArrowString, Td{$i}, DiEnds{$i}, DiArrows{$i}, ";
	}

	// WHERE句：複数セッション対応
	$tmpSession = "";	
	if (!empty($GameSessions)) {
		$inList = implode(",", $GameSessions);
		$tmpSession = "AND QuSession IN ({$inList}) ";
	}
		
	$Select = "SELECT EnId,EnCode,EnName,EnFirstName,EnTournament,EnDivision,EnClass,
			IF(CoName != '', CoName, CoCode) AS CountryName,
			QuTargetNo, QuTarget,QuLetter,
			$tmpSel
			QuScore, QuGold, QuXnine,
			ToId,ToGoldsChars,ToGolds AS GoldLabel,ToXNineChars,ToXNine AS XNineLabel,
			CONCAT(EnDivision,EnClass) AS Class,
			DivDescription,ClDescription,DivViewOrder,ClViewOrder,
			ToName,ToWhere,ToWhenFrom,ToWhenTo,ToCode,QuSession,SesName,
			IF(QuClRank = 0,10000,QuClRank) as ClRank,
			ToOnlineId
		FROM 
       Tournament 
        LEFT JOIN TournamentDistances ON TdTournament=ToId AND TdType=ToType
        LEFT JOIN Entries ON EnTournament=ToId AND EnAthlete=1 AND CONCAT(EnDivision,EnClass) LIKE TdClasses
        LEFT JOIN Countries ON CoId=EnCountry AND CoTournament=EnTournament 
        LEFT JOIN Qualifications ON QuId=EnId
        LEFT JOIN (
            SELECT
                a.DiTournament
                , a.DiSession
                , a.DiEnds AS DiEnds1
                , a.DiArrows AS DiArrows1
                , b.DiEnds AS DiEnds2
                , b.DiArrows AS DiArrows2 
            FROM
                DistanceInformation a 
                JOIN DistanceInformation b 
                    ON a.DiTournament = b.DiTournament 
                    AND a.DiSession = b.DiSession
                    AND a.DiType = b.DiType 
            WHERE
                a.DiDistance = 1 AND b.DiDistance = 2
                AND a.DiType='Q' ) DistInfo
            ON DiTournament=ToId and DiSession=QuSession
        LEFT JOIN Divisions ON DivTournament=EnTournament AND DivId=EnDivision    
        LEFT JOIN Classes ON ClTournament=EnTournament AND ClId=EnClass
        LEFT JOIN Session ON SesTournament=EnTournament AND SesOrder=QuSession AND SesType='Q'
		WHERE ToId = {$TourId} $tmpSession
		";
	$Rs=safe_r_sql($Select);

	

	$ArrayData = [];
	while( $MyRow=safe_fetch($Rs) ){
		$ArrayData[] = json_decode(json_encode($MyRow), true);
	}

	
	
/* 	echo "<pre>";
	var_dump($ArrayData);
	echo "</pre>"; */
	
	if($Order === "Target"){
 		usort($ArrayData, function($a, $b) {
			return $a['QuSession'] <=> $b['QuSession']
            ?: $a['QuTarget'] <=> $b['QuTarget']
            ?: $a['QuLetter'] <=> $b['QuLetter'];
		}); 
	} else {
		usort($ArrayData, function($a, $b) {
			return $a['DivViewOrder'] <=> $b['DivViewOrder']
				?: $a['QuSession'] <=> $b['QuSession']
				?: $a['ClViewOrder'] <=> $b['ClViewOrder']
				?: $a['Class'] <=> $b['Class']
				?: $a['ClRank'] <=> $b['ClRank'];
		});
	}

	$Tour = $ArrayData[0];
	$labelGold = $Tour["GoldLabel"];
	$labelXNine = $Tour["XNineLabel"];
	$pointGold = ValutaArrowString($Tour["ToGoldsChars"]);
	$pointXNine = ValutaArrowString($Tour["ToXNineChars"]);

	// 自動更新フラグ
	$mode_reload = "";
	if(stripslashes($_REQUEST['r'])=="1"){
		$mode_reload = "&r=1";
	}

	// 現在のセッションパラメータ文字列（リンク引き継ぎ用）
	$sesParam = buildSesParam($GameSessions);

	echo <<<EOM
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, user-scalable=yes">
<title>{$Tour['ToName']} - {$Tour['ToWhere']} ({$Tour['ToWhenFrom']}) </title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
<style>
html{
   font-size:clamp(6pt, 1.0vw, 14pt);
   font-family:"UD新ゴ R";
   margin:1vmin;
}

thead {
  top: 0;
  left: 0;	
}

h1,h2{
  margin-bottom:0;
}

table {
  border-collapse:collapse;
  border-spacing: 0;
}

table th,table td{
  text-align: center;
  white-space:nowrap;
  white-space-collapse: preserve;
}

table th{
  background-color: #c79852 !important;
  color: white;
  border:solid 1px black;
  height:1.3em;
}

table td{
  border:solid 1px black;
  padding: 0.3em 0.5em;
}

td.score {
  background:#eee;
  font-weight:bold;
	width:3rem;
	max-width:3rem;
	min-width:3rem;
}
td.goldx9 {
	width:2rem;
	max-width:2rem;
	min-width:2rem;
}
td.s{
  width:1.5em;
  /* background:#eee; */
  margin:1px;
}

td.blank {
  background-image: 
    linear-gradient(20deg, transparent 49%, black 49%, black 51%, transparent 51%), /* 右下がり */
    linear-gradient(-20deg, transparent 49%, black 49%, black 51%, transparent 51%); /* 右上がり */
}

/* スコアカード */
#sc td {
	min-width:2rem;
}

#sc td.point {
  width:3rem;
	min-width:3rem;
  max-width:3rem;
  font-weight:bold;
  font-size:1.2rem;
  border:2px solid black;
}

table.sctable > tbody > tr {
  vertical-align:top;	
}
table.sctable > tbody > tr > td {
   border:0;	
   padding:1rem;
}

.r_class{
	/*width:3rem;*/
	max-width:6rem;
	min-width:3rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}
.r_name{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
	font-weight:bold;
}
.r_country{
	width:8rem;
	max-width:8rem;
	min-width:8rem;
	border-right: 2px solid black !important;
	border-left: 2px solid black !important;
}

.boldleft {
  border-left: 2px solid black !important;
}
.boldright {
  border-right: 2px solid black;
}
.doubleleft {
  border-left: 2px double black !important;
}

.highlight > th{
	background: #863 !important;
}
.highlight > td{
	background: #88663340 !important;
}

/* セッショントグルボタン */
.session-toggle-btn {
  display: inline-block;
  margin: 0 2px;
  padding: 1px 7px;
  border: 1px solid #999;
  border-radius: 4px;
  text-decoration: none;
  color: #333;
  background: #f5f5f5;
  font-size: inherit;
  cursor: pointer;
  user-select: none;
}
.session-toggle-btn:hover {
  background: #e8e8e8;
}
.session-toggle-btn.active {
  background: #c79852;
  border-color: #a07030;
  color: white;
  font-weight: bold;
}
.session-toggle-btn.all-btn.active {
  background: #555;
  border-color: #333;
}

.hidden {
  display:none;	
}
@media print {
  .noprint {
    display: none !important;
  }
}
</style>
<script type="text/javascript" src="//webfonts.sakura.ne.jp/js/sakurav3.js"></script>
</head>
<body>
<h1>{$Tour['ToName']}</h1>
<div>{$TourCode}</div>
<div>会場:{$Tour['ToWhere']} (日程:{$Tour['ToWhenFrom']}
EOM;

  if($Tour['ToWhenFrom'] != $Tour['ToWhenTo']){
      echo "～{$Tour['ToWhenTo']}";
  }
  echo ")</div>"; 

  echo "<div class='noprint'>";

  // ---- 表示順メニュー ----
  if($Order === "Target" ){
     echo "[<a href='?Tour={$TourCode}&Order=Ranking{$sesParam}{$mode_reload}'>ランキング</a>][ターゲット順]";	  
  } else {
     echo "[ランキング][<a href='?Tour={$TourCode}&Order=Target{$sesParam}{$mode_reload}'>ターゲット順</a>]";
  }
  
  if($Tour['ToOnlineId']>0){
	echo "[<a href='https://www.ianseo.net/Details.php?toId={$Tour['ToOnlineId']}'>i@nseoへ</a>]";
  }

  echo "　　";

  // ---- 自動更新メニュー ----
  if(stripslashes($_REQUEST['r'])=="1"){
		echo <<<EOM
<span style='border:1px solid black' id='count'>30</span>
<script>
  cnt = -1;
  setInterval(() => {
	cnt = parseInt(document.getElementById('count').innerHTML);
	cnt--;
	document.getElementById('count').innerHTML = cnt;
	if(cnt==0){
		cnt=30;
		location.reload();
	}
  }, 1000);
</script>
EOM;
		echo "[<a href='?Tour={$TourCode}&Order={$Order}{$sesParam}'>更新停止</a>]";
	} else {
		echo "[<a href='?Tour={$TourCode}&Order={$Order}&r=1{$sesParam}'>自動更新</a>]";
	}

  echo "</div>"; // .noprint

  $preClass = "";
  $preSession = "";
  $preTarget = "";
  $preDistance = "";
  $flgHighlight = false;
  $flg_First = true;
	
	foreach($ArrayData as $Data){
		
		if(is_null($Data["EnId"])){
			continue;
		}
		
		if($preTarget != $Data['QuTarget']){
			$flgHighlight = !$flgHighlight;
		}
    
		if( ( $Order==="Target" && ( $preSession != $Data['QuSession'] || $preDistance != $Data['Td1'] ) ) || ( $Order!=="Target" && $preClass != $Data['Class'])){
		  if( $flg_First ){
			  $flg_First = false;
		  } else {
			if( $preSession != $Data['QuSession'] || ($Order!=="Target" && $preClass != $Data['Class']) ){
				echo "</table><!-aa->\n</div>";
			} else {
				
			}
		  }
		  
		  if( $Order==="Target") {
			    if( $preSession != $Data['QuSession'] ){
					echo "<h2>".($Data['SesName'] ?: "セッション".$Data['QuSession'])."</h2>"; 
					echo "<div class='table_box'><table>";	
				}				
		  } else {
				echo "<h2>{$Data['DivDescription']}{$Data['ClDescription']}</h2>";   
                echo "<div class='table_box'><table>";	
		  }
		  
		  echo <<<EOM
<tr>
EOM;
		  echo "<th rowspan=2 class='boldleft'>".($Order==="Target" ? "的番号" : "順位")."</th>";
		  echo ($Order==="Target" ? "<th rowspan=2 class='r_class'>クラス</th>" : ""); 
		  echo <<<EOM
	<th rowspan=2 class="r_name">選手名</th>
	<th rowspan=2 class="boldright r_country">所属</th>
  <th colspan=3 class="boldright">総合成績</th>
EOM;
		  echo "<th colspan=".(intval($Data['DiEnds1'])+1)." class='boldright di1' data-di='1'>{$Data['Td1']}</th>\n";    
		  echo "<th colspan=".(intval($Data['DiEnds2'])+1)." class='boldright di2' data-di='2'>{$Data['Td2']}</th>\n";   
		  echo <<<EOM
	<th rowspan='2'>スコア<br>カード</th>
</tr>
<tr>
	<th class="boldleft">総合計</th>
	<th class="goldx9">{$Data['GoldLabel']}</th>
	<th class="boldright goldx9">{$Data['XNineLabel']}</th>
EOM;

		  foreach(range(1,$Data['DiEnds1']) as $i){
			echo "<th class='s d1'>{$i}</th>\n";
		  }
		  echo "<th class='doubleleft boldright'>合計</th>\n";
		  foreach(range(1,$Data['DiEnds2']) as $i){
			echo "<th class='s d2'>{$i}</th>\n";
		  }
		  echo "<th class='doubleleft boldright'>合計</th>\n";

		echo <<<EOM
</tr>	
EOM;
		}

		$preClass = $Data['Class'];
		$preSession = $Data["QuSession"];
		$preTarget = $Data["QuTarget"];
		$preDistance = $Data["Td1"];
		
		$_RankText = $Order==="Target" ? str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT) : $Data['ClRank']; 
		if( intval($Data['ClRank'])>10000 ) {
			$_RankText = $Order==="Target" ? $_RankText : "欠";
			$Data['QuD1ArrowString'] = "";
			$Data['QuD2ArrowString'] = "";
			$Data['QuScore'] = "欠";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
			$Data['QuD1Score'] = "";
			$Data['QuD2Score'] = "";			
		} else if( intval($Data['ClRank'])==10000 ) {
			$_RankText = $Data['QuSession']."-".str_pad($Data['QuTarget'].$Data['QuLetter'],4," ",STR_PAD_LEFT);
			$Data['QuD1ArrowString'] = "";
			$Data['QuD2ArrowString'] = "";
			$Data['QuScore'] = "";
			$Data['QuGold'] = "";
			$Data['QuXnine'] = "";
			$Data['QuD1Score'] = "";
			$Data['QuD2Score'] = "";	
		}
    
		$ArrayD1Score = [];
		foreach(str_split(substr($Data['QuD1ArrowString'],0,$Data['QuD1Hits']), $Data['DiArrows1']) as $EndArrow){
			if($EndArrow!=="      "){
				$ArrayD1Score[] = ValutaArrowString($EndArrow);
			} else {
				$ArrayD1Score[] = "";
			}
		}
		$ArrayD2Score = [];
		foreach(str_split(substr($Data['QuD2ArrowString'],0,$Data['QuD2Hits']), $Data['DiArrows2']) as $EndArrow){
			if($EndArrow!=="      "){
				$ArrayD2Score[] = ValutaArrowString($EndArrow);
			} else {
				$ArrayD2Score[] = "";
			}
		}
		
		$ArrayD1Point = DecodeFromString($Data['QuD1ArrowString']);
		$ArrayD2Point = DecodeFromString($Data['QuD2ArrowString']);
		
		$Data['ArrayD1Point'] = $ArrayD1Point;
		$Data['ArrayD2Point'] = $ArrayD2Point;

    
		$D1Score = "";
		for($i=0;$i<$Data['DiEnds1'];$i++){
		  $D1Score .= "<td class='s d1'>".($ArrayD1Score[$i] ?? '')."</td>";
		}
		
		$D2Score = "";
		for($i=0;$i<$Data['DiEnds2'];$i++){
		  $D2Score .= "<td class='s d2'>".($ArrayD2Score[$i] ?? '')."</td>";
		}
		
		$_trclass = ($Order === "Target" && $flgHighlight) ? 'highlight' : '';
		
		echo <<<EOM
<tr class='target-{$Data['QuTarget']} {$_trclass}'>
	<th class="boldleft">{$_RankText}</th>
EOM;
		echo ($Order==="Target" ? "<td class='r_class'>{$Data['Class']}</td>" : "");
	
		$_Name = "{$Data['EnFirstName']}  {$Data['EnName']}";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($_Name,14)."</td>";
		echo "   <td class='boldright r_country' style='text-align:left;'>".shrinktext($Data['CountryName'],14)."</td>";
		echo <<<EOM
  <td class='score sticky'>{$Data['QuScore']}</td>
	<td class='goldx9'>{$Data['QuGold']}</td>
	<td class='goldx9 boldright'>{$Data['QuXnine']}</td>
  {$D1Score}
	<td class='score doubleleft boldright'>{$Data['QuD1Score']}</td>
  {$D2Score}
	<td class='score doubleleft boldright'>{$Data['QuD2Score']}</td>
EOM;
		echo "<td style='padding:0;'><button  onclick='showscore(".json_encode($Data).");'><span class='material-icons'>article</span></button></td>";
		//echo "<script>console.log(JSON.parse('".json_encode($Data)."'));</script>";
		echo <<<EOM
</tr>
EOM;

	}
	echo "</table></div>";

	// ---- セッション絞り込みトグルメニュー（テーブル下） ----
	if(count($SessionList) > 1){
		echo "<br>";
		echo "<div class='noprint'>";
		echo "セッション：";
		$allActive = empty($GameSessions) ? " active" : "";
		echo "<a class='session-toggle-btn all-btn{$allActive}' href='?Tour={$TourCode}&Order={$Order}{$mode_reload}'>全て</a>";
		foreach($SessionList as $Ses){
			$sesId    = $Ses['QuSession'];
			$sesLabel = (!empty($Ses['SesName'])) ? $Ses['SesName'] : "Session {$sesId}";
			$isActive = in_array($sesId, $GameSessions);
			$btnClass = $isActive ? " active" : "";
			$toggled      = toggleSession($GameSessions, $sesId);
			$toggledParam = buildSesParam($toggled);
			echo "<a class='session-toggle-btn{$btnClass}' href='?Tour={$TourCode}&Order={$Order}{$toggledParam}{$mode_reload}'>{$sesLabel}</a>";
		}
		echo "</div>";
	}
	
	echo <<<EOM
<dialog>
  <div style='padding:0 3rem;margin:0;'>
  <div style="text-align:right"><button id="closeDialog">×閉じる</button></div>
  <div>{$Tour['ToName']}<br>{$TourCode}  会場:{$Tour['ToWhere']} ({$Tour['ToWhenFrom']})</div>
  <div id="sc_name" style=''></div>
  <!--<div id="sc_score" style='text-align:right;'></div>-->
  </div>
  <div id="sc"></div>
</dialog>
<script>
const LABEL_GOLD = '{$labelGold}';
const LABEL_XNINE = '{$labelXNine}';
const POINT_GOLD = parseInt('{$pointGold}');
const POINT_XNINE = parseInt('{$pointXNine}');

const dialog = document.querySelector("dialog");
const closeButton = document.querySelector("#closeDialog");
closeButton.addEventListener("click", () => {
  dialog.close(); // モーダルダイアログを閉じる
});

const showscore = (Data) => {
  //console.log(Data);
  const sc = document.querySelector("#sc");
  const sc_name = document.querySelector("#sc_name");
  //const sc_score = document.querySelector("#sc_score");
  
  let tname = "";
  tname += "<span style='font-size:1.5em;'>";
  tname += "<span style='border:solid 1px black;font-weight:bold;font-family: sans-serif;'>"+Data.QuTarget+Data.QuLetter+"</span>";
  tname += Data.EnFirstName+"　"+Data.EnName+"("+Data.CountryName+")";
  tname += "</span>   ";
  tname += Data.SesName+" "+Data.ClDescription+"["+Data.Class+"]";
  tname += " 順位:"+Data.ClRank;
  
  
  sc_name.innerHTML = tname;
  
  /*
  let tscore = "";
  tscore += "<span style='font-size:1.5em;'>";
  tscore += "合計<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuScore+"</span>";
  tscore += "  "+Data.GoldLabel+"<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuGold+"</span>";
  tscore += "  "+Data.XNineLabel+"<span style='border:solid 1px black;padding:0.2em;'>"+Data.QuXnine+"</span>";
  tscore += "</span>";
  sc_score.innerHTML = tscore;
  */

  
  let tbody = "";
  tbody += "<table class='sctable'>";
  tbody += "<tr>";
  tbody += "<td>";
  tbody += "<div>"+Data.Td1+"</div>";
  tbody += createCard(Data.ArrayD1Point,Data.DiArrows1,Data.DiEnds1,Data.QuD1Hits);
  tbody += "</td>";
  tbody += "<td>";
  tbody += "<div>"+Data.Td2+"</div>";
  tbody += createCard(Data.ArrayD2Point,Data.DiArrows2,Data.DiEnds2,Data.QuD2Hits,Data.QuScore,Data.QuGold,Data.QuXnine);
  tbody += "</td>";
  tbody += "</table>";
  
  sc.innerHTML = tbody;
  
	dialog.showModal();
}

function createCard(score,DiArrows=6,DiEnds=6,Hits=36,QuScore=null,QuGold=null,QuXnine=null){
  	
	
  let tbody = "<table>";
  tbody += "<tr><th></th><th>1</th><th>2</th><th>3</th>";
  tbody += "<th>小計</th><th colspan=2>累計</th><th>"+LABEL_GOLD+"</th><th>"+LABEL_XNINE+"</th></tr>";
  
  let ends = 1;
  let sum3 = 0;
  let sum_ends = 0;
  let cnt_GOLD = 0;
  let cnt_XNINE = 0;
  let total = 0;
  let totalcnt_GOLD = 0;
  let totalcnt_XNINE = 0;
  
  tbody += "<tr>";
  for(let i=0;i<(DiArrows*DiEnds);i++){
     if(i%DiArrows==0){
       tbody += "<th "+( DiArrows>3 ? 'rowspan=2' : '' )+">"+ends+"</th>";
       ends++;
       
		sum_ends=0;
		cnt_GOLD = 0;
		cnt_XNINE = 0; 
     }
	 if(i%3==0) sum3 = 0;
	 
	 
     if(i<score.length){
       tbody += "<td class='point'>"+score[i]+"</td>"; 
       point=0;
       if(Number.isInteger(parseInt(score[i]))){
         point = parseInt(score[i]);
       }
       if(score[i]==LABEL_GOLD){
         point=POINT_GOLD;
         cnt_GOLD++;
         totalcnt_GOLD++;
       }
       if(score[i]==LABEL_XNINE){
         point=POINT_XNINE;
         cnt_XNINE++;
         totalcnt_XNINE++;
       }
       total+=point;
       sum3+=point;
       sum_ends+=point;
       
     } else {
       tbody += "<td></td>"; 
     } 
	 
     if(i%3==2){
       tbody += "<td>"+(i<=Hits? sum3 : "")+"</td>";
	   if( DiArrows>3 ){
		   if(i%DiArrows==(DiArrows-1)){
			 tbody += "<td>"+(i<=Hits? sum_ends : "")+"</td>";         
			 tbody += "<td class='point'>"+total+"</td>";
		   } else {
			 tbody += "<td colspan=2 class='blank'></td>";
		   }
	   } else {
			 tbody += "<td colspan=2 class='point'>"+total+"</td>";
	   }
       tbody += "<td>"+(cnt_GOLD || "") +"</td>";
       tbody += "<td>"+(cnt_XNINE || "") +"</td>";
       tbody += "</tr>";
       
       tbody += "<tr>"; 
     }
  }
  tbody += "</tr>";
  
  tbody += "<tr><td colspan=6 style='border:none;text-align:right'>総計</td>";
  tbody += "<td class='point'>"+total+"</td>";
  tbody += "<td>"+totalcnt_GOLD+"</td>";
  tbody += "<td>"+totalcnt_XNINE+"</td>";
  tbody += "</tr>";
  
  if(QuScore!==null){
	  tbody += "<tr style='background:#ffd;'><td colspan=6 style='border:none;text-align:right'>総合計</td>";
	  tbody += "<td class='point'>"+QuScore+"</td>";
	  tbody += "<td>"+QuGold+"</td>";
	  tbody += "<td>"+QuXnine+"</td>";
	  tbody += "</tr>";
  }
  
  tbody += "</table>";  
  return tbody;
}

document.querySelectorAll('th[data-di]').forEach(th => {
  th.style.cursor = 'pointer';
  th.addEventListener('click', () => {
    const di = th.dataset.di;
    th.classList.toggle('clicked');
    const isHidden = th.classList.contains('clicked');
    document.querySelectorAll('.d'+di).forEach(el => {
      el.classList.toggle('hidden', isHidden);
    });
    document.querySelectorAll('th.di'+di).forEach(el => {
	  el.colSpan = isHidden ? 1 : ({$Tour['DiEnds1']}+1);
    });
	

  });
});



</script>
EOM;
	include('Common/Templates/tail-min.php');



function shrinktext($_Text,$maxsize){
  $_cnt = mb_strwidth($_Text);
  if($_cnt==0) $_cnt = 1;
  
  if($_cnt<$maxsize){
    $_size = 1;
  } else {
    $_size = $maxsize/$_cnt;
  }
  
  return "<div style='transform-origin: 0 0;transform:scale({$_size},1);'>{$_Text}</div>";
}