<?php
/*
決勝トーナメント表（個人・団体）を、ianseo.net の Brackets ページに似た形で表示する。

・ianseo 標準の対戦表データ（getBracketsIndividual / getBracketsTeams）を読み、
  種目ごとにトーナメント表を組む。左から 1/16 → 1/8 → 準々決勝 → 準決勝 → 決勝。
  3位決定戦は表の下に別に出す。
・各対戦は、選手（チーム）名・所属・試合の得点（セット制ならセット点）を出し、勝った側を太字にする。
  エンドごとの合計点は得点の右に小さく出す。シュートオフは (SO ...) で出す。
・団体は、チーム名の下にメンバー名を出す。

パラメータ:
  Tour     大会コード（省略時はログイン中の大会）
  Team     0=個人（既定）/ 1=団体
  Event    種目コード（カンマ区切りで複数可。省略時は全種目）
  refresh  自動で読み込み直す間隔（秒。省略時は読み込み直さない）

例: LiveScoreboardFinal.php?Tour=261R0707&Team=0&Event=RW

変更履歴:
2026/10/12 試合前の表示を的番号だけにし（開始時間は出さない）、上下それぞれの側に出す。同じ的なら上を A・下を B にする（T#2A / T#2B）
2026/10/12 Bye は、相手が不戦勝（Tie=2）のときだけ出す（前の試合が終わっていないだけのときは出さない）
2026/10/01 種目の選択は「すべて」か 1 種目だけにする（複数選択をやめる）
2026/10/01 画面の切り替えを共通のパネル（Lib.php）にする。見た目を LiveScoreboard.php に合わせる。自動更新は r=1（30 秒）に統一し、refresh は廃止
2026/10/01 初版
*/
	define('debug',false);
	define('IN_PHP', true);
	ini_set('display_errors', 1);

	require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php

	require_once('Common/Fun_FormatText.inc.php');
	require_once('Common/Lib/CommonLib.php');
	require_once('Common/Lib/ArrTargets.inc.php');
	require_once('Common/Fun_Phases.inc.php');
	require_once(dirname(__FILE__) . '/Lib.php');

	function esc($s) {
		return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
	}

	// ---- 大会の決め方は LiveScoreboard.php と同じ（Tour がなければログイン中の大会） ----
	$TourId = 0;
	if (!empty($_REQUEST['Tour'])) {
		$TourId = intval(getIdFromCode(stripslashes($_REQUEST['Tour'])));
	}
	if (!($TourId > 0) && !empty($_SESSION['TourId'])) {
		$TourId = intval($_SESSION['TourId']);
	}
	if (!($TourId > 0)) {
		include('Common/Templates/head-min.php');
		echo "error!";
		include('Common/Templates/tail-min-min.php');
		die();
	}

	$IsTeam = !empty($_REQUEST['Team']) ? 1 : 0;
	$Reload = (!empty($_REQUEST['r']) && stripslashes($_REQUEST['r']) == '1');

	// 種目の絞り込み
	$EventFilter = [];
	if (!empty($_REQUEST['Event'])) {
		$raw = is_array($_REQUEST['Event']) ? $_REQUEST['Event'] : explode(',', stripslashes($_REQUEST['Event']));
		foreach ($raw as $e) {
			$e = trim($e);
			if ($e !== '' && preg_match('/^[0-9A-Za-z-]+$/', $e)) $EventFilter[] = $e;
		}
	}

	// 大会の情報
	$Tour = ['ToName' => '', 'ToWhere' => '', 'ToWhenFrom' => '', 'ToWhenTo' => '', 'ToCode' => ''];
	$Rs = safe_r_sql("SELECT ToName, ToWhere, ToWhenFrom, ToWhenTo, ToCode FROM Tournament WHERE ToId={$TourId}");
	if ($r = safe_fetch($Rs)) {
		$Tour = ['ToName' => $r->ToName, 'ToWhere' => $r->ToWhere, 'ToWhenFrom' => $r->ToWhenFrom,
			'ToWhenTo' => $r->ToWhenTo, 'ToCode' => $r->ToCode];
	}

	// ---- 対戦表のデータを読む（ランク用のクラスはセッションの大会を見るので、読む間だけ差し替える） ----
	$OrigTourId = $_SESSION['TourId'] ?? null;
	$_SESSION['TourId'] = $TourId;
	// OrisFunctions.php は読み込み時にセッションの大会を見る（印刷言語）ので、大会を決めてから読み込む
	require_once('Common/OrisFunctions.php');

	// 種目の一覧（切り替えリンク用）
	// （決勝の対戦に選手・チームが入っている種目だけ。種目があるだけでは出さない）
	$EventList = lsb_events($TourId, $IsTeam, true);

	$Sections = [];
	$LastUpdate = '';
	// 決勝の設定にない種目のコードは、絞り込みから外す（団体予選から引き継いだときなど）
	$EventFilter = array_values(array_intersect($EventFilter, array_keys($EventList)));
	$want = $EventFilter ? $EventFilter : array_keys($EventList);
	if ($want) {
		if ($IsTeam) {
			$Data = getBracketsTeams($want, false, true, true, true, false);
		} else {
			$Data = getBracketsIndividual($want, false, true, true, true, false, null, false, true);
		}
		$Sections = $Data->rankData['sections'] ?? [];
		$LastUpdate = $Data->LastUpdate ?? '';
	}

	if ($OrigTourId === null) unset($_SESSION['TourId']); else $_SESSION['TourId'] = $OrigTourId;

	// ---- 表示用の関数 ----
	function phaseLabel($phase) {
		if ($phase == 0) return '決勝';
		if ($phase == 1) return '3位決定戦';
		if ($phase == 2) return '準決勝';
		if ($phase == 4) return '準々決勝';
		return '1/' . $phase;
	}

	// 試合の矢の並びからエンドごとの合計点を出す
	function endTotals($arrowString, $arrowsPerEnd) {
		$s = preg_replace('/\s+/', '', (string)$arrowString);
		$ends = [];
		if ($s === '' || $arrowsPerEnd < 1) return $ends;
		for ($i = 0; $i < strlen($s); $i += $arrowsPerEnd) {
			$chunk = substr($s, $i, $arrowsPerEnd);
			$ends[] = strlen($chunk) == $arrowsPerEnd ? ValutaArrowString($chunk) : null;
		}
		return array_values(array_filter($ends, function ($v) { return $v !== null; }));
	}

	// 片側（選手／チーム）の表示用データ。$p は '' か 'opp'
	function sideData($item, $p, $section, $phaseMeta, $isTeam, $other) {
		$k = function ($name) use ($p) {
			return $p === '' ? $name : 'opp' . ucfirst($name);
		};
		$matchMode = !empty($section['meta']['matchMode']);
		$arrows = !empty($phaseMeta['FinElimChooser']) ? $section['meta']['elimArrows'] : $section['meta']['finArrows'];

		$side = [];
		if ($isTeam) {
			$side['name'] = (string)($item[$k('countryName')] ?? '');
			$teamId = $item[$p === '' ? 'teamId' : 'oppTeamId'] ?? null;
			$sub = $item[$p === '' ? 'subTeam' : 'oppSubTeam'] ?? null;
			$members = [];
			if ($teamId !== null && isset($section['athletes'][$teamId][$sub])) {
				foreach ($section['athletes'][$teamId][$sub] as $a) {
					$members[] = trim($a['familyName'] . ' ' . $a['givenName']);
				}
			}
			$side['members'] = $members;
			$side['affil'] = '';
			$side['seed'] = $item[$k('position')] ?? '';
		} else {
			$side['name'] = trim((string)($item[$k('athlete')] ?? ''));
			$side['members'] = [];
			$side['affil'] = (string)($item[$k('countryName')] ?? '');
			$side['seed'] = $item[$k('position')] ?? '';
		}
		$side['bib'] = $isTeam ? '' : (string)($item[$k('bib')] ?? '');
		if (!$side['seed']) $side['seed'] = '';

		$score = $matchMode ? ($item[$k('setScore')] ?? 0) : ($item[$k('score')] ?? 0);
		$oscore = $matchMode ? ($item[$other('setScore')] ?? 0) : ($item[$other('score')] ?? 0);
		$hasAny = ($score != 0 || $oscore != 0 || !empty($item['arrowstring']) || !empty($item['oppArrowstring']));
		$side['score'] = $hasAny ? (string)$score : '';
		$side['ends'] = endTotals($item[$k('arrowstring')] ?? '', intval($arrows));
		$tb = trim((string)($item[$k('tiebreakDecoded')] ?? $item[$k('tiebreak')] ?? ''));
		$side['so'] = $tb;
		$side['win'] = !empty($item[$k('winner')]);
		$irm = (string)($item[$k('irmText')] ?? '');
		$side['irm'] = (!empty($item[$k('irm')]) && $irm !== '') ? $irm : '';
		$side['empty'] = ($side['name'] === '');
		// 不戦勝（Bye）で勝ち上がった側は、ianseo が Tie=2 を付ける
		$side['bye'] = (intval($item[$k('tie')] ?? 0) === 2);
		// 試合の的番号（選手・チームごとに別の的のこともある）
		$side['target'] = (string)($item[$k('target')] ?? '');
		return $side;
	}

	// エンドごとの得点：上下の選手の行をまたぐ 1 つの小さな表にする（対戦枠の右寄り・上下中央）
	function renderEnds($a, $b, $hasSo) {
		if (!$a['ends'] && !$b['ends'] && $a['so'] === '' && $b['so'] === '') return '';
		$cnt = max(count($a['ends']), count($b['ends']));
		$out = '<table class="ends">';
		foreach ([$a, $b] as $s) {
			$out .= '<tr>';
			// 終わった試合（射た分）だけ枠を出す。使わない枠は出さない
			for ($i = 0; $i < $cnt; $i++) {
				$out .= '<td>' . (isset($s['ends'][$i]) ? esc($s['ends'][$i]) : '') . '</td>';
			}
			if ($hasSo) $out .= '<td class="so">' . ($s['so'] !== '' ? esc($s['so']) : '') . '</td>';
			$out .= '</tr>';
		}
		return $out . '</table>';
	}

	// $tgt: 試合前に、この側に出す的番号（'' なら出さない）
	function renderSide($s, $byeWhenEmpty, $showSeed, $tgt = '') {
		$cls = 'side' . ($s['win'] ? ' win' : '') . ($s['empty'] ? ' blank' : '');
		$out = "<div class=\"{$cls}\">";
		if ($showSeed) $out .= '<span class="seed">' . esc($s['seed']) . '</span>';
		$out .= '<span class="who">';
		if ($s['empty']) {
			$out .= '<span class="nm">' . ($byeWhenEmpty ? 'Bye' : '&nbsp;') . '</span>';
		} else {
			$out .= '<span class="nm">' . esc($s['name']) . '</span>';
			if ($s['affil'] !== '') $out .= '<span class="af">' . esc($s['affil']) . '</span>';
			foreach ($s['members'] as $mem) $out .= '<span class="mem">' . esc($mem) . '</span>';
		}
		$out .= '</span>';
		if ($tgt !== '') $out .= '<span class="tg">T#' . esc($tgt) . '</span>';
		$out .= '<span class="sc">' . esc($s['score']);
		if ($s['irm'] !== '') $out .= '<small> ' . esc($s['irm']) . '</small>';
		$out .= '</span>';
		$out .= '</div>';
		return $out;
	}

	// 回戦ごとの対戦枠の幅。3位決定戦は決勝と同じ列に置く
	function matchWidth($phase) {
		$k = ($phase == 1) ? 0 : $phase;
		return $GLOBALS['PhW'][$k] ?? ['mw' => 20, 'ew' => 0, 'so' => false];
	}

	function renderMatch($entry, $section, $isTeam, $showSeed = false) {
		$item = $entry['item'];
		$pm = $entry['phaseMeta'];
		$other = function ($name) { return 'opp' . ucfirst($name); };
		$oppOther = function ($name) { return $name; };
		$a = sideData($item, '', $section, $pm, $isTeam, $other);
		$b = sideData($item, 'opp', $section, $pm, $isTeam, $oppOther);
		$w = matchWidth($entry['phase']);
		// 空の側を「Bye」と出すのは、相手が不戦勝（Tie=2）のときだけ。
		// 相手がいるだけで空なら、前の試合がまだ終わっていない（まだ決まっていない）ので、Bye とは出さない
		$byeA = $a['empty'] && !$b['empty'] && $b['bye'];
		$byeB = $b['empty'] && !$a['empty'] && $a['bye'];
		// 試合前は、的番号だけを上下それぞれの側に出す（開始時間は出さない）。不戦勝の試合には出さない。
		// 上下で同じ的のときは、上を A、下を B にする（T#2A / T#2B）。違う的のときは、そのまま（T#3 / T#4）
		$notStarted = ($a['score'] === '' && $b['score'] === '' && !$byeA && !$byeB && !$a['bye'] && !$b['bye']);
		$tgtA = $tgtB = '';
		if ($notStarted) {
			$tgtA = $a['target'];
			$tgtB = $b['target'];
			if ($tgtA !== '' && $tgtA === $tgtB) {
				$tgtA .= 'A';
				$tgtB .= 'B';
			}
		}
		$out = '<div class="match" style="width:' . $w['mw'] . 'em;--ew:' . $w['ew'] . 'em">' . renderSide($a, $byeA, $showSeed, $tgtA) . renderSide($b, $byeB, $showSeed, $tgtB) . renderEnds($a, $b, $w['so']);
		return $out . '</div>';
	}

	// 偶数の試合番号 $m を根にして、下（前の回戦）へ枝を伸ばした入れ子の HTML を作る
	function renderNode($m, $matches, $section, $isTeam, $isChild) {
		if (!isset($matches[$m])) return '';
		$kids = ($m == 0) ? [4, 6] : [$m * 2, $m * 2 + 2];
		$kidHtml = '';
		foreach ($kids as $kid) {
			$kidHtml .= renderNode($kid, $matches, $section, $isTeam, true);
		}
		$out = '<div class="node' . ($isChild ? ' child' : '') . '">';
		if ($kidHtml !== '') {
			$out .= '<div class="kids">' . $kidHtml . '</div><div class="stub"></div>';
		}
		if ($isChild) {
			// 予選順位は最初の対戦（左端）だけに出す
			$out .= '<div class="mwrap">' . renderMatch($matches[$m], $section, $isTeam, $kidHtml === '') . '</div>';
			$out .= '<div class="conn"></div>';
		} else {
			// 決勝：上に「ゴールド」、下に 3 位決定戦「ブロンズ」
			$out .= '<div class="mwrap final"><div class="medal gold">ゴールド</div>' .
				renderMatch($matches[$m], $section, $isTeam, $kidHtml === '');
			if (isset($matches[2])) {
				$out .= '<div class="bronzebox"><div class="medal">ブロンズ</div>' . renderMatch($matches[2], $section, $isTeam, false) . '</div>';
			}
			$out .= '</div>';
		}
		return $out . '</div>';
	}

	// ---- 切り替えパネル：1 列目は共通、2 列目は種目（決勝の設定がある種目だけ） ----
	$LsbInfo = lsb_info($TourId);
	$LsbHdr = lsb_ianseo_header($TourId);
	$Title = $Tour['ToName'] . ($IsTeam ? '（団体決勝）' : '（個人決勝）');
	$evBase = ['Tour' => $Tour['ToCode'], 'Team' => $IsTeam ? 1 : null, 'r' => $Reload ? 1 : null];
	$evBtns = [];
	if ($EventList) {
		$evBtns[] = lsb_btn('すべて', lsb_url('LiveScoreboardFinal.php', $evBase), !$EventFilter);
		foreach ($EventList as $code => $name) {
			// 「すべて」は全部、種目は 1 つだけ選ぶ（押した種目だけにする）
			$on = in_array($code, $EventFilter);
			$evBtns[] = lsb_btn($name ?: $code, lsb_url('LiveScoreboardFinal.php', $evBase + ['Event' => $code]), $on);
		}
	}
	$LsbCtx = [
		'code' => $Tour['ToCode'], 'reload' => $Reload, 'event' => $EventFilter ? implode(',', $EventFilter) : null, 'selfFile' => 'LiveScoreboardFinal.php',
		'self' => ['Tour' => $Tour['ToCode'], 'Team' => $IsTeam ? 1 : null, 'Event' => $EventFilter ? implode(',', $EventFilter) : null],
	];
	$PanelHtml = lsb_panel($IsTeam ? 'teamfinal' : 'indfinal', $LsbInfo, $LsbCtx, [lsb_group('', $evBtns)]);
?><!DOCTYPE html>
<html lang="ja" class="notranslate" translate="no">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google" content="notranslate">
<title><?php echo esc($Title); ?></title>
<style>
html{
   font-size:clamp(10pt, 1.3vw, 18pt);
   font-family:"UD新ゴ R";
   margin:1vmin;
   background:#fff;
   color:#000;
}
h1,h2{ margin-bottom:0; }
<?php echo lsb_css() . $LsbHdr['css']; ?>
.event{ margin:1em 0 2.5em; }
.event > h2{
  margin:0.8em 0 0.4em;
}

.scroll{ overflow-x:auto; padding-bottom:0.5em; }

/* 見出し（回戦名）の行 */
.heads{ display:flex; margin-bottom:0.4em; }
.heads > div{
  box-sizing:border-box;
  padding:0.2em 0.5em;
  background:#007db3;
  color:#fff;
  border:1px solid #007db3;
  border-radius:0.2em;
  text-align:center;
  white-space:nowrap;
}

/* トーナメント表：node = 左に前の回戦（kids）、右にその勝者が進む試合（match） */
.tree{ display:inline-block; }
.node{ display:flex; align-items:center; }
.kids{ display:flex; flex-direction:column; justify-content:center; }
.stub{ width:12px; border-top:2px solid #007db3; }
.conn{ width:12px; align-self:stretch; position:relative; }
.conn::before{
  content:''; position:absolute; left:0; right:0; top:50%;
  margin-top:-1px; border-top:2px solid #007db3;
}
.kids > .node:first-child > .conn::after,
.kids > .node:last-child  > .conn::after{
  content:''; position:absolute; right:0;
  border-right:2px solid #007db3;
}
.kids > .node:first-child > .conn::after{ top:50%; bottom:0; }
.kids > .node:last-child  > .conn::after{ top:0; bottom:50%; }
.mwrap{ padding:4px 0; }
.mwrap.final{ position:relative; margin:var(--fpad) 0; }

.tree{ --fpad:8em; font-size:11.5px; font-family:sans-serif; }
.tree.team{ --fpad:16em; }
.match{
  background:#e6f7ff;
  border:1px solid #007db3;
  border-radius:0.25em;
  overflow:hidden;
}
.side{
  display:flex;
  align-items:center;
  gap:0.4em;
  padding:0.15em calc(var(--ew, 0em) + 0.4em) 0.15em 0.4em;
  background:#fff;
  min-height:2.6em;
}
.side + .side{ border-top:1px solid #007db3; }
.side .seed{ width:1.6em; text-align:right; color:#777; font-size:0.85em; flex:none; }
.side .who{ flex:1; min-width:0; display:flex; flex-direction:column; }
.side .af, .side .mem{ white-space:nowrap; font-size:0.75em; color:#555; }
.side .nm{ white-space:nowrap; }
.side .sc{ flex:none; min-width:1.2em; text-align:center; font-weight:bold; }
.side .sc small{ font-weight:normal; }
.match{ position:relative; }
.side .sc{ font-size:1.8em; line-height:1; }
.side .sc small{ font-size:0.35em; }
/* エンドごとの得点：上下の選手にまたがる 1 つの表 */
table.ends{
  position:absolute; right:0.4em; top:50%; transform:translateY(-50%);
  border-collapse:collapse; font-size:0.75em; color:#333;
}
table.ends td{ background:#fff; border:1px solid #007db3; width:1.9em; height:1.5em; padding:0; text-align:center; }
table.ends td.so{ width:2.1em; border:none; background:none; white-space:nowrap; }
.side.win{ background:#fffbe0; }
.side.win .nm{ font-weight:bold; }
.side.blank{ color:#999; }
.medal{ font-weight:bold; color:#007db3; padding:0.2em 0; }
.medal.gold{ position:absolute; bottom:100%; margin-bottom:-2px; }
.bronzebox{ position:absolute; top:100%; left:0; margin-top:-2px; padding-top:1.8em; }
.bronzebox .medal{ position:absolute; top:0; left:0; }
.side .tg{ flex:none; font-size:0.75em; color:#007db3; white-space:nowrap; margin-left:0.3em; align-self:center; }
.when{ font-size:0.75em; color:#007db3; padding:0.1em 0.5em; border-top:1px solid #007db3; }

.nodata{ color:#888; padding:1em 0; }
.upd{ color:#888; font-size:0.85em; margin-top:1em; }
</style>
<script type="text/javascript" src="//webfonts.sakura.ne.jp/js/sakurav3.js"></script>
</head>
<body>
<?php echo $LsbHdr['html']; ?>
<?php echo lsb_title($LsbInfo, $IsTeam ? '（団体決勝）' : '（個人決勝）', $LsbCtx); ?>
<?php echo $PanelHtml; ?>

<?php
	if (!$Sections) {
		echo '<div class="nodata">表示する対戦表がありません</div>';
	}

	foreach ($Sections as $evCode => $section) {
		if (empty($section['phases'])) continue;
		echo '<div class="event"><h2>' . esc($section['meta']['eventName'] ?: $evCode) . '</h2>';

		// 試合番号（偶数側）ごとに試合を引けるようにする
		$matches = [];
		foreach ($section['phases'] as $phase => $ph) {
			foreach ($ph['items'] as $item) {
				$matches[intval($item['matchNo'])] = ['item' => $item, 'phase' => intval($phase), 'phaseMeta' => $ph['meta']];
			}
		}
		if (!isset($matches[0])) {
			echo '<div class="nodata">まだ決勝の組み合わせがありません</div></div>';
			continue;
		}

		// 回戦ごとに、エンドごとの得点の枠の数と SO の有無を調べ、対戦枠の幅を決める
		// （幅 = 予選順位 ＋ 氏名・所属 ＋ 対戦スコア ＋ エンドごとの得点の表）
		$phN = [];
		$phSo = [];
		foreach ($matches as $e) {
			$k = ($e['phase'] == 1) ? 0 : $e['phase'];
			$o = function ($name) { return 'opp' . ucfirst($name); };
			$o2 = function ($name) { return $name; };
			foreach ([sideData($e['item'], '', $section, $e['phaseMeta'], $IsTeam, $o), sideData($e['item'], 'opp', $section, $e['phaseMeta'], $IsTeam, $o2)] as $sd) {
				$phN[$k] = max($phN[$k] ?? 0, count($sd['ends']));
				if ($sd['so'] !== '') $phSo[$k] = true;
			}
		}
		$GLOBALS['PhW'] = [];
		foreach ($phN as $k => $n) {
			$so = !empty($phSo[$k]);
			$endsW = $n ? ($n * 1.9 + ($so ? 2.1 : 0)) * 0.75 : 0;
			$GLOBALS['PhW'][$k] = [
				'mw' => round(($IsTeam ? 11.5 : 9.5) + 1.6 + 1.8 + $endsW + ($n ? 1 : 0.4), 1),
				'ew' => $n ? round($endsW + 0.7, 1) : 0,
				'so' => $so,
			];
		}

		// 見出し：決勝から左へ、回戦の数だけ並べる（試合の幅は match 17em ＋ つなぎ 14px×2）
		$phases = [];
		foreach ($matches as $m => $e) {
			if ($e['phase'] >= 2 && !in_array($e['phase'], $phases)) $phases[] = $e['phase'];
		}
		$phases[] = 0;
		rsort($phases);
		// 実際に木に載る回戦だけにする（3位決定戦は別枠）
		echo '<div class="scroll"><div class="tree' . ($IsTeam ? ' team' : '') . '" ">';
		echo '<div class="heads">';
		// 列の幅：試合の幅 ＋ つなぎ（左端と右端は片側だけ、間は両側）
		$nPh = count($phases);
		foreach ($phases as $i => $p) {
			$extra = ($nPh == 1) ? 0 : (($i == 0 || $i == $nPh - 1) ? 12 : 24);
			echo '<div style="width:calc(' . matchWidth($p)['mw'] . 'em + ' . $extra . 'px)">' . esc(phaseLabel($p)) . '</div>';
		}
		echo '</div>';
		echo renderNode(0, $matches, $section, $IsTeam, false);
		echo '</div></div>';

		echo '</div>';
	}
?>
<div class="upd">
  <?php echo $LastUpdate && $LastUpdate != '0000-00-00 00:00:00' ? '最終更新 ' . esc($LastUpdate) : ''; ?>
</div>
</body>
</html>
