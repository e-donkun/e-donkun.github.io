<?php
/*
ライブ得点集計の 3 つの画面（LiveScoreboard.php / LiveScoreboardTeam.php / LiveScoreboardFinal.php）で
共通に使う、画面の切り替えパネルと見出し。

パネルは 2 列。右下のインジケーター（Signage.php）と同じ、丸いボタンで切り替える。
  1 列目（3 つの画面すべてで同じ）
    セッション [すべて][セッション1][セッション2] ｜ [個人決勝] [団体予選] [団体決勝] ｜ [i@nseo.net]
      （[自動更新] は、見出しの会場・日程の後ろに出す）
      ・セッションのボタンは個人予選（LiveScoreboard.php）。セッションが 1 つだけなら [個人予選] だけにする
      ・設定のない画面（決勝のない個人、団体戦のない大会など）のボタンは出さない
  2 列目（画面ごと）
    各画面が、lsb_group() で作ったボタンの組を渡す

各画面は、共通で次の変数を使う。
  Tour  大会コード
  r     1 なら 30 秒ごとに自動で読み込み直す

変更履歴:
2026/10/06 表の箱（.table_box）を、画面の幅を超えるときは箱の中だけ横スクロールにする
2026/10/06 QR コードの URL を、ショートコードではなく、カスタムモジュールまでの正規の URL（LiveScoreboard.php?Tour=大会コード）にする
2026/10/06 右上のリンクと QR コードは、ianseo にログインして同じ大会を開いているときだけ出す（ほかは何も出さない）。URL は動かしているサイトから作る（ドメインを書かない）
2026/10/06 ianseo の標準メニューをやめ、右上に「大会情報を閲覧」のリンクと、QR コードを出すボタンだけにする
2026/10/06 ianseo のヘッダー（ログイン中だけ）で、Menu.php が出力する <script>・<link> が <!DOCTYPE> より前に出て、ブラウザが互換モードになり所属がはみ出す不具合を直す
2026/10/06 ランキングラウンドのボタンは、複数のクラスをまとめている種目（部門・性別・距離が同じ）があるときだけ出す（lsb_round_events を追加）
2026/10/06 団体予選は、得点の入力前でも、団体の設定（種目・団体に出る選手）があれば出す（lsb_team_candidates を追加）
2026/10/06 団体予選の「設定がある」を、画面が読む Teams の TeFinEvent=1 に合わせる
2026/10/01 初版
*/

function lsb_h($s) {
	return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// ---- 大会の情報（見出し・パネルに必要なもの）を調べる ----
function lsb_info($TourId) {
	$TourId = intval($TourId);
	$info = new stdClass();

	$info->tour = ['ToName' => '', 'ToWhere' => '', 'ToWhenFrom' => '', 'ToWhenTo' => '', 'ToCode' => '', 'ToOnlineId' => 0];
	$rs = safe_r_sql("SELECT ToName, ToWhere, ToWhenFrom, ToWhenTo, ToCode, ToOnlineId FROM Tournament WHERE ToId={$TourId}");
	if ($r = safe_fetch($rs)) {
		$info->tour = [
			'ToName' => $r->ToName, 'ToWhere' => $r->ToWhere, 'ToWhenFrom' => $r->ToWhenFrom,
			'ToWhenTo' => $r->ToWhenTo, 'ToCode' => $r->ToCode, 'ToOnlineId' => intval($r->ToOnlineId),
		];
	}

	// 個人予選のセッション
	$info->sessions = [];
	$rs = safe_r_sql("SELECT DISTINCT QuSession, SesName
		FROM Qualifications
		LEFT JOIN Entries ON EnId = QuId AND EnTournament = {$TourId} AND EnAthlete = 1
		LEFT JOIN Session ON SesTournament = {$TourId} AND SesOrder = QuSession AND SesType = 'Q'
		WHERE EnTournament = {$TourId}
		ORDER BY QuSession ASC");
	while ($r = safe_fetch($rs)) {
		$info->sessions[] = [
			'id' => intval($r->QuSession),
			'label' => ($r->SesName !== null && $r->SesName !== '') ? $r->SesName : 'Session ' . intval($r->QuSession),
		];
	}

	// 設定のある画面だけ出す
	$info->hasIndFinal = lsb_count_events($TourId, 0, true) > 0;
	$info->hasTeamQual = lsb_count_events($TourId, 1, false) > 0;
	$info->hasTeamFinal = lsb_count_events($TourId, 1, true) > 0;
	return $info;
}

// 種目の SQL の条件。「設定がある」とは、種目があるだけでなく、中身（選手・チーム）があること。
//   個人決勝: 決勝の対戦に選手が入っている ／ 団体決勝: 決勝の対戦にチームが入っている
//   団体予選: 団体のチームができている、または団体の種目に入る選手がいる（得点の入力前でもチームの組み方を見せる）
function lsb_event_cond($isTeam, $finalOnly) {
	if ($finalOnly) {
		return $isTeam
			? " AND EvFinalFirstPhase!=0 AND EXISTS (SELECT 1 FROM TeamFinals WHERE TfTournament=EvTournament AND TfEvent=EvCode AND TfTeam>0)"
			: " AND EvFinalFirstPhase!=0 AND EXISTS (SELECT 1 FROM Finals WHERE FinTournament=EvTournament AND FinEvent=EvCode AND FinAthlete>0)";
	}
	return $isTeam
		? " AND (EXISTS (SELECT 1 FROM Teams WHERE TeTournament=EvTournament AND TeEvent=EvCode AND TeFinEvent=1 AND TeCoId>0)" .
			" OR EXISTS (SELECT 1 FROM EventClass " . lsb_team_cand_join() . " WHERE EcTournament=EvTournament AND EcCode=EvCode AND EcTeamEvent>0 AND " . lsb_team_cand_where() . "))"
		: "";
}

// ---- 団体予選：チームの候補（得点の入力前の、チームの組み方） ----
// ianseo のチーム編成（MakeTeamsAbs）は、得点か射数のある選手だけをチームに入れるので、得点の入力前は Teams ができない。
// 団体予選も個人予選と同じ Entries / Qualifications を使うので、MakeTeamsAbs と同じ条件で候補を読み取り専用で組む
// （Teams には書かない）。種目（Events）と団体の設定（EventClass）は、呼び出す SQL の側にある。
function lsb_team_cand_country() {
	// チームの単位の国（EvTeamCreationMode で決まる。ifSqlForCountryWithJoin と同じ）
	return "IF(EvTeamCreationMode=0,IF(EnCountry2=0,EnCountry,EnCountry2),IF(EvTeamCreationMode=1,EnCountry,IF(EvTeamCreationMode=2,EnCountry2,EnCountry3)))";
}

// EventClass の次に続ける JOIN。団体の設定（部門・クラス・サブクラス）に合う選手
function lsb_team_cand_join() {
	$ctry = lsb_team_cand_country();
	return "INNER JOIN Entries ON EnTournament=EcTournament AND EnDivision=EcDivision AND EnClass=EcClass
			AND (EcSubClass='' OR EcSubClass='0' OR EnSubClass=EcSubClass)
			AND EnAthlete=1 AND EnStatus<=1 AND IF(EvMixedTeam=1, EnTeamMixEvent, EnTeamFEvent)=1 AND {$ctry}<>0
		INNER JOIN Qualifications ON QuId=EnId
		INNER JOIN IrmTypes ON IrmId=QuIrmType AND IrmShowRank=1
		LEFT JOIN ExtraData ON EdId=EnId AND EdType='P'";
}

function lsb_team_cand_where() {
	return "(EcExtraAddons=0 OR (EdExtra & EcExtraAddons)!=0)";
}

// 団体の種目ごとの、チームの候補。[種目コード => [チーム（AbsTeam の項目と同じ形）, ...]]
// 得点のない選手は得点を空にする。$events を渡すと、その種目だけ読む
function lsb_team_candidates($TourId, $events = []) {
	$ctry = lsb_team_cand_country();
	$ev = $events ? " AND EvCode IN (" . implode(',', array_map('StrSafe_DB', $events)) . ")" : "";
	$rs = safe_r_sql("SELECT DISTINCT EvCode, EvProgr, {$ctry} AS CoId, CoCode, CoName, EnSubTeam,
			EnId, EnFirstName, EnName, QuScore, QuGold, QuXnine, QuHits, QuSession, QuTarget, QuLetter
		FROM Events
		INNER JOIN EventClass ON EcTournament=EvTournament AND EcCode=EvCode AND EcTeamEvent>0
		" . lsb_team_cand_join() . "
		INNER JOIN Countries ON CoId={$ctry} AND CoTournament=EvTournament
		WHERE EvTournament=" . intval($TourId) . " AND EvTeamEvent=1{$ev} AND " . lsb_team_cand_where() . "
		ORDER BY EvProgr, EvCode, CoCode, EnSubTeam, QuSession, QuTarget, QuLetter, EnId");
	$out = [];
	while ($r = safe_fetch($rs)) {
		$key = $r->CoId . '-' . $r->EnSubTeam;
		if (!isset($out[$r->EvCode][$key])) {
			$out[$r->EvCode][$key] = [
				'id' => $r->CoId, 'subteam' => intval($r->EnSubTeam), 'countryName' => $r->CoName, 'athletes' => [],
				'rank' => '', 'score' => 0, 'hits' => 0, 'gold' => 0, 'xnine' => 0, 'irm' => 0, 'irmText' => '',
			];
		}
		$shot = ($r->QuScore != 0 || $r->QuHits != 0);
		$out[$r->EvCode][$key]['athletes'][] = [
			'id' => $r->EnId, 'familyname' => $r->EnFirstName, 'givenname' => $r->EnName,
			'quscore' => $shot ? $r->QuScore : '', 'qugolds' => $shot ? $r->QuGold : 0, 'quxnine' => $shot ? $r->QuXnine : 0,
		];
	}
	foreach ($out as $ev => $teams) $out[$ev] = array_values($teams);
	return $out;
}

function lsb_count_events($TourId, $isTeam, $finalOnly) {
	$rs = safe_r_sql("SELECT COUNT(*) AS n FROM Events WHERE EvTournament=" . intval($TourId) .
		" AND EvTeamEvent=" . intval($isTeam) . lsb_event_cond($isTeam, $finalOnly));
	$r = safe_fetch($rs);
	return $r ? intval($r->n) : 0;
}

// 種目の一覧（コード => 名前）。設定のある種目だけ
function lsb_events($TourId, $isTeam, $finalOnly) {
	$list = [];
	$rs = safe_r_sql("SELECT EvCode, EvEventName FROM Events WHERE EvTournament=" . intval($TourId) .
		" AND EvTeamEvent=" . intval($isTeam) . lsb_event_cond($isTeam, $finalOnly) . " ORDER BY EvProgr, EvCode");
	while ($r = safe_fetch($rs)) {
		$list[$r->EvCode] = $r->EvEventName ?: $r->EvCode;
	}
	return $list;
}

// ---- ランキングラウンドを出す種目 ----
// ランキングラウンドは種目ごとの順位。クラスごとの順位の画面と内容が変わるのは、1 つの種目が複数のクラスをまとめていて、
// そのクラス（選手が入っているもの）の部門・性別・距離がそろっているときだけ。そういう個人の種目の一覧（コード => 名前）を返す。
// 空ならランキングラウンドのボタンを出さない。
//   距離は、TournamentDistances の距離の名前（Td1〜Td8）で見る（距離の数値は 0 のことがあるため）。
//   名前は、入力ミスで違っていても同じ距離として扱う（全角・半角の違い 30ｍ と 30m、大文字・小文字、空白）。
function lsb_round_events($TourId) {
	$rs = safe_r_sql("SELECT DISTINCT EvCode, EvEventName, EvProgr, EcDivision, EcClass, ClSex, Td1, Td2, Td3, Td4, Td5, Td6, Td7, Td8
		FROM Events
		INNER JOIN Tournament ON ToId=EvTournament
		INNER JOIN EventClass ON EcTournament=EvTournament AND EcCode=EvCode AND EcTeamEvent=0
		INNER JOIN Classes ON ClTournament=EvTournament AND ClId=EcClass
		INNER JOIN Entries ON EnTournament=EvTournament AND EnAthlete=1 AND EnDivision=EcDivision AND EnClass=EcClass
			AND (EcSubClass='' OR EcSubClass='0' OR EnSubClass=EcSubClass)
		LEFT JOIN TournamentDistances ON TdTournament=EvTournament AND TdType=ToType AND CONCAT(EcDivision,EcClass) LIKE TdClasses
		WHERE EvTournament=" . intval($TourId) . " AND EvTeamEvent=0
		ORDER BY EvProgr, EvCode, EcDivision, EcClass, TdClasses");
	$ev = [];
	while ($r = safe_fetch($rs)) {
		$key = $r->EcDivision . '|' . $r->EcClass;
		if (isset($ev[$r->EvCode]['cls'][$key])) continue;	// 距離の設定が複数当たるときは、最初の 1 つだけ見る
		$td = [];
		for ($i = 1; $i <= 8; $i++) {
			$v = mb_strtolower(preg_replace('/\s+/u', '', mb_convert_kana((string)$r->{'Td' . $i}, 'as', 'UTF-8')), 'UTF-8');
			if ($v !== '') $td[] = $v;
		}
		$ev[$r->EvCode]['name'] = $r->EvEventName ?: $r->EvCode;
		$ev[$r->EvCode]['cls'][$key] = ['div' => $r->EcDivision, 'sex' => $r->ClSex, 'dist' => implode('/', $td)];
	}
	$list = [];
	foreach ($ev as $code => $e) {
		if (count($e['cls']) < 2) continue;
		$same = true;
		foreach (['div', 'sex', 'dist'] as $f) {
			if (count(array_unique(array_column($e['cls'], $f))) != 1) $same = false;
		}
		if ($same) $list[$code] = $e['name'];
	}
	return $list;
}

// ---- URL ----
// $file に $params（値が null・空のものは付けない。配列は name[]=a&name[]=b）を付ける
function lsb_url($file, $params) {
	$q = [];
	foreach ($params as $k => $v) {
		if ($v === null || $v === '' || $v === []) continue;
		if (is_array($v)) {
			foreach ($v as $x) $q[] = rawurlencode($k) . '[]=' . rawurlencode($x);
		} else {
			$q[] = rawurlencode($k) . '=' . rawurlencode($v);
		}
	}
	return $file . ($q ? '?' . implode('&', $q) : '');
}

// ---- ボタン ----
// $url が null ならリンクにしない。$cls は追加のクラス（LiveScoreboard 側の目印用）
function lsb_btn($label, $url, $on = false, $cls = '') {
	$c = 'lsb-btn' . ($on ? ' on' : '') . ($cls !== '' ? ' ' . $cls : '');
	if ($url === null) return '<span class="' . $c . '">' . lsb_h($label) . '</span>';
	return '<a class="' . $c . '" href="' . lsb_h($url) . '">' . lsb_h($label) . '</a>';
}

// ボタンの組（先頭に見出しの文字を付けられる）。空なら何も出さない
function lsb_group($label, $buttons) {
	if (!$buttons) return '';
	return '<span class="lsb-grp">' . ($label !== '' ? '<span class="lsb-label">' . lsb_h($label) . '</span>' : '') . implode('', $buttons) . '</span>';
}

// 組を、「｜」でつないで 1 行にする
function lsb_row($groups) {
	$groups = array_values(array_filter($groups, function ($g) { return $g !== ''; }));
	if (!$groups) return '';
	return '<div class="lsb-row">' . implode('<span class="lsb-sep">｜</span>', $groups) . '</div>';
}

/*
  パネル全体を作る。
  $cur      今の画面。'ind'（個人予選）/ 'indfinal'（個人決勝）/ 'team'（団体予選）/ 'teamfinal'（団体決勝）
  $info     lsb_info() の結果
  $ctx      ['code' => 大会コード, 'reload' => 自動更新か（自動更新のボタンは lsb_title で見出しに出す）, 'sessions' => 選ばれているセッション（個人予選のみ）,
             'event' => 種目の絞り込み（Event=RW,RM。団体予選・団体決勝で、行き来するときに引き継ぐ）,
             'indKeep' => 個人予選に付け足すパラメータ（個人予選の画面で表示順などを引き継ぐ）]
  $row2     2 列目の組の配列（lsb_group の結果）
*/
function lsb_panel($cur, $info, $ctx, $row2) {
	$code = $ctx['code'];
	$reload = !empty($ctx['reload']);
	$sel = $ctx['sessions'] ?? [];
	$keep = ($cur === 'ind') ? ($ctx['indKeep'] ?? []) : [];
	$base = ['Tour' => $code, 'r' => $reload ? 1 : null];

	// 画面の切り替え（設定のある画面だけ）
	$pages = [];
	if ($info->hasIndFinal) $pages[] = lsb_btn('個人決勝', lsb_url('LiveScoreboardFinal.php', $base), $cur === 'indfinal');
	// 団体予選と団体決勝を行き来するときは、種目の絞り込み（Event=RW など）を引き継ぐ
	$evCarry = ($cur === 'team' || $cur === 'teamfinal') ? ['Event' => ($ctx['event'] ?? null)] : [];
	if ($info->hasTeamQual) $pages[] = lsb_btn('団体予選', lsb_url('LiveScoreboardTeam.php', $base + $evCarry), $cur === 'team');
	if ($info->hasTeamFinal) $pages[] = lsb_btn('団体決勝', lsb_url('LiveScoreboardFinal.php', $base + ['Team' => 1] + $evCarry), $cur === 'teamfinal');

	// セッション（個人予選）
	$ses = [];
	if (count($info->sessions) >= 2) {
		$ses[] = lsb_btn('すべて', lsb_url('LiveScoreboard.php', $base + $keep), $cur === 'ind' && !$sel, 'session-toggle-btn all-btn');
		foreach ($info->sessions as $s) {
			$on = ($cur === 'ind') && in_array($s['id'], $sel);
			if ($cur === 'ind') {
				$next = $on ? array_values(array_diff($sel, [$s['id']])) : array_merge($sel, [$s['id']]);
				sort($next);
			} else {
				$next = [$s['id']];
			}
			$ses[] = lsb_btn($s['label'], lsb_url('LiveScoreboard.php', $base + $keep + ['s' => $next]), $on, 'session-toggle-btn');
		}
		$sesGroup = lsb_group('セッション', $ses);
	} else {
		// 個人予選しかない（ほかに行く画面がない）ときは、「個人予選」のボタンも出さない
		$sesGroup = $pages ? lsb_group('', [lsb_btn('個人予選', lsb_url('LiveScoreboard.php', $base + $keep), $cur === 'ind')]) : '';
	}

	// ianseo.net
	$net = [];
	if ($info->tour['ToOnlineId'] > 0) {
		$net[] = lsb_btn('i@nseo.net', 'https://www.ianseo.net/Details.php?toId=' . $info->tour['ToOnlineId'], false);
	}

	$row1 = lsb_row([$sesGroup, lsb_group('', $pages), lsb_group('', $net)]);
	$row2html = $row2 ? lsb_row($row2) : '';
	if ($row1 === '' && $row2html === '') return '';
	return '<div class="lsb-panel noprint">' . $row1 . $row2html . '</div>';
}

// ---- 自動更新のボタン（今の画面の条件のまま、r だけ切り替える）。見出しの日程の後ろに置く ----
// $ctx: ['reload' => 自動更新か, 'selfFile' => 今の画面のファイル名, 'self' => 今の画面の条件（r を除く）]
function lsb_auto($ctx) {
	$reload = !empty($ctx['reload']);
	$cur = $ctx['self'] ?? [];
	$btn = lsb_btn('自動更新', $ctx['selfFile'] . lsb_query($cur + ['r' => $reload ? null : 1]), $reload, 'lsb-auto');
	if ($reload) {
		// ボタンの中に、次の読み込みまでの秒数を出す
		$btn = str_replace('自動更新</a>', '自動更新 <span id="count">30</span></a>', $btn);
	}
	return '<span class="lsb-inline noprint">' . $btn . '</span>' . ($reload ? lsb_reload_script() : '');
}

// 画面自身の条件（パラメータ）の URL の後ろ半分（?…）を作る
function lsb_query($params) {
	$u = lsb_url('', $params);
	return $u;
}

// ---- 自動更新（30 秒）。スコアカードを開いている間（interval_flg が false）は止める ----
function lsb_reload_script() {
	return <<<'EOM'
<script>
var interval_flg = true;
(function () {
  var e = document.getElementById('count');
  if (!e) return;
  var c = 30;
  e.textContent = c;
  setInterval(function () {
    if (interval_flg) c--;
    e.textContent = c;
    if (c <= 0) location.reload();
  }, 1000);
})();
</script>
EOM;
}

// ---- 見出し（大会名・会場と日程。大会コードは出さない） ----
function lsb_title($info, $suffix = '', $ctx = null) {
	$t = $info->tour;
	$when = $t['ToWhenFrom'] . (($t['ToWhenTo'] && $t['ToWhenTo'] != $t['ToWhenFrom']) ? '～' . $t['ToWhenTo'] : '');
	return '<h1>' . lsb_h($t['ToName'] . $suffix) . '</h1>' .
		'<div>会場:' . lsb_h($t['ToWhere']) . ' (日程:' . lsb_h($when) . ')' . ($ctx ? ' ' . lsb_auto($ctx) : '') . '</div>';
}

// ---- パネルの見た目（背景は付けない。色は決勝の画面の青系） ----
function lsb_css() {
	return <<<'EOM'
/* 何かの出力が DOCTYPE より前に出て互換モードになっても、表の中の文字は周りと同じ大きさにする
   （互換モードでは、表の文字が 16px に戻り、rem で決めた列の幅から文字がはみ出す） */
table{ font-size:inherit; }
/* 表が画面の幅を超えるときは、ページ全体ではなく、表の箱の中だけを横スクロールにする */
.table_box{ max-width:100%; overflow-x:auto; }
.lsb-panel{
  display:flex;
  flex-direction:column;
  gap:3px;
  max-width:100%;
  box-sizing:border-box;
  margin:0.5em 0;
  color:#000;
  font-size:0.9rem;
  line-height:1.9;
  user-select:none;
}
.lsb-row{ display:flex; flex-wrap:wrap; align-items:center; gap:0.2em 0.1em; }
.lsb-grp{ display:inline-flex; flex-wrap:wrap; align-items:center; gap:0.2em 0.3em; }
.lsb-label{ margin-right:0.2em; color:#555; }
.lsb-sep{ color:#999; margin:0 0.6em; }
.lsb-btn{
  display:inline-block;
  padding:0 0.8em;
  border:1px solid #007db3;
  border-radius:4px;
  background:#fff;
  color:#007db3;
  text-decoration:none;
  white-space:nowrap;
  font-size:inherit;
  cursor:pointer;
}
.lsb-btn:hover{ background:#e6f7ff; }
.lsb-btn.on{
  background:#007db3;
  border-color:#007db3;
  color:#fff;
  font-weight:bold;
}
.lsb-btn.on:hover{ background:#006694; }
.lsb-inline{ font-size:0.9rem; margin-left:0.6em; vertical-align:baseline; }
.lsb-btn #count{ display:inline-block; min-width:1.5em; text-align:right; font-variant-numeric:tabular-nums; }
EOM;
}

// ---- 画面の右上：ianseo の大会情報（Main.php）へのリンクと、この大会のライブ得点集計の QR コードを出すボタン ----
// ianseo にログインしていて、同じ大会を開いているときだけ出す。そうでなければ何も出さない（メニューもリンクも出さない）。
// ianseo の標準メニューは出さない。
// リンクと QR コードの URL は、今動かしているサイトの URL（スキーム・ホスト・ianseo の置き場所）から作る。
// QR コードは TCPDF の 2D バーコード（QRCODE）で、サーバー側で SVG にして埋め込む（外部ライブラリ・通信なし）。
// 戻り値: ['css' => <style> の中に入れる CSS, 'html' => <body> の先頭に置く HTML]（出さないときは両方空）
function lsb_site_base() {
	global $CFG;
	$https = (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off')
		|| (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower(explode(',', $_SERVER['HTTP_X_FORWARDED_PROTO'])[0]) === 'https')
		|| (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
	$host = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
	return ($https ? 'https' : 'http') . '://' . $host . $CFG->ROOT_DIR;
}

function lsb_ianseo_header($TourId) {
	$none = ['css' => '', 'html' => ''];
	if (!function_exists('CheckTourSession') || !CheckTourSession()) return $none;
	if (empty($_SESSION['TourId']) || intval($_SESSION['TourId']) !== intval($TourId)) return $none;

	$code = '';
	$rs = safe_r_sql("SELECT ToCode FROM Tournament WHERE ToId=" . intval($TourId));
	if ($r = safe_fetch($rs)) $code = $r->ToCode;

	$base = lsb_site_base();
	$mainUrl = $base . 'Main.php';
	// QR コードは、ショートコードではなく、カスタムモジュールまでの正規の URL（大会コード付き）にする
	$qrUrl = $base . 'Modules/Custom/LiveScoreboard/LiveScoreboard.php?Tour=' . rawurlencode($code);

	require_once('Common/tcpdf/tcpdf_barcodes_2d.php');
	$bc = new TCPDF2DBarcode($qrUrl, 'QRCODE,M');
	$svg = $bc->getBarcodeSVGcode(5, 5, 'black');
	$svg = substr($svg, strpos($svg, '<svg'));	// xml 宣言と DOCTYPE は HTML の中に置けないので外す
	$svg = preg_replace('/<svg /', '<svg class="lsb-qr-svg" role="img" aria-label="QRコード" ', $svg, 1);

	$css = <<<'EOM'
.lsb-top{ display:flex; justify-content:flex-end; align-items:center; gap:0.4em; font-size:0.9rem; line-height:1.9; margin-bottom:0.3em; }
.lsb-top .lsb-btn{ font-family:inherit; }
dialog.lsb-qr{ border:1px solid #007db3; border-radius:6px; padding:1em 1.5em; text-align:center; }
dialog.lsb-qr::backdrop{ background:rgba(0,0,0,0.4); }
dialog.lsb-qr .lsb-qr-svg{ width:min(70vw, 16rem); height:auto; display:block; margin:0 auto 0.5em; }
dialog.lsb-qr .lsb-qr-url{ font-size:0.85rem; word-break:break-all; margin-bottom:0.6em; }
EOM;

	$html = '<div class="lsb-top noprint">'
		. '<a class="lsb-btn" href="' . lsb_h($mainUrl) . '">大会情報を閲覧</a>'
		. '<button type="button" class="lsb-btn" onclick="document.getElementById(\'lsb-qr\').showModal()">QRコード</button>'
		. '</div>'
		. '<dialog id="lsb-qr" class="lsb-qr noprint">' . $svg
		. '<div class="lsb-qr-url">' . lsb_h($qrUrl) . '</div>'
		. '<button type="button" class="lsb-btn" onclick="this.closest(\'dialog\').close()">閉じる</button></dialog>';
	return ['css' => $css, 'html' => $html];
}
