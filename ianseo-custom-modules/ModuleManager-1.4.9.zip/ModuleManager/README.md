# カスタムモジュール管理（ModuleManager）

`Modules/Custom` に置くカスタムモジュールを、WordPress のプラグインのように管理する仕組み。

メニューの「モジュール」→「カスタムモジュール」で開く（本体の「更新」を使える管理者だけ）。画面は 3 つ。

| 画面 | WordPress でいうと | できること |
|---|---|---|
| インストール済み（`index.php`） | インストール済みプラグイン | 有効・無効の切り替え、削除、更新の確認と「今すぐ更新」 |
| 新規追加（`Add.php`） | 新規プラグインを追加 | 配布サイトのカタログを受信して、選んでインストール・更新。zip のアップロード、URL からのインストール |
| パッケージ作成（`Package.php`） | （プラグインの作者が作る readme と zip） | パッケージ情報の編集、配布用 zip と catalog.json の作成 |

ianseo 本体のファイルは変えていない。`Modules/Custom` は本体の自動更新で消されないので（`Update/FileList.php`）、この仕組みも残る。

## 全体の流れ

```
[開発用の ianseo]                    [配布サイト]                    [会場の ianseo]
 パッケージ作成                        catalog.json                    新規追加
  ├ パッケージ情報を入れる              Sample-1.2.0.zip   ──受信──▶    ├ カタログを受信して一覧
  │ （動作確認した ianseo の版など）     ...                             ├ 選んでインストール（sha256 を確かめる）
  ├ zip を作る           ──置く──▶                                      └ インストール済みで「有効にする」
  └ catalog.json を作る  ──置く──▶                         ──ダウンロード──▶ zip をアップロード（ネットがない会場）
```

## パッケージ情報（module.json）

各モジュールのフォルダに置く。パッケージ作成の画面で編集できる。

```json
{
	"id": "SampleModule",
	"name": "サンプルモジュール",
	"description": "何をするモジュールか",
	"version": "1.2.0",
	"author": "作った人",
	"authorUrl": "https://example.com/",
	"homepage": "https://example.com/ianseo-modules/#sample",
	"license": "GPL-2.0",
	"testedIanseo": "2026-03-01 rev 255",
	"requiresIanseo": "2025-09-03",
	"requiresPhp": "8.0",
	"changelog": [
		{ "version": "1.2.0", "date": "2026-09-26", "notes": "〇〇を直した" },
		{ "version": "1.0.0", "date": "2026-08-01", "notes": "初版" }
	],
	"keep": ["data", "settings.csv"]
}
```

| 項目 | 画面の名前 | 内容 |
|---|---|---|
| `id` | フォルダ名（id） | `Modules/Custom` の下のフォルダ名（半角英数字と `_` `-`）。書かないときは zip の一番上のフォルダ名。GitHub の「Download ZIP」のようにフォルダ名に `-main` が付く zip でも、`id` があれば正しいフォルダ名で入る |
| `name` | パッケージ名 | 画面に出す名前 |
| `description` | 説明 | |
| `version` | パッケージの版 | `1.2.0` のような形。PHP の `version_compare()` で比べ、カタログのほうが新しければ「更新」を出す |
| `author` / `authorUrl` | 作者 / 作者の URL | |
| `homepage` | 配布ページ | 説明やダウンロードのページ |
| `license` | ライセンス | |
| `testedIanseo` | 動作確認した ianseo の版 | **パッケージを作るときに必須**。パッケージ作成の画面のボタンで、その ianseo の版を入れられる |
| `requiresIanseo` | 必要な ianseo の版 | これより古い ianseo には入れられない（有効にもできない） |
| `requiresPhp` | 必要な PHP の版 | これより古い PHP では入れられない（有効にもできない） |
| `changelog` | 変更履歴 | 新しい版が先頭。パッケージ作成の画面の「この版の変更点」で書く |
| `keep` | 更新しても残すもの | モジュールのフォルダからの相対パス。その会場で作った設定やデータの場所を書く。パッケージ（zip）には入れない |

`module.json` がないモジュールも一覧には出る（名前はフォルダ名、版はなし）。

### ianseo の版

本体は `ProgramVersion`（`2026-03-01` のような日付）と `ProgramBuild`（`rev 255` のような番号）で版を表す。パッケージ情報には `2026-03-01` か `2026-03-01 rev 255` の形で書く。

比べるときは、まず日付、同じ日付で両方に rev 番号があれば rev 番号も比べる。

| この ianseo と `testedIanseo` | 表示 |
|---|---|
| この ianseo ≦ 動作確認した版 | 「ianseo 〇〇 で動作確認済み」（緑） |
| この ianseo ＞ 動作確認した版 | 「この ianseo では未確認」（黄）。入れる・有効にすることはできるが、確認の画面とメッセージで注意を出す |
| 書かれていない | 「動作確認の記録なし」（灰） |

`requiresIanseo`・`requiresPhp` に足りないときは（赤）、インストールも有効にもできない。

## 更新の確認

WordPress と同じく、更新があるかを確認して知らせるだけで、自動では入れない。入れるのは管理者が「今すぐ更新」を押したとき。

- 更新があると、メニューの「モジュール」と「カスタムモジュール」に数のバッジ（赤い丸）を出す（WordPress の管理メニューの「プラグイン ②」と同じ）。インストール済みのタブにも数を出す
  - 数えるのは、受信したカタログのほうが新しい版で、この ianseo に入れられるもの（必要な ianseo・PHP の版を満たすもの）
  - バッジは管理者（本体の「更新」を使える人）にだけ出す
- インストール済みの画面
  - 更新があるモジュールの下に、黄色いお知らせ（新しい版、動作確認した ianseo の版、変更履歴の詳細、「今すぐ更新」）を出す
  - 「最終確認日時」と「更新を確認」ボタン（すぐに配布サイトを確認する）
- 確認のしかた
  - 配布サイトのカタログを受信するのは、「新規追加」の画面を開いたとき（待つのは 10 秒まで）と、「更新を確認」「保存して受信」「カタログを受信し直す」を押したときだけ。ほかの画面を開いたときに裏で受信することはしない
  - インストール済みの画面は自動では受信しない。前に確認してから 10 日（`State.php` の `CM_CHECK_INTERVAL`）以上たっていれば、「更新を確認」を押すよう促すお知らせを出す
  - 同時に何度も動かないよう、ロック（`.modules/check.lock`）で止める。確認した時刻とエラーは `.modules/check.json` に記録する（インストール済みの画面に出す）
  - 受信するとき、URL に `?_=時刻` を付け、`Cache-Control: no-cache` を送る（GitHub Pages などのキャッシュで古いカタログを受け取らないように）
- いつも同じ配布サイトを使うなら、`State.php` の `CM_DEFAULT_CATALOG_URL` に URL を書いておくと、画面で入れなくても確認する

## 有効・無効のしくみ

| | 有効 | 無効 |
|---|---|---|
| メニュー | `menu.php` を本体が読み込む | `menu.php` を `menu.php.disabled` に名前を変えるので、本体は読み込まない |
| ページ | 開ける | `Modules/Custom/config.php` を読み込んだところで 403 にする |
| ファイル | そのまま | そのまま（削除すると消える） |

- 状態は `Modules/Custom/.modules/state.json` に保存する（モジュール管理そのものを更新しても消えない）
- `Modules/Custom/menu.php` はメニューを作るたびに、`menu.php` の名前を状態にあわせる。FTP などで `menu.php` を置き直しても、無効のモジュールは無効のまま
- 新しくインストールしたモジュールは **無効** の状態で入る。「有効にする」を押すと使える
- 更新しても、有効・無効はそのまま
- 削除できるのは、無効にしたモジュールだけ
- モジュール管理（このフォルダ）は、無効にも削除にもできない

## モジュールの作り方

```
Modules/Custom/
  SampleModule/          ← フォルダ名がモジュールの id
    module.json          ← パッケージ情報
    menu.php             ← メニューに項目を足す（Modules/Custom/menu-dist.php を参照）
    index.php            ← 画面など
    ...
```

ページの最初で `Modules/Custom/config.php` を読み込む。これで、無効にしたときにページが開けなくなる。

```php
require_once(dirname(__DIR__) . '/config.php');   // Modules/Custom/config.php
```

- ianseo の `config.php`（ルート）を直接読み込むと、無効にしてもページは開けてしまう（メニューには出なくなる）
- 更新するときは、フォルダを丸ごと入れ替える（WordPress と同じ）。モジュールのフォルダの中に保存するデータは `keep` に書く
- メニューは `menu.php` の中だけに書く。`Modules/Custom/menu.php` に書くと、無効にしてもメニューが消えない

## パッケージ（配布用 zip）の作り方

1. パッケージ作成の画面でモジュールを選ぶ
2. パッケージ情報を入れる。新しい版を出すときは「パッケージの版」を上げ、「この版の変更点」を書く
3. この ianseo で動作を確かめたら、「この ianseo の版を入れる」を押す
4. 「保存してパッケージを作る」を押す → `Modules/Custom/.modules/packages/＜id＞-＜版＞.zip` ができる
5. 「zip をダウンロード」「catalog.json をダウンロード」「ダウンロードページ（index.html）をダウンロード」で取り出し、配布サイトの同じフォルダに置く

zip の中はこの形になる（手で作るときも同じ形にする）。

```
SampleModule-1.2.0.zip
  SampleModule/
    module.json
    menu.php
    ...
```

- `keep` に書いたものは入れない。無効にしていても `menu.php` の名前で入る
- 一番上にフォルダがなく、直接 `module.json` がある zip も入れられる（そのときは `module.json` に `id` が必要）
- `__MACOSX/`、`.DS_Store`、`Thumbs.db`、`.git/` は入れない
- 「..」などを含む危ないパスがある zip は入れない
- 展開した合計が 200MB まで、ファイル 20000 個まで

## 配布サイト

zip と `catalog.json`（パッケージの一覧）と `index.html`（ダウンロードページ）を同じフォルダに置く。

```
https://example.com/ianseo-modules/
  index.html                ← ダウンロードページ（site/index.html）
  catalog.json
  SampleModule-1.2.0.zip
  ...
```

### ダウンロードページ（site/index.html）

`catalog.json` を読んで、パッケージを一覧にするページ（WordPress のプラグインディレクトリのような形）。このファイルだけで動き、外部のファイルは読まない。

- 見出しは `catalog.json` の `title`、下に「一覧の更新」（`generated`）を出す
- 入れ方の説明と、ianseo の「新規追加」に入れる `catalog.json` の URL（コピーのボタンつき）を出す
- パッケージごとに、名前・作者・説明・版・動作確認した ianseo の版・必要な ianseo・PHP の版・更新日・ライセンス・フォルダ名、変更履歴、SHA-256、「ダウンロード」ボタン、zip の大きさを出す
- 名前・説明・作者で絞り込める
- `index.html#＜id＞` で開くと、そのパッケージへ移る。module.json の `homepage` を `https://…/ianseo-modules/#＜id＞` にしておくと、ianseo の画面の「配布ページ」から、そのパッケージが開く
- ほかの場所の `catalog.json` を読むときは、ページの中の `CATALOG_URL` を書き換える（そのサーバーで CORS を許可する）
- パソコンのファイルを直接開いた（file://）ときは、`catalog.json` を読めないので、配布サイトに置いてから開く
- 色はパソコン・スマホのダークモードにあわせる

### catalog.json

パッケージ作成の画面で作れる。作ったパッケージのうち、モジュールごとに一番新しい版を載せる。

```json
{
	"title": "〇〇の ianseo モジュール",
	"generated": "2026-09-26 10:00:00",
	"generator": "ianseo 2026-03-01 rev 255 / ModuleManager",
	"modules": [
		{
			"id": "SampleModule",
			"name": "サンプルモジュール",
			"description": "何をするモジュールか",
			"version": "1.2.0",
			"author": "作った人",
			"testedIanseo": "2026-03-01 rev 255",
			"requiresIanseo": "2025-09-03",
			"changelog": [ { "version": "1.2.0", "date": "2026-09-26", "notes": "〇〇を直した" } ],
			"download": "SampleModule-1.2.0.zip",
			"sha256": "3169c3c3af16d53c...",
			"size": 12345,
			"updated": "2026-09-26"
		}
	]
}
```

- 各パッケージの項目は module.json と同じ（`keep` はなし）。それに加えて:
  - `download`（必須）: zip の URL。`catalog.json` の場所からの相対 URL でもよい
  - `sha256`: zip の SHA-256。あれば、ダウンロードした zip と比べ、違えば入れない
  - `size`・`updated`: 画面に出すだけ
- `id` と `download` がないものは無視する。同じ `id` が複数あれば、版の新しいほうを使う
- カタログから入れるときは、zip の中の `id` がカタログの `id` と同じか確かめる

### 会場の ianseo での受信

- 新規追加の画面で `catalog.json` の URL を入れて「保存して受信」を押すと、パッケージが一覧になる
  - 名前・説明・作者で絞り込める
  - それぞれに、動作確認した ianseo の版、必要な版、変更履歴、この ianseo に入っている版を出す
  - まだ入れていないものに「インストール」、新しい版があるものに「更新」ボタンが出る
- 受信したカタログは `Modules/Custom/.modules/catalog.json` に保存する
  - 新規追加の画面を開いたとき、前に確認してから 12 時間たっていれば受信し直す（つながらないときは 10 秒であきらめ、前のカタログを出す）
  - 更新の確認（メニューのバッジ、インストール済みの画面のお知らせ）は、保存したカタログと比べて出す
- いつも同じ配布サイトを使うなら、`State.php` の `CM_DEFAULT_CATALOG_URL` に URL を書いておくと、画面で入れなくてもよい
- インターネットにつながっていない会場では、配布ページで zip をダウンロードしておき、「zip をアップロード」で入れる

## ファイル

| ファイル | 内容 |
|---|---|
| `index.php` | インストール済み（更新のお知らせ、更新を確認） |
| `Add.php` | 新規追加 |
| `Package.php` | パッケージ作成 |
| `Lib.php` | 一覧・有効無効・インストール・削除・カタログ・パッケージ作成の処理、画面の部品 |
| `Package.lib.php` | パッケージ情報の読み方、ianseo の版の比べ方、zip の中身の確かめ方（本体の関数を使わない） |
| `State.php` | 有効・無効の状態の読み書き、更新の数・確認の時期・メニューのバッジ（`Modules/Custom/config.php`・`Modules/Custom/menu.php`・`menu.php` から使う） |
| `menu.php` | モジュールメニューに「カスタムモジュール」を足す。更新の数のバッジと、確認の script を出す |
| `cm.css` | 画面の見た目 |
| `site/index.html` | 配布サイトのダウンロードページ |
| `../config.php` | 無効のモジュールのページを止める |
| `../menu.php` | 無効のモジュールの `menu.php` の名前を変える |
| `../.modules/` | 状態・受信したカタログ・更新の確認の記録・作ったパッケージ・作業用のフォルダ（git には入れない） |
