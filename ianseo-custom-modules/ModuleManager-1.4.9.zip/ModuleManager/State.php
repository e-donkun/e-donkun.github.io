<?php
/*
カスタムモジュール管理: 有効・無効の状態を読み書きする。
状態は Modules/Custom/.modules/state.json に保存する（モジュール管理そのものを更新しても消えない場所）。

このファイルは Modules/Custom/config.php（各モジュールのページ）と Modules/Custom/menu.php（メニュー）からも読み込むので、
ianseo 本体の関数を使わない軽い処理だけにする。

無効にしたモジュールは次のようにして止める。
- メニュー: 本体（Common/Menu.php）は Modules/Custom/＜モジュール＞/menu.php を読み込むので、menu.php を menu.php.disabled に名前を変える
- ページ: Modules/Custom/config.php を読み込んだところで、そのページが無効のモジュールのものなら 403 にする

更新の確認: 受信した配布サイトのカタログと、インストール済みのモジュールの版を比べて、更新の数をメニューに出す（ModuleManager/menu.php）。
カタログを受信するのは、「新規追加」（Add.php）を開いたときと、「更新を確認」などのボタンを押したときだけ。
ほかの画面を開いたときに、裏で受信することはしない。
前に確認してから CM_CHECK_INTERVAL たっていれば、「インストール済み」（index.php）に「更新を確認」を促すお知らせを出す。

変更履歴:
2026/11/13 Modules/Custom/config.php がなければ作る（cmEnsureCustomConfig。menu.php・Lib.php から呼ぶ）
2026/11/10 ほかの画面を開いたときに裏で受信する（cmCheckUpdatesBeacon）のをやめる。CM_CHECK_INTERVAL は確認を促すまでの日数（10 日）にする
2026/09/26 更新の数と、更新の確認の時期・script を追加
2026/09/26 初版
*/

/** モジュール管理そのもののフォルダ名（無効にも削除にもできない） */
define('CM_SELF', basename(__DIR__));
/** 配布サイトのカタログの URL（画面で入れていないときに使う） */
define('CM_DEFAULT_CATALOG_URL', '');
/** 前に確認してからこれだけ（秒）たつと、インストール済みの画面で「更新を確認」を促す（自動では受信しない） */
define('CM_CHECK_INTERVAL', 10 * 86400);

require_once(__DIR__ . '/Package.lib.php');

/** カスタムモジュールを置くフォルダ（Modules/Custom/） */
function cmCustomDir() {
	return dirname(__DIR__) . '/';
}

/**
 * Modules/Custom/config.php がなければ作る。
 * 各モジュールのページはこれを読み込み（なければ ianseo の config.php を読む）、無効にしたモジュールのページを止める。
 * どのモジュールの zip にも入っていないので、Modules/Custom を空にしてから入れ直したときなどに無くなる。
 */
function cmEnsureCustomConfig() {
	$File = cmCustomDir() . 'config.php';
	if(is_file($File) or !is_writable(cmCustomDir())) {
		return;
	}
	@file_put_contents($File, <<<'PHP'
<?php
require_once(dirname(dirname(__FILE__)).'/config.php');

// 無効にしたカスタムモジュールのページは開けないようにする（ModuleManager/State.php）
if(is_file(__DIR__ . '/ModuleManager/State.php')) {
	require_once(__DIR__ . '/ModuleManager/State.php');
	cmBlockDisabledModule();
}

PHP
	, LOCK_EX);
}

/** 状態・配布サイトの一覧・作業用のファイルを置くフォルダ（Modules/Custom/.modules/） */
function cmDataDir($Create = false) {
	$Dir = cmCustomDir() . '.modules/';
	if($Create and !is_dir($Dir)) {
		@mkdir($Dir, 0777, true);
		// Apache で直接開けないようにする
		@file_put_contents($Dir . '.htaccess', "Require all denied\n");
	}
	return $Dir;
}

/**
 * 状態を読む
 * - disabled: 無効にしたモジュールのフォルダ名
 * - catalogUrl: 配布サイトの一覧（catalog.json）の URL
 */
function cmLoadState() {
	$State = ['disabled' => [], 'catalogUrl' => ''];
	$File = cmDataDir() . 'state.json';
	if(is_file($File) and is_array($Json = json_decode((string)@file_get_contents($File), true))) {
		$State = array_merge($State, $Json);
	}
	$State['disabled'] = array_values(array_unique(array_filter(array_map('strval', (array)$State['disabled']))));
	$State['catalogUrl'] = (string)$State['catalogUrl'];
	return $State;
}

/** 状態を保存する */
function cmSaveState($State) {
	sort($State['disabled']);
	$File = cmDataDir(true) . 'state.json';
	return file_put_contents($File, json_encode($State, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
}

/** 無効にしたモジュールか（Windows ではフォルダ名の大文字・小文字を区別しないので、区別せずに比べる） */
function cmIsDisabled($Id, $State = null) {
	$State = $State ?? cmLoadState();
	foreach($State['disabled'] as $d) {
		if(strcasecmp($d, $Id) == 0) {
			return true;
		}
	}
	return false;
}

/**
 * モジュールのメニュー（menu.php）を本体に読み込ませるかどうかを切り替える
 * 無効のときは menu.php.disabled という名前にしておく
 */
function cmSetMenu($Id, $Enable) {
	$On = cmCustomDir() . $Id . '/menu.php';
	$Off = $On . '.disabled';
	if($Enable) {
		return is_file($On) or !is_file($Off) or @rename($Off, $On);
	}
	if(!is_file($On)) {
		return true;
	}
	if(is_file($Off)) {
		@unlink($Off);
	}
	return @rename($On, $Off);
}

/**
 * メニューのファイル名を状態にあわせる
 * FTP などで menu.php を置き直したときも、次にメニューを作るときに無効のままにする
 */
function cmSyncMenus($State = null) {
	$State = $State ?? cmLoadState();
	$Dir = cmCustomDir();
	foreach($State['disabled'] as $Id) {
		if(is_file($Dir . $Id . '/menu.php')) {
			cmSetMenu($Id, false);
		}
	}
	foreach(glob($Dir . '*/menu.php.disabled') ?: [] as $File) {
		$Id = basename(dirname($File));
		if(!cmIsDisabled($Id, $State)) {
			cmSetMenu($Id, true);
		}
	}
}

/** いま開いているページが、どのモジュールのものか（Modules/Custom/＜モジュール＞/ の下でなければ空文字） */
function cmModuleOfScript() {
	$Script = realpath($_SERVER['SCRIPT_FILENAME'] ?? '');
	$Base = realpath(cmCustomDir());
	if(!$Script or !$Base) {
		return '';
	}
	$Script = str_replace('\\', '/', $Script);
	$Base = rtrim(str_replace('\\', '/', $Base), '/') . '/';
	if(strncasecmp($Script, $Base, strlen($Base)) != 0) {
		return '';
	}
	$Rest = substr($Script, strlen($Base));
	$Pos = strpos($Rest, '/');
	return $Pos ? substr($Rest, 0, $Pos) : '';
}

/** 無効にしたモジュールのページなら、403 にして止める */
function cmBlockDisabledModule() {
	$Id = cmModuleOfScript();
	if($Id === '' or strcasecmp($Id, CM_SELF) == 0 or !cmIsDisabled($Id)) {
		return;
	}
	global $CFG;
	http_response_code(403);
	header('Content-Type: text/html; charset=utf-8');
	echo '<!DOCTYPE html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
		. '<title>無効のモジュール</title></head><body style="font-family:sans-serif;padding:1em;">'
		. '<p>カスタムモジュール「' . htmlspecialchars($Id) . '」は無効になっています。</p>'
		. '<p>使うときは、管理者がメニューの「モジュール」→「カスタムモジュール」で有効にしてください。</p>'
		. (empty($CFG->ROOT_DIR) ? '' : '<p><a href="' . htmlspecialchars($CFG->ROOT_DIR) . '">トップページへ</a></p>')
		. '</body></html>';
	exit;
}

/** 配布サイトのカタログの URL（画面で入れたもの。なければ CM_DEFAULT_CATALOG_URL） */
function cmCatalogUrl($State = null) {
	$State = $State ?? cmLoadState();
	return $State['catalogUrl'] !== '' ? $State['catalogUrl'] : CM_DEFAULT_CATALOG_URL;
}

/** 受信したカタログの保存場所 */
function cmCatalogFile() {
	return cmDataDir() . 'catalog.json';
}

/** 更新の確認の記録（Modules/Custom/.modules/check.json）: lastCheck = 最後に確認した時刻、error = そのときのエラー */
function cmLoadCheck() {
	$Check = ['lastCheck' => 0, 'error' => ''];
	$File = cmDataDir() . 'check.json';
	if(is_file($File) and is_array($Json = json_decode((string)@file_get_contents($File), true))) {
		$Check = array_merge($Check, $Json);
	}
	// 新規追加の画面などで受信したときも、確認したことにする
	if(is_file(cmCatalogFile()) and ($t = filemtime(cmCatalogFile())) > intval($Check['lastCheck'])) {
		$Check = ['lastCheck' => $t, 'error' => ''];
	}
	$Check['lastCheck'] = intval($Check['lastCheck']);
	$Check['error'] = (string)$Check['error'];
	return $Check;
}

function cmSaveCheck($Check) {
	return file_put_contents(cmDataDir(true) . 'check.json', json_encode($Check, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
}

/** 更新の確認を促す時期か（カタログの URL があり、前に確認してから CM_CHECK_INTERVAL たった。まだ確認していないときも） */
function cmCheckDue() {
	return cmCatalogUrl() !== '' and time() - cmLoadCheck()['lastCheck'] >= CM_CHECK_INTERVAL;
}

/**
 * 更新があるモジュール（受信したカタログのほうが新しい版で、この ianseo に入れられるもの）
 * id => ['name' => 名前, 'from' => 今の版, 'to' => カタログの版]
 * 軽い処理にするため、受信済みのカタログと module.json を比べるだけ
 */
function cmUpdates() {
	$Url = cmCatalogUrl();
	$Catalog = ($Url !== '' and is_file(cmCatalogFile())) ? json_decode((string)@file_get_contents(cmCatalogFile()), true) : null;
	if(!is_array($Catalog) or ($Catalog['url'] ?? '') !== $Url or !is_array($Catalog['modules'] ?? null)) {
		return [];
	}
	$Ret = [];
	foreach($Catalog['modules'] as $c) {
		if(!is_array($c) or !cmValidId($c['id'] ?? null) or !is_file($File = cmCustomDir() . $c['id'] . '/module.json')) {
			continue;
		}
		$Meta = cmReadMeta(@file_get_contents($File));
		$From = is_scalar($Meta['version'] ?? null) ? (string)$Meta['version'] : '';
		$To = is_scalar($c['version'] ?? null) ? (string)$c['version'] : '';
		if($From === '' or $To === '' or !version_compare($To, $From, '>') or cmCompat($c)['problems']) {
			continue;
		}
		$Ret[$c['id']] = ['name' => (string)($c['name'] ?? $c['id']), 'from' => $From, 'to' => $To];
	}
	return $Ret;
}

/**
 * メニューに出す、更新の数のバッジ（WordPress の管理メニューの「プラグイン ②」のようなもの）
 * 本体はメニューの文字を「文字|URL」で分けるので、「|」は使わない
 */
function cmUpdateBadge($Count) {
	return ' <span data-cm-updates="1" title="更新が ' . $Count . ' 件あります" style="display:' . ($Count ? 'inline-block' : 'none') . ';min-width:1.5em;margin-left:0.3em;padding:0 0.4em;box-sizing:border-box;border-radius:0.75em;background:#d63638;color:#fff;font-size:80%;font-weight:bold;line-height:1.5em;text-align:center;">' . $Count . '</span>';
}
