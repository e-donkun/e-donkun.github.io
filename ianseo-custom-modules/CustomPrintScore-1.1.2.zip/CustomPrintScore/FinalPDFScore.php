<?php
/*
個人・団体決勝の予備のブランクスコアカード（PDF）
FinalPrintScore.php から呼ぶ。描画は CustomFinalScorecardsLib.php で行う。

パラメーター:
  Team    0: 個人、1: 団体
  Format  CustomFinalBlankFormats() の書式のキー
  Pages   ページ数（1ページに1試合分）
  SetupQr 1 なら ISK-NG の設定用QRコードを印字する

変更履歴:
2026/10/13 初版
*/
require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php
require_once(dirname(__FILE__) . '/CustomFinalScorecardsLib.php');
CheckTourSession(true);

$Team=(empty($_REQUEST['Team']) ? 0 : 1);
checkFullACL(($Team ? AclTeams : AclIndividuals), '', AclReadOnly);

$Formats=CustomFinalBlankFormats($Team);
$Key=($_REQUEST['Format'] ?? '');
if(empty($Formats[$Key])) {
	// 書式の指定がない・合わないときは最初の書式
	if(!$Formats) {
		die('決勝の種目がありません');
	}
	$Key=array_key_first($Formats);
}

$pdf=CustomCreateFinalBlankScorecard($Team, $Formats[$Key], intval($_REQUEST['Pages'] ?? 1), !empty($_REQUEST['SetupQr']));
$pdf->Output();
