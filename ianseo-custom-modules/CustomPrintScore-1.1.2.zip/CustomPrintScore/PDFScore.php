<?php
/*
Qualification/PDFScore.php のカスタム版。
スコアカードの生成は CustomCreateSessionScorecard()（CustomScorecardsLib.php）で行う。

変更履歴:
2026/09/25 予備のブランクスコアカード（BlankScore=1）の出力を追加
2026/09/23 すべてのセッションもセッション単位の処理と同じ関数で1つのPDFに描画
2026/09/23 セッション「---」ですべてのセッションを印刷
2026/09/23 初版
*/
require_once(is_file(dirname(__DIR__) . '/config.php') ? dirname(__DIR__) . '/config.php' : dirname(__DIR__, 3) . '/config.php'); // Modules/Custom/config.php がなければ ianseo の config.php
require_once('Common/pdf/ScorePDF.inc.php');
require_once('Common/Fun_FormatText.inc.php');
require_once('Common/Fun_Sessions.inc.php');
require_once(dirname(__FILE__) . '/CustomScorecardsLib.php');
checkFullACL(AclQualification, '', AclReadOnly);

$Session=intval($_REQUEST['x_Session']);

// 予備のブランクスコアカード
if(!empty($_REQUEST['BlankScore'])) {
	$pdf=CustomCreateBlankScorecard($Session, $_REQUEST);
	$pdf->output();
	exit;
}

if(!empty($_REQUEST['SessionType']) and $_REQUEST['SessionType']=='E') {
	$Session=$_REQUEST['x_ElimSession'];
	$_REQUEST['x_Phase']=intval($_REQUEST['x_Session']);
	$_REQUEST['ScoreDist']=array(1);
}

// セッション「---」（-1）のときは、すべてのセッションを1つのPDFに印刷する
$pdf=CustomCreateSessionScorecard($Session, $_REQUEST['x_From'], (empty($_REQUEST['x_To']) ? $_REQUEST['x_From'] : $_REQUEST['x_To']), $_REQUEST);
$pdf->output();
