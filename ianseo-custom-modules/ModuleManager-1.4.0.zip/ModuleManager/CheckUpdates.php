<?php
/*
カスタムモジュール管理: 更新の確認（バックグラウンド）。
確認の時期に管理者が ianseo の画面を開くと、ModuleManager/menu.php が出す script からこのページを呼ぶ。
配布サイトのカタログを受信し直すだけで、モジュールは入れない（入れるのは、インストール済みの画面の「今すぐ更新」）。
確認の時期（前に確認してから CM_CHECK_INTERVAL）でなければ、何もしない。
返すもの: {"count": 更新があるモジュールの数}（メニューのバッジに使う）

変更履歴:
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if(!cmCanManage()) {
	http_response_code(403);
	echo json_encode(['count' => 0]);
	exit;
}

// 画面を移っても最後まで続け、呼んだ人のほかの画面を待たせないように、セッションはすぐ閉じる
ignore_user_abort(true);
@set_time_limit(120);
if(session_status() == PHP_SESSION_ACTIVE) {
	session_write_close();
}

cmCheckUpdates(false);
echo json_encode(['count' => count(cmUpdates())]);
