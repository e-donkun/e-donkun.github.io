<?php
/*
カスタムモジュール管理: パッケージ情報（module.json・catalog.json）と、ianseo の版の比べ方。
ianseo 本体の関数は使わない。

パッケージ情報の項目は README.md を参照。

変更履歴:
2026/09/26 初版
*/

/**
 * パッケージ情報の項目（module.json と catalog.json で共通）
 * キー => 画面に出す名前
 */
function cmMetaLabels() {
	return [
		'id' => 'フォルダ名（id）',
		'name' => 'パッケージ名',
		'description' => '説明',
		'version' => 'パッケージの版',
		'author' => '作者',
		'authorUrl' => '作者の URL',
		'homepage' => '配布ページ',
		'license' => 'ライセンス',
		'testedIanseo' => '動作確認した ianseo の版',
		'requiresIanseo' => '必要な ianseo の版（これ以降）',
		'requiresPhp' => '必要な PHP の版（これ以降）',
	];
}

/** JSON を読む（BOM があってもよい）。読めなければ ['_error' => 理由] */
function cmReadMeta($Json) {
	if($Json === false or $Json === null) {
		return null;
	}
	$Json = preg_replace('/^\xEF\xBB\xBF/', '', $Json);
	$Meta = json_decode($Json, true);
	if(!is_array($Meta)) {
		return ['_error' => 'module.json を読めません（' . json_last_error_msg() . '）'];
	}
	return $Meta;
}

/**
 * パッケージ情報をそろえる（文字列の項目は必ずあり、changelog は配列、keep は安全なパスだけ）
 */
function cmNormalizeMeta($Meta) {
	$Meta = is_array($Meta) ? $Meta : [];
	$Ret = [];
	foreach(array_keys(cmMetaLabels()) as $k) {
		$Ret[$k] = is_scalar($Meta[$k] ?? null) ? trim((string)$Meta[$k]) : '';
	}
	$Ret['changelog'] = [];
	foreach((array)($Meta['changelog'] ?? []) as $c) {
		if(is_array($c) and trim((string)($c['version'] ?? '')) !== '') {
			$Ret['changelog'][] = [
				'version' => trim((string)$c['version']),
				'date' => trim((string)($c['date'] ?? '')),
				'notes' => trim((string)($c['notes'] ?? '')),
			];
		}
	}
	$Ret['keep'] = cmKeepPaths($Meta);
	return $Ret;
}

/** module.json の keep（更新しても残すファイル・フォルダ）を、安全な相対パスだけにして返す */
function cmKeepPaths($Meta) {
	$Ret = [];
	foreach((array)($Meta['keep'] ?? []) as $p) {
		$p = trim(str_replace('\\', '/', (string)$p), '/');
		if($p !== '' and cmSafeRelPath($p)) {
			$Ret[] = $p;
		}
	}
	return array_values(array_unique($Ret));
}

/** 相対パスとして安全か（絶対パス・ドライブ名・「.」「..」・制御文字を含まない） */
function cmSafeRelPath($p) {
	return !preg_match('#(^/|^[A-Za-z]:|(^|/)\.\.?(/|$)|[\x00-\x1f])#', $p);
}

/** モジュールのフォルダ名として使える文字か */
function cmValidId($Id) {
	return is_string($Id) and preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/', $Id);
}

/** パッケージの版として使える形か（1.2.0、1.2.0-beta1 など） */
function cmValidVersion($v) {
	return is_string($v) and preg_match('/^\d+(\.\d+){0,3}([-+.]?[A-Za-z0-9]+)*$/', $v);
}

/**
 * ianseo の版
 * 本体は ProgramVersion（2026-03-01 のような日付）と ProgramBuild（rev 255 のような番号）で表す
 * ここでは「2026-03-01」または「2026-03-01 rev 255」の形で書く
 */
function cmIanseoCurrent() {
	if(!defined('ProgramVersion')) {
		return '';
	}
	return ProgramVersion . (defined('ProgramBuild') ? ' ' . ProgramBuild : '');
}

/** ianseo の版を [日付, rev 番号（なければ null）] にする。読めなければ null */
function cmIanseoParse($v) {
	if(!preg_match('/^\s*(\d{4})[-.\/](\d{1,2})[-.\/](\d{1,2})(?:[\s(]*rev\.?\s*(\d+)\)?)?\s*$/i', (string)$v, $m)) {
		return null;
	}
	return [sprintf('%04d-%02d-%02d', $m[1], $m[2], $m[3]), isset($m[4]) && $m[4] !== '' ? intval($m[4]) : null];
}

/** ianseo の版として使える形か */
function cmValidIanseo($v) {
	return cmIanseoParse($v) !== null;
}

/**
 * ianseo の版を比べる（-1, 0, 1）。どちらかが読めなければ null
 * 日付を比べ、同じ日付で両方に rev 番号があれば rev 番号も比べる
 */
function cmIanseoCompare($a, $b) {
	$a = cmIanseoParse($a);
	$b = cmIanseoParse($b);
	if(!$a or !$b) {
		return null;
	}
	if($c = strcmp($a[0], $b[0])) {
		return $c < 0 ? -1 : 1;
	}
	if($a[1] === null or $b[1] === null) {
		return 0;
	}
	return $a[1] <=> $b[1];
}

/**
 * この ianseo で使えるか（WordPress の「Requires at least」「Tested up to」と同じ考え方）
 * - problems: 必要な版に足りないもの（あれば、インストールも有効にもできない）
 * - tested: 'yes' = 動作確認した版まで（この ianseo の版 <= 動作確認した版）
 *           'no'  = この ianseo のほうが新しく、まだ動作確認されていない
 *           ''    = 動作確認した版が書かれていない（またはこの ianseo の版がわからない）
 * - note: 画面に出す短い説明
 */
function cmCompat($Meta, $Current = null, $Php = PHP_VERSION) {
	$Meta = cmNormalizeMeta($Meta);
	$Current = $Current ?? cmIanseoCurrent();
	$Problems = [];
	if($Meta['requiresIanseo'] !== '' and $Current !== '' and cmIanseoCompare($Current, $Meta['requiresIanseo']) === -1) {
		$Problems[] = 'ianseo ' . $Meta['requiresIanseo'] . ' 以降が必要です（この ianseo は ' . $Current . '）。';
	}
	if($Meta['requiresPhp'] !== '' and version_compare($Php, $Meta['requiresPhp'], '<')) {
		$Problems[] = 'PHP ' . $Meta['requiresPhp'] . ' 以降が必要です（この PHP は ' . $Php . '）。';
	}
	$Tested = '';
	$Note = '動作確認の記録なし';
	if($Meta['testedIanseo'] !== '') {
		$c = ($Current === '' ? null : cmIanseoCompare($Current, $Meta['testedIanseo']));
		if($c === null) {
			$Note = 'ianseo ' . $Meta['testedIanseo'] . ' で動作確認';
		} elseif($c <= 0) {
			$Tested = 'yes';
			$Note = 'ianseo ' . $Meta['testedIanseo'] . ' で動作確認済み';
		} else {
			$Tested = 'no';
			$Note = '未確認（ianseo ' . $Meta['testedIanseo'] . ' まで確認）';
		}
	}
	return ['problems' => $Problems, 'tested' => $Tested, 'note' => $Note];
}

/**
 * zip の中身を確かめて、モジュールの場所とパッケージ情報を探す
 *
 * zip の形:
 *   ＜モジュールのフォルダ名＞/module.json
 *   ＜モジュールのフォルダ名＞/menu.php
 *   ＜モジュールのフォルダ名＞/...
 * 一番上にフォルダが 1 つだけあり、その中に module.json か menu.php があること。
 * module.json に id があれば、それをフォルダ名にする（GitHub の「Download ZIP」のように、フォルダ名に -main などが付いていてもよい）。
 * 一番上にフォルダがなく、直接 module.json がある zip は、module.json に id が必要。
 *
 * 返すもの: ['entries' => 名前 => 番号, 'prefix' => 'フォルダ/', 'id' => フォルダ名, 'meta' => module.json の中身]
 * または ['error' => 理由]
 */
function cmZipInspect(ZipArchive $Zip, $MaxFiles = 20000, $MaxBytes = 209715200) {
	if($Zip->numFiles == 0 or $Zip->numFiles > $MaxFiles) {
		return ['error' => 'zip の中のファイルの数が ' . ($Zip->numFiles ? '多すぎます' : '0 です') . '。'];
	}
	$Entries = [];
	$Size = 0;
	for($i = 0; $i < $Zip->numFiles; $i++) {
		$St = $Zip->statIndex($i);
		$Name = str_replace('\\', '/', $St['name']);
		if($Name === '' or preg_match('#(^|/)(__MACOSX|\.git)(/|$)|(^|/)(\.DS_Store|Thumbs\.db)$#', $Name)) {
			continue;
		}
		if(!cmSafeRelPath(rtrim($Name, '/'))) {
			return ['error' => 'zip の中に使えない名前のファイルがあります: ' . $Name];
		}
		$Size += $St['size'];
		if($Size > $MaxBytes) {
			return ['error' => 'zip を展開すると大きすぎます（' . round($MaxBytes / 1024 / 1024) . 'MB まで）。'];
		}
		$Entries[$Name] = $i;
	}

	// 一番上のフォルダを探す
	$Tops = [];
	$RootFiles = false;
	foreach(array_keys($Entries) as $Name) {
		$Pos = strpos($Name, '/');
		if($Pos === false) {
			$RootFiles = true;
		} else {
			$Tops[substr($Name, 0, $Pos)] = true;
		}
	}
	$Folder = (!$RootFiles and count($Tops) == 1) ? array_key_first($Tops) : '';
	$Prefix = ($Folder === '' ? '' : $Folder . '/');
	if(!isset($Entries[$Prefix . 'module.json']) and !isset($Entries[$Prefix . 'menu.php'])) {
		return ['error' => 'ianseo のカスタムモジュールの zip ではないようです（' . ($Prefix === '' ? 'zip の一番上' : $Folder . ' フォルダ') . 'に module.json も menu.php もありません）。'];
	}

	$Meta = isset($Entries[$Prefix . 'module.json']) ? cmReadMeta($Zip->getFromIndex($Entries[$Prefix . 'module.json'])) : [];
	if(!empty($Meta['_error'])) {
		return ['error' => $Meta['_error']];
	}
	$Id = is_scalar($Meta['id'] ?? null) && (string)$Meta['id'] !== '' ? (string)$Meta['id'] : $Folder;
	if($Id === '') {
		return ['error' => 'zip の一番上にモジュールのフォルダを 1 つだけ入れるか、module.json に id を書いてください。'];
	}
	if(!cmValidId($Id)) {
		return ['error' => 'モジュールのフォルダ名「' . $Id . '」は使えません（半角の英数字と _ - だけにしてください）。'];
	}
	return ['entries' => $Entries, 'prefix' => $Prefix, 'id' => $Id, 'meta' => $Meta];
}

/**
 * catalog.json の 1 件をそろえる（パッケージ情報 + download・sha256・size・updated）
 * 使えないもの（id や download がない）は null
 */
function cmNormalizeCatalogEntry($m, $BaseUrl = '') {
	if(!is_array($m) or !cmValidId($m['id'] ?? null) or empty($m['download']) or !is_string($m['download'])) {
		return null;
	}
	$Ret = cmNormalizeMeta($m);
	unset($Ret['keep']);
	if($Ret['name'] === '') {
		$Ret['name'] = $Ret['id'];
	}
	$Ret['homepage'] = cmResolveUrl($BaseUrl, $Ret['homepage']);
	$Ret['authorUrl'] = cmResolveUrl($BaseUrl, $Ret['authorUrl']);
	$Ret['download'] = cmResolveUrl($BaseUrl, $m['download']);
	$Ret['sha256'] = (is_string($m['sha256'] ?? null) and preg_match('/^[0-9a-f]{64}$/i', $m['sha256'])) ? strtolower($m['sha256']) : '';
	$Ret['size'] = intval($m['size'] ?? 0);
	$Ret['updated'] = is_scalar($m['updated'] ?? null) ? (string)$m['updated'] : '';
	return $Ret;
}

/** catalog.json の中の相対 URL を、catalog.json の場所をもとに絶対 URL にする */
function cmResolveUrl($Base, $Url) {
	if($Url === '' or preg_match('#^https?://#i', $Url) or $Base === '') {
		return $Url;
	}
	if(!preg_match('#^(https?://[^/]+)(/[^?\#]*)?#i', $Base, $m)) {
		return $Url;
	}
	if($Url[0] == '/') {
		return $m[1] . $Url;
	}
	$Path = ($m[2] ?? '') === '' ? '/' : $m[2];
	return $m[1] . substr($Path, 0, strrpos($Path, '/') + 1) . $Url;
}

/** http(s) の URL だけを返す（リンクに使う） */
function cmHttpUrl($Url) {
	return preg_match('#^https?://#i', (string)$Url) ? (string)$Url : '';
}
