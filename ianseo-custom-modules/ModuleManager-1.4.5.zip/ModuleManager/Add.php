<?php
/*
カスタムモジュール管理: 新規追加（WordPress の「新規プラグインを追加」のような画面）。
- 配布サイトのカタログ（catalog.json）を受信して、パッケージを一覧にする。選んでインストール・更新する
  前に確認してから CM_CHECK_INTERVAL 秒たっていれば、画面を開いたときに受信し直す
- 配布サイトからダウンロードした zip をアップロードしてインストールする（インターネットにつながっていない会場用）
新しいモジュールは無効の状態で入る。
管理者（本体の「更新」を使える人）だけが使える。

変更履歴:
2026/11/10 「URL からインストール」をやめ、zip の欄の説明を減らす
2026/11/09 表記を整理。インストール済みは「入れ直す」をやめ、無効のボタン「インストール済み(版)」、新しい版は「更新(旧→新)」
2026/09/26 初版（index.php から分ける。カタログから選んでインストール）
*/
require_once(__DIR__ . '/Lib.php');

if(!cmCanManage()) {
	CD_redirect($CFG->ROOT_DIR . 'noAccess.php');
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	cmRequireToken('Add.php');
	@set_time_limit(600);
	switch($_POST['act'] ?? '') {
		case 'install':
			$Ret = cmInstallFromCatalog((string)($_POST['id'] ?? ''));
			break;
		case 'upload':
			$Ret = cmInstallUpload($_FILES['zip'] ?? null);
			break;
		case 'catalogUrl':
			$State = cmLoadState();
			$State['catalogUrl'] = trim((string)($_POST['url'] ?? ''));
			cmSaveState($State);
			$Ret = cmCatalogUrl($State) === '' ? [true, '配布サイトのカタログの URL を消しました。'] : cmFetchCatalog(cmCatalogUrl($State));
			break;
		case 'fetch':
			$Ret = cmFetchCatalog(cmCatalogUrl());
			break;
		default:
			$Ret = [false, 'わからない操作です。'];
	}
	// インストールしたら、インストール済みの画面で有効にできるようにする
	cmDone($Ret, ($Ret[0] and in_array($_POST['act'] ?? '', ['install', 'upload'])) ? 'index.php' : 'Add.php');
}

$CatalogUrl = cmCatalogUrl();
$Catalog = cmLoadCatalog($CatalogUrl);
$FetchError = '';
// 前に受信してから時間がたっていれば、受信し直す（つながらない会場で待たされないよう、短めに待つ）
if($CatalogUrl !== '' and (!$Catalog or cmCheckDue())) {
	$Ret = cmFetchCatalog($CatalogUrl, 10);
	if($Ret[0]) {
		$Catalog = cmLoadCatalog($CatalogUrl);
	} else {
		$FetchError = $Ret[1];
	}
}
$Mods = cmModules();

cmPageHead('カスタムモジュールの追加', 'Add.php');

// 配布サイト
echo '<table class="Tabella cmTable">';
echo '<tr><th colspan="2" class="Main">配布サイトから追加</th></tr>';
echo '<tr><th class="SubTitle">カタログの URL</th><td class="Left">'
	. '<form method="post" class="cmInline">'
	. '<input type="hidden" name="token" value="' . htmlspecialchars(cmToken()) . '">'
	. '<input type="hidden" name="act" value="catalogUrl">'
	. '<input type="url" name="url" value="' . htmlspecialchars(cmLoadState()['catalogUrl']) . '" placeholder="' . htmlspecialchars(CM_DEFAULT_CATALOG_URL ?: 'https://example.com/ianseo-modules/catalog.json') . '"> '
	. '<input type="submit" value="保存して受信">'
	. '</form>'
	. ($CatalogUrl !== '' ? cmButton('fetch', 'カタログを受信し直す') : '')
	. '<div class="cmNote">配布サイトに置いた catalog.json の URLを設定。'
	. ($Catalog ? '<br>最後に受信した日時: ' . htmlspecialchars($Catalog['fetched']) : '')
	. '</div>'
	. ($FetchError !== '' ? '<div class="cmErr">' . htmlspecialchars($FetchError) . ($Catalog ? '（前に受信したカタログを出しています）' : '') . '</div>' : '')
	. '</td></tr>';
echo '</table>';

if($Catalog) {
	echo '<p><input type="search" class="cmSearch" placeholder="パッケージを探す（名前・説明・作者）" oninput="cmFilter(this.value)"></p>';
	echo '<div class="cmCards">';
	foreach($Catalog['modules'] as $c) {
		$m = cmFindModule($Mods, $c['id']);
		$Compat = cmCompat($c);
		$Search = mb_strtolower($c['id'] . ' ' . $c['name'] . ' ' . $c['description'] . ' ' . $c['author']);
		echo '<div class="cmCard" data-search="' . htmlspecialchars($Search) . '">';
		echo '<div><span class="cmName">' . htmlspecialchars($c['name']) . '</span> ' . htmlspecialchars($c['version']) . '<br><span class="cmId">' . htmlspecialchars($c['id']) . '</span></div>';
		echo '<div class="cmDesc">' . nl2br(htmlspecialchars($c['description'])) . '</div>';

		echo '<dl>';
		if($c['author'] !== '') {
			echo '<dt>作者</dt><dd>' . (cmHttpUrl($c['authorUrl']) ? '<a href="' . htmlspecialchars($c['authorUrl']) . '" target="_blank" rel="noopener">' . htmlspecialchars($c['author']) . '</a>' : htmlspecialchars($c['author'])) . '</dd>';
		}
		echo '<dt>動作確認</dt><dd>' . ($c['testedIanseo'] !== '' ? htmlspecialchars($c['testedIanseo']) : '記録なし') . '</dd>';
		if($c['requiresIanseo'] !== '') {
			echo '<dt>必要な ianseo</dt><dd>' . htmlspecialchars($c['requiresIanseo']) . ' 以降</dd>';
		}
		if($c['requiresPhp'] !== '') {
			echo '<dt>必要な PHP</dt><dd>' . htmlspecialchars($c['requiresPhp']) . ' 以降</dd>';
		}
		if($c['updated'] !== '') {
			echo '<dt>更新日</dt><dd>' . htmlspecialchars($c['updated']) . '</dd>';
		}
		if($c['size']) {
			echo '<dt>ファイルサイズ</dt><dd>' . htmlspecialchars($c['size'] >= 1048576 ? round($c['size'] / 1048576, 1) . 'MB' : ceil($c['size'] / 1024) . 'KB') . '</dd>';
		}
		if($c['license'] !== '') {
			echo '<dt>ライセンス</dt><dd>' . htmlspecialchars($c['license']) . '</dd>';
		}
		echo '</dl>';
		echo '<div>' . cmCompatBadge($Compat) . '</div>';

		if($c['changelog']) {
			echo '<details><summary>変更履歴</summary><ul class="cmLog">';
			foreach($c['changelog'] as $l) {
				echo '<li><b>' . htmlspecialchars($l['version']) . '</b>' . ($l['date'] !== '' ? ' (' . htmlspecialchars($l['date']) . ')' : '') . "\n" . htmlspecialchars($l['notes']) . '</li>';
			}
			echo '</ul></details>';
		}

		echo '<div class="cmActions">';
		$Warn = ($Compat['tested'] == 'no' ? "\n注意: " . $Compat['note'] : '');
		$Installed = $m ? ($m['version'] !== '' ? $m['version'] : '版なし') : '';
		if($m and !cmNewer($Catalog, $m)) {
			// 配布サイトの版より新しくなければ、入れ直しはさせない
			echo '<input type="button" value="' . htmlspecialchars('インストール済み(' . $Installed . ')') . '" disabled>';
		} elseif($Compat['problems']) {
			echo '<span class="cmNote">この ianseo には入れられません</span>';
		} elseif(!$m) {
			echo cmButton('install', 'インストール', ['id' => $c['id']], $Warn !== '' ? '「' . $c['name'] . '」をインストールします。' . $Warn . "\nよろしいですか？" : '');
		} else {
			echo cmButton('install', '更新(' . $Installed . '→' . $c['version'] . ')', ['id' => $c['id']], '「' . $c['name'] . '」を ' . $Installed . ' から ' . $c['version'] . ' に更新します。' . $Warn . "\nよろしいですか？");
		}
		if(cmHttpUrl($c['homepage'])) {
			echo '<a class="cmInline" href="' . htmlspecialchars($c['homepage']) . '" target="_blank" rel="noopener">配布ページ</a>';
		}
		echo '</div>';
		echo '</div>';
	}
	echo '</div>';
	if(!$Catalog['modules']) {
		echo '<p class="cmNote">配布中のパッケージはありません。</p>';
	}
	echo '<script>
		function cmFilter(q) {
			q = q.toLowerCase().trim();
			document.querySelectorAll(".cmCard").forEach(function(c) {
				c.style.display = (q === "" || c.dataset.search.indexOf(q) >= 0) ? "" : "none";
			});
		}
	</script>';
} elseif($CatalogUrl === '') {
	echo '<p class="cmNote">カタログの URL を入れると、配布サイトのパッケージが一覧になります。</p>';
}

// zip から
echo '<br><table class="Tabella cmTable">';
echo '<tr><th colspan="2" class="Main">zip から追加・更新</th></tr>';
echo '<tr><th class="SubTitle">zip をアップロード</th><td class="Left">'
	. '<form method="post" enctype="multipart/form-data" class="cmInline">'
	. '<input type="hidden" name="token" value="' . htmlspecialchars(cmToken()) . '">'
	. '<input type="hidden" name="act" value="upload">'
	. '<input type="file" name="zip" accept=".zip,application/zip" required> '
	. '<input type="submit" value="インストール">'
	. '</form>'
	. '<div class="cmNote">配布ページからダウンロードした zip を選んでください。アップロードできるのは ' . htmlspecialchars(cmUploadLimit()) . ' までです。</div>'
	. '</td></tr>';
echo '</table>';

require_once('Common/Templates/tail.php');
