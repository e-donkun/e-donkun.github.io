<?php
/*
スマホモード: スコアカード修正
本体の Qualification/WriteScoreCard.php（素点を編集（スコアカードビュー））に当たる画面。
- 的の選手一覧・スコアカードの取得は本体の画面と同じ条件
- 1 本ごとの保存は本体の Qualification/UpdateArrow.php を呼ぶ（本体の画面と同じ処理。順位・チームも本体と同じく再計算される）
- 入力できる点数は本体の GetGoodLettersFromDist() / GetGoodLettersFromTgtId()（的の種類ごとの点数）から作る
- 順位の再計算・チームの再構築は本体の Qualification/CalcRank.php・MakeTeams.php・MakeTeamsAbs.php を呼ぶ

変更履歴:
2026/09/26 初版
*/
require_once(__DIR__ . '/Lib.php');
spCheckPage('Scorecard');

require_once('Common/Lib/ArrTargets.inc.php');
require_once('Common/Fun_FormatText.inc.php');
require_once('Common/Fun_Various.inc.php');
require_once('Common/Fun_Sessions.inc.php');

$q = safe_r_sql("SELECT ToNumSession, ToNumDist, ToGolds, ToXNine FROM Tournament WHERE ToId=" . intval($_SESSION['TourId']));
$Tour = safe_fetch($q);

$Sessions = [];
foreach(GetSessions('Q') as $s) {
	$Sessions[intval($s->SesOrder)] = $s->Descr;
}

$Ses = intval($_REQUEST['s'] ?? 0);
$Dist = intval($_REQUEST['d'] ?? 0);
$Tgt = intval($_REQUEST['t'] ?? 0);
$ReqEnId = intval($_REQUEST['a'] ?? 0);
$EnId = 0;
if(!isset($Sessions[$Ses])) {
	$Ses = 0;
}
if($Dist < 1 or $Dist > $Tour->ToNumDist) {
	$Dist = 0;
}

// 的の選手（本体の画面で的番号だけを入れたときと同じ条件）
$Archers = [];
if($Ses and $Dist and $Tgt) {
	$atSql = createAvailableTargetSQL($Ses, $_SESSION['TourId']);
	$Rs = safe_r_sql("SELECT EnId, EnCode, EnName, EnFirstName, EnDivision, EnClass, CoCode, CoName, EnStatus,
			QuTarget, QuLetter, CONCAT(QuTarget, QuLetter) AS Target, QuScore, QuD{$Dist}Score AS SelScore
		FROM Entries
		INNER JOIN Qualifications ON EnId=QuId
		INNER JOIN Countries ON EnCountry=CoId
		RIGHT JOIN ($atSql) at ON QuSession=FullTgtSession AND QuTarget=FullTgtTarget AND QuLetter=FullTgtLetter
		INNER JOIN Tournament ON EnTournament=ToId
		WHERE EnAthlete=1 AND QuSession={$Ses} AND ToId=" . intval($_SESSION['TourId']) . " AND QuTarget={$Tgt}
		ORDER BY QuLetter");
	while($r = safe_fetch($Rs)) {
		$Archers[intval($r->EnId)] = $r;
	}
	// 選んだ選手がこの的にいなければ、最初の選手を表示する
	$EnId = isset($Archers[$ReqEnId]) ? $ReqEnId : ($Archers ? array_key_first($Archers) : 0);
}

// スコアカード（本体の画面で的番号と記号を入れたときと同じ内容）
$Card = null;
if($EnId) {
	$tmpSel = '';
	for($i = 1; $i <= $Tour->ToNumDist; $i++) {
		$tmpSel .= "QuD{$i}Score, QuD{$i}Gold, QuD{$i}Xnine, ";
	}
	$Rs = safe_r_sql("SELECT EnId, EnCode, EnName, EnFirstName, EnDivision, EnClass, CoCode, CoName,
			QuSession, QuTarget, CONCAT(QuTarget, QuLetter) AS Target,
			QuD{$Dist}Score AS SelScore, QuD{$Dist}Gold AS SelGold, QuD{$Dist}Xnine AS SelXNine,
			$tmpSel
			QuScore, QuGold, QuXnine, QuD{$Dist}ArrowString AS ArrowString,
			IF(TfGolds!='', TfGolds, ToGolds) AS GoldLabel, IF(TfXNine!='', TfXNine, ToXNine) AS XNineLabel,
			coalesce(DiEnds, ToNumEnds) as NumEnds, coalesce(DiArrows, ToMaxDistScore/ToGolds) as NumArrows, coalesce(DiScoringEnds, 0) as ScoringEnds,
			coalesce(DiScoringOffset, 0) as ScoringOffset, ToCategory in (4,8) as IsField3D
		FROM Entries
		INNER JOIN Qualifications ON EnId=QuId
		INNER JOIN Countries ON EnCountry=CoId AND EnTournament=CoTournament
		INNER JOIN Tournament ON EnTournament=ToId
		LEFT JOIN DistanceInformation ON DiTournament=EnTournament AND DiSession=QuSession AND DiDistance={$Dist} AND DiType='Q'
		LEFT JOIN TargetFaces ON TfTournament=EnTournament AND EnTargetFace=TfId
		WHERE EnId={$EnId} AND EnTournament=" . intval($_SESSION['TourId']));
	if($r = safe_fetch($Rs)) {
		$NumEnds = intval($r->NumEnds);
		$NumArrows = intval($r->NumArrows);
		$MaxArrows = $NumEnds * $NumArrows;
		$ArrowString = str_pad($r->ArrowString ?? '', $MaxArrows, ' ', STR_PAD_RIGHT);

		// フィールド・3D は本体と同じく、担当する的のエンドから並べる
		$OffSet = 0;
		$ScoringEnds = $NumEnds;
		if($r->IsField3D and $NumEnds) {
			$OffSet = ((intval($r->QuTarget) - 1) % $NumEnds + intval($r->ScoringOffset)) % $NumEnds;
			$ScoringEnds = intval($r->ScoringEnds) ?: $NumEnds;
		}

		$Ends = [];
		$Running = 0;
		$EndTotals = [];
		for($e = 0; $e < $NumEnds; $e++) {
			$Arr = [];
			$Tot = 0;
			for($j = 0; $j < $NumArrows; $j++) {
				$Idx = $e * $NumArrows + $j;
				$Arr[] = DecodeFromLetter(trim($ArrowString[$Idx]));
				$Tot += ValutaArrowString($ArrowString[$Idx]);
			}
			$Running += $Tot;
			$EndTotals[$e] = ['arrows' => $Arr, 'tot' => $Tot, 'run' => $Running];
		}
		for($i = 0; $i < $NumEnds; $i++) {
			$CurEnd = ($i + $OffSet) % $NumEnds;
			$Ends[] = ['end' => $CurEnd, 'outOfRange' => $i >= $ScoringEnds] + $EndTotals[$CurEnd];
		}

		// 入力できる点数（本体の UpdateArrow.php が受け付ける値と同じ）
		$TgtId = 0;
		GetGoodLettersFromDist($EnId, $Dist, $TgtId);
		$Keys = [];
		foreach(GetGoodLettersFromTgtId($TgtId, -1) as $l) {
			$p = $GLOBALS['LetterPoint'][$l]['P'] ?? '';
			if($p !== '' and !in_array($p, $Keys)) {
				$Keys[] = $p;
			}
		}
		if(!$Keys) {
			$Keys = ['X', '10', '9', '8', '7', '6', '5', '4', '3', '2', '1', 'M'];
		}

		$Dists = [];
		for($i = 1; $i <= $Tour->ToNumDist; $i++) {
			$Dists[] = ['score' => $r->{"QuD{$i}Score"}, 'gold' => $r->{"QuD{$i}Gold"}, 'xnine' => $r->{"QuD{$i}Xnine"}];
		}

		$Card = [
			'id' => intval($r->EnId),
			'name' => trim($r->EnFirstName . ' ' . $r->EnName),
			'code' => $r->EnCode,
			'country' => trim($r->CoCode . ' ' . $r->CoName),
			'divcl' => $r->EnDivision . ' ' . $r->EnClass,
			'target' => $r->Target,
			'dist' => $Dist,
			'numArrows' => $NumArrows,
			'ends' => $Ends,
			'keys' => $Keys,
			'goldLabel' => $r->GoldLabel,
			'xnineLabel' => $r->XNineLabel,
			'cur' => ['score' => $r->SelScore, 'gold' => $r->SelGold, 'xnine' => $r->SelXNine],
			'tot' => ['score' => $r->QuScore, 'gold' => $r->QuGold, 'xnine' => $r->QuXnine],
			'dists' => $Dists,
		];
	}
}

spHead('Scorecard', ['SpCard' => $Card]);

function spScoreLink($Ses, $Dist, $Tgt, $EnId=0) {
	return '?s=' . $Ses . '&d=' . $Dist . '&t=' . $Tgt . ($EnId ? '&a=' . $EnId : '');
}
?>
<form class="sp-card" method="get" action="" id="SpSelForm">
	<div class="sp-row">
		<label class="sp-field"><span>セッション</span>
			<select name="s">
				<option value="0">--</option>
<?php foreach($Sessions as $k => $v) { ?>
				<option value="<?php echo $k; ?>"<?php echo $k == $Ses ? ' selected' : ''; ?>><?php echo spH($v); ?></option>
<?php } ?>
			</select>
		</label>
		<label class="sp-field"><span>距離</span>
			<select name="d">
				<option value="0">--</option>
<?php for($i = 1; $i <= $Tour->ToNumDist; $i++) { ?>
				<option value="<?php echo $i; ?>"<?php echo $i == $Dist ? ' selected' : ''; ?>><?php echo $i; ?></option>
<?php } ?>
			</select>
		</label>
	</div>
	<label class="sp-field"><span>的番号（数字だけ）</span>
		<div class="sp-row">
<?php if($Ses and $Dist and $Tgt > 1) { ?>
			<a class="sp-btn sub" style="flex:none" href="<?php echo spScoreLink($Ses, $Dist, $Tgt - 1); ?>">◀</a>
<?php } ?>
			<input type="number" name="t" inputmode="numeric" min="1" value="<?php echo $Tgt ?: ''; ?>" style="text-align:center">
<?php if($Ses and $Dist and $Tgt) { ?>
			<a class="sp-btn sub" style="flex:none" href="<?php echo spScoreLink($Ses, $Dist, $Tgt + 1); ?>">▶</a>
<?php } ?>
			<button class="sp-btn" type="submit" style="flex:none">表示</button>
		</div>
	</label>
</form>

<?php if($Ses and $Dist and $Tgt) { ?>
	<?php if(!$Archers) { ?>
<div class="sp-empty">この的に選手がいません</div>
	<?php } else { ?>
<div class="sp-archer-tabs" style="margin-top:12px">
		<?php foreach($Archers as $a) { ?>
	<a class="sp-chip<?php echo $a->EnId == $EnId ? ' active' : ''; ?>" style="text-align:center" href="<?php echo spScoreLink($Ses, $Dist, $Tgt, $a->EnId); ?>"><b><?php echo spH($a->QuLetter); ?></b><br><small><?php echo spH($a->EnFirstName); ?></small></a>
		<?php } ?>
</div>
	<?php } ?>
<?php } else { ?>
<p class="sp-note">セッション・距離・的番号を選んで「表示」を押してください。</p>
<?php } ?>

<div id="SpCardArea"></div>

<details class="sp-card" style="margin-top:12px">
	<summary>順位の計算・チーム</summary>
	<label class="sp-switch" style="margin:12px 0"><input type="checkbox" id="SpNoRecalc"> 入力中は順位計算を止める（止めるのをやめたときにまとめて計算）</label>
	<div class="sp-list">
		<button type="button" class="sp-btn sub block" data-act="calcDist"><?php echo spH(get_text('CalcRankDist', 'Tournament')); ?></button>
		<button type="button" class="sp-btn sub block" data-act="calc"><?php echo spH(get_text('CalcRank', 'Tournament')); ?></button>
		<button type="button" class="sp-btn sub block" data-act="teams"><?php echo spH(get_text('MakeTeams', 'Tournament')); ?></button>
	</div>
</details>

<script>
const SpSc = {sel: -1, cells: []};

function spScRender() {
	const c = SpCard;
	const area = document.getElementById('SpCardArea');
	if (!c) return;
	const cols = (c.numArrows > 3 && c.numArrows % 3 == 0) ? 3 : Math.min(c.numArrows, 6);
	let html = '<div class="sp-card" style="margin-top:4px">'
		+ '<div class="sp-card-head"><span class="sp-badge">' + spEsc(c.target) + '</span><div class="sp-card-main">'
		+ '<div class="sp-name">' + spEsc(c.name) + '</div>'
		+ '<div class="sp-sub">' + spEsc([c.code, c.country, c.divcl].filter(x => x).join(' / ')) + '</div>'
		+ '</div></div>'
		+ '<div class="sp-totals">'
		+ '<div><small>' + c.dist + '距離目</small><b id="SpCur">' + spEsc(c.cur.score) + '</b></div>'
		+ '<div><small>' + spEsc(c.goldLabel) + '</small><b id="SpCurG">' + spEsc(c.cur.gold) + '</b></div>'
		+ '<div><small>' + spEsc(c.xnineLabel) + '</small><b id="SpCurX">' + spEsc(c.cur.xnine) + '</b></div>'
		+ '<div><small>総合計</small><b id="SpTot">' + spEsc(c.tot.score) + '</b></div>'
		+ '</div>'
		+ '<div class="sp-sub" style="white-space:normal">' + c.dists.map((d, i) => (i + 1) + '距離目: <span id="SpD' + (i + 1) + '">' + spEsc(d.score) + '</span>').join('　') + '</div>'
		+ '</div>'
		+ '<div class="sp-ends" style="margin-top:8px">';
	c.ends.forEach(e => {
		html += '<div class="sp-end' + (e.outOfRange ? ' out-of-range' : '') + '">'
			+ '<div class="sp-end-no">' + (e.end + 1) + '</div>'
			+ '<div class="sp-arrows" style="--cols:' + cols + '">';
		e.arrows.forEach((a, j) => {
			const idx = e.end * c.numArrows + j;
			html += '<div class="sp-arrow" data-idx="' + idx + '">' + spEsc(a) + '</div>';
		});
		html += '</div><div class="sp-end-tot"><b id="SpEnd' + e.end + '">' + e.tot + '</b><span id="SpRun' + e.end + '">' + e.run + '</span></div></div>';
	});
	html += '</div>';
	area.innerHTML = html;

	// 表示順（フィールド・3D ではエンドの並びが変わる）に入力欄を並べる
	SpSc.cells = [...area.querySelectorAll('.sp-arrow')];

	const pad = document.createElement('div');
	pad.className = 'sp-keypad';
	pad.style.setProperty('--kcols', Math.min(6, Math.max(4, Math.ceil((c.keys.length + 3) / 2))));
	pad.innerHTML = c.keys.map(k => '<button type="button" data-key="' + spEsc(k) + '">' + spEsc(k) + '</button>').join('')
		+ '<button type="button" class="fn" data-fn="clear">消す</button>'
		+ '<button type="button" class="fn" data-fn="prev">◀ 前</button>'
		+ '<button type="button" class="fn" data-fn="next">次 ▶</button>';
	document.body.appendChild(pad);
	document.body.classList.add('sp-has-keypad');

	area.addEventListener('click', ev => {
		const cell = ev.target.closest('.sp-arrow');
		if (cell) spScSelect(SpSc.cells.indexOf(cell));
	});
	pad.addEventListener('click', ev => {
		const b = ev.target.closest('button');
		if (!b) return;
		if (b.dataset.key !== undefined) spScWrite(b.dataset.key);
		else if (b.dataset.fn === 'clear') spScWrite('');
		else if (b.dataset.fn === 'prev') spScSelect(SpSc.sel - 1);
		else if (b.dataset.fn === 'next') spScSelect(SpSc.sel + 1);
	});

	// 最初の未入力の矢を選ぶ
	const first = SpSc.cells.findIndex(x => x.textContent.trim() === '');
	spScSelect(first >= 0 ? first : 0, true);
}

function spScSelect(i, noScroll) {
	if (i < 0 || i >= SpSc.cells.length) return;
	if (SpSc.sel >= 0 && SpSc.cells[SpSc.sel]) SpSc.cells[SpSc.sel].classList.remove('sel');
	SpSc.sel = i;
	const cell = SpSc.cells[i];
	cell.classList.add('sel');
	if (!noScroll) {
		const r = cell.getBoundingClientRect();
		const pad = document.querySelector('.sp-keypad');
		const limit = pad ? pad.getBoundingClientRect().top : window.innerHeight;
		if (r.bottom > limit - 8 || r.top < 70) cell.scrollIntoView({block: 'center', behavior: 'smooth'});
	}
}

/* 本体の UpdateArrow.php で 1 本を保存する */
async function spScWrite(point) {
	const cell = SpSc.cells[SpSc.sel];
	if (!cell) return;
	const idx = cell.getAttribute('data-idx');
	const pos = SpSc.sel;
	cell.classList.add('sp-saving');
	cell.classList.remove('sp-error');
	try {
		const d = await spPostJson('Qualification/UpdateArrow.php', {
			Dist: SpCard.dist,
			Index: idx,
			Id: SpCard.id,
			NoRecalc: document.getElementById('SpNoRecalc').checked ? 1 : 0,
			Point: point,
		});
		if (d.error && d.error != 0) {
			cell.classList.add('sp-error');
			spToast('保存できませんでした（入力できない値、またはロック中）', true);
		} else {
			cell.textContent = d.arrowsymbol;
			document.getElementById('SpCur').textContent = d.curscore;
			document.getElementById('SpCurG').textContent = d.curgold;
			document.getElementById('SpCurX').textContent = d.curxnine;
			document.getElementById('SpTot').textContent = d.score;
			const dd = document.getElementById('SpD' + SpCard.dist);
			if (dd) dd.textContent = d.curscore;
			(d.endscore || []).forEach((v, e) => { const x = document.getElementById('SpEnd' + e); if (x) x.textContent = v; });
			(d.runscore || []).forEach((v, e) => { const x = document.getElementById('SpRun' + e); if (x) x.textContent = v; });
			if (SpSc.sel === pos && point !== '') spScSelect(pos + 1);
		}
	} catch (e) {
		cell.classList.add('sp-error');
		spToast('保存できませんでした: ' + e.message, true);
	}
	cell.classList.remove('sp-saving');
}

/* 本体の CalcRank.php / MakeTeams.php / MakeTeamsAbs.php を呼ぶ */
async function spScAct(act) {
	const dist = SpCard ? SpCard.dist : parseInt(document.querySelector('#SpSelForm [name=d]').value, 10);
	try {
		if (act === 'calcDist') {
			if (!dist) { spToast('距離を選んでください', true); return; }
			const r = await spGetJson('Qualification/CalcRank.php', {Dist: dist});
			spToast(r.msg, r.error != 0);
		} else if (act === 'calc') {
			const r = await spGetJson('Qualification/CalcRank.php');
			spToast(r.msg, r.error != 0);
		} else if (act === 'teams') {
			const r = await spGetJson('Qualification/MakeTeams.php');
			if (r.error != 0) { spToast(r.msg, true); return; }
			const r2 = await spGetJson('Qualification/MakeTeamsAbs.php');
			spToast(r.msg + ' / ' + r2.msg, r2.error != 0);
		}
	} catch (e) {
		spToast('処理できませんでした: ' + e.message, true);
	}
}

document.addEventListener('DOMContentLoaded', () => {
	// セッションと距離は前回の選択を初期値にする
	const form = document.getElementById('SpSelForm');
	['s', 'd'].forEach(n => {
		const sel = form.querySelector('[name=' + n + ']');
		if (sel.value === '0' && spStore('sc_' + n)) sel.value = spStore('sc_' + n);
		if (sel.value === '') sel.value = '0';
	});
	form.addEventListener('submit', () => {
		['s', 'd'].forEach(n => spStore('sc_' + n, form.querySelector('[name=' + n + ']').value));
	});
	const chk = document.getElementById('SpNoRecalc');
	chk.checked = spStore('sc_norecalc') === '1';
	chk.addEventListener('change', async () => {
		spStore('sc_norecalc', chk.checked ? '1' : '0');
		if (!chk.checked) {
			// 本体の「後で更新」をやめたときと同じく、まとめて計算する
			spToast('順位とチームを計算しています…');
			await spScAct('calcDist');
			await spScAct('calc');
			await spScAct('teams');
		}
	});
	document.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', () => spScAct(b.dataset.act)));
	spScRender();
});
</script>
<?php
spTail('Scorecard');
